//package distribution
//
//import java.sql.DriverManager
//
//import util.MintGlobalProperties
//import etljobs.distribution.{EtlJobDistributionRevenue, EtlJobDistributionSubscription}
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, SessionManager}
//import org.apache.spark.sql.functions.{col, from_unixtime, unix_timestamp}
//import org.apache.spark.sql.{Dataset, Encoders, Row}
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.distribution.DistributionRevenue.DistributionRevenueOracle
//import schema.distribution.DistributionSubscription.DistributionSubOracle
//
//class EtlDistSubscriptionSuite extends FlatSpec with Matchers {
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
////  val preparedStatement1 = connection.prepareStatement("CREATE TABLE SUBSCRIBER_NO_UPLOAD_BI ( \"CUSTOMER CODE\" VARCHAR(50), \"BOUQUET/ALACARTE\" VARCHAR(50), \"BOUQUET/ALACARTE NAME\" VARCHAR(50), \"COUNT ON 7TH\" VARCHAR(50), \"COUNT ON 14TH\" VARCHAR(50), \"COUNT ON 21ST\" VARCHAR(50), \"COUNT ON 28TH\" VARCHAR(50), \"TYPE OF BILLING\" VARCHAR(50), \"MONTH YEAR\" VARCHAR(50), vertical VARCHAR(50),state VARCHAR(50),is_pushed_to_billing VARCHAR(50),\"DPO NAME\" VARCHAR(50),date VARCHAR(50));")
////  preparedStatement1.executeUpdate()
////  val preparedStatement2 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI ( \"CUSTOMER CODE\", \"BOUQUET/ALACARTE\", \"BOUQUET/ALACARTE NAME\", \"COUNT ON 7TH\", \"COUNT ON 14TH\" , \"COUNT ON 21ST\", \"COUNT ON 28TH\", \"TYPE OF BILLING\" , \"MONTH YEAR\", vertical,state,is_pushed_to_billing,\"DPO NAME\") VALUES (" +  "'120865'" + "," + "'BOUQUET'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'112'" + "," + "'626'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
////  val preparedStatement3 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI ( \"CUSTOMER CODE\", \"BOUQUET/ALACARTE\", \"BOUQUET/ALACARTE NAME\", \"COUNT ON 7TH\", \"COUNT ON 14TH\" , \"COUNT ON 21ST\", \"COUNT ON 28TH\", \"TYPE OF BILLING\" , \"MONTH YEAR\", vertical,state,is_pushed_to_billing,\"DPO NAME\") VALUES (" +  "'120865'" + "," + "'BOUQUET'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'112'" + "," + "'626'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
////  val preparedStatement4 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI ( \"CUSTOMER CODE\", \"BOUQUET/ALACARTE\", \"BOUQUET/ALACARTE NAME\", \"COUNT ON 7TH\", \"COUNT ON 14TH\" , \"COUNT ON 21ST\", \"COUNT ON 28TH\", \"TYPE OF BILLING\" , \"MONTH YEAR\", vertical,state,is_pushed_to_billing,\"DPO NAME\") VALUES (" +  "'120865'" + "," + "'BOUQUET'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'112'" + "," + "'626'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
////  val preparedStatement5 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI ( \"CUSTOMER CODE\", \"BOUQUET/ALACARTE\", \"BOUQUET/ALACARTE NAME\", \"COUNT ON 7TH\", \"COUNT ON 14TH\" , \"COUNT ON 21ST\", \"COUNT ON 28TH\", \"TYPE OF BILLING\" , \"MONTH YEAR\", vertical,state,is_pushed_to_billing,\"DPO NAME\") VALUES (" +  "'120865'" + "," + "'BOUQUET'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'112'" + "," + "'626'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
//
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE SUBSCRIBER_NO_UPLOAD_BI (   customer_code VARCHAR(50), bouquet_alacarte VARCHAR(50), bouquet_alacarte_name VARCHAR(50), count_on_seventh_week VARCHAR(50), count_on_fourteenth_WEEK VARCHAR(50), count_on_twentifirst_WEEK VARCHAR(50), count_on_twentieight_WEEK VARCHAR(50), type_of_billing VARCHAR(50), month_year VARCHAR(50), vertical VARCHAR(50),state VARCHAR(50),is_pushed_to_billing VARCHAR(50),dpo_name VARCHAR(50),date VARCHAR(50));")
//  preparedStatement1.executeUpdate()
//  val preparedStatement2 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI (  customer_code , bouquet_alacarte , bouquet_alacarte_name , count_on_seventh_week , count_on_fourteenth_WEEK , count_on_twentifirst_WEEK , count_on_twentieight_WEEK , type_of_billing, month_year , vertical ,state ,is_pushed_to_billing ,dpo_name ,date ) VALUES (" +  "'120865'" + "," + "'BOUQUET'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'112'" + "," + "'626'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement3 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI (  customer_code , bouquet_alacarte , bouquet_alacarte_name , count_on_seventh_week , count_on_fourteenth_WEEK , count_on_twentifirst_WEEK , count_on_twentieight_WEEK , type_of_billing, month_year , vertical ,state ,is_pushed_to_billing ,dpo_name ,date ) VALUES (" +  "'110864'" + "," + "'BOUQUET'" + ","+ "'STAR MOVIES'" + "," + "'12'" + "," + "'226'" + "," + "'6226'" + "," + "'6396'" + ","+ "'6396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement4 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI (  customer_code , bouquet_alacarte , bouquet_alacarte_name , count_on_seventh_week , count_on_fourteenth_WEEK , count_on_twentifirst_WEEK , count_on_twentieight_WEEK , type_of_billing, month_year , vertical ,state ,is_pushed_to_billing ,dpo_name ,date ) VALUES (" +  "'100856'" + "," + "'BOUQUET'" + ","+ "'TAMIL HD VALUE'" + "," + "'11'" + "," + "'622'" + "," + "'6226'" + "," + "'636'" + ","+ "'396'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement5 = connection.prepareStatement("insert into SUBSCRIBER_NO_UPLOAD_BI (  customer_code , bouquet_alacarte , bouquet_alacarte_name , count_on_seventh_week , count_on_fourteenth_WEEK , count_on_twentifirst_WEEK , count_on_twentieight_WEEK , type_of_billing, month_year , vertical ,state ,is_pushed_to_billing ,dpo_name ,date ) VALUES (" +  "'120788'" + "," + "'BOUQUET'" + ","+ "'SVP LITE HINDI'" + "," + "'112'" + "," + "'226'" + "," + "'6226'" + "," + "'696'" + ","+ "'696'"  +  "," +  "'Nov-2019'" + "," + "'Independent'" + "," + "'Karnataka'" + "," + "'YES'" +  "," + "'KARNATAKA GRAMEENA CABLE TV COMMUNICATION'"  + "," + "'2019-04-01'" + ")"  )
//
//  preparedStatement2.executeUpdate()
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//
//  // STEP 1: Initialize job properties and create BQ tables required for jobs
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties = Map(
//    "job_name" -> "EtlJobDistributionSubscription" ,
//    "job_input_path" -> "SUBSCRIBER_NO_UPLOAD_BI",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/subscription",
//    "output_dataset" -> "test",
//    "output_table_name" -> "dist_subscription",
//    "jdbc_url" -> s"${container.getJdbcUrl}" ,
//    "jdbc_credentials" -> "",
//    "jdbc_host_name" -> "",
//    "user" -> s"${container.getUsername}",
//    "password" -> s"${container.getPassword}",
//    "driver" -> "org.postgresql.Driver",
//    "debug" -> "false",
//    "test"->"true"
//  )
//  // STEP 2: Execute JOB
//  val etljob = new EtlJobDistributionSubscription(job_properties, global_properties)
//
//
//  val mapping  = Encoders.product[DistributionSubOracle]
//  val sm = new SessionManager(global_properties) {}
//
//  // STEP 3: Run tests
//  val raw : Dataset[DistributionSubOracle] = ReadApi.LoadDS[DistributionSubOracle](
//    Seq(job_properties("job_input_path")),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val raw_format = raw.withColumn("date_int",from_unixtime(unix_timestamp(col("date"),"yyyy-MM-dd"),"yyyyMMdd")).as[DistributionSubOracle](mapping)
//  val transfomed = etljob.DistributionSubTransform(sm.spark,job_properties)(raw_format)
//
//  val raw_format_count:Long = raw_format.count()
//  val transfomed_count:Double = transfomed.count()
//
//  val Row(sum_count_on_seventh_week_raw:Double) = raw_format.selectExpr("""sum(count_on_seventh_week)""").first()
//  val Row(sum_count_on_seventh_week_transformed:Double) = transfomed.selectExpr("""sum(count_on_seventh_week)""").first()
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from SUBSCRIBER_NO_UPLOAD_BI;")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in dataframe and oracle table " in {
//    assert(raw_format_count==transfomed_count)
//  }
//
//  "Sum of monthly_average" should "be matching in  dataframe and oracle table " in {
//    assert("%.4f".format(sum_count_on_seventh_week_raw).toDouble=="%.4f".format(sum_count_on_seventh_week_transformed).toDouble)
//  }
//}