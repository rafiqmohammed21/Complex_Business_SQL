//package revenue
//
//import java.sql.DriverManager
//
//import com.google.cloud.bigquery.FieldValueList
//import util.MintGlobalProperties
//import etljobs.revenue.EtlJobFunnel
//import etljobs.bigquery.QueryApi
//import etljobs.spark.ReadApi
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.revenue.Funnel.{FunnelSchemaBQ, FunnelSchemaPostgre}
//import etljobs.utils.{CSV, GlobalProperties, JDBC, PARQUET, SessionManager}
//import org.apache.spark.sql.{Dataset, Row}
//
//
//
//class EtlJobFunnelSuite extends  FlatSpec with Matchers  {
//
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  println(container.getJdbcUrl + " " + container.getUsername + " " +  container.getPassword)
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl,container.getUsername,container.getPassword)
//
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE funnel_info (funnel_id BIGINT,channel_name VARCHAR, month DATE, created_at Timestamp,year_month VARCHAR, updated_at Timestamp, advertiser_group VARCHAR, missed_client BOOLEAN,campaign_budget INTEGER,share_in_campaign VARCHAR,creator_name VARCHAR, region VARCHAR,  impact_regular VARCHAR, projection_inr VARCHAR);")
//  preparedStatement1.executeUpdate()
//  //insert rows into created table
//  val preparedStatement2 = connection.prepareStatement("insert into funnel_info ( funnel_id ,channel_name , month , created_at ,year_month , updated_at , advertiser_group , missed_client ,campaign_budget ,share_in_campaign ,creator_name , region ,  impact_regular , projection_inr ) VALUES (" +  "304" + "," + "'Star Plus'" + "," + "'2019-08-01'" + "," + "'2019-07-25 08:10:28.637103'" + "," + "'201907'" + "," + "'2019-08-30 08:53:21.998011'" + "," + "'Bennett Coleman'" + "," + "'False'" + "," + "0.0" + "," + "0.0" + "," + "'Ankit Anand'" + "," + "'NORTH'" + "," + "'regular'" + "," + "0.0" + ")")
//  val preparedStatement3 = connection.prepareStatement("insert into funnel_info ( funnel_id ,channel_name , month , created_at ,year_month , updated_at , advertiser_group , missed_client ,campaign_budget ,share_in_campaign ,creator_name , region ,  impact_regular , projection_inr ) VALUES (" +  "305" + "," + "'Star Plus'" + "," + "'2019-08-01'" + "," + "'2019-07-25 08:10:28.637103'" + "," + "'201907'" + "," + "'2019-08-30 08:53:21.998011'" + "," + "'Bennett Coleman'" + "," + "'False'" + "," + "0.0" + "," + "0.0" + "," + "'Ankit Anand'" + "," + "'NORTH'" + "," + "'regular'" + "," + "0.0" + ")")
//  val preparedStatement4 = connection.prepareStatement("insert into funnel_info ( funnel_id ,channel_name , month , created_at ,year_month , updated_at , advertiser_group , missed_client ,campaign_budget ,share_in_campaign ,creator_name , region ,  impact_regular , projection_inr ) VALUES (" +  "306" + "," + "'Star Plus'" + "," + "'2019-08-01'" + "," + "'2019-07-25 08:10:28.637103'" + "," + "'201907'" + "," + "'2019-08-30 08:53:21.998011'" + "," + "'Bennett Coleman'" + "," + "'False'" + "," + "0.0" + "," + "0.0" + "," + "'Ankit Anand'" + "," + "'NORTH'" + "," + "'regular'" + "," + "0.0" + ")")
//  val preparedStatement5 = connection.prepareStatement("insert into funnel_info ( funnel_id ,channel_name , month , created_at ,year_month , updated_at , advertiser_group , missed_client ,campaign_budget ,share_in_campaign ,creator_name , region ,  impact_regular , projection_inr ) VALUES (" +  "307" + "," + "'Star Plus'" + "," + "'2019-08-01'" + "," + "'2019-07-25 08:10:28.637103'" + "," + "'201907'" + "," + "'2019-08-30 08:53:21.998011'" + "," + "'Bennett Coleman'" + "," + "'False'" + "," + "0.0" + "," + "0.0" + "," + "'Ankit Anand'" + "," + "'NORTH'" + "," + "'regular'" + "," + "0.0" + ")")
//
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//  preparedStatement2.executeUpdate()
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//  //Defining the test case variables
//
//  val job_properties = Map(
//      "job_name" -> "EtlJobFunnel",
//      "job_input_path" -> "funnel_info",
//      "job_output_path" -> f"${global_properties.gcs_output_bucket}/funnel_test",
//      //"job_output_path" -> s"$canonical_path/mint/src/test/resources/output/funnel",
//      "refresh_dates" -> "\'201907\'",
//      "jdbc_url" -> container.getJdbcUrl,
//      "user" -> container.getUsername,
//      "password" -> container.getPassword,
//      "output_dataset" -> "test",
//      "output_table_name" -> "funnel_test",
//      "driver" -> "org.postgresql.Driver"
//    )
//
//
//  val etljob = new EtlJobFunnel(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val query_alias  =
//        s""" (SELECT *
//                ,to_date(to_char(created_at, 'yyyyMM01'), 'yyyyMMdd') as date
//                ,to_char(created_at, 'yyyyMM01') as date_int
//         FROM   ${job_properties("job_input_path")} WHERE year_month in (${job_properties("refresh_dates")}))t""".stripMargin
//
//  val sm = new SessionManager(global_properties) {}
//
//  val raw : Dataset[FunnelSchemaPostgre] = ReadApi.LoadDS[FunnelSchemaPostgre](
//    Seq(query_alias),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val op  = etljob.revenueFunnelTransform(sm.spark, job_properties)(raw)
//  val count_records_transformed:Long  = op.count()
//
//  println("count_records_transformed : " + count_records_transformed)
//
//  //query the bq table and get the data loaded from previous steps
//  val query:String  =s""" select count(*) as count,
//                          sum(campaign_budget) campaign_budget
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//  val campaign_df_bq = result.head.get("campaign_budget")
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from funnel_info")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//
//}