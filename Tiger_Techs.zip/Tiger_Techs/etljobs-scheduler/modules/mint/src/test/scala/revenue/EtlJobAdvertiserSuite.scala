//package revenue
//
//import java.sql.DriverManager
//
//import com.google.cloud.bigquery.FieldValueList
//import util.MintGlobalProperties
//import etljobs.revenue.{EtlJobAdvertiser, EtlJobFunnel}
//import etljobs.bigquery.QueryApi
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, SessionManager}
//import org.apache.spark.sql.Dataset
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.revenue.Funnel.FunnelSchemaPostgre
//import .AdvertiserDetailInfoPostGre
//
//
//class EtlJobAdvertiserSuite extends  FlatSpec with Matchers  {
//
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
//
//  //prepare create table command
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE advertiser (   advertiser_name VARCHAR,onair_id INTEGER ,source VARCHAR ,region VARCHAR ,advertiser_group_name VARCHAR,segment VARCHAR,advertiser_category VARCHAR,agency_group_name VARCHAR,year_month TEXT);")
//  preparedStatement1.executeUpdate()
//
//  //insert rows into created table
//  val preparedStatement2 = connection.prepareStatement("insert into advertiser ( advertiser_name ,onair_id  ,source  ,region  ,advertiser_group_name ,segment ,advertiser_category ,agency_group_name ,year_month ) VALUES (" +  "'OPPO INDIA'" + "," + "7709" + "," + "'ONAIR'" + "," + "'WEST'" + "," + "'Star India Entertainment'" + "," + "'CA'" + "," + "'Network'"+ "," + "'Direct for Agency Comm'" + "," + "'201907'" + ")")
//  val preparedStatement3 = connection.prepareStatement("insert into advertiser ( advertiser_name ,onair_id  ,source  ,region  ,advertiser_group_name ,segment ,advertiser_category ,agency_group_name ,year_month ) VALUES (" +  "'DENA BANK(MU)'" + "," + "7701" + "," + "'ONAIR'" + "," + "'SOUTH'" + "," + "'Star India Entertainment'" + "," + "'CA'" + "," + "'Network'"+ "," + "'Direct for Agency Comm'" + "," + "'201907'" + ")")
//  val preparedStatement4 = connection.prepareStatement("insert into advertiser ( advertiser_name ,onair_id  ,source  ,region  ,advertiser_group_name ,segment ,advertiser_category ,agency_group_name ,year_month ) VALUES (" +  "'CONNAUGHT PLAZA RESTAURANT PVT LTD(MU)'" + "," + "019" + "," + "'ONAIR'" + "," + "'WEST'" + "," + "'Star India Entertainment'" + "," + "'CA'" + "," + "'Network'"+ "," + "'Direct for Agency Comm'" + "," + "'201907'" + ")")
//  val preparedStatement5 = connection.prepareStatement("insert into advertiser ( advertiser_name ,onair_id  ,source  ,region  ,advertiser_group_name ,segment ,advertiser_category ,agency_group_name ,year_month ) VALUES (" +  "'DELL COMPUTERS'" + "," + "66019" + "," + "'ONAIR'" + "," + "'WEST'" + "," + "'Star India Entertainment'" + "," + "'CA'" + "," + "'Network'"+ "," + "'Direct for Agency Comm'" + "," + "'201907'" + ")")
//
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//  preparedStatement2.executeUpdate()
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//  //Defining the test case variables
//
//  //Defining the test case variables
//  val job_properties = Map(
//    "job_name" -> "EtlJobAdvertiserDetails",
//    "job_input_path" -> "advertiser",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/advertiser_test",
//    "refresh_dates" -> "\'201907\'",
//    "jdbc_url" -> container.getJdbcUrl,
//    "user" -> container.getUsername,
//    "password" -> container.getPassword,
//    "output_dataset" -> "test",
//    "output_table_name" -> "advertiser_test",
//    "driver" -> "org.postgresql.Driver"
//  )
//
//  val etljob = new EtlJobAdvertiser(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val query_alias  = s""" (SELECT * FROM (SELECT *, to_date(concat(year_month,'01'),'yyyyMMdd') as date
//                ,concat(year_month,'01') as date_int
//                FROM  ${job_properties("job_input_path")} ) a WHERE year_month in (${job_properties("refresh_dates")}) ) t""".stripMargin
//
//  val sm = new SessionManager(global_properties) {}
//
//  val raw : Dataset[AdvertiserDetailInfoPostGre] = ReadApi.LoadDS[AdvertiserDetailInfoPostGre](
//    Seq(query_alias),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val op  = etljob.revenueAdvertiserTransform(sm.spark, job_properties)(raw)
//  val count_records_transformed:Long  = op.count()
//
//  println("count_records_transformed : " + count_records_transformed)
//
//  //query the bq table and get the data loaded from previous steps
//  val query:String  =s""" select count(*) as count
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from advertiser")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//
//}