//package spotRatings
//
//import com.google.cloud.bigquery.{BigQuery, FieldValueList}
//import etljobs.bigquery.QueryApi
//import etljobs.south_regional.spot_rating.EtlJobRegionalOrEntertainment
//import etljobs.spark.ReadApi
//import etljobs.utils.{CSV, JDBC, SessionManager}
//import org.apache.spark.sql.{Dataset, Row}
//import org.scalatest.{BeforeAndAfterAll, FlatSpec, Matchers}
//import schema.RegionalSpotRating.RegSpotRatings
//import .AdvertiserDetailInfoPostGre
//import util.MintGlobalProperties
//
//import scala.sys.process._
//
//
//class EtlRegBQTestSuite extends   FlatSpec with Matchers {
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties = Map(
//      "job_name" -> "EtlJobEntSpotRatings" ,
//      "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings/year=2019/week=31/raw" ,
//      "job_output_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings",
//      "output_dataset" -> "viewership",
//      "output_table_name" -> "reg_spot_ratings_test",
//      "debug" -> "false",
//      "test"->"true"
//  )
//
//  val sm = new SessionManager(global_properties) {}
//
//  val etljob = new EtlJobRegionalOrEntertainment(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val raw : Dataset[RegSpotRatings] = ReadApi.LoadDS[RegSpotRatings](
//    Seq(job_properties("job_input_path")+"/gec/*"),
//    CSV("|", true)
//  )(sm.spark)
//
//  val transformed  = etljob.enrichRegionalSpotRating(sm.spark,job_properties)(raw)
//
//  val count_records_transformed:Long  = transformed.count
//  val Row(sum_ratings_transformed:Double) = transformed.selectExpr("""sum(ratings)""").first()
//  val Row(sum_duration_transformed:Long) = transformed.selectExpr("""sum(duration)""").first()
//  val Row(sum_impressions_transformed:Double) = transformed.selectExpr("""sum(impressions)""").first()
//
//  val query:String  =s""" select count(*) as count,
//                          sum(ratings) sum_ratings,
//                          sum(duration) sum_duration,
//                          sum(impressions) sum_impressions
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//  val sum_ratings_df_bq:Double = result.head.get("sum_ratings").getDoubleValue
//  val sum_duration_df_bq:Long = result.head.get("sum_duration").getLongValue
//  val sum_impressions_df_bq:Double = result.head.get("sum_impressions").getDoubleValue
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//
//  "Sum of ratings" should "be matching in orc dataframe and BQ table " in {
//    assert("%.4f".format(sum_ratings_transformed).toDouble=="%.4f".format(sum_ratings_df_bq).toDouble)
//  }
//
//  "Sum of duration" should "be matching in orc dataframe and BQ table" in {
//    assert(sum_duration_transformed==sum_duration_df_bq)
//  }
//
//  "Sum of impressions" should "be matching in orc dataframe and BQ table" in {
//    assert("%.4f".format(sum_impressions_transformed).toDouble=="%.4f".format(sum_impressions_df_bq).toDouble)
//  }
//
//}
//
//
