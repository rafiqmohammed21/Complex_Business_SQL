//package revenue
//
//import java.sql.DriverManager
//
//import util.MintGlobalProperties
//import etljobs.revenue.EtlJobOnAirCurrency
//import etljobs.bigquery.QueryApi
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, ORC, SessionManager}
//import org.apache.spark.sql.{Dataset, Row}
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.revenue.Revenue.{AirRawBq, AirRawPostgre, OnairRawSchema, SprBQ}
//
//class EtlJobCurrencySuite extends FlatSpec with Matchers {
//
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  println(container.getJdbcUrl + " " + container.getUsername + " " +  container.getPassword)
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl,container.getUsername,container.getPassword)
//
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE currencies (onair_currency_id INTEGER,name VARCHAR, onair_currency_date DATE, conversion_rate DOUBLE PRECISION);")
//  preparedStatement1.executeUpdate()
//  //insert rows into created table
//  val preparedStatement2 = connection.prepareStatement("insert into currencies ( onair_currency_id,name , onair_currency_date , conversion_rate ) VALUES (" +  "775" + "," + "'Canadian Dollar'" + "," + "'2019-06-01'" + "," + "0.205635862"  + ")")
//  val preparedStatement3 = connection.prepareStatement("insert into currencies ( onair_currency_id,name , onair_currency_date , conversion_rate ) VALUES (" +  "777" + "," + "'American Dollar'" + "," + "'2019-06-01'" + "," + "0.205635862"  +   ")")
//  val preparedStatement4 = connection.prepareStatement("insert into currencies ( onair_currency_id,name , onair_currency_date , conversion_rate ) VALUES (" +  "778" + "," + "'South African Rand'" + "," + "'2019-06-01'" + "," + "0.205635862" + ")")
//  val preparedStatement5 = connection.prepareStatement("insert into currencies ( onair_currency_id,name , onair_currency_date , conversion_rate ) VALUES (" +  "779" + "," + "'UK Dollar'" + "," + "'2019-06-01'" + "," + "0.205635862" + ")")
//
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//  preparedStatement2.executeUpdate()
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//  //Defining the test case variables
////
//  val job_properties = Map(
//    "job_name" -> "EtlJobOnAirCurrency",
//    "job_input_path" -> "currencies",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/currencies_test",
//    "job_output_file_name" -> "currency.orc",
//    "jdbc_url" -> container.getJdbcUrl,
//    "user" -> container.getUsername,
//    "password" -> container.getPassword,
//    "output_dataset" -> "test",
//    "output_table_name" -> "currency_test",
//    "driver" -> "org.postgresql.Driver"
//  )
//
//
//
//  val etljob = new EtlJobOnAirCurrency(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val sm = new SessionManager(global_properties) {}
//
//  val query_alias  = s""" (SELECT onair_currency_id,name, onair_currency_date,conversion_rate FROM  ${job_properties("job_input_path")} ) t""".stripMargin
//
//  val raw: Dataset[AirRawPostgre] = ReadApi.LoadDS[AirRawPostgre](
//    Seq(etljob.query_alias),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//    )(sm.spark)
//
//  val op: Dataset[AirRawBq] = etljob.currency_transform(sm.spark, job_properties)(raw)
//  val Row(sum_conversion: Double, count_currency: Long) = op.selectExpr("sum(conversion)","count(*)").first()
//
//
//  val query:String = s""" SELECT count(*) as count,
//                                 sum(conversion) conversion,
//                          FROM $destination_dataset.$destination_table """.stripMargin
//
//  val result = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_bq:Long = result.head.get("count").getLongValue
//  val sum_conversion_bq:Double = result.head.get("conversion").getDoubleValue
//
//  "Record counts" should "be matching in transformed DF and BQ table " in {
//    assert(count_currency==count_records_bq)
//  }
//
//  "Sum of rc_price" should "be matching in transformed DF and BQ table " in {
//    assert(sum_conversion==sum_conversion_bq)
//  }
//}
