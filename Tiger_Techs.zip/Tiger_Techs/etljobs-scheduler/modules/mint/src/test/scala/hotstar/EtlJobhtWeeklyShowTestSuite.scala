//package hotstar
//
//import util.MintGlobalProperties
//import etljobs.revenue.EtlJobOnAirSPR
//import etljobs.bigquery.QueryApi
//import etljobs.hotstar.entertainment.EtlJobHotstarEntWeeklyChannelPerformance
//import etljobs.spark.ReadApi
//import etljobs.utils.{ORC, SessionManager}
//import org.apache.spark.sql.{Dataset, Row}
//import org.scalatest.{FlatSpec, Matchers}
//import schema.revenue.Revenue.{OnairRawSchema, SprBQ}
//
//class EtlJobhtWeeklyShowTestSuite extends FlatSpec with Matchers {
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties : Map[String,String] = Map(
//    "job_name" -> "EtlJobHotstarEntWeeklyChannelPerformance",
//    "job_input_path" -> "/Users/sonawanes/Documents/ht/*",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/transformed/hotstar_aggregated_metrics/entertainment/weekly_channel_performance",
//    "output_dataset" -> "test",
//    "output_table_name" -> "weekly_channel_performance",
//    "output_file_name" -> "weekly_channel_performance.orc"
//  )
//
//  val etljob = new EtlJobHotstarEntWeeklyChannelPerformance(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
////  val sm = new SessionManager(global_properties) {}
////
////  val raw: Dataset[OnairRawSchema] = ReadApi.LoadDS[OnairRawSchema](
////    Seq(job_properties("spr_history_load_input_path")),
////    ORC )(sm.spark)
////
////  etljob.where_clause.toString()
////  val op: Dataset[SprBQ] = etljob.spr_transform(sm.spark, job_properties,etljob.where_clause.toString())(raw)
////  val Row(rc_price: Double,spot_rate_in_inr: Double, count_spr: Long) = op.selectExpr("sum(rc_price)","sum(spot_rate_in_inr)","count(*)").first()
////
////  val destination_dataset = job_properties("output_dataset")
////  val destination_table = job_properties("output_table_name")
////
////  val query:String = s""" SELECT count(*) as count,
////                                 sum(rc_price) rc_price,
////                                 sum(spot_rate_in_inr) spot_rate_in_inr,
////                          FROM $destination_dataset.$destination_table """.stripMargin
////
////  val result = QueryApi.getDataFromBQ(sm.bq, query)
////  val count_records_bq:Long = result.head.get("count").getLongValue
////  val sum_rc_price_bq:Double = result.head.get("rc_price").getDoubleValue
////  val sum_spot_rate_in_inr_bq:Double = result.head.get("spot_rate_in_inr").getDoubleValue
////
////  "Record counts" should "be matching in transformed DF and BQ table " in {
////    assert(count_spr==count_records_bq)
////  }
////
////  "Sum of rc_price" should "be matching in transformed DF and BQ table " in {
////    assert(rc_price==sum_rc_price_bq)
////  }
////
////  "Sum of spot_rate_in_inr" should "be matching in transformed DF and BQ table " in {
////    assert(spot_rate_in_inr==sum_spot_rate_in_inr_bq)
////  }
//
//}
