//package revenue
//
//import java.sql.DriverManager
//
//import com.google.cloud.bigquery.FieldValueList
//import util.MintGlobalProperties
//import etljobs.revenue.EtlJobFunnel
//import etljobs.bigquery.QueryApi
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, SessionManager}
//import org.apache.spark.sql.Dataset
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.revenue.Funnel.FunnelSchemaPostgre
//import etljobs.revenue.EtlJobSalesUnit
//import schema.revenue.SalesUnitProduct.SalesUnitProductPostgre
//
//class EtlJobSalesUnitSuite extends  FlatSpec with Matchers  {
//
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
//
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE sales_unit (  on_air_sales_unit VARCHAR, product_name VARCHAR, product_id BIGINT, impact_regular VARCHAR, channel_skew_weight JSON, year_month VARCHAR);")
//  preparedStatement1.executeUpdate()
//
//  //insert rows into created table
//  val preparedStatement2 = connection.prepareStatement("insert into sales_unit (on_air_sales_unit, product_name, product_id, impact_regular, channel_skew_weight, year_month ) VALUES (" +  "'(THIS IS US)-(O)-(SAT)-(22:00-23:00)-(SWSD)'" + "," + "'(Chacha Chaudhary)-(O)-(Sun)-(08:00-08:30)-(SPHD)'" + "," + "13829" + "," + "'regular'" + "," + "'{\"weekpart\":{\"WD\":0,\"WE\":1},\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1}}'" + "," + "'201907'" + ")")
//  val preparedStatement3 = connection.prepareStatement("insert into sales_unit (on_air_sales_unit, product_name, product_id, impact_regular, channel_skew_weight, year_month ) VALUES (" +  "'(THIS IS US)-(O)-(SAT)-(22:00-23:00)-(SWSD)'" + "," + "'(Chacha Chaudhary)-(O)-(Sun)-(08:00-08:30)-(SPHD)'" + "," + "13829" + "," + "'regular'" + "," + "'{\"weekpart\":{\"WD\":0,\"WE\":1},\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1}}'" + "," + "'201907'" + ")")
//  val preparedStatement4 = connection.prepareStatement("insert into sales_unit (on_air_sales_unit, product_name, product_id, impact_regular, channel_skew_weight, year_month ) VALUES (" +  "'(THIS IS US)-(O)-(SAT)-(22:00-23:00)-(SWSD)'" + "," + "'(Chacha Chaudhary)-(O)-(Sun)-(08:00-08:30)-(SPHD)'" + "," + "13829" + "," + "'regular'" + "," + "'{\"weekpart\":{\"WD\":0,\"WE\":1},\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1}}'" + "," + "'201907'" + ")")
//  val preparedStatement5 = connection.prepareStatement("insert into sales_unit (on_air_sales_unit, product_name, product_id, impact_regular, channel_skew_weight, year_month ) VALUES (" +  "'(THIS IS US)-(O)-(SAT)-(22:00-23:00)-(SWSD)'" + "," + "'(Chacha Chaudhary)-(O)-(Sun)-(08:00-08:30)-(SPHD)'" + "," + "13829" + "," + "'regular'" + "," + "'{\"weekpart\":{\"WD\":0,\"WE\":1},\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1}}'" + "," + "'201907'" + ")")
//
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//  preparedStatement2.executeUpdate()
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//  //Defining the test case variables
//
//  val job_properties = Map(
//      "job_name" -> "EtlJobSalesUnit",
//      "job_input_path" -> "sales_unit",
//      "job_output_path" -> f"${global_properties.gcs_output_bucket}/sales_unit_test",
//      "refresh_dates" -> "\'201907\'",
//      "jdbc_url" -> container.getJdbcUrl,
//      "user" -> container.getUsername,
//      "password" -> container.getPassword,
//      "output_dataset" -> "test",
//      "output_table_name" -> "sales_unit_test",
//      "driver" -> "org.postgresql.Driver"
//    )
//
//
//  val etljob = new EtlJobSalesUnit(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val query_alias  = s""" (SELECT * FROM (SELECT *, to_date(concat(year_month,'01'),'yyyyMMdd') as date
//                ,concat(year_month,'01') as date_int
//                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) as channel_daypart_pt
//                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) as channel_daypart_npt
//                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) as channel_weekpart_wd
//                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float)  as channel_weekpart_we
//                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) as channel_dayparttwo_cpt
//                FROM  ${job_properties("job_input_path")}) a WHERE year_month in (${job_properties("refresh_dates")}) ) t""".stripMargin
//
//  val sm = new SessionManager(global_properties) {}
//
//  val raw : Dataset[SalesUnitProductPostgre] = ReadApi.LoadDS[SalesUnitProductPostgre](
//    Seq(query_alias),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val op  = etljob.revenueSalesUnitTransform(sm.spark, job_properties)(raw)
//  val count_records_transformed:Long  = op.count()
//
//  println("count_records_transformed : " + count_records_transformed)
//
//  //query the bq table and get the data loaded from previous steps
//  val query:String  =s""" select count(*) as count
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from sales_unit")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//}