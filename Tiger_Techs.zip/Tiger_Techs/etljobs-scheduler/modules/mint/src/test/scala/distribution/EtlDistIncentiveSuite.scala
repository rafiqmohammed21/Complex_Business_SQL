//package distribution
//
//import java.util.Properties
//
//import org.scalatest.{FlatSpec, Matchers}
//import org.apache.spark.sql.functions.{col, from_unixtime, unix_timestamp}
//import org.apache.spark.sql.{Encoders, Row}
//import java.sql.DriverManager
//
//import org.apache.spark.sql.{Dataset, Row}
//import util.MintGlobalProperties
//import etljobs.distribution.EtlJobDistributionIncentive
//import etljobs.spark.ReadApi
//import etljobs.utils.{CSV, JDBC, SessionManager}
//import org.testcontainers.containers.PostgreSQLContainer
//import schema.distribution.DistributionIncentive.{DistributionIncentiveBQ, DistributionIncentiveOracle}
//
//class EtlDistIncentiveSuite extends FlatSpec with Matchers {
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE CUSTOM_INCENTIVE_ANNEX_DETAILS (   seq_no VARCHAR(50), sms_input_hdr_id VARCHAR(50), customer_nbr VARCHAR(50), penetration_incentive VARCHAR(50), lcn_incentive VARCHAR(50), volume_incentive VARCHAR(50), premiumization_incentive VARCHAR(50), lead_incentive VARCHAR(50), total_incentive VARCHAR(50), max_elg_inc VARCHAR(50), additional_inc VARCHAR(50), revised_inc VARCHAR(50), start_date VARCHAR(50), end_date VARCHAR(50), par_month VARCHAR(50), par_year VARCHAR(50), mini_bouquet_incentive VARCHAR(50), ala_incentive VARCHAR(50), mkt_code VARCHAR(50), mkt_name VARCHAR(50), market_revenue VARCHAR(50), incentive_amount VARCHAR(50), old_incentive_amount VARCHAR(50), prev_ref_nbr VARCHAR(50), penetration_type VARCHAR(50), hindi_speaking_universe_count VARCHAR(50), telugu_universe_count VARCHAR(50), marathi_universe_count VARCHAR(50), kannada_universe_count VARCHAR(50), malayalam_universe_count VARCHAR(50), tamil_universe_count VARCHAR(50), nesa_universe_count VARCHAR(50), universe VARCHAR(50), incentive_version VARCHAR(50), invoice_nbr VARCHAR(50), invoice_id VARCHAR(50), westbengal_universe_count VARCHAR(50), penetration_per VARCHAR(50),lead_penetration_per VARCHAR(50), incentive_refno VARCHAR(50), broadcaster VARCHAR(50), date VARCHAR(50));")
//  preparedStatement1.executeUpdate()
//  val preparedStatement2 = connection.prepareStatement("insert into CUSTOM_INCENTIVE_ANNEX_DETAILS (   seq_no , sms_input_hdr_id , customer_nbr , penetration_incentive , lcn_incentive , volume_incentive, premiumization_incentive, lead_incentive , total_incentive , max_elg_inc , additional_inc , revised_inc , start_date , end_date , par_month , par_year , mini_bouquet_incentive , ala_incentive , mkt_code , mkt_name , market_revenue , incentive_amount , old_incentive_amount , prev_ref_nbr , penetration_type , hindi_speaking_universe_count  , telugu_universe_count , marathi_universe_count , kannada_universe_count , malayalam_universe_count , tamil_universe_count , nesa_universe_count , universe , incentive_version , invoice_nbr , invoice_id , westbengal_universe_count , penetration_per ,lead_penetration_per , incentive_refno , broadcaster , date  ) VALUES (" + "'1017832'" + "," + "'20108'" + "," + "'120831'" + "," + "'0.0'" + "," + "'0'" + "," + "'0'" + "," + "'0'" + "," + "'0.0'" + "," + "'0.0'" + "," + "'15'" + "," + "'0'" + "," + "'0.0'" + ","+ "'2019-10-01T00:00:00'" +","+"'2019-10-31T00:00:00'" + "," + "'OCT'" + "," + "'2019'" + "," + "'0'" + "," + "'0'" + "," + "'HSM_REV_AMD 2A-3'" + "," + "'Hindi Speaking Market (HSM)'" + "," + "'5737905.26'" + "," + "'0.0'" + "," + "'0.0'" + "," + "'NA'"+","+"'PARTA'"+","+"'200903.0'"+","+"'NA'"+","++","+"'NA'"+","+"'NA'"+","+"'NA'"+","+"'NA'"+","+"'0'"+","+"'INCENT_VER_2'"+","+"'M05300006987'"+","+"'1738690'"+","+"'1843490.0'"+","+"'61.15'"+","+"'69.11'"+","+"'9673'"+","+ "'COMBINED_SIPL'" + "," + "'2019-04-01'" + ")" )
//  val preparedStatement3 = connection.prepareStatement("insert into CUSTOM_INCENTIVE_ANNEX_DETAILS (   seq_no , sms_input_hdr_id , customer_nbr , penetration_incentive , lcn_incentive , volume_incentive, premiumization_incentive, lead_incentive , total_incentive , max_elg_inc , additional_inc , revised_inc , start_date , end_date , par_month , par_year , mini_bouquet_incentive , ala_incentive , mkt_code , mkt_name , market_revenue , incentive_amount , old_incentive_amount , prev_ref_nbr , penetration_type , hindi_speaking_universe_count  , telugu_universe_count , marathi_universe_count , kannada_universe_count , malayalam_universe_count , tamil_universe_count , nesa_universe_count , universe , incentive_version , invoice_nbr , invoice_id , westbengal_universe_count , penetration_per ,lead_penetration_per , incentive_refno , broadcaster , date  ) VALUES (" + "'2017832'" + "," + "'20108'" + "," + "'120831'" + "," + "'0.0'" + "," + "'0'" + "," + "'0'" + "," + "'0'" + "," + "'0.0'"+","+"'0.0'"+","+"'15'"+","+"'0'"+","+"'0.0'"+","+ "'2019-10-01T00:00:00'" +","+"'2019-10-31T00:00:00'"+","+"'OCT'"+","+"'2019'"+","+"'0'"+","+"'0'"+","+"'HSM_REV_AMD 2A-3'"+","+"'Hindi Speaking Market (HSM)'"+","+"'5737905.26'"+","+"'0.0'"+","+"'0.0'"+","+"''"+","+"'PARTA'"+","+"'200903.0'"+","+"''"+","++","+"''"+","+"''"+","+"''"+","+"''"+","+"'0'"+","+"'INCENT_VER_2'"+","+"'M05300006987'"+","+"'1738690'"+","+"'1843490.0'"+","+"'61.15'"+","+"'69.11'"+","+"'9673'"+","+ "'COMBINED_SIPL'" + "," + "'2019-04-01'" + ")" )
//  val preparedStatement4 = connection.prepareStatement("insert into CUSTOM_INCENTIVE_ANNEX_DETAILS (   seq_no , sms_input_hdr_id , customer_nbr , penetration_incentive , lcn_incentive , volume_incentive, premiumization_incentive, lead_incentive , total_incentive , max_elg_inc , additional_inc , revised_inc , start_date , end_date , par_month , par_year , mini_bouquet_incentive , ala_incentive , mkt_code , mkt_name , market_revenue , incentive_amount , old_incentive_amount , prev_ref_nbr , penetration_type , hindi_speaking_universe_count  , telugu_universe_count , marathi_universe_count , kannada_universe_count , malayalam_universe_count , tamil_universe_count , nesa_universe_count , universe , incentive_version , invoice_nbr , invoice_id , westbengal_universe_count , penetration_per ,lead_penetration_per , incentive_refno , broadcaster , date  ) VALUES (" + "'1014832'" + "," + "'20108'" + "," + "'120831'" + "," + "'0.0'" + "," + "'0'" + "," + "'0'" + "," + "'0'" + "," + "'0.0'"+","+"'0.0'"+","+"'15'"+","+"'0'"+","+"'0.0'"+","+ "'2019-10-01T00:00:00'" +","+"'2019-10-31T00:00:00'"+","+"'OCT'"+","+"'2019'"+","+"'0'"+","+"'0'"+","+"'HSM_REV_AMD 2A-3'"+","+"'Hindi Speaking Market (HSM)'"+","+"'5737905.26'"+","+"'0.0'"+","+"'0.0'"+","+"''"+","+"'PARTA'"+","+"'200903.0'"+","+"''"+","++","+"''"+","+"''"+","+"''"+","+"''"+","+"'0'"+","+"'INCENT_VER_2'"+","+"'M05300006987'"+","+"'1738690'"+","+"'1843490.0'"+","+"'61.15'"+","+"'69.11'"+","+"'9673'"+","+ "'COMBINED_SIPL'" + "," + "'2019-04-01'" + ")" )
//  val preparedStatement5 = connection.prepareStatement("insert into CUSTOM_INCENTIVE_ANNEX_DETAILS (   seq_no , sms_input_hdr_id , customer_nbr , penetration_incentive , lcn_incentive , volume_incentive, premiumization_incentive, lead_incentive , total_incentive , max_elg_inc , additional_inc , revised_inc , start_date , end_date , par_month , par_year , mini_bouquet_incentive , ala_incentive , mkt_code , mkt_name , market_revenue , incentive_amount , old_incentive_amount , prev_ref_nbr , penetration_type , hindi_speaking_universe_count  , telugu_universe_count , marathi_universe_count , kannada_universe_count , malayalam_universe_count , tamil_universe_count , nesa_universe_count , universe , incentive_version , invoice_nbr , invoice_id , westbengal_universe_count , penetration_per ,lead_penetration_per , incentive_refno , broadcaster , date  ) VALUES (" + "'1017862'" + "," + "'20108'" + "," + "'120831'" + "," + "'0.0'" + "," + "'0'" + "," + "'0'" + "," + "'0'" + "," + "'0.0'"+","+"'0.0'"+","+"'15'"+","+"'0'"+","+"'0.0'"+","+ "'2019-10-01T00:00:00'" +","+"'2019-10-31T00:00:00'"+","+"'OCT'"+","+"'2019'"+","+"'0'"+","+"'0'"+","+"'HSM_REV_AMD 2A-3'"+","+"'Hindi Speaking Market (HSM)'"+","+"'5737905.26'"+","+"'0.0'"+","+"'0.0'"+","+"''"+","+"'PARTA'"+","+"'200903.0'"+","+"''"+","++","+"''"+","+"''"+","+"''"+","+"''"+","+"'0'"+","+"'INCENT_VER_2'"+","+"'M05300006987'"+","+"'1738690'"+","+"'1843490.0'"+","+"'61.15'"+","+"'69.11'"+","+"'9673'"+","+ "'COMBINED_SIPL'" + "," + "'2019-04-01'" + ")" )
//
//  preparedStatement2.executeUpdate()
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//
//  // STEP 1: Initialize job properties and create BQ tables required for jobs
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties = Map(
//    "job_name" -> "EtlJobDistributionIncentive" ,
//    "job_input_path" -> "CUSTOM_INCENTIVE_ANNEX_DETAILS",
//    "job_output_path" -> s"$canonical_path/src/test/resources/output/distribution/incentive",
//    "output_dataset" -> "test",
//    "distribution_output_table_name" -> "dist_incentive",
//    "jdbc_url" -> s"${container.getJdbcUrl}" ,
//    "user" -> s"${container.getUsername}",
//    "password" -> s"${container.getPassword}",
//    "driver" -> "org.postgresql.Driver",
//    "debug" -> "false",
//    "test"->"true"
//  )
//  // STEP 2: Execute JOB
//  val etljob = new EtlJobDistributionIncentive(job_properties, global_properties)
//
//  val mapping  = Encoders.product[DistributionIncentiveOracle]
//  val sm = new SessionManager(global_properties) {}
//
//  // STEP 3: Run tests
//
//  val raw : Dataset[DistributionIncentiveOracle] = ReadApi.LoadDS[DistributionIncentiveOracle](
//    Seq(job_properties("ratings_input_path")),
//    JDBC(container.getJdbcUrl, global_properties.postgre_jdbc_url, global_properties.postgre_password, global_properties.postgre_driver)
//  )(sm.spark)
//
//  val raw_format = raw.withColumn("date_int",from_unixtime(unix_timestamp(col("date"),"yyyy-MM-dd"),"yyyyMMdd")).as[DistributionIncentiveOracle](mapping)
//  val transfomed = etljob.DistributionIncentiveTransform(sm.spark,job_properties)(raw_format)
//
//
//  val raw_format_count:Long = raw_format.count()
//  val transfomed_count:Double = transfomed.count()
//
//  val Row(sum_penetration_incentive_raw:Double) = raw_format.selectExpr("""sum(penetration_incentive)""").first()
//  val Row(sum_penetration_incentive_transformed:Double) = transfomed.selectExpr("""sum(penetration_incentive)""").first()
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from CUSTOM_INCENTIVE_ANNEX_DETAILS;")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in dataframe and oracle table " in {
//    assert(raw_format_count==transfomed_count)
//  }
//
//  "Sum of penetration_incentive" should "be matching in  dataframe and oracle table " in {
//    assert("%.4f".format(sum_penetration_incentive_raw).toDouble=="%.4f".format(sum_penetration_incentive_transformed).toDouble)
//  }
//}