//package distribution
//
//import java.sql.DriverManager
//
//import util.MintGlobalProperties
//import etljobs.distribution.{EtlJobDistributionIncentive, EtlJobDistributionRevenue}
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, SessionManager}
//import org.apache.spark.sql.functions.{col, from_unixtime, unix_timestamp}
//import org.apache.spark.sql.{Dataset, Encoders, Row}
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import org.testcontainers.containers.OracleContainer
//
//
//import schema.distribution.DistributionIncentive.DistributionIncentiveOracle
//import schema.distribution.DistributionRevenue.DistributionRevenueOracle
//
//
//class EtlDistRevenueSuite extends FlatSpec with Matchers {
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE CUSTOM_CRN_REPLICA_REPORT_BI (   customer_nbr VARCHAR(50), bouquet_alacarte VARCHAR(50), bouquet_alacarte_name VARCHAR(50), monthly_average VARCHAR(50), charge_amount VARCHAR(50), type_of_billing VARCHAR(50), total_amount VARCHAR(50), month_year VARCHAR(50), vertical VARCHAR(50), is_pushed_to_billing VARCHAR(50), dpo_name VARCHAR(50), date VARCHAR(50));")
//  preparedStatement1.executeUpdate()
//  val preparedStatement2 = connection.prepareStatement("insert into CUSTOM_CRN_REPLICA_REPORT_BI (  customer_nbr , bouquet_alacarte , bouquet_alacarte_name, monthly_average , charge_amount , type_of_billing , total_amount, month_year , vertical , is_pushed_to_billing , dpo_name ,date) VALUES (" +  "'123662'" + "," + "'ALACARTE'" + ","+ "'STAR SPORTS 1 KANNADA'" + "," + "'1.75'" + "," + "'26.6'" + "," + "'NORMAL BILLING'" + "," + "'NORMAL BILLING'" + ","+ "'Nov-2019'"  +  "," +  "'Key Accounts'" + "," + "'YES'" + "," + "'RAJESH FUN SQUARE'" + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement3 = connection.prepareStatement("insert into CUSTOM_CRN_REPLICA_REPORT_BI (  customer_nbr , bouquet_alacarte , bouquet_alacarte_name, monthly_average , charge_amount , type_of_billing , total_amount, month_year , vertical , is_pushed_to_billing , dpo_name,date ) VALUES (" +  "'123662'" + "," + "'ALACARTE'" + ","+ "'UTV MOVIES'" + "," + "'268.5'" + "," + "'429.6'" + "," + "'NORMAL BILLING'" + "," + "'NORMAL BILLING'" + ","+ "'Nov-2019'"  +  "," +  "'Key Accounts'" + "," + "'YES'" + "," + "'RAJESH FUN SQUARE'" + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement4 = connection.prepareStatement("insert into CUSTOM_CRN_REPLICA_REPORT_BI (  customer_nbr , bouquet_alacarte , bouquet_alacarte_name, monthly_average , charge_amount , type_of_billing , total_amount, month_year , vertical , is_pushed_to_billing , dpo_name,date ) VALUES (" +  "'123662'" + "," + "'ALACARTE'" + ","+ "'VIJAY HD'" + "," + "'2.75'" + "," + "'41.8'" + "," + "'NORMAL BILLING'" + "," + "'NORMAL BILLING'" + ","+ "'Nov-2019'"  +  "," +  "'Key Accounts'" + "," + "'YES'" + "," + "'RAJESH FUN SQUARE'" + "," + "'2019-04-01'" + ")"  )
//  val preparedStatement5 = connection.prepareStatement("insert into CUSTOM_CRN_REPLICA_REPORT_BI (  customer_nbr , bouquet_alacarte , bouquet_alacarte_name, monthly_average , charge_amount , type_of_billing , total_amount, month_year , vertical , is_pushed_to_billing , dpo_name ,date ) VALUES (" +  "'123662'" + "," + "'ALACARTE'" + ","+ "'HINDI VALUE'" + "," + "'0'" + "," + "'26.6'" + "," + "'NORMAL BILLING'" + "," + "'NORMAL BILLING'" + ","+ "'Nov-2019'"  +  "," +  "'Key Accounts'" + "," + "'YES'" + "," + "'RAJESH FUN SQUARE'" + "," + "'2019-04-01'" + ")"  )
//
//  preparedStatement2.executeUpdate()
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//
//  // STEP 1: Initialize job properties and create BQ tables required for jobs
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties = Map(
//    "job_name" -> "EtlJobDistributionRevenue" ,
//    "job_input_path" -> "CUSTOM_CRN_REPLICA_REPORT_BI",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/dist_revenue_test",
//    "output_dataset" -> "test",
//    "output_table_name" -> "dist_revenue_test",
//    "jdbc_url" -> s"${container.getJdbcUrl}" ,
//    "jdbc_credentials" -> "",
//    "jdbc_host_name" -> "",
//    "user" -> s"${container.getUsername}",
//    "password" -> s"${container.getPassword}",
//    "driver" -> "org.postgresql.Driver",
//    "debug" -> "false",
//    "test"->"true"
//  )
//
//
//  val etljob = new EtlJobDistributionRevenue(job_properties, global_properties)
//  val mapping  = Encoders.product[DistributionRevenueOracle]
//  val sm = new SessionManager(global_properties) {}
//
//  // STEP 3: Run tests
//
//  val raw : Dataset[DistributionRevenueOracle] = ReadApi.LoadDS[DistributionRevenueOracle](
//    Seq(job_properties("job_input_path")),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val raw_format = raw.withColumn("date_int",from_unixtime(unix_timestamp(col("date"),"yyyy-MM-dd"),"yyyyMMdd")).as[DistributionRevenueOracle](mapping)
//  val transfomed = etljob.DistributionSubTransform(sm.spark,job_properties)(raw_format)
//
//
//  val raw_format_count:Long = raw_format.count()
//  val transfomed_count:Double = transfomed.count()
//
//  val Row(sum_monthly_average_raw:Double) = raw_format.selectExpr("""sum(monthly_average)""").first()
//  val Row(sum_monthly_average_transformed:Double) = transfomed.selectExpr("""sum(monthly_average)""").first()
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from CUSTOM_CRN_REPLICA_REPORT_BI;")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in dataframe and oracle table " in {
//    assert(raw_format_count==transfomed_count)
//  }
//
//  "Sum of monthly_average" should "be matching in  dataframe and oracle table " in {
//    assert("%.4f".format(sum_monthly_average_raw).toDouble=="%.4f".format(sum_monthly_average_transformed).toDouble)
//  }
//}