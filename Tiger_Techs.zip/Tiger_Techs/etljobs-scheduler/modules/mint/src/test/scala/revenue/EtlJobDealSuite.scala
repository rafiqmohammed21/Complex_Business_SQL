//package revenue
//
//import java.sql.DriverManager
//
//import com.google.cloud.bigquery.FieldValueList
//import util.MintGlobalProperties
//import etljobs.revenue.EtlJobAdvertiser
//import etljobs.bigquery.QueryApi
//import etljobs.spark.ReadApi
//import etljobs.utils.{JDBC, SessionManager}
//import org.apache.spark.sql.Dataset
//import org.scalatest.{FlatSpec, Matchers}
//import org.testcontainers.containers.PostgreSQLContainer
//import .AdvertiserDetailInfoPostGre
//import etljobs.revenue.EtlJobDeal
//import schema.revenue.Deal.DealPostgre
//import org.apache.spark.sql.Row
//
//
//class EtlJobDealSuite extends  FlatSpec with Matchers  {
//
//  val container = new PostgreSQLContainer("postgres:latest")
//  container.start
//
//  val connection = DriverManager.getConnection(container.getJdbcUrl, container.getUsername, container.getPassword)
//
//  //prepare create table command
//  val preparedStatement1 = connection.prepareStatement("CREATE TABLE deal_info ( proposal_id BIGINT,proposal_product_id BIGINT,proposal_name VARCHAR,proposal_type VARCHAR,category VARCHAR,status VARCHAR,commercial_duration_in_sec INTEGER,start_date DATE,end_date DATE,channel_name VARCHAR,advertiser_group_id BIGINT,agency_group_id BIGINT,advertiser_id BIGINT,agency_id BIGINT,advertiser_group_name VARCHAR,agency_group_name VARCHAR,region VARCHAR,currency VARCHAR,onair_deal_id INTEGER,reconcile_status BOOLEAN,channel_tgmarkets VARCHAR[],spr_airing_start_date TIMESTAMP,spr_airing_end_date TIMESTAMP,month INTEGER,year INTEGER,channel_skew_weight JSON,price FLOAT,fct INTEGER,monthly_fct NUMERIC,monthly_outlay NUMERIC,weight NUMERIC,product_name VARCHAR,week_days VARCHAR[],start_time INTEGER,end_time INTEGER,impact_regular VARCHAR,year_month TEXT);")
//  preparedStatement1.executeUpdate()
//
//  //insert rows into created table
//  val preparedStatement2 = connection.prepareStatement("insert into deal_info ( proposal_id ,proposal_product_id ,proposal_name ,proposal_type ,category ,status ,commercial_duration_in_sec ,start_date ,end_date ,channel_name ,advertiser_group_id ,agency_group_id ,advertiser_id ,agency_id ,advertiser_group_name ,agency_group_name ,region ,currency ,onair_deal_id ,reconcile_status ,channel_tgmarkets ,spr_airing_start_date ,spr_airing_end_date ,month ,year ,channel_skew_weight ,price ,fct ,monthly_fct ,monthly_outlay ,weight ,product_name ,week_days ,start_time ,end_time ,impact_regular ,year_month  ) VALUES (" + "99"+ "," + "4195" +","+ "'Star_Bharat_Amazon_20Sep18_1602'"+","+"'Campaign ER'"+","+"'NA'"+","+"'Approved'"+","+"10"+","+"'2018-09-28'"+","+"'2018-10-04'"+","+"'Star Bharat'"+","+"85"+","+"5"+","+"8891.0"+","+"1776.0"+","+"'Amazon'"+","+"'IPG'"+","+"'SOUTH'"+","+"'Indian Rupees'"+","+"123"+","+"'false'" + "," + "'{\"CS 15+ HSM (U)\",\"CS 15+ HSM (U+R)\",\"CS 15+ HSM (U)\"}'" + "," + "'2018-09-28 00:00:00'"+","+"'2018-10-04 00:00:00'"+","+"9"+","+"2018"+","+"'{\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1,\"Early DH\":0,\"Late DH\":0},\"weekpart\":{\"WD\":1,\"WE\":0}}'"+","+"58000.0"+","+"150"+","+"49.5"+","+"287100.0"+","+"0.33"+","+"'(Nimki Mukhiya)-(O)-(Mon-Sat)-(20:30-21:00)-(SBSD)'"+","+"'{\"mon\",\"tue\",\"wed\",\"thu\",\"fri\",\"sat\"}'"+","+"2030"+","+"2100"+","+"'regular'"+","+"'201907'" + ")")
//  val preparedStatement3 = connection.prepareStatement("insert into deal_info ( proposal_id ,proposal_product_id ,proposal_name ,proposal_type ,category ,status ,commercial_duration_in_sec ,start_date ,end_date ,channel_name ,advertiser_group_id ,agency_group_id ,advertiser_id ,agency_id ,advertiser_group_name ,agency_group_name ,region ,currency ,onair_deal_id ,reconcile_status ,channel_tgmarkets ,spr_airing_start_date ,spr_airing_end_date ,month ,year ,channel_skew_weight ,price ,fct ,monthly_fct ,monthly_outlay ,weight ,product_name ,week_days ,start_time ,end_time ,impact_regular ,year_month  ) VALUES (" + "99"+ "," + "4195" +","+ "'Star_Bharat_Amazon_20Sep18_1602'"+","+"'Campaign ER'"+","+"'NA'"+","+"'Approved'"+","+"10"+","+"'2018-09-28'"+","+"'2018-10-04'"+","+"'Star Bharat'"+","+"85"+","+"5"+","+"8891.0"+","+"1776.0"+","+"'Amazon'"+","+"'IPG'"+","+"'SOUTH'"+","+"'Indian Rupees'"+","+"123"+","+"'false'" + "," + "'{\"CS 15+ HSM (U)\",\"CS 15+ HSM (U+R)\",\"CS 15+ HSM (U)\"}'" + "," + "'2018-09-28 00:00:00'"+","+"'2018-10-04 00:00:00'"+","+"9"+","+"2018"+","+"'{\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1,\"Early DH\":0,\"Late DH\":0},\"weekpart\":{\"WD\":1,\"WE\":0}}'"+","+"58000.0"+","+"150"+","+"49.5"+","+"287100.0"+","+"0.33"+","+"'(Nimki Mukhiya)-(O)-(Mon-Sat)-(20:30-21:00)-(SBSD)'"+","+"'{\"mon\",\"tue\",\"wed\",\"thu\",\"fri\",\"sat\"}'"+","+"2030"+","+"2100"+","+"'regular'"+","+"'201907'" + ")")
//  val preparedStatement4 = connection.prepareStatement("insert into deal_info ( proposal_id ,proposal_product_id ,proposal_name ,proposal_type ,category ,status ,commercial_duration_in_sec ,start_date ,end_date ,channel_name ,advertiser_group_id ,agency_group_id ,advertiser_id ,agency_id ,advertiser_group_name ,agency_group_name ,region ,currency ,onair_deal_id ,reconcile_status ,channel_tgmarkets ,spr_airing_start_date ,spr_airing_end_date ,month ,year ,channel_skew_weight ,price ,fct ,monthly_fct ,monthly_outlay ,weight ,product_name ,week_days ,start_time ,end_time ,impact_regular ,year_month  ) VALUES (" + "99"+ "," + "4195" +","+ "'Star_Bharat_Amazon_20Sep18_1602'"+","+"'Campaign ER'"+","+"'NA'"+","+"'Approved'"+","+"10"+","+"'2018-09-28'"+","+"'2018-10-04'"+","+"'Star Bharat'"+","+"85"+","+"5"+","+"8891.0"+","+"1776.0"+","+"'Amazon'"+","+"'IPG'"+","+"'SOUTH'"+","+"'Indian Rupees'"+","+"123"+","+"'false'" + "," + "'{\"CS 15+ HSM (U)\",\"CS 15+ HSM (U+R)\",\"CS 15+ HSM (U)\"}'" + "," + "'2018-09-28 00:00:00'"+","+"'2018-10-04 00:00:00'"+","+"9"+","+"2018"+","+"'{\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1,\"Early DH\":0,\"Late DH\":0},\"weekpart\":{\"WD\":1,\"WE\":0}}'"+","+"58000.0"+","+"150"+","+"49.5"+","+"287100.0"+","+"0.33"+","+"'(Nimki Mukhiya)-(O)-(Mon-Sat)-(20:30-21:00)-(SBSD)'"+","+"'{\"mon\",\"tue\",\"wed\",\"thu\",\"fri\",\"sat\"}'"+","+"2030"+","+"2100"+","+"'regular'"+","+"'201907'" + ")")
//  val preparedStatement5 = connection.prepareStatement("insert into deal_info ( proposal_id ,proposal_product_id ,proposal_name ,proposal_type ,category ,status ,commercial_duration_in_sec ,start_date ,end_date ,channel_name ,advertiser_group_id ,agency_group_id ,advertiser_id ,agency_id ,advertiser_group_name ,agency_group_name ,region ,currency ,onair_deal_id ,reconcile_status ,channel_tgmarkets ,spr_airing_start_date ,spr_airing_end_date ,month ,year ,channel_skew_weight ,price ,fct ,monthly_fct ,monthly_outlay ,weight ,product_name ,week_days ,start_time ,end_time ,impact_regular ,year_month  ) VALUES (" + "99"+ "," + "4195" +","+ "'Star_Bharat_Amazon_20Sep18_1602'"+","+"'Campaign ER'"+","+"'NA'"+","+"'Approved'"+","+"10"+","+"'2018-09-28'"+","+"'2018-10-04'"+","+"'Star Bharat'"+","+"85"+","+"5"+","+"8891.0"+","+"1776.0"+","+"'Amazon'"+","+"'IPG'"+","+"'SOUTH'"+","+"'Indian Rupees'"+","+"123"+","+"'false'" + "," + "'{\"CS 15+ HSM (U)\",\"CS 15+ HSM (U+R)\",\"CS 15+ HSM (U)\"}'" + "," + "'2018-09-28 00:00:00'"+","+"'2018-10-04 00:00:00'"+","+"9"+","+"2018"+","+"'{\"daypart\":{\"PT\":1,\"NPT\":0},\"dayparttwo\":{\"CPT\":1,\"Early DH\":0,\"Late DH\":0},\"weekpart\":{\"WD\":1,\"WE\":0}}'"+","+"58000.0"+","+"150"+","+"49.5"+","+"287100.0"+","+"0.33"+","+"'(Nimki Mukhiya)-(O)-(Mon-Sat)-(20:30-21:00)-(SBSD)'"+","+"'{\"mon\",\"tue\",\"wed\",\"thu\",\"fri\",\"sat\"}'"+","+"2030"+","+"2100"+","+"'regular'"+","+"'201907'" + ")")
//
//  preparedStatement3.executeUpdate()
//  preparedStatement4.executeUpdate()
//  preparedStatement5.executeUpdate()
//  preparedStatement2.executeUpdate()
//
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//  //Defining the test case variables
//
//  //Defining the test case variables
//  val job_properties = Map(
//    "job_name" -> "EtlJobDeal",
//    "job_input_path" -> "deal_info",
//    "job_output_path" -> f"${global_properties.gcs_output_bucket}/deal_test",
//    "refresh_dates" -> "\'201907\'",
//    "jdbc_url" -> container.getJdbcUrl,
//    "user" -> container.getUsername,
//    "password" -> container.getPassword,
//    "output_dataset" -> "test",
//    "output_table_name" -> "deal_test",
//    "driver" -> "org.postgresql.Driver"
//  )
//
//  val etljob = new EtlJobDeal(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val query_alias  = s""" (SELECT * FROM (SELECT *
//                ,to_date(concat(year_month,'01'),'yyyyMMdd') as date
//                ,concat(year_month,'01') as date_int
//                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) * (monthly_outlay) as channel_pt_revenue
//                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) * (monthly_outlay) as channel_npt_revenue
//                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) * (monthly_outlay) as channel_wd_revenue
//                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float) * (monthly_outlay)  as channel_we_revenue
//                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) * (monthly_outlay) as channel_cpt_revenue
//                ,((channel_skew_weight -> 'dayparttwo' ->> 'Afternoon')::Float) * (monthly_outlay) as channel_afternoon_revenue
//                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) * (monthly_fct) as channel_pt_fct
//                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) * (monthly_fct) as channel_npt_fct
//                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) * (monthly_fct) as channel_wd_fct
//                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float) * (monthly_fct)  as channel_we_fct
//                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) * (monthly_fct) as channel_cpt_fct
//                ,((channel_skew_weight -> 'dayparttwo' ->> 'Afternoon')::Float) * (monthly_fct) as channel_afternoon_fct
//                from ${job_properties("job_input_path")})
//                a WHERE year_month in (${job_properties("refresh_dates")}) )  t""".stripMargin
//
//
//  val sm = new SessionManager(global_properties) {}
//
//  val raw : Dataset[DealPostgre] = ReadApi.LoadDS[DealPostgre](
//    Seq(query_alias),
//    JDBC(container.getJdbcUrl, container.getUsername, container.getPassword,job_properties("driver"))
//  )(sm.spark)
//
//  val op  = etljob.revenueDealTransform(sm.spark, job_properties)(raw)
//  val count_records_transformed:Long  = op.count()
//  val Row(sum_price_transformed:Double) = raw.selectExpr("""sum(price)""").first()
//  val Row(sum_channel_pt_revenue_transformed:Double) = raw.selectExpr("""sum(channel_pt_revenue)""").first()
//
//
//  println("count_records_transformed : " + count_records_transformed)
//
//  //query the bq table and get the data loaded from previous steps
//  val query:String  =s""" select count(*) as count,
//                          sum(price) price,
//                          sum(channel_pt_revenue) channel_pt_revenue
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//  val sum_price_bq:Double = result.head.get("price").getDoubleValue
//  val sum_channel_pt_revenue_df_bq:Double = result.head.get("channel_pt_revenue").getDoubleValue
//
//
//
//  "PostgreSQL container" should "be started" in {
//    val preparedStatement3 = connection.prepareStatement("SELECT count(*) from deal_info")
//    val resultSet3 = preparedStatement3.executeQuery()
//    resultSet3.next()
//    assert(resultSet3.getInt(1) >= 1)
//    resultSet3.close()
//  }
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//
//  "Sum of share_in_campaign" should "be matching in orc dataframe and BQ table " in {
//    assert("%.4f".format(sum_price_transformed).toDouble=="%.4f".format(sum_price_bq).toDouble)
//  }
//
//  "Sum of projection_inr" should "be matching in orc dataframe and BQ table" in {
//    assert("%.4f".format(sum_channel_pt_revenue_transformed).toDouble=="%.4f".format(sum_channel_pt_revenue_df_bq).toDouble)
//  }
//
//
//}