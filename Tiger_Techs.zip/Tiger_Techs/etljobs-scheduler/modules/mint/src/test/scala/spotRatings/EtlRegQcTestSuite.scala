//package spotRatings
//
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
//import etljobs.south_regional.spot_rating.EtlJobRegionalOrEntertainmentQc
//import util.MintGlobalProperties
//import etljobs.utils.SessionManager
//import org.apache.spark.sql.SparkSession
//import org.scalatest.{BeforeAndAfterAll, FlatSpec, Matchers}
//
//class EtlRegQcTestSuite  extends   FlatSpec with Matchers with BeforeAndAfterAll  with DataFrameSuiteBase  {
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties1a = Map(
//    "job_name" -> "EtlJobRegSpotRatingsQc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings_qc/case1_pass/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings_qc/case1_pass/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties1b = Map(
//    "job_name" -> "EtlJobRegSpotRatingsQc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings_qc/case1_pass/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings_qc/case1_pass/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties2 = Map(
//    "job_name" -> "EtlJobRegSpotRatingsQc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings_qc/case2_qc_missing/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings_qc/case2_qc_missing/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties3 = Map(
//    "job_name" -> "EtlJobRegSpotRatingsQc" ,
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings_qc/case3_RAW_missing/raw" ,
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings_qc/case3_RAW_missing/qc_result",
//    "debug" -> "false",
//    "test"->"true"
//  )
//  val job_properties4 = Map(
//    "job_name" -> "EtlJobRegSpotRatingsQc" ,
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_spot_ratings_qc/case4_diff_duration_rat/raw" ,
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_spot_ratings_qc/case4_diff_duration_rat/qc_result",
//    "debug" -> "false",
//    "test"->"true"
//  )
//  val sm = new SessionManager(global_properties) {}
//
//  "Duration column" should " be matching in aggregated RAW and QC files" in {
//
//    val etljob = new EtlJobRegionalOrEntertainmentQc(job_properties1b, global_properties)
//
//    val raw_prep = etljob.getRawData(sm.spark, job_properties1b("job_input_path")+"/all_regions/*").toDF()
//    val qc_file_path = etljob.getQcPathFromRaw(job_properties1b("job_input_path"))
//    val qc_prep = etljob.getQcData(sm.spark,qc_file_path+"/all_regions/*").toDF()
//    assertDataFrameEquals(raw_prep.selectExpr("duration").orderBy("duration"), qc_prep.selectExpr("cast(duration_qc as long) as duration").orderBy("duration"))
//  }
//
//  "Rating column" should " be matching in aggregated RAW and QC data" in {
//    val sm = new SessionManager(global_properties) {}
//    val etljob = new EtlJobRegionalOrEntertainmentQc(job_properties1b, global_properties)
//    val raw_prep = etljob.getRawData(sm.spark, job_properties1b("job_input_path")+"/all_regions/*")
//    val qc_file_path = etljob.getQcPathFromRaw(job_properties1b("job_input_path"))
//    val qc_prep = etljob.getQcData(sm.spark,qc_file_path+"/all_regions/*")
//
//    assertDataFrameApproximateEquals(raw_prep.selectExpr("rat_av as rat").orderBy("rat"), qc_prep.selectExpr("rat_av_wg_qc as rat").orderBy("rat"), 0.001)
//  }
//
//
//
//}