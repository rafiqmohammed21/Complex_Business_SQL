//package timeBand30
//
//import com.holdenkarau.spark.testing.DataFrameSuiteBase
//import util.MintGlobalProperties
//import etljobs.utils.SessionManager
//import org.apache.spark.sql.SparkSession
//import org.scalatest.{BeforeAndAfterAll, FlatSpec, Matchers}
//import etljobs.south_regional.timeBand30
//import etljobs.south_regional.timeBand30.EtlJobRegionalQc
//class EtlRegQcTestSuite extends FlatSpec with Matchers  with DataFrameSuiteBase with BeforeAndAfterAll {
//
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties1a = Map(
//    "job_name" -> "EtlJobRegionalTb30Qc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30_qc/case1_pass/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30_qc/case1_pass/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties1b = Map(
//    "job_name" -> "EtlJobRegionalTb30Qc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30_qc/case1_pass/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30_qc/case1_pass/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties2 = Map(
//    "job_name" -> "EtlJobRegionalTb30Qc",
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30_qc/case2_qc_missing/raw",
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30_qc/case2_qc_missing/qc_result",
//    "debug" -> "false",
//    "test" -> "true"
//  )
//  val job_properties3 = Map(
//    "job_name" -> "EtlJobRegionalTb30Qc" ,
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30_qc/case3_RAW_missing/raw" ,
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30_qc/case3_RAW_missing/qc_result",
//    "debug" -> "false",
//    "test"->"true"
//  )
//  val job_properties4 = Map(
//    "job_name" -> "EtlJobRegionalTb30Qc" ,
//    "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30_qc/case4_diff_duration_rat/raw" ,
//    "qc_result_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30_qc/case4_diff_duration_rat/qc_result",
//    "debug" -> "false",
//    "test"->"true"
//  )
//
//  val sm = new SessionManager(global_properties) {}
//  "Duration column" should " be matching in aggregated RAW and QC files" in {
//
//    val etljob = new EtlJobRegionalQc(job_properties1b, global_properties)
//    val raw_prep = etljob.getRawData(sm.spark, job_properties1b("job_input_path")+"/all_region/*").toDF()
//    val qc_file_path = etljob.getQcPathFromRaw(job_properties1b("job_input_path"))
//    val qc_prep = etljob.getQcData(sm.spark,qc_file_path+"/all_region/*").toDF()
//    assertDataFrameEquals(raw_prep.selectExpr("duration").orderBy("duration"), qc_prep.selectExpr("cast(duration_qc as long) as duration").orderBy("duration"))
//  }
//
//  "Rating column" should " be matching in aggregated RAW and QC data" in {
//
//    val etljob = new EtlJobRegionalQc(job_properties1b, global_properties)
//
//    val raw_prep = etljob.getRawData(sm.spark, job_properties1b("job_input_path")+"/all_region/*")
//    val qc_file_path = etljob.getQcPathFromRaw(job_properties1b("job_input_path"))
//    val qc_prep = etljob.getQcData(sm.spark,qc_file_path+"/all_region/*")
//
//
//    assertDataFrameApproximateEquals(raw_prep.selectExpr("rat_sum as rat").orderBy("rat"), qc_prep.selectExpr("rat_sum_qc as rat").orderBy("rat"), 0.001)
//  }
//
//
//
//
//}