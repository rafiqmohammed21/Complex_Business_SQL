//package timeBand30
//
//import com.google.cloud.bigquery.FieldValueList
//import etljobs.spark.ReadApi
//import etljobs.utils.{CSV, SessionManager}
//import org.apache.spark.sql.{Dataset, Row}
//import org.scalatest.{ FlatSpec, Matchers}
//import schema.RegionalTimeBand30.RegTimeBand30
//import etljobs.bigquery.QueryApi
//import etljobs.south_regional.timeBand30.EtlJobRegional
//import util.MintGlobalProperties
//
//class EtlRegBQTestSuite extends FlatSpec with Matchers  {
//  val canonical_path = new java.io.File(".").getCanonicalPath
//  val global_properties = new MintGlobalProperties(canonical_path + "/mint/src/test/resources/loaddata.properties")
//
//  val job_properties = Map(
//      "job_name" -> "EtlJobEntTb30" ,
//      "job_input_path" -> s"$canonical_path/src/test/resources/input/reg_time_band_30/year=2019/week=41/raw" ,
//      "job_output_path" -> s"$canonical_path/src/test/resources/output/reg_time_band_30/year=2019/week=41/",
//      "output_dataset" -> "test",
//      "output_table_name" -> "reg_time_band_30_test",
//      "debug" -> "true",
//      "test"->"true"
//  )
//
//
//  val sm = new SessionManager(global_properties) {}
//
//  val etljob = new EtlJobRegional(job_properties, global_properties)
//  val state = etljob.execute()
//  println(state)
//
//
//  val destination_dataset = job_properties("output_dataset")
//  val destination_table = job_properties("output_table_name")
//
//  val raw : Dataset[RegTimeBand30] = ReadApi.LoadDS[RegTimeBand30](
//    Seq(job_properties("job_input_path")+"/gec/*"),
//    CSV("|", true)
//  )(sm.spark)
//  val transformed  = etljob.enrichRegionalTimeBand30(sm.spark,job_properties)(raw)
//
//  val count_records_transformed:Long  = transformed.count
//  val Row(sum_ratings_transformed:Double) = transformed.selectExpr("""sum(ratings)""").first()
//  val Row(sum_duration_transformed:Long) = transformed.selectExpr("""sum(real_length_sec_sum)""").first()
//  val Row(sum_impressions_transformed:Double) = transformed.selectExpr("""sum(impressions)""").first()
//
//  val query:String  =s""" select count(*) as count,
//                          sum(ratings) sum_ratings,
//                          sum(real_length_sec_sum) sum_duration,
//                          sum(impressions) sum_impressions
//                          from $destination_dataset.$destination_table """.stripMargin
//
//  val result:Iterable[FieldValueList] = QueryApi.getDataFromBQ(sm.bq, query)
//  val count_records_df_bq:Long = result.head.get("count").getLongValue
//  val sum_ratings_df_bq:Double = result.head.get("sum_ratings").getDoubleValue
//  val sum_duration_df_bq:Long = result.head.get("sum_duration").getLongValue
//  val sum_impressions_df_bq:Double = result.head.get("sum_impressions").getDoubleValue
//
//  "Record counts" should "be matching in orc dataframe and BQ table " in {
//    assert(count_records_transformed==count_records_df_bq)
//  }
//
//  "Sum of ratings" should "be matching in orc dataframe and BQ table " in {
//    assert("%.4f".format(sum_ratings_transformed).toDouble=="%.4f".format(sum_ratings_df_bq).toDouble)
//  }
//
//  "Sum of duration" should "be matching in orc dataframe and BQ table" in {
//    assert(sum_duration_transformed==sum_duration_df_bq)
//  }
//
//  "Sum of impressions" should "be matching in orc dataframe and BQ table" in {
//    assert("%.4f".format(sum_impressions_transformed).toDouble=="%.4f".format(sum_impressions_df_bq).toDouble)
//  }
//
//}
//
//
