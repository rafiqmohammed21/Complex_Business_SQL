package etljobs.wooqer

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsWithOutRefreshDates
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.wooqer.Wooqer.{WooqerData, WooqerDataEnrich}
import util.MintGlobalProperties

/** Object EtlJobWooqer gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobWooqer(
                         val job_properties:MintEtlJobProps,
                         val global_properties: Option[GlobalProperties]
                  )
  extends  SequentialEtlJob with SparkManager {


  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]

  def enrichDfWooqer(spark: SparkSession,dataset: Dataset[WooqerData]) : Dataset[WooqerDataEnrich]={

    val mapping = Encoders.product[WooqerDataEnrich] //channel_name region
    dataset
      .withColumnRenamed("client_name","advertiser_group")
      .withColumnRenamed("channel","channel_name")
      .withColumnRenamed("store","region")
      .withColumn("genre_campaign_size", col("genre_campaign_size").cast(DoubleType))
      .withColumn("our_pitch", col("our_pitch").cast(DoubleType))
      .withColumn("campaign_phasing_first_month_value", col("campaign_phasing_first_month_value").cast(DoubleType))
      .withColumn("campaign_phasing_second_month_value", col("campaign_phasing_second_month_value").cast(DoubleType))
      .withColumn("campaign_phasing_third_month_value", col("campaign_phasing_third_month_value").cast(DoubleType))
      .withColumn("campaign_phasing_fourth_month_value", col("campaign_phasing_fourth_month_value").cast(DoubleType))
      .as[WooqerDataEnrich](mapping)
  }

  val query_alias =
    """ (SELECT * FROM wooqer) t """.stripMargin

  val step1 = SparkReadTransformWriteStep[WooqerData, WooqerDataEnrich](
    name                    = "Load_Jdbc_wooqer",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichDfWooqer,
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_wooqer_BQ",
    input_location             =  Left(props.job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}