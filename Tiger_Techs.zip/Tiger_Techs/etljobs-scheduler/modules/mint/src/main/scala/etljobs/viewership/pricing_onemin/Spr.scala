package etljobs.viewership.pricing_onemin

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{Dataset, Row, SparkSession}
import schema.Format.{DISPROffSetSchema, MMAdvertiserGroups, MMAdvertisers, MMChannels, MMProposalBookingEntries, MMProposals, MMTGMarkets}
import udfs.{Common, PricingOneMin}
import util.{MasterJdbcConn, MintGlobalProperties}

class Spr(spark:SparkSession)(implicit jdbc_conn:Map[String,String]) extends Serializable with PricingOneMin with MasterJdbcConn with Common  {

  def sprOffSetDataPreparation(source:Dataset[Row],conf: MintGlobalProperties)={
    val AdvertiserSourceDataSet = FetchMasterData(conf.MM_advertiser_table,select_clause=MMAdvertisers,spark=spark, conf=conf).select("onair_id","txn_group_id")
      .toDF("advertiser_id_master", "txn_group_id")
      .distinct()
      .join(FetchMasterData(conf.MM_advertiser_group_table,select_clause=MMAdvertiserGroups,spark=spark, conf=conf)
        .select("id", "name")
        .toDF("txn_group_id", "advertiser_group").distinct()
        ,Seq("txn_group_id"), "inner")
      .select("advertiser_id_master", "advertiser_group")
      .distinct()

    val SPRWithAdvMasterDF      = source.join(AdvertiserSourceDataSet,Seq("advertiser_id_master"),"left")
    val SPRMasterDF             = SPRWithAdvMasterDF.withColumn("duration",get_duration_udf(lit("spr"),col("duration")))
      .orderBy("aired_time")
    val SPROffsetSourceDF       = SPRMasterDF.select((DISPROffSetSchema ++ Seq("advertiser_group")).head,(DISPROffSetSchema ++ Seq("advertiser_group")).tail:_*)

    SPROffsetSourceDF.toDF("year","week","advertiser_id_master","channel","date","length","spr_aired_time","timeband","advertiser_group")
  }

  def getMintMasterData(conf: MintGlobalProperties)= {
    (FetchMasterData(conf.MM_proposal_booking_entries_table,select_clause=MMProposalBookingEntries,spark=spark,conf=conf)
      .select("deal_id", "proposal_id")
      .where("reconcile_status=true")
      .select("deal_id", "proposal_id")
      .toDF("deal_number", "proposal_id")
      .distinct,

      FetchMasterData(conf.MM_proposals_table,select_clause=MMProposals,spark=spark,conf=conf)
        .select("id", "primary_tgmkt_id", "secondary_tgmkt_id")
        .toDF("proposal_id", "primary_tgmarket_id", "secondary_tgmarket_id")
        .distinct,

      FetchMasterData(conf.MM_tg_markets_table,select_clause=MMTGMarkets,spark=spark,conf=conf)
        .select("id", "name")
        .toDF("primary_tgmarket_id", "tgmarket_name"),
      FetchMasterData(conf.MM_tg_markets_table,select_clause=MMTGMarkets,spark=spark,conf=conf)
        .select("id", "name")
        .toDF("secondary_tgmarket_id", "tgmarket_name"),
      FetchMasterData(conf.MM_channel_table,select_clause=MMChannels,spark=spark,conf=conf)
        .select("name", "channel_tgmarket")
        .toDF("channel_name", "channel_tgmarket")
        .withColumn("channel_tgmarket",FillArr(col("channel_tgmarket"))))
  }

  def sprGRPMasterDataPreparation(source:Dataset[Row],conf: MintGlobalProperties) = {
    val SPRMinuteSource          = source.filter(col("aired_time").notEqual(" ")).filter(col("aired_time").notEqual(""))
    val SPRMinuteProposalbookings= SPRMinuteSource.join(getMintMasterData(conf)._1,Seq("deal_number"),"left")
    val SPRMinuteProposals       = SPRMinuteProposalbookings.join(getMintMasterData(conf)._2,Seq("proposal_id"),"left")
    val SPRMinuteTGMARKET        = SPRMinuteProposals.join(getMintMasterData(conf)._3,Seq("primary_tgmarket_id"),"left").withColumnRenamed("tgmarket_name", "client_primary")
    val SPRMinuteSecTGMARKET     = SPRMinuteTGMARKET.join (getMintMasterData(conf)._4,Seq("secondary_tgmarket_id"), "left").withColumnRenamed("tgmarket_name", "client_secondary")
    val SPRMinuteChannel         = SPRMinuteSecTGMARKET.join(getMintMasterData(conf)._5,Seq("channel_name"),"left")
    SPRMinuteChannel
  }

  def sprGRPDatawithOffsetPreparation(source:Dataset[Row],offsetsource:Dataset[Row]) = {
    source.withColumn("channel",RemCharConvertToCap(col("channel_name"),"\\s+",""))
      .join(offsetsource,Seq("year","week","channel","date"),"left").na.fill("0",Seq("offset"))
      .withColumn("aired_time",AddSectoTime(col("aired_time"),col("offset")))
      .withColumn("timeband",MinTimeBand(col("aired_time")))
      .withColumn("duration",col("duration")/1000 cast(IntegerType))
  }

  def sprGRPDataWithTimeBandExplode(source:Dataset[Row])={
    source.withColumn("time_band_extended",RecursiveTime(col("aired_time"),col("timeband"),col("duration")))
      .withColumn("time_band_exploded",explode(col("time_band_extended")))
      .withColumn("time_band_splitted",split(col("time_band_exploded"),"#"))
      .withColumn("new_duration",col("time_band_splitted").getItem(0))
      .withColumn("timeband",col("time_band_splitted").getItem(1))
  }

  def sprGRPDataTGMarketsRetrofit(source:Dataset[Row])={
    source.na.fill("NA",Seq("client_primary","client_secondary"))
      .withColumn("channel_tgmarket", when(col("channel_tgmarket").isNull,array(lit("na"),lit("na"),lit("na")))
        .otherwise(col("channel_tgmarket")))
      .withColumn("channel_primary",RemCharConvertToCap(col("channel_tgmarket").getItem(0),"\\s+",""))
      .withColumn("channel_generic",RemCharConvertToCap(col("channel_tgmarket").getItem(2),"\\s+",""))
      .withColumn("client_primary",RemCharConvertToCap(col("client_primary"),"\\s+",""))
      .withColumn("client_secondary",RemCharConvertToCap(col("client_secondary"),"\\s+",""))
  }

}
