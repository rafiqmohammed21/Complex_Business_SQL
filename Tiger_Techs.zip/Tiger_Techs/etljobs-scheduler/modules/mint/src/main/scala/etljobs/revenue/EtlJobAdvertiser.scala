package etljobs.revenue

import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenueProps
import org.apache.spark.sql.{Dataset, Encoders, SaveMode}
import schema.master.EntAdvertiserMaster.{AdvertiserDetailInfoBQ, AdvertiserDetailInfoPostGre}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql._
import _root_.util.MintGlobalProperties
import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.spark.SparkManager

// Job specific imports
/** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */
case class EtlJobAdvertiser(
                             val job_properties: MintEtlJobProps,
                             val global_properties: Option[GlobalProperties]
                      )
  extends SequentialEtlJob  with SparkManager {

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenueProps = job_properties.asInstanceOf[RevenueProps]

  def revenueAdvertiserTransform(props:RevenueProps)(spark: SparkSession,dataset: Dataset[AdvertiserDetailInfoPostGre]) : Dataset[AdvertiserDetailInfoBQ]={
    import spark.implicits._

    val mapping = Encoders.product[AdvertiserDetailInfoBQ]
    output_date_paths=dataset
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    dataset.as[AdvertiserDetailInfoBQ](mapping)

  }

  val months = props.refresh_dates.split(",").toList

  val query_alias  = s""" (SELECT * FROM (SELECT *, to_date(concat(year_month,'01'),'yyyyMMdd') as date
                ,concat(year_month,'01') as date_int
                FROM  ${props.job_input_path} ) a WHERE year_month in (${props.refresh_dates}) ) t""".stripMargin

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val step1 = SparkReadTransformWriteStep[AdvertiserDetailInfoPostGre, AdvertiserDetailInfoBQ](
    name                    = "Load_Jdbc_advertiser_GCP",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = revenueAdvertiserTransform(props),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )

  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_advertiser_BQ",
    input_location =        Right(output_date_paths),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}
