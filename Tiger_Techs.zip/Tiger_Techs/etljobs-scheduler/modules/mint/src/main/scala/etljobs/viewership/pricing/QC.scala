package etljobs.viewership.pricing

import etlflow.spark.ReadApi
import etlflow.utils.{CSV, GlobalProperties}
import etljobs.MintEtlJobProps.PricingJobProps
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, Row, SparkSession}
import org.apache.spark.sql.functions.{broadcast, col, lit, sum}
import org.apache.spark.sql.types.{DecimalType, DoubleType, IntegerType, StringType}
import schema.Format.{DIPricingDestination, DIPricingQc, DIPricingRaw}
import schema.viewership.Pricing._
import udfs.{Common, Pricing}
import util.MintGlobalProperties

class QC extends Pricing with Common  {

  @transient val pricing_logger = Logger.getLogger(getClass.getName)

  def validation( run_type:String, year_week_df: DataFrame,global_properties: Option[GlobalProperties])(spark: SparkSession,ip:Unit) = {
    val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

    pricing_logger.info(s"STEP 1) => Starting BARC Validation process between Raw and Qc for Pricing")

    val BARCSource = run_type match {
      case "Ingestion_Weekly" =>
        {
          pricing_logger.info(s"Inside Ingestion_Weekly")
          (ReadApi.LoadDS[PricingRawOrigin](Seq(mint_global_properties.DI_input_pricing_path),CSV(delimiter="|",quotechar="\"",header_present = true),s"UPPER(target) != 'TARGET'")(spark = spark).toDF(DIPricingRaw:_*),
           ReadApi.LoadDS[PricingQcOrigin]( Seq(mint_global_properties.DI_input_pricing_qc_path),CSV(delimiter="|",quotechar="\"",header_present = true),s"UPPER(target) != 'TARGET'")(spark = spark).toDF(DIPricingQc:_*)
             .select("sno","channel","target","region","level","ev_type","length","rat_percent","year","week"))

        }
      case "Ingestion_NewTG"  =>
        {
          pricing_logger.info(s"Inside Ingestion_NewTG")
          (ReadApi.LoadDS[PricingRawNewTGOrigin](Seq(mint_global_properties.DI_input_pricing_newtg_path),CSV(delimiter="|",quotechar="\"",header_present = true),s"UPPER(target) != 'TARGET'")(spark = spark).toDF(DIPricingRaw:_*),
           ReadApi.LoadDS[PricingQcNewTGOrigin](Seq(mint_global_properties.DI_input_pricing_qc_newtg_path),CSV(delimiter="|",quotechar="\"",header_present = true),s"UPPER(target) != 'TARGET'")(spark = spark).toDF(DIPricingQc:_*)
             .select("sno","channel","target","region","level","ev_type","length","rat_percent","year","week"))

        }
    }

    val BARCRawSource = BARCSource._1.join(year_week_df,Seq("year","week"),"inner")
    val BARCSumSource  = BARCSource._2.join(year_week_df,Seq("year","week"),"inner")

    val BarcRawSourceDF           = BARCRawSource.withColumn("timeband",timebandsplit(col("start_time")))

    val BarcRawSourceRetrofitDF  =  MultipleWithColtoRetrofit(BarcRawSourceDF, Seq("channel","target","region","ev_type","level")).cache()


    val BarcRawSourceTMPDF        = BarcRawSourceRetrofitDF.select(col("year"), col("week"), col("tmp_channel"), col("tmp_target"), col("tmp_region"), col("tmp_level"), col("tmp_ev_type"), col("length"), ((col("length") * col("rat_percent")) / 10).as("GPRS"))
    val BarcRawSourceAggDF        = BarcRawSourceTMPDF.groupBy("year", "week", "tmp_channel", "tmp_target", "tmp_region", "tmp_level", "tmp_ev_type")
      .agg(sum("length").cast(IntegerType).cast(StringType).alias("raw_sum_length"), sum(col("GPRS"))
        .alias("raw_sum_gprs"))
      .withColumn("raw_rat_percent", avgtvrcal(col("raw_sum_length"), col("raw_sum_gprs"),lit("ceil")))
      .withColumn("raw_rat_percent_floor", avgtvrcal(col("raw_sum_length"), col("raw_sum_gprs"), lit("floor")))
      .drop("raw_sum_gprs")

    val BarcSumSourceRetrofitDF  = MultipleWithColtoRetrofit(BARCSumSource.asInstanceOf[DataFrame], Seq("channel","target","region","ev_type","level")).cache()
    val BarcSumSourceAggDF       = BarcSumSourceRetrofitDF.select(col("week"),col("tmp_channel"),col("tmp_target"),col("tmp_region"),col("tmp_ev_type"),col("tmp_level"),col("length"), col("rat_percent")).distinct

    pricing_logger.info("Calculating weighted avg and summary length of qc file")
    val BarcSumLengthAggDF = BarcSumSourceAggDF.groupBy("week", "tmp_channel", "tmp_target", "tmp_region", "tmp_level", "tmp_ev_type").agg(sum("length").alias("sum_length"))
    val BarcSumRatWeightAvgDF = BarcSumSourceAggDF.withColumn("rat_percent",col("length")*col("rat_percent")).groupBy("week", "tmp_channel", "tmp_target", "tmp_region", "tmp_level", "tmp_ev_type").agg(sum("rat_percent").alias("rat_percent"))
    val BarcSumAggDF = BarcSumLengthAggDF.join(BarcSumRatWeightAvgDF,Seq("week", "tmp_channel", "tmp_target", "tmp_region", "tmp_level", "tmp_ev_type"),"inner").withColumn("rat_percent",col("rat_percent")/col("sum_length"))

    pricing_logger.info("Validation based on length and avg rating percentage--invalid records")

    val InvalidRecComb           = BarcSumAggDF.join(BarcRawSourceAggDF, Seq("week", "tmp_channel", "tmp_target", "tmp_region", "tmp_level", "tmp_ev_type"), "inner")
      .withColumn("diff_rat_percent",col("raw_rat_percent").cast(DoubleType)-col("rat_percent").cast(DoubleType))
      .where("sum_length != raw_sum_length or diff_rat_percent > 0.0001 or diff_rat_percent < -0.0001")
      .select("year", "week", "tmp_channel", "tmp_target", "tmp_region", "raw_sum_length")

    pricing_logger.info("Validation based on length and avg rating percentage--valid records")

    val ValidRecordsDF           = BarcRawSourceRetrofitDF.join(broadcast(InvalidRecComb), Seq("year", "week", "tmp_channel", "tmp_target", "tmp_region"), "left")
      .where("raw_sum_length is null")
      .withColumn("date", newdateformat(col("dt_date")))
      .drop(Seq("tmp_channel", "tmp_target",
        "tmp_region", "tmp_ev_type", "tmp_level",
        "GPRS", "raw_sum_length","dt_date"): _*)

    val InvalidRecCombDF          = InvalidRecComb.drop("raw_sum_length")
      .toDF("year", "week", "channel", "target", "region")

    if (BarcRawSourceAggDF.count <= BarcSumAggDF.count && InvalidRecCombDF.count==0) {
      pricing_logger.info("Validation is success")
    }
    else throw new Exception("Validation is failed")

  }

  def IngestionWeekly  (year_week_df:DataFrame)(spark : SparkSession, dataset : Dataset[PricingRawOrigin]) = Ingestion(spark, year_week_df:DataFrame)(dataset.asInstanceOf[Dataset[Row]])
  def IngestionNewTG   (year_week_df:DataFrame)(spark : SparkSession,  dataset : Dataset[PricingRawNewTGOrigin])= Ingestion(spark, year_week_df:DataFrame)(dataset.asInstanceOf[Dataset[Row]])

  def Ingestion(spark:SparkSession, year_week_df:DataFrame)(dataset:Dataset[Row]) :Dataset[PricingRawDestination] = {
    val encoder = Encoders.product[PricingRawDestination]

    val final_dataset = dataset
      .toDF(DIPricingRaw:_*)
      .join(year_week_df,Seq("year","week"),"inner")
      .filter(s"UPPER(target) != 'TARGET'")
      .withColumn("timeband",timebandsplit(col("start_time")))
      .withColumn("date", newdateformat(col("dt_date")))
      .withColumn("length",col("length") cast IntegerType)
      .withColumn("rat_percent",col("rat_percent") cast DecimalType(16,6))
      .withColumn("impressions_000",col("impressions_000") cast DecimalType(16,6))
      .withColumn("target_000",col("target_000") cast DecimalType(16,6))
      .select(DIPricingDestination.head,DIPricingDestination.tail:_*)
      .as[PricingRawDestination](encoder)
    final_dataset

  }
}
