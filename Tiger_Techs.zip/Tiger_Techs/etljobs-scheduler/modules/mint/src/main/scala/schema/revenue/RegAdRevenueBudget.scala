package schema.revenue

object RegAdRevenueBudget {

  case class RegAdRevenueBudget (
                                 Channel_name : String,
                                 year: Int,
                                 month: String,
                                 budget_revenue: Double,
                                 deployed: Double,
                                 region: String,
                                 ecs_group: String,
                                 deployed_regular: String,
                                 deployed_impact: String,
                                 budget_regular: String,
                                 budget_impact: String
                                )
  case class RegAdRevenueBudgetEnriched (
                                            Channel_name : String,
                                            year: Int,
                                            month: Int,
                                            budget_revenue: Double,
                                            deployed: Double,
                                            region: String,
                                            ecs_group: String,
                                            deployed_regular: String,
                                            deployed_impact: String,
                                            budget_regular: String,
                                            budget_impact: String
                                        )
}
