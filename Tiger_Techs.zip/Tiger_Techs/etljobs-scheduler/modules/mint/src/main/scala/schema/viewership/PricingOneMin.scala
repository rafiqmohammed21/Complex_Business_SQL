package schema.viewership

import java.sql.Date

import org.apache.spark.sql.types.Decimal

object PricingOneMin {

  final case class PricingOneMinRawSchema(
                                           year:String,
                                           week:String,
                                           Target:String,
                                           Region:String,
                                           Channel:String,
                                           Date:String,
                                           TimeBand:String,
                                           `Impressions'000`:String,
                                           `Audience'000`:String
                                         )

  final case class PricingOneMinOffsetSchema(year:String,
                                             week:String,
                                             channel:String,
                                             offset:String,
                                             audit:String,
                                             hour:String,
                                             date:String
                                            )
  final case class SprOffsetSchema(
                                    advertiser_id_master:String,
                                    channel_name:String,
                                    date:String,
                                    duration:Int,
                                    aired_time:String,
                                    time_band:String
                                  )

  final case class DISPROffSetSchema( year:String,
                                      week:String,
                                    advertiser_id_master:String,
                                    channel_name:String,
                                    date:String,
                                    duration:Int,
                                    aired_time:String,
                                    time_band:String
                                  )


  final case class PricingOffsetSchema(
                                        channel:String,
                                        date:String,
                                        advertiser:String,
                                        brand:String,
                                        length:Integer,
                                        level:String,
                                        start_time:String,
                                        timeband:String
                                      )

  final case class DIPricingOffSetSchema(
                                          year:String,
                                          week:String,
                                        channel:String,
                                        date:String,
                                        advertiser:String,
                                        brand:String,
                                        length:Integer,
                                        level:String,
                                        start_time:String,
                                        timeband:String
                                      )


  final case class PricingOneMinGRPSchema(channel_id:String,
                                          channel_name:String,
                                          telecast_date:String,
                                          advertiser_id_master :Integer,
                                          advertiser_name_master:String,
                                          agency_id:String,
                                          agency_name:String,
                                          program_id:String,
                                          program_name:String,
                                          sales_unit_pool_id:String,
                                          sales_unit_pool_name:String,
                                          aired_time:String,
                                          duration:Integer,
                                          pitched_price:Decimal,
                                          rc_name:String,
                                          rc_price:Decimal,
                                          commercial_material:String,
                                          brand:String,
                                          deal_name:String,
                                          deal_number:String,
                                          sales_location:String,
                                          spot_status:String,
                                          revenue_classification:String,
                                          currency:String,
                                          event_status:String,
                                          commercial_type:String,
                                          currency_id :Integer,
                                          advertiser_name_child:String,
                                          gstin_number_buyer:String,
                                          house_no:String,
                                          prod_cat:String,
                                          plan:String,
                                          plan_number:String,
                                          po_no:String,
                                          deal_type:String,
                                          sales_team:String,
                                          sales_executive:String,
                                          entity_state:String,
                                          entity_gstin_number:String,
                                          deal_status:String,
                                          plan_status:String,
                                          break_block_type:String,
                                          content_type:String,
                                          spot_id:String,
                                          spot_rate_in_inr:String,
                                          time_band:String,
                                          cl_pr_grp:Double,
                                          cl_sec_grp:Double,
                                          ch_pr_grp:Double,
                                          ch_gen_grp:Double,
                                          year:Integer,
                                          week:Integer,
                                          date:Date)

}