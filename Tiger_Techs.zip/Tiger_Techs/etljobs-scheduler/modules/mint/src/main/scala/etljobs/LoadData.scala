package etljobs

import etlflow.EtlJobApp
import etlflow.etljobs.EtlJob
import etljobs.MintEtlJobName.{EtlJobAdvertiserDetails, EtlJobDistributionActiveUniverse, EtlJobDistributionChannelBouquet, EtlJobDistributionData, EtlJobEntProvisions, EtlJobFunnel, _}
import util.MintGlobalProperties

import scala.util.Try

object LoadData extends EtlJobApp[MintEtlJobName[MintEtlJobProps], MintEtlJobProps, MintGlobalProperties] {

  override def globalProperties: Option[MintGlobalProperties] = Try(new MintGlobalProperties(sys.env.getOrElse("PROPERTIES_FILE_PATH", "loaddata_new.properties"))).toOption

  override val etl_job_name_package: String = my_job_package

  def toEtlJob(job_name: MintEtlJobName[MintEtlJobProps]): (MintEtlJobProps, Option[MintGlobalProperties]) => EtlJob = {
    job_name match {
      case EtlJobBarcWeekMonthToDate             => etljobs.master.barc_week_month_to_date.EtlJobBarcWeekMonthToDate
      case EtlJobHotstarMasterMapping            => etljobs.hotstar.mapping.EtlJobHotstarMasterMapping
      case EtlJobDistributionActiveUniverse      => etljobs.distribution.EtlJobDistributionActiveUniverse
      case EtlJobDistributionChannelBouquet      => etljobs.distribution.EtlJobDistributionChannelBouquet
      case EtlJobDistributionData                => etljobs.distribution.EtlJobDistributionData
      case EtlJobEntProvisions                   => etljobs.revenue.EtlJobEntProvisions
      case EtlJobFunnel                          => etljobs.revenue.EtlJobFunnel
      case EtlJobAdvertiserDetails               => etljobs.revenue.EtlJobAdvertiser
      case EtlJobDealInfo                        => etljobs.revenue.EtlJobDeal
      case EtlJobSalesUnit                       => etljobs.revenue.EtlJobSalesUnit
      case EtlJobRO                              => etljobs.revenue.EtlJobRo
      case EtlJobEntRegAdRevenueCPRP             => etljobs.revenue.ent_ad.EtlJobEntRegAdRevenueCPRP
      case EtlJobEntRegAdRevenueTarget           => etljobs.revenue.ent_ad.EtlJobEntRegAdRevenueTarget
      case EtlJobEntRegAdvertiserMaster          => etljobs.master.EtlJobEntRegAdvertiserMaster
      case EtlJobEntRegChannelMaster             => etljobs.master.EtlJobEntRegChannelMaster
      case EtlJobEntRegMonthWiseAgency           => etljobs.master.EtlJobEntRegMonthWiseAgency
      case EtlJobOnairSalesUnitTaggings          => etljobs.master.EtlJobOnairSalesUnitTaggings
      case EtlJobWooqer                          => etljobs.wooqer.EtlJobWooqer
      case EtlJobWooqerUniverse                  => etljobs.wooqer.EtlJobWooqerUniverse
      case EtlJobFactRevBQ                       => etljobs.sales_dashboard.EtlJobFactRevBQ
      case EtlJobFactViewBQ                      => etljobs.sales_dashboard.EtlJobFactViewBQ
      case EtlJobFactRegSpot                     => etljobs.sales_dashboard.EtlJobFactRegSpot
      case EtlJobFactRegTB30                     => etljobs.sales_dashboard.EtlJobFactRegTB30
      case EtlJobRefreshViewsPG                  => etljobs.sales_dashboard.EtlJobRefreshViewsPG
      case EtlJobFactTablesV1                    => etljobs.sales_dashboard.EtlJobFactTablesV1
      case EtlJobSprReg                          => etljobs.sales_dashboard.EtlJobSprReg
      case EtlJobDistributionRevenue             => etljobs.distribution.EtlJobDistributionRevenue
      case EtlJobDistributionSubscription        => etljobs.distribution.EtlJobDistributionSubscription
      case EtlJobDistributionIncentive           => etljobs.distribution.EtlJobDistributionIncentive
      case EtlJobDistributionActiveUniverse      => etljobs.distribution.EtlJobDistributionActiveUniverse
      case EtlJobDistributionChannelBouquet      => etljobs.distribution.EtlJobDistributionChannelBouquet
      case EtlJobHotstarEnt                      => etljobs.hotstar.entertainment.EtlJobHotstarEnt
      case EtlJobHotstarEntSteps                 => etljobs.hotstar.entertainment.EtlJobHotstarEntSteps
      case EtlJobHotstarSports                   => etljobs.hotstar.sports.EtlJobHotstarSports
      case EtlJobHotstarSportSteps               => etljobs.hotstar.sports.EtlJobHotstarSportSteps
      case EtlJobChannelMasterMapping            => etljobs.master.EtlJobChannelMasterMapping
      case EtlJobPrismSportTournament            => etljobs.sports.EtlJobPrismSportTournament
      case EtlJobProgLogsSports                  => etljobs.sports.EtlJobProgLogsSports
      case EtlJobDistributionData                => etljobs.distribution.EtlJobDistributionData
      case EtlJobSportsSeasonEvent               => etljobs.master.EtlJobSportsSeasonEvent
      case EtlJobSportsOnairTillBarcDate         => etljobs.master.EtlJobSportsOnairTillBarcDate
      case EtlJobSportsOnairAfterBarcDate        => etljobs.master.EtlJobSportsOnairAfterBarcDate
      case EtlJobSportsViewershipMapping         => etljobs.master.EtlJobSportsViewershipMapping
      case EtlJobSportsBarcMonth                 => etljobs.master.EtlJobSportsBarcMonth
      case EtlJobPricing                         => etljobs.viewership.pricing.EtlJobPricing
      case EtlJobPricingGcsSensor                         => etljobs.viewership.pricing.EtlJobPricingGcsSensor
      case EtlJobPricingNewTG                    => etljobs.viewership.pricing.EtlJobPricingNewTG
      case EtlJobNamePricingOneMin               => etljobs.viewership.pricing_onemin.EtlJobPricingOneMin
      case EtlJobNamePricingOneMinGcsSensor      => etljobs.viewership.pricing_onemin.EtlJobPricingOneMinGcsSensor
      case EtlJobDownload                        => etljobs.download.EtlJobDownload
      case EtlJobDistManagementAllocation        => etljobs.revenue.EtlJobDistManagementAllocation
      case EtlJobDistStatAllocation              => etljobs.revenue.EtlJobDistStatAllocation
      case EtlJobDistUnbilledDeferred            => etljobs.revenue.EtlJobDistUnbilledDeferred
      case EtlJobDistIncentiveAccrued            => etljobs.revenue.EtlJobDistIncentiveAccrued
      case EtlJobBarcImpactTaggings              => etljobs.master.EtlJobEntRegBarcImpactTaggings
      case EtlJobSportsFinanceRevenueMatchWise   => etljobs.master.sport_finance.EtlJobSportsFinanceRevenueMatchWise
      case EtlJobSportsFinanceRevenueMonthWise   => etljobs.master.sport_finance.EtlJobSportsFinanceRevenueMonthWise
      case EtlJobRevenueCalender                 => etljobs.master.revenue_calender.EtlJobRevenueCalender
      case EtlJobFactRevAdvertiserMappings       => etljobs.sales_dashboard.EtlJobFactRevAdvertiserMappings
      case EtlJobRegChannelMaster                => etljobs.master.EtlJobRegChannelMaster
      case EtlJobRegAdvertiserMaster             => etljobs.master.EtlJobRegAdvertiserMaster
      case EtlJobFactTablesCommon                => etljobs.sales_dashboard.EtlJobFactTablesCommon
      case EtlJobDummy                           => etljobs.sales_dashboard.EtlJobDummy
      case EtlJobBIAdvertiserMaster              => etljobs.master.EtlJobBIAdvertiserMaster
      case DataTransfer                          => etljobs.datatransfer.DataTransferJob
      case EtlJobEntSpotRatings                  => etljobs.south_regional.spot_rating.EtlJobSpotRating
      case EtlJobRegSpotRatings                  => etljobs.south_regional.spot_rating.EtlJobSpotRating
      case EtlJobRegTb30                         => etljobs.south_regional.timeBand30.EtlJobTb30
      case EtlJobEntTb30                         => etljobs.south_regional.timeBand30.EtlJobTb30
      case EtlJobEntSpotRatingsQc                =>  etljobs.south_regional.spot_rating.EtlJobSpotRatingQc
      case EtlJobRegSpotRatingsQc                =>  etljobs.south_regional.spot_rating.EtlJobSpotRatingQc
      case EtlJobRegTb30Qc                       =>  etljobs.south_regional.timeBand30.EtlJobTb30Qc
      case EtlJobEntTb30Qc                       =>  etljobs.south_regional.timeBand30.EtlJobTb30Qc
      case EtlJobBIChannelMaster                 =>  etljobs.master.EtlJobBIChannelMaster
      case EtlJobRegAdRevenueDeployed            =>  etljobs.revenue.EtlJobRegAdRevDeployed
      case EtlJobRegAdRevenueBudget              =>  etljobs.revenue.EtlJobRegAdRevBudget
      case EtlJobDistPackageTagMaster            => etljobs.master.EtlJobDistPackageTagMaster


    }
  }
}