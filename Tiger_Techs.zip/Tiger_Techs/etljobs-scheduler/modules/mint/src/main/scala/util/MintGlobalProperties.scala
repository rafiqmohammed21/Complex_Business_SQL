package util

import etlflow.utils.GlobalProperties

class MintGlobalProperties(properties_file:String) extends GlobalProperties(properties_file){

  /*Common Settings*/


  lazy val environment                  = config.getProperty("environment")
  lazy val gcs_cred_json                = config.getProperty("gcs_cred_json")

  lazy val business                     = config.getProperty("business")
  lazy val business_jdbc_conn           = config.getProperty("business_jdbc_conn")

  lazy val MM_channel_source_table      = config.getProperty("MM_channel_source_table")
  lazy val MM_channel_table             = config.getProperty("MM_channel_table")
  lazy val MM_advertiser_table          = config.getProperty("MM_advertiser_table")
  lazy val MM_advertiser_group_table    = config.getProperty("MM_advertiser_group_table")
  lazy val MM_advertiser_cat_table      = config.getProperty("MM_advertiser_cat_table")
  lazy val MM_agency_table              = config.getProperty("MM_agency_table")
  lazy val MM_agency_group_table        = config.getProperty("MM_agency_group_table")
  lazy val MM_deals_table               = config.getProperty("MM_deals_table")
  lazy val MM_proposal_booking_entries_table = config.getProperty("MM_proposal_booking_entries_table")
  lazy val MM_proposals_table           = config.getProperty("MM_proposals_table")
  lazy val MM_product_revenues          = config.getProperty("MM_product_revenues")
  lazy val MM_definition_rules_table    = config.getProperty("MM_definition_rules")
  lazy val MM_locations_table           = config.getProperty("MM_spr_locations_table")
  lazy val MM_sales_units_table         = config.getProperty("MM_sales_units_table")
  lazy val MM_products_table            = config.getProperty("MM_products_table")
  lazy val MM_tg_markets_table          = config.getProperty("MM_tg_markets_table")
  lazy val MM_currencies_table          = config.getProperty("MM_currencies_table")

  lazy val DI_input_spr_path            = config.getProperty("DI_input_spr_path")
  lazy val DI_input_pricing_path        = config.getProperty("DI_input_pricing_path")
  lazy val DI_input_pricing_newtg_path  = config.getProperty("DI_input_pricing_newtg_path")
  lazy val DI_input_pricing_qc_path     = config.getProperty("DI_input_pricing_qc_path")
  lazy val DI_input_pricing_qc_newtg_path = config.getProperty("DI_input_pricing_qc_newtg_path")
  lazy val DI_input_posteval_path       = config.getProperty("DI_input_posteval_path")
  lazy val DI_output_spr_path           = config.getProperty("DI_output_spr_path")
  lazy val DI_output_offset_path        = config.getProperty("DI_output_offset_path")
  lazy val DI_output_posteval_path      = config.getProperty("DI_output_posteval_path")
  lazy val DI_output_pricing_path       = config.getProperty("DI_output_pricing_path")
  lazy val DI_output_pricing_reports_path = config.getProperty("DI_output_pricing_reports_path")
  lazy val DI_output_pricing_cubes_path   = config.getProperty("DI_output_pricing_cubes_path")
  lazy val DI_output_pricing_reports    = config.getProperty("DI_output_pricing_reports")

  lazy val DD_origin_path               = config.getProperty("DD_origin_path")

  lazy val gcs_output_bucket            = sys.env.getOrElse("GCS_OUTPUT_BUCKET", config.getProperty("gcs_output_bucket"))

  lazy val ent_postgre_jdbc_url         = config.getProperty("ent_postgre_jdbc_url")
  lazy val ent_postgre_user             = config.getProperty("ent_postgre_user")
  lazy val ent_postgre_password         = config.getProperty("ent_postgre_password")
  lazy val reg_postgre_jdbc_url         = config.getProperty("reg_postgre_jdbc_url")
  lazy val reg_postgre_user             = config.getProperty("reg_postgre_user")
  lazy val reg_postgre_password         = config.getProperty("reg_postgre_password")
  lazy val sales_db_postgre_jdbc_url    = config.getProperty("sales_db_postgre_jdbc_url")
  lazy val sales_db_postgre_filter_api_jdbc_url    = config.getProperty("sales_db_postgre_filter_api_jdbc_url")
  lazy val sales_db_postgre_user        = config.getProperty("sales_db_postgre_user")
  lazy val sales_db_postgre_password    = config.getProperty("sales_db_postgre_password")
  lazy val postgre_driver               = config.getProperty("postgre_driver")

  lazy val metastar_url                 = config.getProperty("metastar_url")

  lazy val oracle_jdbc_jdbc             = config.getProperty("oracle_jdbc_url_jdbc")
  lazy val oracle_jdbc_credential       = config.getProperty("oracle_jdbc_url_credential")
  lazy val oracle_jdbc_host_name        = config.getProperty("oracle_jdbc_url_host_name")
  lazy val oracle_user                  = config.getProperty("oracle_user")
  lazy val oracle_password              = config.getProperty("oracle_password")
  lazy val oracle_driver                = config.getProperty("oracle_driver")

  lazy val aws_secret                   = sys.env("AWS_SECRET_KEY")
  lazy val aws_access                   = sys.env("AWS_ACCESS_KEY")
  //slack notification level parameter
  lazy val slack_notification_level     = config.getOrDefault("slack_notification_level","info")
  lazy val flyway_db_url     = config.getProperty("log_db_url")
  lazy val flyway_db_user     = config.getProperty("log_db_user")
  lazy val flyway_db_password    = config.getProperty("log_db_pwd")

  lazy val mail_port     = config.getProperty("mail_port")
  lazy val mail_host     = config.getProperty("mail_host")
  lazy val mail_user    = config.getProperty("mail_user")
  lazy val mail_password    = config.getProperty("mail_password")
}
