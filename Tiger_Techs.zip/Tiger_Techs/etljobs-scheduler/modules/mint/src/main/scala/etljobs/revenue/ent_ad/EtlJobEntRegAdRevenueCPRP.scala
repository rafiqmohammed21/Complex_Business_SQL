package etljobs.revenue.ent_ad

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEntWithSalesDB
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions.{col, lower, when}
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.revenue.EntAd.{EntAdRevenueTargetCPRP, EntAdRevenueTargetCPRPEnriched, ViewEntAdRevenueTargetCPRP}
import util.MintGlobalProperties

// Job specific imports
/** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobEntRegAdRevenueCPRP(
                                 val job_properties: MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                               )
  extends SequentialEtlJob with SparkManager  {

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val props : RevenuePropsForRegOrEntWithSalesDB = job_properties.asInstanceOf[RevenuePropsForRegOrEntWithSalesDB]

  def entAdRevenueCPRPTransform(spark:SparkSession, dataset: Dataset[EntAdRevenueTargetCPRP]) : Dataset[EntAdRevenueTargetCPRPEnriched]={

    val mapping  = Encoders.product[EntAdRevenueTargetCPRPEnriched]
    dataset
      .withColumn("value",col("value").cast(DoubleType))
      .withColumnRenamed("channel_group","channel_name")
      .withColumn("month",
        when(lower(col("month")).contains("jan"),1)
          .when(lower(col("month")).contains("feb"),2)
          .when(lower(col("month")).contains("mar"),3)
          .when(lower(col("month")).contains("apr"),4)
          .when(lower(col("month")).contains("may"),5)
          .when(lower(col("month")).contains("jun"),6)
          .when(lower(col("month")).contains("jul"),7)
          .when(lower(col("month")).contains("aug"),8)
          .when(lower(col("month")).contains("sep"),9)
          .when(lower(col("month")).contains("oct"),10)
          .when(lower(col("month")).contains("nov"),11)
          .when(lower(col("month")).contains("dec"),12)
          .otherwise(0) )
      .as[EntAdRevenueTargetCPRPEnriched](mapping)

  }

  val query_alias =
    """ (SELECT * FROM ent_ad_revenue_target_cprp) t """.stripMargin

  val step1 = SparkReadTransformWriteStep[EntAdRevenueTargetCPRP, EntAdRevenueTargetCPRPEnriched](
    name                    = "Load_Jdbc_ent_ad_revenue_cprp",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url,mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = entAdRevenueCPRPTransform,
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_ent_ad_revenue_cprp_BQ",
    input_location             = Left(props.ent_job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.ent_output_dataset,
    output_table       = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step5 = SparkReadTransformWriteStep[EntAdRevenueTargetCPRP, EntAdRevenueTargetCPRPEnriched](
    name                    = "Load_Jdbc_reg_ad_revenue_cprp",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url,mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = entAdRevenueCPRPTransform,
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step6 = BQLoadStep(
    name                    = "Load_Jdbc_reg_ad_revenue_cprp_BQ",
    input_location             = Left(props.reg_job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.reg_output_dataset,
    output_table       = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val reg_query_update_table_from_view  = "SELECT * FROM `mint-bi-reporting.test_reports.ad_revenue_target_cprp`"

  val step7 = BQLoadStep(
    name                    = "Update_BQ_test.ad_revenue_target_cprp_from_view",
    input_location             = Left(reg_query_update_table_from_view),
    input_type           = BQ,
    output_dataset     = "test",
    output_table       = "ad_revenue_target_cprp_from_view",
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val step8 = SparkReadWriteStep[ViewEntAdRevenueTargetCPRP](
    name                    = "Load_Jdbc_ad_Rev_target_cprp",
    input_location          = Seq("test.ad_revenue_target_cprp_from_view"),
    input_type              = BQ,
    output_location         = "ad_revenue_target_cprp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url,mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )

  val etlStepList: List[EtlStep[Unit,Unit]]  =  {
    if (props.bu == "ent") EtlStepList(step1,step2,step7,step8)
    else if (props.bu == "reg") EtlStepList(step5,step6,step7,step8)
    else EtlStepList(step1,step2,step5,step6,step7,step8)
  }

}