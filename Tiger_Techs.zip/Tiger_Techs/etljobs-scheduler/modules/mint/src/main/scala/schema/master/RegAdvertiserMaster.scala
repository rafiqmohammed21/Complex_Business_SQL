package schema.master

object RegAdvertiserMaster {
  case class RegAdvertiserMaster (
                                   Kannada_Region:String,
                                   Telugu_Region:String,
                                   Tamil_Region:String,
                                   Marathi_Region:String,
                                   Advertiser_Common_name:String,
                                   Advertiser_Category:String,
                                   Agency_name:String,
                                   Bengali_Region:String,
                                   source:String,
                                   Malayalam_Region:String,
                                   Advertiser_name:String
                                 )
}
