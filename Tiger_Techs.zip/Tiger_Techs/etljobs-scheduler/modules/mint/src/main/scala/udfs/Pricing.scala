package udfs

import org.apache.spark.sql.functions.udf

trait Pricing {

  val derive_avg_tvr = (length_sum:String,gprs_sum:String,high_or_low:String)=> high_or_low match {
    case "ceil"  => BigDecimal(gprs_sum.toDouble / length_sum.toInt * 10).setScale(6, BigDecimal.RoundingMode.CEILING).toString
    case "floor" => BigDecimal(gprs_sum.toDouble / length_sum.toInt * 10).setScale(6, BigDecimal.RoundingMode.FLOOR).toString
  }

  val derive_date_format = (old_date:String)=>{
    if(old_date.substring(4,5) == "-")
      old_date
    else if(old_date.substring(4,5) == "/")
      old_date.substring(0,4) +"-"+ old_date.substring(5,7) +"-"+ old_date.substring(8,10)
    else
      old_date.substring(6, 10) +"-"+ old_date.substring(0, 2) +"-"+ old_date.substring(3, 5)
  }

  val derive_time_band   = (air_time_input:String)=> {
    val time_format = air_time_input.split(" ")(1)
    val hours = air_time_input.split(" ")(0).split(":")(0)
    val minutes = air_time_input.split(" ")(0).split(":")(1)
    val (start_minutes, end_minutes) = minutes.toInt match {
      case x if (x >= 0 && x < 30) => ("00", "30")
      case x if (x >= 30 && x <= 60) => ("30", "00")}
    val (start_time, end_time) = time_format match {
      case x if x == "AM" && (hours.toInt < 2 || hours.toInt == 12) => if (hours.toInt == 12) (hours.toInt + 12 + "" + start_minutes, if (start_minutes.toInt >= 30) hours.toInt + 13 + "" + end_minutes else hours.toInt + 12 + "" + end_minutes) else (hours.toInt + 24 + "" + start_minutes, if (start_minutes.toInt >= 30) hours.toInt + 25 + "" + end_minutes else hours.toInt + 24 + "" + end_minutes)
      case x if x == "AM" && (hours.toInt >= 2 && hours.toInt != 12) => (hours + "" + start_minutes, if (start_minutes.toInt >= 30 && hours.toInt < 9) "0" + (hours.toInt + 1 + "" + end_minutes) else if (start_minutes.toInt >= 30 && hours.toInt >= 9) (hours.toInt + 1 + "" + end_minutes) else (hours + "" + end_minutes))
      case x if x == "PM" => if (hours.toInt == 12) ((hours.toInt) + "" + start_minutes, if (start_minutes.toInt >= 30) ((hours.toInt + 1) + "" + end_minutes) else ((hours.toInt) + "" + end_minutes)) else ((hours.toInt + 12) + "" + start_minutes, if (start_minutes.toInt >= 30) ((hours.toInt + 13) + "" + end_minutes) else ((hours.toInt + 12) + "" + end_minutes))}
    start_time+"-"+end_time
  }

  val HourTimeBand=(AiredTimeInput:String)=>{
    val AiredTime = AiredTimeInput.split("-")(0)
    val ParseTimeTmp=AiredTime.grouped(2).toList.take(2)
    val Hour = ParseTimeTmp(0)+""+"00"
    val HourUpdated =(ParseTimeTmp(0).toString.toInt+1).formatted("%02d")+""+"00"
    Hour+"-"+HourUpdated
  }


  val avgtvrcal = udf(derive_avg_tvr)
  val newdateformat = udf(derive_date_format)
  val timebandsplit =udf(derive_time_band)
  val HourBand      = udf(HourTimeBand)
}
