package util

import etlflow.spark.ReadApi
import etlflow.utils.JDBC
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import schema.master._

trait MasterJdbcConn {

  def FetchMasterData(master_table: String,where_clause:String = "1=1",select_clause:Seq[String]=Seq("*"),spark: SparkSession,conf: MintGlobalProperties) (implicit  jdbc_conn:Map[String,String] ) = {

    val md_logger = Logger.getLogger(getClass.getName)
    md_logger.info(s"fetching master data for $master_table")

    master_table match {

             case conf.MM_channel_table                 => ReadApi.LoadDS[Channels](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_channel_source_table          => ReadApi.LoadDS[ChannelSources](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause= where_clause)(spark).distinct()
             case conf.MM_advertiser_table              => ReadApi.LoadDS[Advertisers](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_advertiser_group_table        => ReadApi.LoadDS[AdvertiserGroups](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_advertiser_cat_table          => ReadApi.LoadDS[AdvertiserCategories](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_agency_table                  => ReadApi.LoadDS[Agencies](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_agency_group_table            => ReadApi.LoadDS[AgencyGroups](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_deals_table                   => ReadApi.LoadDS[Deals](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_proposal_booking_entries_table => ReadApi.LoadDS[ProposalBookingEntries](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_proposals_table               => ReadApi.LoadDS[Proposals](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_product_revenues              => ReadApi.LoadDS[ProductRevenues](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_definition_rules_table        => ReadApi.LoadDS[DefinitionRules](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_locations_table               => ReadApi.LoadDS[Locations](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_sales_units_table             => ReadApi.LoadDS[SalesUnits](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_products_table                => ReadApi.LoadDS[Products](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
             case conf.MM_tg_markets_table              => ReadApi.LoadDS[TgMarkets](Seq(master_table),input_type=JDBC(jdbc_conn("jdbc_url"),jdbc_conn("jdbc_user"),jdbc_conn("jdbc_password"),conf.postgre_driver),where_clause = where_clause)(spark).distinct()
    }
      }

}

