package master

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, row_number}
import schema.Format._
import udfs.Common
import util.{MasterJdbcConn, MintGlobalProperties}

trait CustomJdbcConn extends Common with MasterJdbcConn {


  def FetchDDMasterData(module: String,master_table: String,where_clause:String = "1=1",select_clause:Seq[String]=Seq("*"),spark: SparkSession,conf: MintGlobalProperties) (implicit  jdbc_conn:Map[String,String] ) = {

    val module_source =  module.toLowerCase match  {
      case "spr" | "grp" | "revenue" | "clientview" => "ONAIR"
      case "barc" => "BARC"
    }

    master_table match {
      case conf.MM_channel_source_table          => FetchMasterData(master_table,where_clause=s"upper(name)='${module_source}'",select_clause = MMChannelSources,spark,conf)(jdbc_conn).select("channel_id", "channel_name").withColumn("Channel TMP",RemCharConvertToCap(col("channel_name")," ",""))
      case conf.MM_channel_table                 => FetchMasterData(master_table,where_clause="1=1",select_clause = MMChannels,spark,conf)(jdbc_conn).select("id","name").toDF("channel_id", "channel_group_name")
      case conf.MM_advertiser_group_table        => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAdvertiserGroups,spark,conf)(jdbc_conn).select("id", "name", "segment", "advertiser_category_id").toDF("txn_group_id", "advertiser_group_master", "segment", "advertiser_category_id")
      case conf.MM_advertiser_cat_table          => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAdvertiserCategories,spark,conf)(jdbc_conn).select("id", "name").toDF("advertiser_category_id", "advertiser_category")
      case conf.MM_agency_table                  => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAgencies,spark,conf)(jdbc_conn).select("onair_id", "txn_group_id").toDF("agency_id", "agency_group_id")
      case conf.MM_agency_group_table            => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAgencyGroups,spark,conf)(jdbc_conn).select("id", "name").toDF("agency_group_id", "agency_group_name")
      case conf.MM_deals_table                   => FetchMasterData(master_table,where_clause="1=1",select_clause = MMDeals,spark,conf)(jdbc_conn).select("onair_id", "name","updated_at").withColumn("top_record",row_number() over(Window.partitionBy("onair_id").orderBy(col("updated_at").desc))).where("top_record=1").drop("top_record","updated_at").toDF("deal_number", "deal_name")
      case conf.MM_proposal_booking_entries_table => FetchMasterData(master_table,where_clause="reconcile_status=true",select_clause = MMProposalBookingEntries,spark,conf)(jdbc_conn).select("deal_id", "proposal_id").toDF("deal_number","proposal_id").withColumn("sales_app_deal_number",col("proposal_id"))
      case conf.MM_proposals_table               => FetchMasterData(master_table,where_clause="1=1",select_clause = MMProposals,spark,conf)(jdbc_conn).select("id", "name","currency_conversion_rate").toDF("proposal_id", "sales_app_deal_name","currency_conversion_rate")
      case conf.MM_product_revenues              => FetchMasterData(master_table,where_clause="1=1",select_clause = MMProductRevenues,spark,conf)(jdbc_conn)
      case conf.MM_definition_rules_table        => FetchMasterData(master_table,where_clause="1=1",select_clause = MMDefinitionRules,spark,conf)(jdbc_conn)
      case conf.MM_locations_table               => FetchMasterData(master_table,where_clause="1=1",select_clause = MMLocations,spark,conf)(jdbc_conn).select("name", "region").toDF("sales_location", "region")
      case conf.MM_sales_units_table             => FetchMasterData(master_table,where_clause="1=1",select_clause = MMSalesUnits,spark,conf)(jdbc_conn).select("onair_id", "product_id").toDF("sales_unit_pool_id", "product_id")
      case conf.MM_products_table                => FetchMasterData(master_table,where_clause="1=1",select_clause = MMProducts,spark,conf)(jdbc_conn).select("id", "impact_regular").toDF("product_id", "impact_regular")
      case conf.MM_advertiser_table if module == "barc" => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAdvertisers,spark,conf)(jdbc_conn).select("name", "txn_group_id","brand").toDF("advertiser", "txn_group_id", "brand").withColumn("Advertiser TMP",RemCharConvertToCap(col("advertiser")," ","")).withColumn("Brand TMP",RemCharConvertToCap(col("brand")," ","")).drop(Seq("advertiser","brand"):_*).distinct()
      case conf.MM_advertiser_table if module != "barc" => FetchMasterData(master_table,where_clause="1=1",select_clause = MMAdvertisers,spark,conf)(jdbc_conn).select("onair_id", "txn_group_id","region").distinct()
    }
  }

}
