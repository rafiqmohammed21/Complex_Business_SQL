package schema.regional

import java.sql.{Date, Timestamp}

import scala.collection.immutable.ListMap

object RegionalSpotRating {

  case class QCSchema (
                         row_num:Int,
                         year_qc:Int,
                         week_qc:Int,
                         target_qc:String,
                         region_qc:String,
                         channel_qc:String,
                         event_type_qc:String,
                         level_qc:String,
                         duration_qc:Int,
                         rat_av_wg_qc:String,
                         imp_av_wg_qc:String,    // will be changed to double
                         target_av_wg_qc:String  // will be changed to double
                        // ,_corrupt_record:String
                       )

  case class RegSpotRatings (
                              row_num:Int,
                         target:String,
                         region:String,
                         sector:String,
                         category:String,
                         brand:String,
                         advertiser:String,
                         advertiser_group:String,
                         master_programme:String,
                         no:String,
                         to:Int,
                         position:String,
                         level:String,
                         event_type:String,
                         promo_type:String,
                         promo_category:String,
                         promo_sponsor_name:String,
                         promo_programme_name:String,
                         pib:String,
                         tib:String,
                         pp_start_time:String,
                         cp_start_time:String,
                         channel:String,
                         start_time_av_tm:String,
                         end_time_av_tm:String,
                         break_code:String,
                         date:String,
                         week:Int,
                         time_band:String,
                         programme_genre:String,
                         programme_theme:String,
                         duration:Int,
                         ratings:Double,
                         impressions:Double,
                         target_av:Double
                            )

  case class RegSpotRatingsEnriched (
                              row_num:Int,
                              target:String,
                              region:String,
                              sector:String,
                              category:String,
                              brand:String,
                              advertiser:String,
                              advertiser_group:String,
                              master_programme:String,
                              no:String,
                              to:Int,
                              position:String,
                              level:String,
                              event_type:String,
                              promo_type:String,
                              promo_category:String,
                              promo_sponsor_name:String,
                              promo_programme_name:String,
                              pib:String,
                              tib:String,
                              pp_start_time:String,
                              cp_start_time:String,
                              channel:String,
                              start_time_av_tm:String,
                              end_time_av_tm:String,
                              break_code:String,
                              date:Date,
                              week:Int,
                              time_band:String,
                              programme_genre:String,
                              programme_theme:String,
                              duration:Int,
                              ratings:Double,
                              impressions:Double,
                              target_av:Double,
                              year:Int,
                              timeband_start_time:String,
                              timeband_end_time:String,
                              barc_year:String,
                              date_int: String
                                    )

}
