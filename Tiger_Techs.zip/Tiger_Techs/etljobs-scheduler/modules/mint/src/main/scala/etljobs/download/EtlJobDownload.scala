package etljobs.download
import etlflow.LoggerResource
import etlflow.etljobs.{GenericEtlJob}
import etlflow.etlsteps.{HttpMethod, HttpStep, SendMailStep, SparkETLStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, JSON, SMTP}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DownloadJobProps
import etljobs.download.MessageTemplate._
import org.apache.spark.sql.{SaveMode, SparkSession}
import schema.Format.{DDBarcBasic, DDGrpBasic, DDRevenueBasic, DDSprBasic}
import schema.download._
import udfs.Common
import util.MintHelper._
import util.{Configs, MintGlobalProperties, MintHelper}
import zio.ZIO
case class EtlJobDownload(
                           val job_properties: MintEtlJobProps,
                           val global_properties: Option[GlobalProperties]
                    )
  extends GenericEtlJob with SparkUDF with Common with SparkManager {

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : DownloadJobProps = job_properties.asInstanceOf[DownloadJobProps]

  val module             = props.job_module
  etl_job_logger.info("module  : " + module)


  val csv_path = "https://s3.console.aws.amazon.com/s3/buckets/" + Configs.data_download_var.get("data_download_bucket").get + '/' + data_download_path_finder(Configs.ENV,props.job_module,props.job_token,props.job_business) + '/'
  var (callback_success_url,callback_failure_url) = MintHelper.url_finder(props.job_module,props.job_token,props.job_business)

  etl_job_logger.info("HTTP callback_success_url : " + callback_success_url)
  etl_job_logger.info("HTTP callback_failure_url : " + callback_failure_url)

  def paths =
  {
    val criteria_path = module match {
      case "spr" | "barc"                   => s"""${mint_global_properties.DD_origin_path}/${props.job_business}/${props.job_module}/criteria/${props.job_token}"""
      case "grp" | "revenue" | "clientview" => s"""${mint_global_properties.DD_origin_path}/${props.job_business}/${props.job_module}/criteria/${props.job_token}"""
    }

    val input_path = module match {
      case "spr" | "revenue" => mint_global_properties.DI_output_spr_path
      case "barc" => mint_global_properties.DI_output_pricing_path
      case "grp" | "clientview" => mint_global_properties.DI_output_posteval_path
    }

    val output_path = module match {
      case "spr" | "barc" | "clientview"   => s"""${mint_global_properties.DD_origin_path}/${props.job_business}/$module/data/${props.job_token}"""
      case "grp" | "revenue"               => s"""${mint_global_properties.DD_origin_path}/${props.job_business}/$module/data/${props.job_token.split("_")(1)}"""
    }

    (criteria_path,input_path,output_path)
  }

  val step1 = SparkReadTransformWriteStep[SprDownloadCriteriaMapper,DDSpr](
    name = "EtlSprDownload",
    input_location      = Seq(paths._1),
    input_type          = JSON(true),
    transform_function  = Spr(module,paths._1,paths._2,getJBDCConn(mint_global_properties)(props.job_business),DDSprBasic,mint_global_properties),
    output_type         = CSV(delimiter=",",header_present = true),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = paths._3,
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step2 = SparkReadTransformWriteStep[PEDownloadCriteriaMapper,DDSpr](
    name = "EtlRevenueDownload",
    input_location      = Seq(paths._1),
    input_type          = JSON(true),
    transform_function  = PostEval.RevenueCriteria(module,paths._1,paths._2,getJBDCConn(mint_global_properties)(props.job_business),DDRevenueBasic,mint_global_properties),
    output_type         = CSV(delimiter=",",header_present = true),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = paths._3,
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step3 = SparkReadTransformWriteStep[PEDownloadCriteriaMapper,DDGrp](
    name = "EtlGrpDownload",
    input_location      = Seq(paths._1),
    input_type          = JSON(true),
    transform_function  = PostEval.GrpCriteria(module,paths._1,paths._2,getJBDCConn(mint_global_properties)(props.job_business),DDGrpBasic,mint_global_properties),
    output_type         = CSV(delimiter=",",header_present = true),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = paths._3,
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val step4 = new SparkETLStep[Unit,Unit](
    name = "EtlCVDownload",
    transform_function = Cv(module,paths._1,paths._2, paths._3,getJBDCConn(mint_global_properties)(props.job_business),DDGrpBasic,mint_global_properties)
  )

  val step5 = SparkReadTransformWriteStep[BarcDownloadCriteriaMapper,DDBarc](
    name = "EtlBarcDownload",
    input_location      = Seq(paths._1),
    input_type          = JSON(true),
    transform_function  = Barc(module,paths._1,paths._2,getJBDCConn(mint_global_properties)(props.job_business),DDBarcBasic,mint_global_properties),
    output_type         = CSV(delimiter=",",header_present = true),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = paths._3,
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val callback_success = HttpStep(
    name        = "mint call back SUCCESS " +  module,
    http_method = HttpMethod.GET,
    url         = callback_success_url,
    headers     = Map("content-type"->"application/json","x-user-auth-token" -> "g7uGXPQ_ZraGG2f2B8sgHWarTNW_axjvh-krn3QgsPjz_azqWg")
  )

  val callback_failure = HttpStep(
    name        = "mint call back FAILED " +  module,
    http_method = HttpMethod.GET,
    url         = callback_failure_url,
    headers     = Map("content-type"->"application/json","x-user-auth-token" -> "g7uGXPQ_ZraGG2f2B8sgHWarTNW_axjvh-krn3QgsPjz_azqWg")
  )

  val send_mail_success = SendMailStep(
    name          = "Send Success Email for " + module,
    body          = finalMessageTemplate(Configs.ENV,props.job_business,props.job_module,props.job_token,csv_path,"Success"),
    subject       = Configs.ENV + " - Etl Job Name: " + "EtlJobDownload" + s" - Success",
    recipient_list = Configs.data_download_mail_reciepients,
    credentials   = SMTP(mint_global_properties.mail_port,mint_global_properties.mail_host,mint_global_properties.mail_user,mint_global_properties.mail_password)
  )

  val send_mail_failure = SendMailStep(
    name          = "Send failure Email for " + module,
    body          = finalMessageTemplate(Configs.ENV,props.job_business,props.job_module,props.job_token,csv_path,"Failed"),
    subject       = Configs.ENV + " - Etl Job Name: " + "EtlJobDownload" + s" - Failed",
    recipient_list = Configs.data_download_mail_reciepients,
    credentials   = SMTP(mint_global_properties.mail_port,mint_global_properties.mail_host,mint_global_properties.mail_user,mint_global_properties.mail_password)
  )


  val job: ZIO[LoggerResource, Throwable, Unit] = module match {

      case "spr"     => {
        for {
          - <- step1.execute().foldM(
            _ => {ZIO.collectAllPar(Seq(callback_failure.execute(), send_mail_failure.execute()))},
            _ => {ZIO.collectAllPar(Seq(callback_success.execute(), send_mail_success.execute()))}
          )
        } yield ()
      }
      case "revenue" => {
        for {
          - <- step2.execute().foldM(
            _ => {ZIO.collectAllPar(Seq(callback_failure.execute(), send_mail_failure.execute()))},
            _ => {ZIO.collectAllPar(Seq(callback_success.execute(), send_mail_success.execute()))}
          )
        } yield ()
      }
      case "grp"     => {
        for {
          - <- step3.execute().foldM(
            _ => {ZIO.collectAllPar(Seq(callback_failure.execute(), send_mail_failure.execute()))},
            _ => {ZIO.collectAllPar(Seq(callback_success.execute(), send_mail_success.execute()))}
          )
        } yield ()
      }
      case "clientview"  => {
        for {
          - <- step4.execute().foldM(
            _ => {ZIO.collectAllPar(Seq(callback_failure.execute(), send_mail_failure.execute()))},
            _ => {ZIO.collectAllPar(Seq(callback_success.execute(), send_mail_success.execute()))}
          )
        } yield ()
      }
      case "barc"    => {
        for {
          - <- step5.execute().foldM(
            _ => {ZIO.collectAllPar(Seq(callback_failure.execute(), send_mail_failure.execute()))},
            _ => {ZIO.collectAllPar(Seq(callback_success.execute(), send_mail_success.execute()))}
          )
        } yield ()
      }
   }
}

