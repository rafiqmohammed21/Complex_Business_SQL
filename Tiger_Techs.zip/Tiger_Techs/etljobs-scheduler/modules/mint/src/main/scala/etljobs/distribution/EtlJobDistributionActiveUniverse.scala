package etljobs.distribution

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{ReadApi, SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DistributionChannelMasterProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DateType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.distribution.Distribution.{Distribution_active_universe, Distribution_active_universe_enriched, Distribution_state_master}


case class EtlJobDistributionActiveUniverse(
                                             job_properties: MintEtlJobProps,
                                             global_properties: Option[GlobalProperties]
                                      )
  extends SequentialEtlJob with SparkUDF  with SparkManager  {

  var start_date : String = ""
  var end_date : String = ""
  lazy val reg_logger = Logger.getLogger(getClass.getName)
  var output_date_paths : Seq[(String,String)] = Seq()
  val props : DistributionChannelMasterProps = job_properties.asInstanceOf[DistributionChannelMasterProps]

  def enrichDistributionActiveuniverse(props:DistributionChannelMasterProps)(spark: SparkSession,dataset: Dataset[Distribution_active_universe]) : Dataset[Distribution_active_universe_enriched] = {
    import spark.implicits._
    val enrichedDS = dataset
      .withColumn("date",expr(""" case when month < 10 then concat(year,"-0",month,"-01") when month >= 10 then concat(year,"-",month,"-01") end  """ ).cast(DateType))

    val distribution_state_master=ReadApi.LoadDS[Distribution_state_master](Seq(props.distribution_state_master_input_path),CSV(",",true))(spark)

    val distribution_active_universe_enriched_mapping = Encoders.product[Distribution_active_universe_enriched]
    val final_df=enrichedDS.as("enrichedDS")
      .join(distribution_state_master.as("distribution_state_master"),$"enrichedDS.states"===$"distribution_state_master.State","inner")
      .drop($"distribution_state_master.State")
      .withColumn("date_int" , get_formatted_date(col("date").toString(),"yyyy-MM-dd","yyyyMMdd"))
      .as[Distribution_active_universe_enriched](distribution_active_universe_enriched_mapping)

    start_date = final_df.selectExpr("min(date)").first().getDate(0).toString
    end_date = final_df.selectExpr("max(date)").first().getDate(0).toString
    reg_logger.info(s"start_date is: $start_date  and end_date is $end_date")
    output_date_paths = final_df
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    reg_logger.info("Output file paths will be: ")
    output_date_paths.foreach(path => reg_logger.info(path))
    final_df
  }

  val step1 = SparkReadTransformWriteStep[Distribution_active_universe, Distribution_active_universe_enriched](
    name                    = "load_distribution_active_data_ORC",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(),
    output_location         = props.job_output_path,
    transform_function      = enrichDistributionActiveuniverse(props),
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )


  val step2 = BQLoadStep[Distribution_active_universe_enriched](
    name                        = "load_distribution_active_data_BQ",
    input_location              = Right(output_date_paths),
    input_type                  = ORC,
    output_dataset              = props.distribution_output_dataset,
    output_table                = props.distribution_output_table_name,
    output_write_disposition    = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition   = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]]  = EtlStepList(step1,step2)
}
