package etljobs.sales_dashboard

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, DBQueryStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevSRAndSales
import org.apache.spark.sql.SaveMode
import schema.revenue.SalesDB.{FactRevSchema, FactViewSchema}
import util.MintGlobalProperties

// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobFactTablesV1(
                               val job_properties: MintEtlJobProps,
                               val global_properties: Option[GlobalProperties]
                        )
  extends SequentialEtlJob  with SparkManager {

  val props : RevSRAndSales = job_properties.asInstanceOf[RevSRAndSales]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val query_rev_v1  = "SELECT * FROM `mint-bi-reporting.revenue_reports.fact_revenue_v1`"
  val query_sr_v1  = "SELECT * FROM `mint-bi-reporting.viewership_reports.fact_spot_ratings_v1`"

  val step1 = BQLoadStep(
    name                            = "UPDATE_BQ_FACT_REV_V1",
    input_location                  =  Left(query_rev_v1),
    input_type                      = BQ,
    output_dataset                  = props.rev_output_dataset,
    output_table                    = props.rev_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step2 = SparkReadWriteStep[ FactRevSchema](
    name                    = "LOAD_FACT_REV_V1_POSTGRES",
    input_location          = Seq("revenue.fact_revenue_v1"),
    input_type              = BQ,
    output_location         = "fact_revenue_v1_temp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )
  val step3 = DBQueryStep(
    name  = "POSTGRES_UPDATE_FACT_REV_TABLE",
    query = "Begin; delete from fact_revenue_v1 where 1 =1; insert into fact_revenue_v1  select * from fact_revenue_v1_temp; commit;",
    credentials = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver)
  )
  val step4 = BQLoadStep(
    name                            = "UPDATE_BQ_FACT_SR_V1",
    input_location                  =  Left(query_sr_v1),
    input_type                      = BQ,
    output_dataset                  = props.sr_output_dataset,
    output_table                    = props.sr_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step5 = SparkReadWriteStep[FactViewSchema](
    name                    = "LOAD_FACT_SR_V1_POSTGRES",
    input_location          = Seq("viewership.fact_spot_ratings_v1"),
    input_type              = BQ,
    output_location         = "fact_spot_ratings_v1_temp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )
  val step6 = DBQueryStep(
    name  = "POSTGRES_UPDATE_FACT_SR_TABLE",
    query = "Begin; delete from fact_spot_ratings_v1 where 1 =1; insert into fact_spot_ratings_v1  select * from fact_spot_ratings_v1_temp; commit;",
    credentials = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver)
  )


  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2,step3,step4,step5,step6)

}