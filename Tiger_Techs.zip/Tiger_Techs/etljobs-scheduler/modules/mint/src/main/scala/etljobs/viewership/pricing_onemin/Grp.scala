package etljobs.viewership.pricing_onemin

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, regexp_replace, sum}
import schema.Format.DIPostEvalGRPSchema

class Grp extends udfs.Pricing with udfs.PricingOneMin {

  def grpClientPrimaryTVR(SPRDataset:DataFrame,BARCDataset:DataFrame)= {
    val BARCDatasetModified = BARCDataset.withColumnRenamed("tgmarket","client_primary")
      .select("channel","date","timeband","client_primary","tvr")
    val TVRDataSet          = SPRDataset.join(BARCDatasetModified,Seq("channel","date","timeband","client_primary"),"left")
      .na.fill(0.0,Seq("tvr"))
    TVRDataSet.withColumn("client_primary_tvr",col("new_duration")*col("TVR"))
      .drop("tvr")
  }

  def grpClientSecondaryTVR(SPRDataset:DataFrame,BARCDataset:DataFrame)= {
    val BARCDatasetModified = BARCDataset.withColumnRenamed("tgmarket","client_secondary")
      .select("channel","date","timeband","client_Secondary","tvr")
    val TVRDataSet          = SPRDataset.join(BARCDatasetModified,Seq("channel","date","timeband","client_secondary"),"left")
      .na.fill(0.0,Seq("TVR"))
    TVRDataSet.withColumn("client_secondary_tvr",col("new_Duration")*col("tvr"))
      .drop("tvr")
  }

  def grpChannelPrimaryTVR(SPRDataset:DataFrame,BARCDataset:DataFrame)={
    val BARCDatasetModified = BARCDataset.withColumnRenamed("tgmarket","channel_primary")
      .select("channel","date","timeband","channel_primary","tvr")
    val TVRDataSet          = SPRDataset.join(BARCDatasetModified,Seq("channel","date","timeband","channel_primary"),"left")
      .na.fill(0.0,Seq("tvr"))
    TVRDataSet.withColumn("channel_primary_tvr",col("new_Duration")*col("TVR"))
      .drop("tvr")
  }

  def grpChannelGenericTVR(SPRDataset:DataFrame,BARCDataset:DataFrame)={
    val BARCDatasetModified = BARCDataset.withColumnRenamed("tgmarket","CHANNEL_GENERIC")
      .select("channel","date","timeband","channel_generic","tvr")
    val TVRDataSet          = SPRDataset.join(BARCDatasetModified,Seq("channel","date","timeband","channel_generic"),"left")
      .na.fill(0.0,Seq("tvr"))
    TVRDataSet.withColumn("channel_generic_tvr",col("new_duration")*col("tvr"))
      .drop("tvr")
  }

  def removeTMPCols(SPRDataset:DataFrame)={
    SPRDataset.drop("client_primary",
      "client_Secondary",
      "channel_tgmarket",
      "offset",
      "time_band_extended",
      "time_band_exploded",
      "time_band_splitted",
      "channel_primary",
      "channel_generic",
      "new_duration",
      "Client_Primary_TVR",
      "Client_Secondary_TVR",
      "Channel_Primary_TVR",
      "Channel_Generic_TVR",
      "primary_tgmarket_id",
      "secondary_tgmarket_id",
      "proposal_id",
      "channel")
  }

  def adjustNewTimeBand(SprDataset:DataFrame)={
    SprDataset.withColumn("timeband",regexp_replace(MinTimeBand(col("aired_time")),":",""))
  }

  def deriveRAWGRP(RawDataSet:DataFrame,Schema:Seq[String])={
    val ClPrGRP    = RawDataSet.groupBy(Schema.head,Schema.tail:_*).agg((sum("Client_Primary_TVR")/10).as("Cl_pr_GRP")).distinct
    val ClSecGRP   = RawDataSet.groupBy(Schema.head,Schema.tail:_*).agg((sum("Client_Secondary_TVR")/10).as("Cl_sec_GRP")).distinct
    val ChPrGRP    = RawDataSet.groupBy(Schema.head,Schema.tail:_*).agg((sum("Channel_Primary_TVR")/10).as("Ch_Pr_GRP")).distinct
    val ChGenGRP   = RawDataSet.groupBy(Schema.head,Schema.tail:_*).agg((sum("Channel_Generic_TVR")/10).as("Ch_Gen_GRP")).distinct
    ClPrGRP.join(ClSecGRP,Seq("channel","date","aired_time","spot_id"))
      .join(ChPrGRP,Seq("channel","date","aired_time","spot_id"))
      .join(ChGenGRP,Seq("channel","date","aired_time","spot_id"))
  }

  def TheFinalGRP(RawDataSet:DataFrame,MasterDataSet:DataFrame)={
    val FinalGRP = RawDataSet.join(MasterDataSet,Seq("channel","date","aired_time","spot_id"),"left")
    removeTMPCols(FinalGRP).select(DIPostEvalGRPSchema.head,DIPostEvalGRPSchema.tail:_*).distinct()
  }


}
