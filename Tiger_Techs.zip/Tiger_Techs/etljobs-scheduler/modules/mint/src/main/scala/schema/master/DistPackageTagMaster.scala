package schema.master

object DistPackageTagMaster {
  case class DistPackageTagMaster (
                               Package_Name: String,
                               Broadcaster: String
                             )
}