package etljobs.master

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEnt
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SaveMode
import schema.master.EntAdvertiserMaster.AdvertiserDetailInfoPostGre
import util.MintGlobalProperties

/** Object EtlJobEntAdvertiserMaster gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobEntRegAdvertiserMaster(
                                         val job_properties: MintEtlJobProps,
                                         val global_properties: Option[GlobalProperties]
                               )
  extends  SequentialEtlJob with SparkUDF with SparkManager {
  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : RevenuePropsForRegOrEnt = job_properties.asInstanceOf[RevenuePropsForRegOrEnt]

  val query_alias =
    """ (select *, to_date(concat(year_month,'01'),'yyyyMMdd') as date from advertiser_detail_info) t """.stripMargin

  val step1 = SparkReadWriteStep[AdvertiserDetailInfoPostGre](
    name                    = "Load_Jdbc_ent_advertiser_master",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step2 = BQLoadStep(
    name                            = "Load_Jdbc_ent_advertiser_master_BQ",
    input_location                  = Left(props.ent_job_output_path + "/part*"),
    input_type                      = ORC,
    output_dataset                  = props.ent_output_dataset,
    output_table                    = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step3 = SparkReadWriteStep[AdvertiserDetailInfoPostGre](
    name                    = "Load_Jdbc_reg_advertiser_master",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step4 = BQLoadStep(
    name                            = "Load_Jdbc_reg_advertiser_master_BQ",
    input_location                  = Left(props.reg_job_output_path + "/part*"),
    input_type                      = ORC,
    output_dataset                  = props.reg_output_dataset,
    output_table                    = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )



  val etlStepList: List[EtlStep[Unit,Unit]] = {
    if (props.bu == "ent") EtlStepList(step1,step2)
    else if (props.bu == "reg") EtlStepList(step3,step4)
    else EtlStepList(step1,step2,step3,step4)
  }
}
