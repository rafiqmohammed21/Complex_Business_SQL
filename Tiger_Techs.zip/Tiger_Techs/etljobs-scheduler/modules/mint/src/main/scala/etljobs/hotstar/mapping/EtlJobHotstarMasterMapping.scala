package etljobs.hotstar.mapping

import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.hotstar.HotstarMasterMapping.{HotstarMasterMappingAws, HotstarMasterMappingBQ}

case  class EtlJobHotstarMasterMapping(
                                        job_properties:MintEtlJobProps,
                                        global_properties: Option[GlobalProperties]
                                )
  extends SequentialEtlJob  with SparkManager {
  private val gcs_output_path = f"gs://${global_properties.get.gcp_project}/output/ratings"
  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  def hotstar_master_mapping_transform(spark: SparkSession,dataset: Dataset[HotstarMasterMappingAws]) : Dataset[HotstarMasterMappingBQ] = {

    val mapping  = Encoders.product[HotstarMasterMappingBQ]
    dataset.printSchema()
    val df_master_mapping = dataset.withColumn("date",col("date").cast(DateType))
      .withColumn("match_number",col("match_number").cast(IntegerType))
      .withColumn("F_year",col("F_year").cast(IntegerType))
      .withColumn("edition_number",col("edition_number").cast(IntegerType))


    df_master_mapping.printSchema()
    df_master_mapping.show(10)
    df_master_mapping.as[HotstarMasterMappingBQ](mapping)
  }

  private val step1 = SparkReadTransformWriteStep[HotstarMasterMappingAws, HotstarMasterMappingBQ](
    name                    = "load_hostar_master_mapping_GCP",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(",",true),
    output_location         = props.job_output_path,
    transform_function      = hotstar_master_mapping_transform,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.output_file_name)
  )


  private val step2 = BQLoadStep(
    name                            = "load_hostar_master_mapping_BQ",
    input_location                  = Left(props.job_output_path + "/" + props.output_file_name),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name,
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)
}
