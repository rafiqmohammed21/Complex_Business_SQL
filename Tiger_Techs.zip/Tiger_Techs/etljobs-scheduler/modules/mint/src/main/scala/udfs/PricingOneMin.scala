package udfs

import java.util.Calendar
import java.util.concurrent.TimeUnit

import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.udf

import scala.math.abs
import java.io.Serializable

trait PricingOneMin extends Serializable {

  val FillArray = (Arr:Seq[String])=>{
    Arr match {
      case Arr if Arr.length == 2 => (Arr :+ "NA").toList
      case Arr if Arr.length == 1  => (Arr :+ "NA" :+ "NA").toList
      case Arr if Arr.length == 0 => List("NA","NA","NA")
      case _ => Arr
    }
  }

  val FormattedStartTime=(StartTime:String)=>{
    val meridiem=StartTime.toString().split(" ")(1)
    val time = StartTime.toString().split(" ")(0).replace(":","")
    val hour = StartTime.toString().split(" ")(0).split(":")(0)
    val FormattedTime= meridiem match {
      case x if x == "PM" && (hour.toInt != 12) => (time.toInt+120000)
      case x if x == "PM" && (hour.toInt == 12) => time
      case x if x == "AM" && (hour.toInt < 2 || hour.toInt == 12) => if (hour.toInt == 12) (time.toInt + 120000) else (time.toInt + 240000)
      case x if x == "AM" && (hour.toInt >= 2) => time
    }
    FormattedTime.toString
  }

  val GetOffSet=(BarcTime:String,SPRTime:String)=>{
    val formatter_datetime = new java.text.SimpleDateFormat("HHmmss")
    val current_parse = formatter_datetime.parse(SPRTime)
    val lead_parse = formatter_datetime.parse(BarcTime)
    val duration = lead_parse.getTime - current_parse.getTime
    TimeUnit.MILLISECONDS.toSeconds(abs(duration)).toString
  }

  val TVR=(Impression:Column,Target:Column)=> {
    (Impression / Target) * 100
  }

  val AddSec=(airedTime:String,offset:String)=>{
    val formatter_time = new java.text.SimpleDateFormat("HHmmss")
    val current_parse = formatter_time.parse(airedTime)
    val Calendar_TS=Calendar.getInstance()
    Calendar_TS.setTime(current_parse)
    Calendar_TS.add(Calendar.SECOND,offset.toDouble.toInt)
    val FinalTime=formatter_time.format(Calendar_TS.getTime)
    val FinalTimeFormatted=FinalTime.grouped(2).toList
    if (FinalTimeFormatted(0)=="00") "24".concat(FinalTimeFormatted(1)).concat(FinalTimeFormatted(2)) else FinalTime
  }

  val MinuteTimeBand=(AiredTimeInput:String)=>{
    val AiredTime = if(AiredTimeInput.length==6) AiredTimeInput else "0"+AiredTimeInput
    val ParseTimeTmp=AiredTime.grouped(2).toList.take(2)
    val ParseTime=if (ParseTimeTmp(0) == "00") List(24,ParseTimeTmp(1)) else ParseTimeTmp
    val MinuteUpdate=(ParseTime(1).toString.toInt+1).formatted("%02d")
    val HourUpdated =(ParseTime(0).toString.toInt+1).formatted("%02d")
    val FinalParse = if(ParseTime(1)=="59") ParseTime.updated(0,HourUpdated).updated(1,"00") else ParseTime.updated(1,MinuteUpdate)
    val StartTime=ParseTime.foldRight("00")((x,y)=> x+":"+String.valueOf(y))
    val EndTime=FinalParse.foldRight("00")((x,y)=> x+":"+String.valueOf(y))
    StartTime+" - "+EndTime}

  val GetDurationInSec = (current_time_stamp: String, lead_time_stamp: String) => {
    val formatter_datetime = new java.text.SimpleDateFormat("HHmmss")
    val current_parse = formatter_datetime.parse(current_time_stamp)
    val current_time = new java.sql.Date(current_parse.getTime)
    val lead_parse = formatter_datetime.parse(lead_time_stamp)
    val lead_time = new java.sql.Date(lead_parse.getTime)
    val duration = lead_time.getTime - current_time.getTime
    val duration_sec = TimeUnit.MILLISECONDS.toSeconds(duration)
    duration_sec.toInt
  }

  def TimeBandRecursive(aired_time:String,time_band:String,duration:Int,difference:Int,empty_val:List[String]):List[String]= difference match {
    case  x if(x <= 0) => {
      (duration.toString+"#"+time_band) :: empty_val}
    case x if(x > 0) =>  {
      var start_time=time_band.split(" - ")(0)
      var end_time = time_band.split(" - ")(1)
      var time_gap = if (GetDurationInSec(aired_time,end_time) > 0) GetDurationInSec(aired_time,end_time) else 1
      var time_difference = duration.toInt - (if (time_gap <=0) GetDurationInSec(aired_time,end_time) else time_gap)
      var new_time_difference = difference.toInt - 60
      val new_time_band = end_time+" - "+AddSec(end_time,60.toString)
      var final_list = (time_gap.toString+"#"+time_band) :: empty_val
      TimeBandRecursive(end_time,new_time_band,time_difference,new_time_difference,final_list)
    }
  }

  def TimeBandRetrofitted=(AiredTime:String,TimeBand:String,Length:String)=>{
    var StartTime=TimeBand.split(" - ")(0).replace(":","")
    var EndTime = TimeBand.split(" - ")(1).replace(":","")
    var end_time_60sec = AddSec(EndTime,60.toString)
    var SecToADD = GetDurationInSec(AiredTime,EndTime)
    var LengthDifference = Length.toDouble.toInt - SecToADD.toInt
    TimeBandRecursive(AiredTime,TimeBand.replace(":",""),Length.toDouble.toInt,LengthDifference,List.empty).grouped(2).toList.flatten
  }

  def duration_in_sec(module:String,duration:String):Option[Int]= {
    val Duration = Option(duration).getOrElse(return None).toInt
    module match { case "grp" | "clientview" => Some(Duration) case "revenue" | "spr" => Some(Duration/1000) }
  }

  val FormattedTime = udf(FormattedStartTime)
  val OffSet        = udf(GetOffSet)
  val AddSectoTime  = udf(AddSec)
  val MinTimeBand   = udf(MinuteTimeBand)
  val RecursiveTime = udf(TimeBandRetrofitted)
  val get_duration_udf = udf[Option[Int],String,String](duration_in_sec)
  val FillArr       = udf(FillArray)
}
