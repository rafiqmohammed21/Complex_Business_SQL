package etljobs.hotstar.sports

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlJobProps
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.HotstarSptProps
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.hotstar.HotstarEntertainment.HotstarEntDailyChannelPerformanceAws
import schema.hotstar.HotstarSports.{HotstarDailyCumViewerAws, HotstarDailyCumViewerBQ, HotstarDailyVideoViewersAWS, HotstarDailyVideoViewersBQ, HotstarMatchwisePeakConcurrencyAWS, HotstarMatchwisePeakConcurrencyBQ, HotstarMatchwiseVideoViewersAWS, HotstarMatchwiseVideoViewersBQ}
import util.Configs

case class EtlJobHotstarSportSteps(
                                val job_properties: MintEtlJobProps,
                                val global_properties: Option[GlobalProperties]
                              )

  extends  SequentialEtlJob with SparkUDF with SparkManager {

  val props : HotstarSptProps = job_properties.asInstanceOf[HotstarSptProps]


  def hotstar_daily_cum_viewers_transform(spark: SparkSession,dataset: Dataset[HotstarDailyCumViewerAws]): Dataset[HotstarDailyCumViewerBQ] = {

    val mapping = Encoders.product[HotstarDailyCumViewerBQ]
    val df_daily_cum_viewers = dataset.withColumnRenamed("_col0", "tournament_id")
      .withColumnRenamed("_col1", "tournament_name")
      .withColumnRenamed("_col2", "season_id")
      .withColumnRenamed("_col3", "season_name")
      .withColumnRenamed("_col4", "game_name")
      .withColumnRenamed("_col5", "cumulative_video_viewers")
      .withColumnRenamed("cd", "date")
      .withColumn("tournament_id",col("tournament_id").cast(IntegerType))
      .withColumn("season_id",col("season_id").cast(IntegerType))
      .withColumn("cumulative_video_viewers",col("cumulative_video_viewers").cast(IntegerType))

    df_daily_cum_viewers.printSchema()
    df_daily_cum_viewers.show(10)
    df_daily_cum_viewers.as[HotstarDailyCumViewerBQ](mapping)

  }
  def hotstar_daily_video_viewers_transform(spark: SparkSession,dataset: Dataset[HotstarDailyVideoViewersAWS]) : Dataset[HotstarDailyVideoViewersBQ] = {

    val mapping = Encoders.product[HotstarDailyVideoViewersBQ]
    val df_daily_video_viewers = dataset.withColumnRenamed("_col0", "tournament_id")
      .withColumnRenamed("_col1", "tournament_name")
      .withColumnRenamed("_col2", "season_id")
      .withColumnRenamed("_col3", "season_name")
      .withColumnRenamed("_col4", "game_name")
      .withColumnRenamed("_col5", "daily_watch_time")
      .withColumnRenamed("_col6", "daily_video_viewers")
      .withColumnRenamed("cd", "date")
      .withColumn("tournament_id",col("tournament_id").cast(IntegerType))
      .withColumn("season_id",col("season_id").cast(IntegerType))
      .withColumn("daily_watch_time",col("daily_watch_time").cast(IntegerType))
      .withColumn("daily_video_viewers",col("daily_video_viewers").cast(IntegerType))


    df_daily_video_viewers.printSchema()
    df_daily_video_viewers.show(10)
    df_daily_video_viewers.as[HotstarDailyVideoViewersBQ](mapping)

  }
  def hotstar_match_wise_peak_concurrency_transform(spark: SparkSession,dataset: Dataset[HotstarMatchwisePeakConcurrencyAWS]) : Dataset[HotstarMatchwisePeakConcurrencyBQ] = {

    val mapping  = Encoders.product[HotstarMatchwisePeakConcurrencyBQ]
    val hotstar_df = dataset.withColumnRenamed("_col0", "tournament_id")
      .withColumnRenamed("_col1", "tournament_name")
      .withColumnRenamed("_col2", "season_id")
      .withColumnRenamed("_col3", "season_name")
      .withColumnRenamed("_col4", "game_name")
      .withColumnRenamed("_col5", "match_id")
      .withColumnRenamed("_col6", "match_name")
      .withColumnRenamed("_col7", "content_id")
      .withColumnRenamed("_col8", "peak_concurrency")
      .withColumnRenamed("cd", "date")
      .withColumn("tournament_id",col("tournament_id").cast(IntegerType))
      .withColumn("season_id",col("season_id").cast(IntegerType))
      .withColumn("match_id",col("match_id").cast(IntegerType))
      .withColumn("peak_concurrency",col("peak_concurrency").cast(IntegerType))

      .drop("_col9")
      .as[HotstarMatchwisePeakConcurrencyBQ](mapping)

    hotstar_df.printSchema()
    hotstar_df.show(10)
    hotstar_df
  }
  def hotstar_match_wise_video_viewers_transform(spark: SparkSession,dataset: Dataset[HotstarMatchwiseVideoViewersAWS]) : Dataset[HotstarMatchwiseVideoViewersBQ] = {

    val mapping  = Encoders.product[HotstarMatchwiseVideoViewersBQ]
    val hotstar_df = dataset.withColumnRenamed("_col0", "tournament_id")
      .withColumnRenamed("_col1", "tournament_name")
      .withColumnRenamed("_col2", "season_id")
      .withColumnRenamed("_col3", "season_name")
      .withColumnRenamed("_col4", "game_name")
      .withColumnRenamed("_col5", "match_id")
      .withColumnRenamed("_col6", "match_name")
      .withColumnRenamed("_col7", "daily_watch_time")
      .withColumnRenamed("_col8", "daily_video_viewers")
      .withColumnRenamed("cd", "date")
      .withColumn("tournament_id", col("tournament_id").cast(IntegerType))
      .withColumn("season_id", col("season_id").cast(IntegerType))
      .withColumn("match_id", col("match_id").cast(IntegerType))
      .withColumn("daily_watch_time", col("daily_watch_time").cast(IntegerType))
      .withColumn("daily_video_viewers", col("daily_watch_time").cast(IntegerType))
      .as[HotstarMatchwiseVideoViewersBQ](mapping)


    hotstar_df.printSchema()
    hotstar_df.show(10)
    hotstar_df
  }

  val hotstar_bucket = "s3a://" + Configs.common_variables.get("hotstar_bucket_name").get + "/" + Configs.common_variables.get("hotstar_bucket_prefix").get
  etl_job_logger.info("Accessing hotstar bucket :" + hotstar_bucket)


  val daily_cum_viewers_data_transfer = SparkReadWriteStep[HotstarDailyCumViewerAws](
    name                    = "Aws data transfer for daily_cum_viewers ",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_folder_name").get),
    input_type              = ORC,
    output_location         = props.daily_cum_viewers_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val daily_video_viewers_data_transfer = SparkReadWriteStep[HotstarDailyVideoViewersAWS](
    name                    = "Aws data transfer for daily_video_viewers ",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_folder_name").get),
    input_type              = ORC,
    output_location         = props.daily_video_viewers_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val match_wise_peak_concurrency_data_transfer = SparkReadWriteStep[HotstarMatchwisePeakConcurrencyAWS](
    name                    = "Aws data transfer for match_wise_peak_concurrency ",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_folder_name").get),
    input_type              = ORC,
    output_location         = props.match_wise_peak_concurrency_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val match_wise_video_viewers_data_transfer = SparkReadWriteStep[HotstarMatchwiseVideoViewersAWS](
    name                    = "Aws data transfer for match_wise_video_viewers ",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_folder_name").get),
    input_type              = ORC,
    output_location         = props.match_wise_video_viewers_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val daily_cum_viewers_ingestion =  SparkReadTransformWriteStep[HotstarDailyCumViewerAws, HotstarDailyCumViewerBQ](
    name = "load_hostar_daily_cum_viewers_GCP",
    input_location          = Seq(props.daily_cum_viewers_job_input_path.get),
    input_type              = ORC,
    output_location         = props.daily_cum_viewers_job_output_path.get,
    transform_function      = hotstar_daily_cum_viewers_transform,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.daily_cum_viewers_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val daily_cum_viewers_bq_ingestion = BQLoadStep[HotstarDailyCumViewerBQ](
    name = "load_hostar_daily_cum_viewers_BQ",
    input_location             = Left(props.daily_cum_viewers_job_output_path.get + "/" + props.daily_cum_viewers_output_file_name.get),
    input_type           = ORC,
    output_dataset     = props.output_dataset.get,
    output_table       = props.daily_cum_viewers_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED,

  )

  val daily_video_viewers_ingestion =  SparkReadTransformWriteStep[HotstarDailyVideoViewersAWS, HotstarDailyVideoViewersBQ](
    name                    = "load_hostar_daily_video_viewers_GCP",
    input_location          = Seq(props.daily_video_viewers_job_input_path.get),
    input_type              = ORC,
    output_location         = props.daily_video_viewers_job_output_path.get,
    transform_function      = hotstar_daily_video_viewers_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.daily_video_viewers_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val daily_video_viewers_bq_ingestion = BQLoadStep[HotstarDailyVideoViewersBQ](
    name                            = "load_hostar_daily_video_viewers_BQ",
    input_location                  = Left(props.daily_video_viewers_job_output_path.get + "/" + props.daily_video_viewers_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.daily_video_viewers_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val match_wise_peak_concurrency_ingestion = SparkReadTransformWriteStep[HotstarMatchwisePeakConcurrencyAWS, HotstarMatchwisePeakConcurrencyBQ](
    name                    = "load_hostar_match_wise_peak_concurrency_GCP",
    input_location          = Seq(props.match_wise_peak_concurrency_job_input_path.get),
    input_type              = ORC,
    output_location         = props.match_wise_peak_concurrency_job_output_path.get,
    transform_function      = hotstar_match_wise_peak_concurrency_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.match_wise_peak_concurrency_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val match_wise_peak_concurrency_bq_ingestion = BQLoadStep[HotstarMatchwisePeakConcurrencyBQ](
    name                            = "load_hostar_match_wise_peak_concurrency_BQ",
    input_location                  = Left(props.match_wise_peak_concurrency_job_output_path.get + "/" + props.match_wise_peak_concurrency_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.match_wise_peak_concurrency_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val match_wise_video_viewers_ingestion = SparkReadTransformWriteStep[HotstarMatchwiseVideoViewersAWS, HotstarMatchwiseVideoViewersBQ](
    name                    = "load_hotstar_match_wise_video_viewers_GCP",
    input_location          = Seq(props.match_wise_video_viewers_job_input_path.get),
    input_type              = ORC,
    output_location         = props.match_wise_video_viewers_job_output_path.get,
    transform_function      = hotstar_match_wise_video_viewers_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.match_wise_video_viewers_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val match_wise_video_viewers_bq_ingestion = BQLoadStep[HotstarMatchwiseVideoViewersBQ](
    name                            = "load_hotstar_match_wise_video_viewers_BQ",
    input_location                  = Left(props.match_wise_video_viewers_job_output_path.get + "/" + props.match_wise_video_viewers_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.match_wise_video_viewers_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  var job_list = List[EtlStep[Unit,Unit]]()

  if (props.match_wise_video_viewers_job_input_path.get != "")
    job_list = job_list ++ List(match_wise_video_viewers_data_transfer,match_wise_video_viewers_ingestion,match_wise_video_viewers_bq_ingestion)

  if (props.match_wise_peak_concurrency_job_input_path.get != "")
    job_list = job_list ++ List(match_wise_peak_concurrency_data_transfer,match_wise_peak_concurrency_ingestion,match_wise_peak_concurrency_bq_ingestion)

  if (props.daily_video_viewers_job_input_path.get != "")
    job_list = job_list ++ List(daily_video_viewers_data_transfer,daily_video_viewers_ingestion,daily_video_viewers_bq_ingestion)

  if (props.daily_cum_viewers_job_input_path.get != "")
    job_list =  job_list ++ List(daily_cum_viewers_data_transfer,daily_cum_viewers_ingestion,daily_cum_viewers_bq_ingestion)

  val etlStepList: List[EtlStep[Unit,Unit]] = job_list


}