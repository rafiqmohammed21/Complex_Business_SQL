package etljobs.datatransfer;
/*
 * Copyright 2015 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// [START all]

import com.google.api.services.storagetransfer.Storagetransfer;
import com.google.api.services.storagetransfer.model.*;

import java.io.IOException;
import java.util.Arrays;

/**
 * Creates a one-off transfer job from Amazon S3 to Google Cloud Storage.
 */
public final class AwsRequester {
  /**
   * Creates and executes a request for a TransferJob from Amazon S3 to Cloud Storage.
   *
   * <p>The {@code startDate} and {@code startTime} parameters should be set according to the UTC
   * Time Zone. See:
   * https://developers.google.com/resources/api-libraries/documentation/storagetransfer/v1/java/latest/com/google/api/services/storagetransfer/v1/model/Schedule.html#getStartTimeOfDay()
   *
   * @return the response TransferJob if the request is successful
   * @throws InstantiationException
   *           if instantiation fails when building the TransferJob
   * @throws IllegalAccessException
   *           if an illegal access occurs when building the TransferJob
   * @throws IOException
   *           if the client failed to complete the request
   */

  public static TransferJob createAwsTransferJob(
          String projectId,
          String jobDescription,
          String awsSourceBucket,
          String gcsSinkBucket,
          java.util.List<String> ListOfPrefix,
          String startDate,
          String startTime,
          Boolean overwrite_dest_folder,
          String awsAccessKeyId,
          String awsSecretAccessKey)
          throws InstantiationException, IllegalAccessException, IOException {
      Date date = TransferJobUtils.createDate(startDate);
      TimeOfDay time = TransferJobUtils.createTimeOfDay(startTime);
      TransferJob transferJob =
              new TransferJob()
                      .setDescription(jobDescription)
                      .setStatus("ENABLED")
                      .setProjectId(projectId)
                      .setTransferSpec(
                              new TransferSpec()
                                      .setGcsDataSink(new GcsData().setBucketName(gcsSinkBucket))
                                      .setAwsS3DataSource(
                                              new AwsS3Data()
                                                      .setBucketName(awsSourceBucket)
                                                      .setAwsAccessKey(new AwsAccessKey().setAccessKeyId(awsAccessKeyId).setSecretAccessKey(awsSecretAccessKey)))
                                      .setObjectConditions(new ObjectConditions().setIncludePrefixes(ListOfPrefix))
                                      .setTransferOptions(
                                              new TransferOptions()
                                                      .setDeleteObjectsFromSourceAfterTransfer(false)
                                                      .setOverwriteObjectsAlreadyExistingInSink(true)
                                                      .setDeleteObjectsUniqueInSink(overwrite_dest_folder)))
                                      .setSchedule(
                                               new Schedule()
                                                      .setScheduleStartDate(date)
                                                      .setScheduleEndDate(date)
                                                      .setStartTimeOfDay(time));

      Storagetransfer client = TransferClientCreator.createStorageTransferClient();
      System.out.println("transferJob : " +transferJob);
      return client.transferJobs().create(transferJob).execute();
  }

    public static void run(String projectId,
            String jobDescription,
            String awsSourceBucket,
            String gcsSinkBucket,
            java.util.List<String> listOfPrefix,
            String date,
            String time,
            Boolean overwrite_dest_folder,
            String awsAccessKeyId,
            String awsSecretAccessKey)
            throws InstantiationException, IllegalAccessException, IOException {
        java.util.List  prefix = Arrays.asList(listOfPrefix);
        System.out.println("prefix : " + prefix);
        TransferJob responseT =
                createAwsTransferJob(
                        projectId,
                        jobDescription,
                        awsSourceBucket,
                        gcsSinkBucket,
                        prefix,
                        date,
                        time,
                        overwrite_dest_folder,
                        awsAccessKeyId,
                        awsSecretAccessKey);
        System.out.println("Return transferJob: " + responseT.toPrettyString());
    }

  /**
   * Output the contents of a successfully created TransferJob.
   */
  public static void main(String[] args) {
    try {
      run(     args[0]
              ,args[1]
              ,args[2]
              ,args[3]
              ,Arrays.asList(args[4])
              ,args[5]
              ,args[6]
              ,Boolean.parseBoolean(args[7])
              ,args[8]
              ,args[9]
      );
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
//[END all]
