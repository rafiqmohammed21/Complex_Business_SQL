package etljobs.south_regional.spot_rating

import java.text.SimpleDateFormat
import java.util.Date

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps._
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.regional.RegionalSpotRating.{RegSpotRatings, RegSpotRatingsEnriched}
import udfs.Common

import scala.sys.process._

/** Object EtlJobRegional gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads regional data from regional_input_path mentioned in input parameters
 * then enrich it using function enrichRegionalSpotRating and writes in ORC format at given output path
 * by partitioning it on date
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery partitioned table by date
 */

case class EtlJobSpotRating (
                         val job_properties: MintEtlJobProps,
                         val global_properties: Option[GlobalProperties]
                       )
  extends SequentialEtlJob with  SparkUDF with Common with SparkManager {

  var start_date : String = ""
  var end_date : String = ""
  lazy val reg_logger = Logger.getLogger(getClass.getName)

  val sdf = new SimpleDateFormat("yyyyMMddHHmmssss")
  val curr_time = sdf.format(new Date)

  var output_date_paths : (Seq[(String,String)],String,String) = (Seq(),"","")

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  /** Enriches regspotratings dataset by adding columns year, timeband_start_time, timeband_end_time, date_int, barc_year
   * and casting column date to date type
   * It also generates output paths partitioned by date_int for saving data in ORC format
   * @param spark spark session
   * @param dataset raw dataset which needs to be enriched
   * @return reg_spot_ratings enriched dataframe
   */
  def enrichRegionalSpotRating(spark: SparkSession,dataset: Dataset[RegSpotRatings]) : Dataset[RegSpotRatingsEnriched] = {
    val mapping  = Encoders.product[RegSpotRatingsEnriched]
    import spark.implicits._

    val reg_spot_ratings = dataset
      .withColumn("year",substring(col("date"),-4,4))
      .withColumn("year" , col("year").cast(IntegerType))
      .withColumn("timeband_start_time",split(col("time_band"),"-")(0))
      .withColumn("timeband_end_time",split(col("time_band"),"-")(1))
      .withColumn("date", expr(get_formatted_date_without_existing_format("date","yyyy-MM-dd")).cast(DateType))
      .withColumn("barc_year" ,lit("2020"))
      .withColumn("date_int" , get_formatted_date(col("date").toString(),"yyyy-MM-dd","yyyyMMdd"))

    start_date = reg_spot_ratings.selectExpr("min(date)").first().getDate(0).toString
    end_date = reg_spot_ratings.selectExpr("max(date)").first().getDate(0).toString
    reg_logger.info(s"start_date is: $start_date  and end_date is $end_date")
    val seq = reg_spot_ratings
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path+"_"+curr_time + "/date_int=" + path + "/part*",path))
    output_date_paths = (seq, start_date, end_date)

    reg_logger.info("Output file paths will be: ")
    output_date_paths._1.foreach(path => reg_logger.info(path))
    reg_spot_ratings.as[RegSpotRatingsEnriched](mapping)



  }

  def deleteTransformFolder(spark: SparkSession, ip: Unit):Unit={
    val x= s"gsutil rm -r ${props.job_output_path}".!
  }

  //    val region_dir_pair_list : List[(String,String)] = getInputDirsVariable(job_properties("job_input_path"),spark)

  var var_api_name = ""
  val regions_list :List[String]=List("bengali","kannada","malayalam","marathi","tamil","telugu")
  if(job_name =="EtlJobEntSpotRatings") {
    var_api_name = "entertainment_spot_ratings"
    reg_logger.info("Entertainment data input dirs are: ")
    reg_logger.info(props.job_input_path + "/gec")
  } else {
    var_api_name = "regional_spot_ratings"
    reg_logger.info("Regional data input dirs are: ")
    regions_list.foreach(region=> reg_logger.info(props.job_input_path + "/" + region))
  }

  val step1 =  SparkETLStep(
    name="GCS_TRANSFORMED_FOLDER_CLEAN_UP",
    transform_function=deleteTransformFolder
  )

  val step_ent= SparkReadTransformWriteStep[RegSpotRatings, RegSpotRatingsEnriched](
    name                    = "LoadRegionalSpotRatingORC",
    input_location          = Seq(props.job_input_path + "/gec"),
    input_type              = CSV("|",true),
    transform_function      = enrichRegionalSpotRating,
    output_location         = props.job_output_path+"_"+curr_time,
    output_type             = ORC,
    output_partition_col    = Seq("date_int"),
    output_save_mode        = SaveMode.Overwrite,
    output_repartitioning   = true,
  )


  val steps_reg  = regions_list.map { region =>
    SparkReadTransformWriteStep[RegSpotRatings, RegSpotRatingsEnriched](
      name = "LoadRegionalSpotRatingORC",
      input_location = Seq(props.job_input_path + "/" + region),
      input_type = CSV("|", true),
      transform_function = enrichRegionalSpotRating,
      output_location = props.job_output_path+"_"+curr_time,
      output_type = ORC,
      output_partition_col = Seq("date_int"),
      output_save_mode = SaveMode.Append,
      output_repartitioning = true,
    )
  }

  val step2 = BQLoadStep(
    name = "LoadRegionalSpotRatingBQ",
    input_location = Right(output_date_paths._1),
    input_type = ORC,
    output_dataset = props.output_dataset,
    output_table = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  def  getQueryAlias(sd:String, ed:String):String = {

    f""" CALL `mint-bi-reporting.${props.output_dataset}_reports.sp_ent_spot_ratings_channel_tg`(date '${sd}', date '${ed}');""".stripMargin
  }

  val step3 = BQQueryStep(
    name                    = "Load_ent_spot_ratings_channel_tg_BQ",
    query        = getQueryAlias(output_date_paths._2,output_date_paths._3)
  )

  def  getQueryAliasReg(sd:String, ed:String):String = {
    f""" CALL `mint-bi-reporting.${props.output_dataset}_reports.sp_reg_spot_ratings_channel_tg`(date '${sd}', date '${ed}');""".stripMargin
  }

  val step3_reg = BQQueryStep(
    name         = "Load_reg_spot_ratings_channel_tg_BQ",
    query        = getQueryAliasReg(output_date_paths._2,output_date_paths._3)
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = {
    if(props.job_input_path.contains("entertainment"))
      EtlStepList(step1,step_ent, step2,step3)
    else
      EtlStepList(step1) ++ steps_reg ++ EtlStepList(step2, step3_reg)
  }

}