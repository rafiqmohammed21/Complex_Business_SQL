package etljobs.revenue

import _root_.util.MintGlobalProperties
import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsMintBqSdb
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, _}
import schema.revenue.SalesDB.{EntProvisionsCommonSchema, EntProvisionsEnrichedSchema, EntProvisionsSchema}

// Job specific imports
/** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobEntProvisions(
                                val job_properties: MintEtlJobProps,
                                val global_properties: Option[GlobalProperties]
                         )
  extends SequentialEtlJob with SparkManager  {

  val props : RevenuePropsMintBqSdb = job_properties.asInstanceOf[RevenuePropsMintBqSdb]

  Logger.getLogger("org").setLevel(Level.WARN)

  def enrichProvisions(spark: SparkSession,dataset: Dataset[EntProvisionsSchema]) : Dataset[EntProvisionsEnrichedSchema]={
    val mapping  = Encoders.product[EntProvisionsEnrichedSchema]
    dataset
      .withColumn("d_month",
        when(lower(col("disney_calender_month")).contains("jan"),1)
          .when(lower(col("disney_calender_month")).contains("feb"),2)
          .when(lower(col("disney_calender_month")).contains("mar"),3)
          .when(lower(col("disney_calender_month")).contains("apr"),4)
          .when(lower(col("disney_calender_month")).contains("may"),5)
          .when(lower(col("disney_calender_month")).contains("jun"),6)
          .when(lower(col("disney_calender_month")).contains("jul"),7)
          .when(lower(col("disney_calender_month")).contains("aug"),8)
          .when(lower(col("disney_calender_month")).contains("sep"),9)
          .when(lower(col("disney_calender_month")).contains("oct"),10)
          .when(lower(col("disney_calender_month")).contains("nov"),11)
          .when(lower(col("disney_calender_month")).contains("dec"),12)
          .otherwise(0) )
      .as[EntProvisionsEnrichedSchema](mapping)

  }

  val query_alias  = s""" (SELECT *  from datalake_provisions_data )t""".stripMargin
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val step1 = SparkReadTransformWriteStep[EntProvisionsSchema,EntProvisionsEnrichedSchema](
    name                    = "LOAD_ENT_PROVISIONS_MINT_PG_TO_ORC",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichProvisions,
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step2 = BQLoadStep(
    name                    = "LOAD_ENT_PROVISIONS_ORC_TO_BQ",
    input_location          = Left(props.job_output_path + "/part*"),
    input_type              = ORC,
    output_dataset          = props.output_dataset,
    output_table            = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step3 = SparkReadTransformWriteStep[EntProvisionsSchema,EntProvisionsEnrichedSchema](
    name                    = "LOAD_REG_PROVISIONS_MINT_PG_TO_ORC",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichProvisions,
    output_location         = props.job_output_path+"_reg",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step4 = BQLoadStep(
    name                    = "LOAD_REG_PROVISIONS_ORC_TO_BQ",
    input_location          = Left(props.job_output_path+"_reg" + "/part*"),
    input_type              = ORC,
    output_dataset          = props.output_dataset,
    output_table            = props.output_table_name+"_reg",
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val query_provisions =
    s""" select * from  `mint-bi-reporting.dev_reports.datalake_provisions_data_common` """.stripMargin

  val step5 = BQLoadStep(
    name                            = "LOAD_BQ_PROVISIONS_COMMON",
    input_location                  =  Left(query_provisions),
    input_type                      = BQ,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name+"_common",
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step6 = SparkReadWriteStep[EntProvisionsCommonSchema](
    name                    = "LOAD_BQ_TO_PG_PROVISIONS_COMMON",
    input_location          = Seq(s"${props.output_dataset}.${props.output_table_name}_common"),
    input_type              = BQ,
    output_location         = props.output_table_name+"_common",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2,step3,step4,step5,step6)

}