package etljobs.sales_dashboard

import java.sql.{DriverManager, ResultSet}

import etlflow.LoggerResource
import etlflow.etljobs.GenericEtlJob
import etlflow.etlsteps.SparkETLStep
import etlflow.spark.SparkManager
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.SparkSession
import zio.ZIO

// Spark Imports

/** Object EtlJobRefreshViewsPG gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobRefreshViewsPG(
                                 val job_properties: MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                          )
  extends GenericEtlJob with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  def refreshViewsPG(spark: SparkSession, ip: Unit)= {

    val comma_sep_views_string = props.job_input_path.replaceAll(":",",")
    etl_job_logger.info("comma_sep_views_string : " + comma_sep_views_string)
    var list_view_query_pair :List[(String,String)]= List()
    comma_sep_views_string.split(",").foreach{ view=>
      list_view_query_pair++=List((view,spark.read.text(s"gs://star-dl-temp/AWS-GCP-replication/partition/view_name=$view/*").collectAsList().get(0).get(0).toString.replace("\"","")))
    }
    classOf[org.postgresql.Driver]
    val con_str = "jdbc:postgresql://10.40.32.3:5432/postgres_p?user=postgres&password=mact123"
    val conn = DriverManager.getConnection(con_str)
    try {
      val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
      list_view_query_pair.foreach{ case (view,query) =>
        stm.executeUpdate(s"drop view $view")
        stm.executeUpdate(query)
      }
    } finally {
      conn.close()
    }
  }

  val step1 = new SparkETLStep[Unit,Unit](
      name="GCP_POSTGRES_VIEWS_REFRESH",
      transform_function=refreshViewsPG
    )

  val job: ZIO[LoggerResource, Throwable, Unit] =
    for {
      _   <- step1.execute()
    } yield ()
}