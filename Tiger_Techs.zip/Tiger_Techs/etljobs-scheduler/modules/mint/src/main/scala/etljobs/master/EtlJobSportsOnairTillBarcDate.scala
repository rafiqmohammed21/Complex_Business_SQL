package etljobs.master

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.{EtlStepList, LoggerResource}
import etlflow.etljobs.{EtlJob, SequentialEtlJob}
import etlflow.etlsteps.{BQLoadStep, EtlStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import schema.sports.SportsMasters.Onair_Till_Barc
import zio.Task

// Spark Imports

/** Object EtlJobEntChannelMaster gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobSportsOnairTillBarcDate(
                                          val job_properties: MintEtlJobProps,
                                          val global_properties: Option[GlobalProperties]
                                   )
  extends  SequentialEtlJob with SparkUDF with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val step1 =  BQLoadStep[Onair_Till_Barc](
    name                    = "Load_onair_till_barc_to_BQ",
    input_location             = Left(props.job_input_path),
    input_type           = CSV(",",true),
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)

}
