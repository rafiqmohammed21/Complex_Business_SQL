package etljobs.download

import etlflow.spark.ReadApi
import etlflow.utils.ORC
import master.CustomJdbcConn
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, SparkSession}
import schema.Format.{DDsprOutput, DDsprTemp}
import schema.download.{DDSpr, SprDownloadCriteriaMapper}
import udfs.{Download, Spr}
import util.MintGlobalProperties


object Spr extends Download with CustomJdbcConn with Serializable with Spr {

  @transient val sprdd_logger = Logger.getLogger(getClass.getName)

  def apply(module:String, criteria_path: String, input_path: String, jdbc_conn:Map[String,String], sprColumns: Seq[String], conf:MintGlobalProperties)(spark: SparkSession,dataset:Dataset[SprDownloadCriteriaMapper]) = {

    val encoder  =  Encoders.product[DDSpr]
    val criteria =  dataset.collect

    sprdd_logger.info(s"SPR Criteria is " + criteria.mkString)


    val temp_table_seq = for (criteria <- criteria) yield {

      val where_clause = if (criteria.advertiser_id.length == 0) {
        s"`date`>=${retrofit(criteria.start_date.mkString(""))} and " +
          s"`date`<=${retrofit(criteria.end_date.mkString(""))} and " +
          s"channel_id in (${retrofit(criteria.channel_id.mkString(","))}) " +
          s"brand in (${retrofit(criteria.brand.mkString(","))})"
      }
      else if (criteria.brand.length == 0) {
        s"`date`>=${retrofit(criteria.start_date.mkString(""))} and " +
          s"`date`<=${retrofit(criteria.end_date.mkString(""))} and " +
          s"channel_id in (${retrofit(criteria.channel_id.mkString(","))}) and " +
          s"advertiser_id_master in (${retrofit(criteria.advertiser_id.mkString(","))})"
      }
      else {
        s"`date`>=${retrofit(criteria.start_date.mkString(""))} and " +
          s"`date`<=${retrofit(criteria.end_date.mkString(""))} and " +
          s"channel_id in (${retrofit(criteria.channel_id.mkString(","))}) and " +
          s"advertiser_id_master in (${retrofit(criteria.advertiser_id.mkString(","))}) " +
          s"brand in (${retrofit(criteria.brand.mkString(","))})"
      }

      val condition = "UNION ALL"
      var select = s"select * from temp where $where_clause"
      select + s" $condition "

    }

    sprdd_logger.info(s"Select Query is ## " + temp_table_seq.mkString)

    val dates_combo = dataset
      .agg(min("start_date").as("start_date")
        ,max("end_date").as("end_date"))
      .select("start_date","end_date").distinct().collect()
    val start_date = dates_combo.map(x=>x(0)).mkString("")
    val end_date = dates_combo.map(x=>x(1)).mkString("")

    ReadApi.LoadDF(Seq(input_path),input_type=ORC,where_clause = s"date >='${start_date}' and date <='${end_date}'")(spark).distinct
      .createOrReplaceTempView("temp")

    val select_query_final = temp_table_seq.mkString("").dropRight(10)

    println(select_query_final)

    Download(spark.sql(s"$select_query_final").selectExpr(sprColumns:_*).cache,module,jdbc_conn,spark = spark,conf = conf).as(encoder)

  }

  def Download(spr_df:DataFrame,module : String,jdbc_conn:Map[String,String], spark:SparkSession,conf: MintGlobalProperties) = {

    val spr_source = spr_df
      .withColumn("week day", date_format(col("date"),"EEEE"))
      .withColumn("aired_time", get_24hr_formatted_udf(col("aired_time")))
      .withColumn("telecast_date", get_formatted_date("telecast_date","yyyyMMdd","yyyy-MM-dd"))
      .withColumn("date", col("telecast_date"))
      .withColumn("Channel TMP",RemCharConvertToCap(col("channel")," ",""))
      .withColumn("duration",get_duration_udf(lit(module),col("duration")))
      .join(broadcast(FetchDDMasterData(module,conf.MM_channel_source_table,spark = spark,conf = conf)(jdbc_conn))    , Seq("Channel TMP"), "inner")
      .join(broadcast(FetchDDMasterData(module,conf.MM_channel_table,spark = spark,conf = conf) (jdbc_conn) )         , Seq("channel_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_advertiser_table,spark = spark,conf = conf)(jdbc_conn) )       , Seq("onair_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_advertiser_group_table,spark = spark,conf = conf)(jdbc_conn))  , Seq("txn_group_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_advertiser_cat_table,spark = spark,conf = conf)(jdbc_conn))    , Seq("advertiser_category_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_agency_table,spark = spark,conf = conf) (jdbc_conn)   )        , Seq("agency_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_agency_group_table,spark = spark,conf = conf)(jdbc_conn))      , Seq("agency_group_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_deals_table,spark = spark,conf = conf)(jdbc_conn)   )          , Seq("deal_number"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_proposal_booking_entries_table,spark = spark,conf = conf)(jdbc_conn) )  , Seq("deal_number"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_proposals_table,spark = spark,conf = conf)(jdbc_conn) )     , Seq("proposal_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_sales_units_table,spark = spark,conf = conf)(jdbc_conn))      , Seq("sales_unit_pool_id"), "left")
      .join(broadcast(FetchDDMasterData(module,conf.MM_products_table,spark = spark,conf = conf)(jdbc_conn)   )       , Seq("product_id"), "left")
      .na.fill("", Seq("sales_app_deal_number","region"))
      .na.fill("n.a")
      .drop(Seq("product_id",
        "onair_id","agency_id",
        "advertiser_category_id",
        "txn_group_id","channel_id",
        "Channel TMP","agency_group_id",
        "telecast_date", "sales_location",
        "proposal_id","channel_name"):_*)
      .distinct

    val spr_final_DF = spr_source.select(DDsprTemp.head,DDsprTemp.tail : _*)
    spr_final_DF.toDF(DDsprOutput:_*)
  }

}