package etljobs.viewership.pricing_onemin

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import schema.Format.DIPostEvalGrpTempCols
import udfs.Common
import util.MintGlobalProperties

class Migration(spark:SparkSession,conf:MintGlobalProperties) extends Common{

  import spark.implicits._


  def DataSegregatedByBusiness(operation:String,SPRSourceDF:Dataset[Row],BARCSourceDF:Dataset[Row],OffsetSourceDF:Dataset[Row]=Seq("").toDF,business_map:Map[String,Map[String,String]]=Map.empty,business:Array[String],empty_df:DataFrame):DataFrame= business match {

    case x if (x.isEmpty) => empty_df
    case x if (!x.isEmpty) => {

      val spr_interim_source = BifurcateSourceForBusiness(SPRSourceDF.asInstanceOf[DataFrame],
        "channel_name",
        conf.MM_channel_source_table,
        "channel_name", business_map(x.head), spark, conf)
      val barc_interim_source = BifurcateSourceForBusiness(BARCSourceDF.asInstanceOf[DataFrame],
        "channel",
        conf.MM_channel_source_table,
        "channel_name", business_map(x.head), spark, conf)

      val empty_df_union = operation match {
        case "offset" => empty_df.union(offsetGen(spr_interim_source, barc_interim_source, business_map(x.head)))
        case "grp"    => empty_df.union(grpGen(spr_interim_source, barc_interim_source, OffsetSourceDF, business_map(x.head)))
      }

      DataSegregatedByBusiness(operation, SPRSourceDF, BARCSourceDF, OffsetSourceDF, business_map = business_map, business = business.tail, empty_df = empty_df_union)
    }
  }

  def offsetGen(SPRDataset:Dataset[Row],BARCDataset:Dataset[Row],jdbc_conn:Map[String,String]) = {
    val offset              = new Offset()
    val spr                 = new Spr(spark)(jdbc_conn)
    val barc                = new Pricing(spark, conf)(jdbc_conn)

    val sPRDataset          = spr.sprOffSetDataPreparation(SPRDataset,conf)
    val bARCDataset         = barc.barcOffSetDataPreparation(BARCDataset)
    val OffsetDF            = offset.offsetDerivation(sPRDataset, bARCDataset)

    offset.assignDefalutOffset(OffsetDF)
  }


  def grpGen(SPRDataset:Dataset[Row],BARCDataset:Dataset[Row],OffsetDataset:Dataset[Row],jdbc_conn:Map[String,String]) = {
    val spr      = new Spr(spark)(jdbc_conn)
    val barc     = new Pricing(spark, conf)(jdbc_conn)
    val grp      = new Grp()

    val GRPOneMinSPRSourceDF = spr.sprGRPMasterDataPreparation(SPRDataset,conf)
    val GRPWithOffsetSourceDF= spr.sprGRPDatawithOffsetPreparation(GRPOneMinSPRSourceDF,OffsetDataset)
    val GRPWithnewTimebandDF = spr.sprGRPDataWithTimeBandExplode(GRPWithOffsetSourceDF)
    val GRPWithTGMarketDF    = spr.sprGRPDataTGMarketsRetrofit(GRPWithnewTimebandDF)
    val GRPBarcSourceDF      = barc.barcGRPDataPreparation(BARCDataset)
    val GRPClientPrimaryDF   = grp.grpClientPrimaryTVR(GRPWithTGMarketDF,GRPBarcSourceDF)
    val GRPClientSecDF       = grp.grpClientSecondaryTVR(GRPClientPrimaryDF,GRPBarcSourceDF)
    val GRPChannelPrimaryDF  = grp.grpChannelPrimaryTVR(GRPClientSecDF,GRPBarcSourceDF)
    val GRPChannelGenericDF  = grp.grpChannelGenericTVR(GRPChannelPrimaryDF,GRPBarcSourceDF)

    val  GRPRawSourceDF       = grp.deriveRAWGRP(grp.adjustNewTimeBand(GRPChannelGenericDF),DIPostEvalGrpTempCols)
    grp.TheFinalGRP(grp.adjustNewTimeBand(GRPChannelGenericDF),GRPRawSourceDF)
  }


}
