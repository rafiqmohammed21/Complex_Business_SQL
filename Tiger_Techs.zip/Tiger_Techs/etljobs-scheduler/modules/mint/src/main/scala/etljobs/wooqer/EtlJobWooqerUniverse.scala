package etljobs.wooqer

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsWithOutRefreshDates
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode}
import schema.wooqer.Wooqer.{WooqerUniverse, WooqerUniverseEnriched}
import util.MintGlobalProperties
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql._
import org.apache.spark.sql.functions._

/** Object EtlJobWooqer gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobWooqerUniverse(
                                 val job_properties:MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                          )
  extends  SequentialEtlJob  with SparkManager{

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]

  def enrichDfWooqerUniverse(spark: SparkSession,dataset: Dataset[WooqerUniverse]) : Dataset[WooqerUniverseEnriched]={
    val mapping = Encoders.product[WooqerUniverseEnriched]
    dataset
      .withColumnRenamed("channel_group","channel_name")
      .withColumn("year", col("year").cast(IntegerType))
      .withColumn("month",
        when(lower(col("month")).contains("jan"),1)
          .when(lower(col("month")).contains("feb"),2)
          .when(lower(col("month")).contains("mar"),3)
          .when(lower(col("month")).contains("apr"),4)
          .when(lower(col("month")).contains("may"),5)
          .when(lower(col("month")).contains("jun"),6)
          .when(lower(col("month")).contains("jul"),7)
          .when(lower(col("month")).contains("aug"),8)
          .when(lower(col("month")).contains("sep"),9)
          .when(lower(col("month")).contains("oct"),10)
          .when(lower(col("month")).contains("nov"),11)
          .when(lower(col("month")).contains("dec"),12)
          .otherwise(0) )
      .as[WooqerUniverseEnriched](mapping)
  }

  val query_alias =
    """ (SELECT * FROM wooqer_universe) t """.stripMargin
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val step1 = SparkReadTransformWriteStep[WooqerUniverse, WooqerUniverseEnriched](
    name                    = "Load_Jdbc_wooqer_universe",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichDfWooqerUniverse,
    output_location         = props.job_output_path ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_wooqer_universe_BQ",
    input_location             = Left(props.job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}