package schema.revenue_calender

import java.sql.Date

object RevenueCalender {

  case class RevenueCalenderMapping(Year: Int,
                                    Month: Int,
                                    Start_Date: Date,
                                    End_Date: Date,
                                    Quarter:String,
                                    F_year:String
                                   )

}
