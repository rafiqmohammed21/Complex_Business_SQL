package etljobs.revenue

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsWithOutRefreshDates
import org.apache.spark.sql.SaveMode
import schema.revenue.DistManagement.DistManagementAllocation
// Spark Imports
import org.apache.log4j.{Level, Logger}

case class EtlJobDistManagementAllocation(
                                           val job_properties: MintEtlJobProps,
                                           val global_properties: Option[GlobalProperties]
                            )
  extends SequentialEtlJob with SparkManager {

  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]

  val step1 = SparkReadWriteStep[DistManagementAllocation](
    name                    = "Load_dist_management_allocation_gcs",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(",",true),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step2 = BQLoadStep(
    name                    = "Load_Dist_Management_Allocation_BQ",
    input_location             = Left(props.job_output_path + "/part*"),
    input_type           =ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}
