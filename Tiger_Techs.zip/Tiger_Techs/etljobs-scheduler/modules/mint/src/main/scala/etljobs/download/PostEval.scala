package etljobs.download

import etlflow.spark.ReadApi
import etlflow.utils.ORC
import master.CustomJdbcConn
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, date_format, lit}
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, SparkSession}
import schema.Format._
import schema.download.{DDGrp, DDSpr, PEDownloadCriteriaMapper}
import udfs.Download
import util.MintGlobalProperties

object PostEval extends CustomJdbcConn with Download with Serializable {

  @transient val dd_logger = Logger.getLogger(getClass.getName)

  def RevenueCriteria(module: String, criteria_path: String, input_path: String, jdbc_conn:Map[String,String], peColumns: Seq[String],conf: MintGlobalProperties)(spark:SparkSession,dataset:Dataset[PEDownloadCriteriaMapper]) = {

    val encoder = Encoders.product[DDSpr]
    val FinalDF = PostEval(module,criteria_path,input_path,jdbc_conn,peColumns,spark = spark,conf = conf)(dataset)
    FinalDF.asInstanceOf[DataFrame].as(encoder)
  }

  def GrpCriteria(module: String, criteria_path: String, input_path: String, jdbc_conn:Map[String,String], peColumns: Seq[String],conf: MintGlobalProperties)(spark:SparkSession,dataset:Dataset[PEDownloadCriteriaMapper]) = {
    val encoder = Encoders.product[DDGrp]
    val FinalDF = PostEval(module,criteria_path,input_path,jdbc_conn,peColumns,spark = spark,conf = conf)(dataset)
    FinalDF.asInstanceOf[DataFrame].as(encoder)
  }


  def apply(module: String, criteria_path: String, input_path: String, jdbc_conn:Map[String,String], peColumns: Seq[String],spark:SparkSession, conf: MintGlobalProperties)(dataset:Dataset[PEDownloadCriteriaMapper]) = {

    val criteria =  dataset.collect

    dd_logger.info(s"Deal number is " + criteria.mkString(","))

    val where_clause = s"deal_number in (${retrofit(criteria.map(x=>x.onair_deal_no).head.replaceAll("[\\[\\]]",""))})"

    val SourceDF = ReadApi.LoadDF(Seq(input_path),input_type=ORC,where_clause = where_clause, select_clause=peColumns)(spark).distinct

    Download(SourceDF,module,jdbc_conn,spark = spark,conf = conf)
  }

  def Download(spr_df:DataFrame,module:String,jdbc_conn:Map[String,String],spark:SparkSession,conf: MintGlobalProperties) = {

    val spr_source = spr_df
      .withColumn("week day", date_format(col("date"),"EEEE"))
      .withColumn("aired_time", get_24hr_formatted_udf(col("aired_time")))
      .withColumn("telecast_date", get_formatted_date("telecast_date","yyyyMMdd","yyyy-MM-dd"))
      .withColumn("date", col("telecast_date"))
      .withColumn("duration",get_duration_udf(lit(module),col("duration")))
      .withColumn("Channel TMP",RemCharConvertToCap(col("channel")," ",""))
      .join(FetchDDMasterData(module,conf.MM_channel_source_table,spark = spark,conf = conf)(jdbc_conn), Seq("Channel TMP"), "inner")
      .join(FetchDDMasterData(module,conf.MM_channel_table,spark = spark,conf = conf)(jdbc_conn), Seq("channel_id"), "left")
      //.join(FetchDDMasterData(module,conf.MM_definition_rules_table,spark = spark,conf = conf)(jdbc_conn), Seq("channel_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_table,spark = spark,conf = conf)(jdbc_conn), Seq("onair_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_group_table,spark = spark,conf = conf)(jdbc_conn), Seq("txn_group_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_cat_table,spark = spark,conf = conf)(jdbc_conn), Seq("advertiser_category_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_agency_table,spark = spark,conf = conf)(jdbc_conn), Seq("agency_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_agency_group_table,spark = spark,conf = conf)(jdbc_conn), Seq("agency_group_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_deals_table,spark = spark,conf = conf)(jdbc_conn), Seq("deal_number"), "left")
      .join(FetchDDMasterData(module,conf.MM_proposal_booking_entries_table,spark = spark,conf = conf)(jdbc_conn), Seq("deal_number"), "left")
      .join(FetchDDMasterData(module,conf.MM_proposals_table,spark = spark,conf = conf)(jdbc_conn), Seq("proposal_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_sales_units_table,spark = spark,conf = conf)(jdbc_conn), Seq("sales_unit_pool_id"), "left")
      //.join(FetchDDMasterData(module,conf.MM_product_revenues,spark = spark,conf = conf)(jdbc_conn), Seq("proposal_id","sales_unit_pool_id"), "left")
      .join(FetchDDMasterData(module,conf.MM_products_table,spark = spark,conf = conf)(jdbc_conn), Seq("product_id"), "left")
      .na.fill("", Seq("sales_app_deal_number","region"))
      .na.fill("n.a")
      .drop(Seq("product_id",
        "telecast_date","txn_group_id",
        "advertiser_category_id","agency_id",
        "channel_id","Channel TMP","sales_location",
        "proposal_id","onair_id","agency_group_id","channel_name"):_*)
      .distinct


    module match {
      case "grp" => {
        val grp_formatted = spr_source.select(DDGrpTemp.head,DDGrpTemp.tail : _*)
        grp_formatted.toDF(DDGrpOutput: _*)
      }
      case "revenue" => {
        val revenue_formatted = spr_source.select(DDRevenueTemp.head,DDRevenueTemp.tail: _*)
        revenue_formatted.toDF(DDRevenueOutput: _*)
      }
      case "clientview" => {
        val cv_formatted = spr_source.select(DDCvTemp.head,DDCvTemp.tail : _*)
        cv_formatted.toDF(DDCvOutput:_*)
      }
    }
  }

}
