package etljobs.revenue

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsWithOutRefreshDates
import org.apache.spark.sql.functions.{col, lower, when}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.revenue.RegAdRevenueDeployed.{RegAdRevenueDeployed, RegAdRevenueDeployedEnriched}
// Spark Imports
import org.apache.log4j.{Level, Logger}

case class EtlJobRegAdRevDeployed(
                                     val job_properties: MintEtlJobProps,
                                     val global_properties: Option[GlobalProperties]
                              )
  extends SequentialEtlJob with SparkManager {

  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]

  def regAdRevenueDeployedTransform(spark:SparkSession, dataset: Dataset[RegAdRevenueDeployed]) : Dataset[RegAdRevenueDeployedEnriched]={

    val mapping  = Encoders.product[RegAdRevenueDeployedEnriched]
    dataset
      .withColumn("month",
        when(lower(col("month")).contains("jan"),1)
          .when(lower(col("month")).contains("feb"),2)
          .when(lower(col("month")).contains("mar"),3)
          .when(lower(col("month")).contains("apr"),4)
          .when(lower(col("month")).contains("may"),5)
          .when(lower(col("month")).contains("jun"),6)
          .when(lower(col("month")).contains("jul"),7)
          .when(lower(col("month")).contains("aug"),8)
          .when(lower(col("month")).contains("sep"),9)
          .when(lower(col("month")).contains("oct"),10)
          .when(lower(col("month")).contains("nov"),11)
          .when(lower(col("month")).contains("dec"),12)
          .otherwise(0) )
      .as[RegAdRevenueDeployedEnriched](mapping)

  }

  val step1 = SparkReadTransformWriteStep[RegAdRevenueDeployed,RegAdRevenueDeployedEnriched](
    name                    = "Load_reg_ad_rvenue_deployed_gcs",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(",",true),
    transform_function      = regAdRevenueDeployedTransform,
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step2 = BQLoadStep(
    name                    = "Load_reg_ad_rvenue_deployed_BQ",
    input_location             = Left(props.job_output_path + "/part*"),
    input_type           =ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}
