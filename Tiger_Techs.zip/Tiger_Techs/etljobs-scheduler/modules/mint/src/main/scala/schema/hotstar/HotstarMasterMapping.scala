package schema.hotstar

import java.sql.Date

object HotstarMasterMapping {

  case class HotstarMasterMappingAws(date: Date,
                                     match_number: Int,
                                     team1: String,
                                     team2: String,
                                     teams: String,
                                     match_no:String,
                                     event: String,
                                     edition: String,
                                     F_year: Int,
                                     edition_number: Int,
                                     season_name: String
                                    )

  case class HotstarMasterMappingBQ(date: Date,
                                    match_number: Int,
                                    team1: String,
                                    team2: String,
                                    teams: String,
                                    match_no:String,
                                    event: String,
                                    edition: String,
                                    F_year: Int,
                                    edition_number: Int,
                                    season_name: String
                                   )

}