package udfs

import java.text.SimpleDateFormat
import java.util.{Calendar, TimeZone}

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

trait Spr  {
  val timeband_split=(air_time:String)=> {
    if(air_time=="NULL" || air_time=="0" || air_time=="null" || air_time==""){
      "0000-0030"
    }
    else{
      val air_time_split = if(air_time.length==6) air_time.splitAt(2) else air_time.splitAt(1)
      val hours = if(air_time_split._1.length>1) air_time_split._1 else "0"+air_time_split._1
      var minutes = air_time_split._2.splitAt(2)._1
      if (minutes.splitAt(1)._1 == 0.toString)
        minutes = minutes.splitAt(1)._2
      else
        minutes
      val start_time_hours = hours
      if (minutes.toInt >= 0 && minutes.toInt < 30) {
        val start_time_start_minutes = "00"
        val start_time_end_minutes = "30"
        start_time_hours + "" + start_time_start_minutes + "-" + start_time_hours + "" + start_time_end_minutes
      }
      else {
        val start_time_start_minutes = "30"
        val start_time_end_minutes = "00"
        val end_hours=if((start_time_hours.toInt + 1).toString.length==2) (start_time_hours.toInt + 1) else "0"+(start_time_hours.toInt + 1)
        start_time_hours + "" + start_time_start_minutes + "-" + end_hours  + "" + start_time_end_minutes
      }}
  }

  val get_year_week=(current_timestamp:String)=> {
    val inputFormat = new  java.text.SimpleDateFormat("yyyy-MM-dd")
    val calendar_format=Calendar.getInstance()
    calendar_format.setTime(inputFormat.parse(current_timestamp))
    var week = calendar_format.get(Calendar.WEEK_OF_YEAR)
    val day = calendar_format.get(Calendar.DAY_OF_WEEK)
    var year = calendar_format.get(Calendar.YEAR)
    val month = calendar_format.get(Calendar.MONTH)
    if (day == 7) week = week + 1 else week
    if (week == 53 || (week == 1 && month == 11)) {
      week = 1
      year = year + 1
    }
    year.toString.concat(week.toString)
  }

  def GetMorEve={
    val Meridian=Calendar.getInstance(TimeZone.getTimeZone("Asia/Calcutta")).get(Calendar.AM_PM)
    Meridian match {
      case 1 => "evening"
      case 0 => "morning"
    }
  }

  /*
 given the week and year, outputs the week 'end' date
  */
  def get_week_end_date( w:String, y:String, dateFmt:String ) : String = {

    var week_no = w.toInt
    var year_no = y.toInt
    val cal = Calendar.getInstance
    cal.clear()
    cal.set(Calendar.YEAR, year_no)
    cal.set(Calendar.WEEK_OF_YEAR, week_no)
    cal.set(Calendar.DAY_OF_WEEK, 7)
    cal.roll(Calendar.DAY_OF_YEAR, -1)
    val sdf = new SimpleDateFormat(dateFmt)
    return sdf.format(cal.getTime())
  }
  def current_week_start_date(w: String, y: String) : String = {
    val dateFmt = "yyyy-MM-dd"
    val w_int = w.toInt
    val y_int = y.toInt
    val cal1 = Calendar.getInstance
    cal1.clear()
    cal1.set(Calendar.WEEK_OF_YEAR, w_int)
    cal1.set(Calendar.YEAR, y_int)
    cal1.set(Calendar.DAY_OF_WEEK, 1)
    // since week start day is Sun in java calendar, hence this -1
    cal1.roll(Calendar.DAY_OF_YEAR, -1)
    val sdf_new = new SimpleDateFormat(dateFmt)
    return sdf_new.format(cal1.getTime())
  }

  def countOccurrences(src: String, tgt: String):Int={
    src.sliding(tgt.length).count(window => window == tgt)}
  val countOccurrencesUDF = udf[Int,String,String](countOccurrences)

  def addCountOfDelimiters(inputDF: DataFrame, delimiter:String): DataFrame = {
    inputDF.withColumn("count_of_delimiter",countOccurrencesUDF(col("value"),lit(delimiter)))
  }

  def getDistinctValuesOfCountOfDelimiters(inputDF: DataFrame) = {
    inputDF.
      select(col("count_of_delimiter")).
      distinct
  }

  def addColumnsForChamp(loadDF: DataFrame, list_of_columns: List[String]): DataFrame = {
    list_of_columns.foldLeft(loadDF)((loadDF, newColumn) => loadDF.withColumn(newColumn, lit("").as("StringType")))
  }


  def orderColumnsBasedOnList(inputDF: DataFrame, orderOfColumns: List[String]): DataFrame = {
    inputDF.select(orderOfColumns.head, orderOfColumns.tail: _*)
  }

  def getColumnsContainingCountOfNullValues(inputDF: DataFrame): Array[Column]= {
    inputDF.columns.map(c => sum(when(trim(col(c))===""||col(c).isNull,1).otherwise(0)).alias(c))
  }


  val timebandsplit  = udf(timeband_split)
  val getweekandyear = udf(get_year_week)
  val getyear = udf((str: String) => str.substring(0, 4))
  val getweek = udf((str: String) => str.substring(4, str.length()))

}
