package util

import java.util.Calendar

import etljobs.etlsteps.{GCSStorage, listBlobs}
import org.apache.log4j.Logger
import zio.Runtime

object MintHelper {

  val etl_job_logger = Logger.getLogger(getClass.getName)

  def url_finder(job_module:String,job_token:String,job_business:String):(String,String) = {
    var callback_success_url = ""
    var callback_failure_url = ""
    etl_job_logger.info("module  : " + job_module)

    val data_download_cb_url = Configs.data_download_var.get("data_download_cb_url").get

    if(job_module.equalsIgnoreCase("grp")) {
      etl_job_logger.info(" Inside Job Module : " + job_module)
      callback_success_url = data_download_cb_url+ "/spr_download?type=posteval_grp&token=" + job_token + "&business=" + job_business + "&status=" + "success"
      callback_failure_url = data_download_cb_url + "/spr_download?type=posteval_grp&token=" + job_token + "&business=" + job_business + "&status=" + "fail"
    } else if(job_module.equalsIgnoreCase("revenue")) {
      etl_job_logger.info(" Inside Job Module : " + job_module)
      callback_success_url = data_download_cb_url + "/spr_download?type=posteval_revenue&token=" + job_token + "&business=" + job_business + "&status=" + "success"
      callback_failure_url = data_download_cb_url + "/spr_download?type=posteval_revenue&token=" + job_token + "&business=" + job_business + "&status=" + "fail"
    } else if(job_module.equalsIgnoreCase("clientview")) {
      etl_job_logger.info(" Inside Job Module : " + job_module)
      callback_success_url = data_download_cb_url + "/spr_download?type=posteval_client_view&token=" + job_token + "&business=" + job_business + "&status=" + "success"
      callback_failure_url = data_download_cb_url + "/spr_download?type=posteval_client_view&token=" + job_token + "&business=" + job_business + "&status=" + "fail"

    } else if(job_module.equalsIgnoreCase("spr")) {
      etl_job_logger.info(" Inside Job Module : " + job_module)
      callback_success_url = data_download_cb_url + "/spr_download?token=" + job_token + "&business=" + job_business + "&status=" + "success"
      callback_failure_url = data_download_cb_url + "/spr_download?token=" + job_token + "&business=" + job_business + "&status=" + "fail"
    } else if(job_module.equalsIgnoreCase("barc")) {
      etl_job_logger.info(" Inside Job Module : " + job_module)
      callback_success_url = data_download_cb_url + "/barc_download?token=" + job_token + "&business=" + job_business + "&status=" + "success"
      callback_failure_url = data_download_cb_url + "/barc_download?token=" + job_token + "&business=" + job_business + "&status=" + "fail"
    } else {
      etl_job_logger.info("Invalid MODULE specified in REST api call")
      throw new ExceptionInInitializerError("Invalid MODULE specified in REST api call")
    }
    (callback_success_url,callback_failure_url)
  }

  def data_download_path_finder(run_env:String, module:String, token:String, business:String) :String={
    var path = ""
    if(module == "grp") {
      path = "download/"  + business + "/" + run_env.toLowerCase + "/posteval/" + module + "/data/" + token.split("_")(1)
    } else if( module == "revenue") {
      path= "download/" + business + "/" + run_env.toLowerCase + "/posteval/" + module + "/data/" + token.split("_")(1)
    } else if( module == "clientview") {
      path= "download/" + business + "/" + run_env.toLowerCase + "/posteval/" + module + "/data/" + token + "/raw"
    } else if( module == "spr") {
      path= "download/" + business + "/" + run_env.toLowerCase + "/" + module + "/data/" + token
    } else if( module == "barc") {
      path =  "download/" + business + "/" + run_env.toLowerCase + "/" + module + "/data/" + token
    } else {
      etl_job_logger.info("Invalid MODULE specified for download path")
      path = "Invalid"
    }
    path
  }

  def get_current_month_week_year(): (Int,Int,Int)= {
    val calendar = Calendar.getInstance
    val week = calendar.get(Calendar.WEEK_OF_YEAR)
    val month = calendar.get(Calendar.MONTH) + 1
    val year = calendar.get(Calendar.YEAR)
    (year,month,week)
  }

  def getMaxPartitionValue(bucketName:String, prefix: String, prefix_format:String )(ip:Unit):String = {
    val env     = GCSStorage.live()
    val lookup  = listBlobs(bucketName,prefix).provideLayer(env)
    val max_partition_value = Runtime.default.unsafeRun(lookup)
      .map(_.getName)
      .map{ path =>
        if(prefix_format=="year")
          path.split("/")(2).split("=")(1)
        else {
          val week = path.split("/")(3).split("=")(1)
          "%02d".format(week.toInt  + 1)
        }
      }.max

    max_partition_value
  }

  def getYearWeekList(bucketName:String, prefix: String,year:String,job_type:String)(ip:Unit):List[(String,String)] = {
    val env     = GCSStorage.live()
    val lookup  = listBlobs(bucketName,prefix).provideLayer(env)
    val partition_value = Runtime.default.unsafeRun(lookup)
      .map(_.getName)
      .map{ path =>
        if(job_type=="daily")
          path.split("/")(3).split("=")(1)
        else
          path.split("/")(4).split("=")(1)
      }.reverse

    var year_week_list:List[(String,String)] = List.empty
    for(index <- 0 until partition_value.length){
      year_week_list=year_week_list:+((year,partition_value(index)))
    }
    year_week_list.slice(0,4)
  }

}
