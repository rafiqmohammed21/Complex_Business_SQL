package udfs

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Column, DataFrame, SparkSession}

trait Download {

  /*def cv_criteraia_parser(args: Array[String]) = {
    var Criteria_Map   = Map.empty [String, List[(String,String)]]
    args.map {
      case arg => {
        val keyValue = arg.split('^');
        val TG  = keyValue(2).replace(".","~~")
        Criteria_Map += (TG -> (keyValue(0)->keyValue(1) :: (Criteria_Map get TG getOrElse Nil)))
      }
    }
    Criteria_Map
  }*/

  def cv_criteraia_parser(dataset:DataFrame) = {
    var Criteria_Map   = Map.empty [String, List[(Long,String)]]
    dataset.collect
      .map {x => x.getStruct(0)}
      .map { x => (x(1).asInstanceOf[String],x(0).asInstanceOf[Long],x(2).asInstanceOf[String]) }
      .map { case (k,vk,vv) => {
        val TG  = k.replace(".","~~")
        Criteria_Map += (TG -> (vk -> vv :: (Criteria_Map get TG getOrElse Nil)))
      }
      }
    Criteria_Map
  }

  def retrofit = (in_parameter:String) => {
    "\'" + in_parameter.replace(" ", "")
      .replace("'", "")
      .replace(",", "','")
      .toUpperCase + "\'"
  }

  def get_24hr_formatted (input_time:String):Option[String]={
    val time = Option(input_time).getOrElse(return None)
    val time_split=if (time.length == 6) time.splitAt(2) else time.splitAt(1)
    val hours=if (time_split._1.length ==2 ) time_split._1 else "0"+time_split._1
    val minutes=time_split._2.splitAt(2)._1
    val seconds=time_split._2.splitAt(2)._2
    Some(hours+":"+minutes+":"+seconds)
  }

  def get_12hr_formatted(startTime:String):Option[String]={
    val StartTime = Option(startTime).getOrElse(return None).toString
    val meridiem=StartTime.split(" ")(1)
    val time = StartTime.split(" ")(0).replace(":","")
    val hour = StartTime.split(" ")(0).split(":")(0)
    val FormattedTime= meridiem match {
      case x if x == "PM" && (hour.toInt != 12) => (time.toInt+120000)
      case x if x == "PM" && (hour.toInt == 12) => time
      case x if x == "AM" && (hour.toInt == 12) => "00"+(time.toInt-120000)
      case x if x == "AM" && (hour.toInt != 12) => time
    }
    val time_new=FormattedTime.toString
    val time_split=if (time_new.length == 6) time_new.splitAt(2) else time_new.splitAt(1)
    val hours=if (time_split._1.length ==2 ) time_split._1 else "0"+time_split._1
    val minutes=time_split._2.splitAt(2)._1
    val seconds=time_split._2.splitAt(2)._2
    Some(hours+":"+minutes+":"+seconds)
  }

  val get_formatted_date = (ColumnName:String,ExistingFormat:String,NewFormat:String) => {
    from_unixtime(unix_timestamp(col(ColumnName), ExistingFormat), NewFormat)
  }

  def duration_in_sec(module:String,duration:String):Option[Int]= {
    val Duration = Option(duration).getOrElse(return None).toInt
    module match { case "grp" | "clientview" => Some(Duration) case "revenue" | "spr" => Some(Duration/1000) }
  }

  def type_grp_decider(source_grp_type:Column)= {
    when(source_grp_type===lit("clpri"),col("Cl_Pr_Grp"))
      .when(source_grp_type===lit("clsec"),col("Cl_Sec_Grp"))
      .when(source_grp_type===lit("chpri"),col("Ch_Pr_Grp"))
      .when(source_grp_type===lit("chgen"),col("Ch_Gen_Grp"))
  }

  def DynamicStructSchema(schema_to_add:List[String])(spark:SparkSession) = {
    import spark.implicits._
    val StructType = new StructType()
    schema_to_add.foldLeft(StructType)((StructType,name) => {
      StructType.add($"$name".string)
    })
  }

  def outlay(pitched_price:Column,currency_rate:Column)={
    ( pitched_price * currency_rate )
  }

  def get_conversion_rate(pitched_price:Column,duration:Column) =round((pitched_price / duration) * 10,2)

  def get_round_value(column:Column) = round(column,6)
  def get_grp_tvt(numerator:Column,denominator:Column) : Column = (numerator*denominator)/10

  def MultipleWeightedColToAdd(df_to_be_modified:DataFrame,weights_schema: scala.collection.mutable.Map[String,org.apache.spark.sql.types.StructType],col_to_be_added:Seq[String]) = {
    col_to_be_added.foldLeft(df_to_be_modified)((df_to_be_modified,c) => {
      val weight_parameters = c.split('.')
      val schema = weights_schema(weight_parameters(1))
      df_to_be_modified.withColumn(c,from_json(col(weight_parameters(0))(weight_parameters(1)),schema)(weight_parameters(2)))
    })
  }

  val get_duration_udf =        udf[Option[Int],String,String](duration_in_sec)
  val get_24hr_formatted_udf  = udf[Option[String],String](get_24hr_formatted)
  val get_12hr_formatted_udf  = udf[Option[String],String](get_12hr_formatted)
}
