package etljobs.hotstar.entertainment

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, GCSPutStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GCP, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.HotstarEntProps
import etlflow.etlsteps.DataprocSparkJobStep
import org.apache.spark.sql.SaveMode
import schema.hotstar.HotstarEntertainment._
import util.Configs


case class EtlJobHotstarEnt(
                             val job_properties: MintEtlJobProps,
                             val global_properties: Option[GlobalProperties]
                      )
  extends SequentialEtlJob with SparkUDF  with SparkManager{


  val props : HotstarEntProps = job_properties.asInstanceOf[HotstarEntProps]
  val canonical_path: String          = new java.io.File(".").getCanonicalPath

  val mr_file = Configs.mr_file
  val local_docker_path = "/tmp"
  etl_job_logger.info("local_docker_path  : " + local_docker_path)

  etl_job_logger.info("mr_file  : " + mr_file)

  val daily_channel_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_channel_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_channel_gcs_bucket_prefix").get
  val daily_show_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_show_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_show_gcs_bucket_prefix").get
  val weekly_channel_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_channel_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_channel_gcs_bucket_prefix").get
  val weekly_show_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_show_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_show_gcs_bucket_prefix").get

  etl_job_logger.info("daily_channel_mintreporting_path  : " + daily_channel_mintreporting_path)
  etl_job_logger.info("daily_show_mintreporting_path  : " + daily_show_mintreporting_path)
  etl_job_logger.info("weekly_channel_mintreporting_path  : " + weekly_channel_mintreporting_path)
  etl_job_logger.info("weekly_show_mintreporting_path  : " + weekly_show_mintreporting_path)

  val hotstar_ent_job = DataprocSparkJobStep(
    name     = "DataProc Job Submission for EtlJobHotstarEnt",
    job_name = "EtlJobHotstarEntSteps",
    props    = Map(),
    global_properties = global_properties
  )

  val load_ht_ent_daily_channel_performance_locally = SparkReadWriteStep[HotstarEntDailyChannelPerformanceBQ](
    name                    = "load ht_ent_daily_channel_performance locally",
    input_location          = Seq(props.daily_channel_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_ent_daily_channel_performance",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_ent_daily_channel_performance.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val load_ht_ent_daily_show_performance_locally = SparkReadWriteStep[HotstarEntDailyShowPerformanceBQ](
    name                    = "load_ht_ent_daily_show_performance_locally",
    input_location          = Seq(props.daily_show_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_ent_daily_show_performance",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_ent_daily_show_performance.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val load_ht_ent_weekly_show_performance_locally = SparkReadWriteStep[HotstarEntWeeklyShowPerformanceBQ](
    name                    = "load_ht_ent_weekly_show_performance_locally",
    input_location          = Seq(props.weekly_show_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_ent_weekly_show_performance",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_ent_weekly_show_performance.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,


  )

  val load_ht_ent_weekly_channel_performance_locally = SparkReadWriteStep[HotstarEntWeeklyChannelPerformanceBQ](
    name                    = "load_ht_ent_weekly_channel_performance_locally",
    input_location          = Seq(props.weekly_channel_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_ent_weekly_channel_performance",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_ent_weekly_channel_performance.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val gcsput_step_for_daily_channel = GCSPutStep(
    name    = "gcsput_step_for_daily_channel",
    bucket  = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_channel_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_channel_gcs_bucket_prefix").get + "/" + "ht_ent_daily_channel_performance.orc",
    file    = s"$local_docker_path/ht_ent_daily_channel_performance/ht_ent_daily_channel_performance.orc",
    credentials = mr_file
  )

  val gcsput_step_for_daily_show = GCSPutStep(
    name    = "gcsput_step_for_daily_show",
    bucket  = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_show_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_show_gcs_bucket_prefix").get + "/" + "ht_ent_daily_show_performance.orc",
    file    = s"$local_docker_path/ht_ent_daily_show_performance/ht_ent_daily_show_performance.orc",
    credentials = mr_file
  )

  val gcsput_step_for_weekly_channel = GCSPutStep(
    name    = "gcsput_step_for_weekly_channel",
    bucket  = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_channel_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_channel_gcs_bucket_prefix").get + "/" + "ht_ent_weekly_channel_performance.orc",
    file    = s"$local_docker_path/ht_ent_weekly_channel_performance/ht_ent_weekly_channel_performance.orc",
    credentials = mr_file
  )

  val gcsput_step_for_weekly_show = GCSPutStep(
    name    = "gcsput_step_for_weekly_show",
    bucket  = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_show_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_show_gcs_bucket_prefix").get + "/" + "ht_ent_weekly_show_performance.orc",
    file    = s"$local_docker_path/ht_ent_weekly_show_performance/ht_ent_weekly_show_performance.orc",
    credentials = mr_file
  )

  val daily_channel_mintreporting_bq_ingestion = BQLoadStep[HotstarEntDailyChannelPerformanceBQ](
    name                            = "load_hostar_Entertainment_daily_channel_performance_BQ",
    input_location                  = Left(daily_channel_mintreporting_path + "/" + "ht_ent_daily_channel_performance.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_channel_performance").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )


  val daily_show_mintreporting_bq_ingestion = BQLoadStep[HotstarEntDailyShowPerformanceBQ](
    name                            = "load_hostar_Entertainment_daily_show_performance_BQ",
    input_location                  = Left(daily_show_mintreporting_path +  "/" + "ht_ent_daily_show_performance.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_daily_show_performance").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )

  val weekly_show_mintreporting_bq_ingestion = BQLoadStep[HotstarEntWeeklyShowPerformanceBQ](
    name                            = "load_hostar_Entertainment_weekly_show_performance_BQ",
    input_location                  = Left(weekly_show_mintreporting_path + "/" + "ht_ent_weekly_show_performance.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_show_performance").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials =mr_file
  )

  val weekly_channel_mintreporting_bq_ingestion = BQLoadStep[HotstarEntWeeklyChannelPerformanceBQ](
    name                            = "load_hostar_Entertainment_weekly_channel_performance_BQ",
    input_location                  = Left(weekly_channel_mintreporting_path + "/" + "ht_ent_weekly_channel_performance.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_ent_info.get("hotstar_ent_weekly_channel_performance").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )

  val etlStepList: List[EtlStep[Unit,Unit]] =
    EtlStepList(
      hotstar_ent_job,
      load_ht_ent_daily_channel_performance_locally,
      load_ht_ent_daily_show_performance_locally,
      load_ht_ent_weekly_channel_performance_locally,
      load_ht_ent_weekly_show_performance_locally,
      gcsput_step_for_daily_channel,
      gcsput_step_for_daily_show,
      gcsput_step_for_weekly_channel,
      gcsput_step_for_weekly_show,
      daily_channel_mintreporting_bq_ingestion,
      daily_show_mintreporting_bq_ingestion,
      weekly_channel_mintreporting_bq_ingestion,
      weekly_show_mintreporting_bq_ingestion
    )

}
