package schema.revenue

object DistIncentiveAcc {

  case class DistIncentiveAccrued (
                                    customer_nbr:String,
                                    year:Int,
                                    month:Int,
                                    incentive_amount:Float,
                                    broadcaster:String
                                  )

}
