package etljobs.datatransfer

import etlflow.etlsteps.EtlStep
import org.apache.spark.sql.SparkSession
import util.MintGlobalProperties
import zio.Task

import scala.collection.JavaConverters._
import scala.util.Try

class DataTransferStep ( val name : String
                         ,job_description : String
                         ,source_bucket : String
                         ,dest_bucket : String
                         ,prefix : String
                         ,dl_source_folder : Boolean = true
                         ,ow_dest_folder : Boolean = true
                         ,job_type : String
                         ,access_key:String
                         ,secret_key:String
                       )
  extends EtlStep[Unit,Unit] with utils {

  val prefix_list = prefix.split(",").toList.asJava

  def process(spark: =>Unit): Task[Unit] = Task  {

    Try {
      println("you are inside")
      job_type.toLowerCase match {

        case "awstogcs" => AwsRequester.run("mint-bi-reporting",
          job_description,
          source_bucket,
          dest_bucket,
          prefix_list,
          currentDateTime()._1,
          currentDateTime()._2,
          ow_dest_folder,
          access_key,
          secret_key
        )

        case "gcstogcs" => NearlineRequester.run("mint-bi-reporting",
          job_description,
          source_bucket,
          dest_bucket,
          prefix_list,
          dl_source_folder,
          ow_dest_folder,
          currentDateTime()._1,
          currentDateTime()._2)
      }
    }
  }
}

object DataTransferStep {
  def apply ( name : String
              ,job_description : String
              ,source_bucket : String
              ,dest_bucket : String
              ,prefix : String
              ,dl_source_folder : Boolean
              ,ow_dest_folder : Boolean
              ,job_type : String
              ,access_key : String
              ,secret_key : String
            ):DataTransferStep =
    new DataTransferStep(name ,job_description ,source_bucket ,dest_bucket ,prefix ,dl_source_folder ,ow_dest_folder, job_type,access_key,secret_key )
}