package etljobs.viewership.pricing

import etlflow.LoggerResource
import etlflow.etljobs.GenericEtlJob
import etlflow.etlsteps.{HttpMethod, HttpStep, SparkETLStep, SparkReadTransformWriteStep}
import etlflow.spark.{ReadApi, SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.PricingJobProps
import etljobs.viewership.pricing.Cube.{ent_adv_brand_date_paths, ent_pgm_date_paths, reg_adv_brand_date_paths, reg_pgm_date_paths}
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}
import schema.viewership.Pricing._
import udfs.Common
import util.{Configs, MintGlobalProperties}
import zio.ZIO

case class EtlJobPricingNewTG(
                               val job_properties:MintEtlJobProps,
                               val global_properties: Option[GlobalProperties]
                             )
  extends  GenericEtlJob with SparkUDF with Common with SparkManager {


  @transient val pricing_logger = Logger.getLogger(getClass.getName)

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : PricingJobProps = job_properties.asInstanceOf[PricingJobProps]

  var run_type = props.job_type

  val Year_Week_DF = ReadApi.LoadDS[PricingRawNewTGOrigin](Seq(mint_global_properties.DI_input_pricing_newtg_path)
                                    ,CSV(delimiter="|",quotechar="\"",header_present = true)
                                    ,s"UPPER(target) != 'TARGET'")(spark = spark)
                            .select("year","week")
                            .distinct()

  if(run_type.equalsIgnoreCase("historical"))
     run_type = "Ingestion_NewTG"

  val step1 = new SparkETLStep[Unit,Unit](
    name = "EtlJobPricingQc",
    transform_function = new QC().validation( "Ingestion_NewTG", Year_Week_DF,global_properties)
  )

  val step2 = SparkReadTransformWriteStep[PricingRawNewTGOrigin,PricingRawDestination](
    name = "EtlJobPricingIngestion",
    input_location      = Seq(mint_global_properties.DI_input_pricing_newtg_path),
    input_type          = CSV(delimiter="|",header_present = true,quotechar="\""),
    transform_function  = new QC().IngestionNewTG(Year_Week_DF),
    output_type         = ORC,
    output_save_mode    = SaveMode.Append,
    output_location     = mint_global_properties.DI_output_pricing_path,
    output_partition_col = Seq("year","week","date")
  )

  val step3 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptAdvBrand](
    name  = "EtlJobPricingEntAdvBrandRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).AdvBrandDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).master_list("adv_brand"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step4 =  SparkReadTransformWriteStep[PricingRawDestination,PricingRptMasterPrgm](
    name  = "EtlJobPricingEntMasterPgmRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).MasterPrgmDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).master_list("master_program"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step5 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptTGMarker](
    name  = "EtlJobPricingEntTGMarketRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).TGMarketDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).master_list("tg_market_list"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step6 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptYearWeekDate](
    name  = "EtlJobPricingEntYearWeekRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).YearWeekDateDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"entertainment",Year_Week_DF).master_list("year_week_date"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val step7 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptAdvBrand](
    name  = "EtlJobPricingRegAdvBrandRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).AdvBrandDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).master_list("adv_brand"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step8 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptMasterPrgm](
    name  = "EtlJobPricingRegMasterPgmRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).MasterPrgmDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).master_list("master_program"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step9 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptTGMarker](
    name  = "EtlJobPricingRegTGMarketRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).TGMarketDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).master_list("tg_market_list"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step10 = SparkReadTransformWriteStep[PricingRawDestination,PricingRptYearWeekDate](
    name  = "EtlJobPricingRegYearWeekRpt",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).YearWeekDateDF,
    output_type         = CSV(delimiter="|",header_present = true,quotechar="\""),
    output_save_mode    = SaveMode.Overwrite,
    output_location     = new Report(spark = spark,props,mint_global_properties,"regional",Year_Week_DF).master_list("year_week_date"),
    output_filename     = Some("part-00000"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val step11 = SparkReadTransformWriteStep[PricingRawDestination,PricingAdvViewerShip](
    name = "EtlJobLoadPricingEntAdvCubeToGCS",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Cube(spark, props, mint_global_properties,"entertainment", Year_Week_DF).GenerateAdvViewerShip(getJBDCConn(mint_global_properties)("entertainment"),ent_adv_brand_date_paths),
    output_type         = ORC,
    output_save_mode    = SaveMode.Overwrite,
    output_location     = mint_global_properties.DI_output_pricing_cubes_path + '/' + "ent"+ "_" + props.job_output_table_name + "_" + "adv_brand",
    output_partition_col= Seq("rating_date"),
    output_repartitioning= true
  )

  val step12 = SparkReadTransformWriteStep[PricingRawDestination,PricingAdvViewerShip](
    name = "EtlJobLoadPricingRegAdvCubeToGCS",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Cube(spark, props, mint_global_properties,"regional", Year_Week_DF).GenerateAdvViewerShip(getJBDCConn(mint_global_properties)("regional"),reg_adv_brand_date_paths),
    output_type         = ORC,
    output_save_mode    = SaveMode.Overwrite,
    output_location     = mint_global_properties.DI_output_pricing_cubes_path + '/' + "reg"+ "_" + props.job_output_table_name + "_" + "adv_brand",
    output_partition_col= Seq("rating_date"),
    output_repartitioning= true
  )

  val step13 = SparkReadTransformWriteStep[PricingRawDestination,PricingPgmViewerShip](
    name = "EtlJobLoadPricingEntPgmCubeToGCS",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Cube(spark, props, mint_global_properties,"entertainment", Year_Week_DF).GeneratePgmViewerShip(getJBDCConn(mint_global_properties)("entertainment"),ent_pgm_date_paths),
    output_type         = ORC,
    output_save_mode    = SaveMode.Overwrite,
    output_location     = mint_global_properties.DI_output_pricing_cubes_path + '/' + "ent"+ "_" + props.job_output_table_name + "_" + "pgm",
    output_partition_col= Seq("rating_date"),
    output_repartitioning= true
  )

  val step14 = SparkReadTransformWriteStep[PricingRawDestination,PricingPgmViewerShip](
    name = "EtlJobLoadPricingRegPgmCubeToGCS",
    input_location      = Seq(mint_global_properties.DI_output_pricing_path),
    input_type          = ORC,
    transform_function  = new Cube(spark, props, mint_global_properties,"regional", Year_Week_DF).GeneratePgmViewerShip(getJBDCConn(mint_global_properties)("regional"),reg_pgm_date_paths),
    output_type         = ORC,
    output_save_mode    = SaveMode.Overwrite,
    output_location     = mint_global_properties.DI_output_pricing_cubes_path + '/' + "reg"+ "_" + props.job_output_table_name + "_" + "pgm",
    output_partition_col= Seq("rating_date"),
    output_repartitioning= true
  )


  def pricing_callback_http_step(url:String,business:String,module:String) = HttpStep(
    name        =  "callback_http_step_" + module + "_" + business,
    http_method =  HttpMethod.GET,
    url         =  url,
    headers     = Map("content-type"->"application/json","x-user-auth-token" -> "g7uGXPQ_ZraGG2f2B8sgHWarTNW_axjvh-krn3QgsPjz_azqWg")
  )

  val pricing_callbacl_failure_seq = Seq(
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_callback_url").get  + "business=regional&status=fail","regional","pricing").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_callback_url").get  + "business=entertainment&status=fail","entertainment","pricing").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_ur_callback_url").get  + "business=regional&status=fail","regional","pricing_ur").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_ur_callback_url").get  + "business=entertainment&status=fail","entertainment","pricing_ur").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_stg_callback_url").get  + "business=regional&status=fail","regional","pricing_stg").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_stg_callback_url").get  + "business=entertainment&status=fail","entertainment","pricing_stg").execute(),
  )

  val pricing_callbacl_success_seq = Seq(
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_callback_url").get  + "business=regional&status=success","regional","pricing").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_callback_url").get  + "business=entertainment&status=success","entertainment","pricing").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_ur_callback_url").get  + "business=regional&status=success","regional","pricing_ur").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_ur_callback_url").get  + "business=entertainment&status=success","entertainment","pricing_ur").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_stg_callback_url").get  + "business=regional&status=success","regional","pricing_stg").execute(),
    pricing_callback_http_step(Configs.pricing_ingestion_var.get("pricing_stg_callback_url").get  + "business=entertainment&status=success","entertainment","pricing_stg").execute(),
  )

  val job: ZIO[LoggerResource, Throwable, Unit] = run_type match {
    case "Ingestion_NewTG" => {
      if (mint_global_properties.environment.equalsIgnoreCase("prod")) {
        for {
          _ <- step1.execute().tapError{ ex =>
              ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step1.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step2.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step3.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step4.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step5.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step6.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step7.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step8.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step9.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step10.execute().foldM(
            _ => ZIO.collectAllPar(pricing_callbacl_failure_seq),
            _ => ZIO.collectAllPar(pricing_callbacl_success_seq)
          )
        } yield ()
      } else {
        for {
          _ <- step1.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step2.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step3.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step4.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step5.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step6.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step7.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step8.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step9.execute().tapError{ ex =>
            ZIO.collectAllPar(pricing_callbacl_failure_seq)
          }
          _ <- step10.execute().foldM(
            _ => ZIO.collectAllPar(pricing_callbacl_failure_seq),
            _ => ZIO.collectAllPar(Seq(pricing_callbacl_success_seq(0),pricing_callbacl_success_seq(1)))
          )
        } yield ()
      }
    }
    case "Cube_Weekly" => {
      for {
        _ <- step11.execute()
        _ <- step12.execute()
        _ <- step13.execute()
        _ <- step14.execute()
      } yield ()
    }

  }
}

