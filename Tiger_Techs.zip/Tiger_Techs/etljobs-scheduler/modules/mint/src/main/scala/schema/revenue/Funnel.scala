package schema.revenue

import java.sql.{Date, Timestamp}

object Funnel {
  case class  FunnelSchemaPostgre (funnel_id:BigInt,
                            channel_name:String,
                            month:Date,
                            created_at:Timestamp,
                            year_month:String,
                            updated_at:Timestamp,
                            advertiser_group:String,
                            missed_client:Boolean,
                            campaign_budget:Int,
                            share_in_campaign:String,
                            creator_name:String,
                            region:String,
                            impact_regular:String,
                            projection_inr:String,
                            date:Date,
                            date_int: String

                           )

  case class FunnelSchemaBQ (funnel_id:BigInt,
                            channel_name:String,
                            month:Date,
                            created_at:Timestamp,
                            year_month:String,
                            updated_at:Timestamp,
                            advertiser_group:String,
                            missed_client:Boolean,
                            campaign_budget:Int,
                            share_in_campaign:String,
                            creator_name:String,
                            region:String,
                            impact_regular:String,
                            projection_inr:Double,
                            date:Date,
                             date_int: String
                           )
}
