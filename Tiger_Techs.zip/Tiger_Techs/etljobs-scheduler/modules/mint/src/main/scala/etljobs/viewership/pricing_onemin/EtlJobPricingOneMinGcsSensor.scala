package etljobs.viewership.pricing_onemin

import java.io.Serializable

import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{DataprocSparkJobStep, EtlStep, GCSSensorStep}
import etlflow.spark.SparkUDF
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.PricingOneMinJobProps
import etljobs.datatransfer.DataTransferStep
import udfs.Common
import util.{Configs, MintGlobalProperties}

import scala.concurrent.duration._

case class EtlJobPricingOneMinGcsSensor(
                                 val job_properties:MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                               )
   extends Serializable with  SequentialEtlJob with SparkUDF with Common {

  val mint_global_properties  = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : PricingOneMinJobProps = job_properties.asInstanceOf[PricingOneMinJobProps]

  etl_job_logger.info("Bucket_name : " + props.bucket_name)
  etl_job_logger.info("Prefix : " + props.path_prefix + "/year=" + props.job_run_year + "/week=" + props.job_run_week)
  etl_job_logger.info("key : " + props.key_file)
  etl_job_logger.info("Key : " + props.job_type)

  val DataTransferStep1 = DataTransferStep(
    name = s"DataTransfer For EtlJobPricingOneMin Raw Data ",
    job_description = "pricing1min_data_copy",
    source_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_aws").get,
    dest_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get,
    prefix = props.path_prefix + "/year=" + props.job_run_year + "/week=" + props.job_run_week,
    job_type = "awstogcs",
    dl_source_folder = false,
    ow_dest_folder = false,
    access_key = "AKIAIMVJOLSKVH7BPFVQ",
    secret_key = "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"
  )

  val step2 = GCSSensorStep(
    name    = "EtlJobPricingOneMin_Raw_Success_File_Check",
    bucket  = props.bucket_name,
    prefix  = props.path_prefix + "/year=" + props.job_run_year + "/week=" + props.job_run_week,
    key     = props.key_file,
    retry   = 8,
    spaced  = 1800.seconds
  )

  val step3 = DataprocSparkJobStep(
    name     = "DataProc Job Submission for PricingOneMin Ingestion",
    job_name = "EtlJobNamePricingOneMin",
    props    = Map("job_run_year" -> props.job_run_year,"job_run_week" -> props.job_run_week, "job_type" -> props.job_type),
    global_properties     = Some(mint_global_properties)
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = props.job_type match {
    case "weekly"        => EtlStepList(DataTransferStep1,step2,step3)
  }
}
