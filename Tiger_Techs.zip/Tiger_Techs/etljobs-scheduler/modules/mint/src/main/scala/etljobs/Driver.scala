package etljobs
import org.apache.log4j.Logger

object Driver {
  lazy val ld_logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    ld_logger.info("Welcome to EtlJobs Core Library ")
  }
}
