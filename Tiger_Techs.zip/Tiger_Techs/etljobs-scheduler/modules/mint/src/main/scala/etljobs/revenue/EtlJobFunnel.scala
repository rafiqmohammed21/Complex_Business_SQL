package etljobs.revenue

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEntWithRefreshDates
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{DoubleType, StringType}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.revenue.Funnel.{FunnelSchemaBQ, FunnelSchemaPostgre}
import util.MintGlobalProperties

// Job specific imports
/** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobFunnel(
                         val job_properties: MintEtlJobProps,
                         val global_properties: Option[GlobalProperties]
                  )
  extends SequentialEtlJob with SparkManager  {

  val props : RevenuePropsForRegOrEntWithRefreshDates = job_properties.asInstanceOf[RevenuePropsForRegOrEntWithRefreshDates]

  val refresh_dates = props.refresh_dates.replaceAll(":",",")
  etl_job_logger.info("comma_sep_views_string : " + refresh_dates)

  var output_date_paths_ent : Seq[(String,String)] = Seq()
  var output_date_paths_reg : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  def revenueFunnelTransformEnt(props:RevenuePropsForRegOrEntWithRefreshDates)(spark: SparkSession,dataset: Dataset[FunnelSchemaPostgre]) : Dataset[FunnelSchemaBQ]={
    import spark.implicits._

    val mapping = Encoders.product[FunnelSchemaBQ ]

    val final_funnel_df=dataset.withColumn("share_in_campaign",col("share_in_campaign").cast(StringType))
      .withColumn("projection_inr",col("projection_inr").cast(DoubleType))
    output_date_paths_ent=final_funnel_df
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.ent_job_output_path + "/date_int=" + path + "/part*",path))

    output_date_paths_ent.foreach(println)
    final_funnel_df.as[FunnelSchemaBQ](mapping)
  }

  def revenueFunnelTransformReg(props:RevenuePropsForRegOrEntWithRefreshDates)(spark: SparkSession,dataset: Dataset[FunnelSchemaPostgre]) : Dataset[FunnelSchemaBQ]={
    import spark.implicits._

    val mapping = Encoders.product[FunnelSchemaBQ ]

    val final_funnel_df=dataset.withColumn("share_in_campaign",col("share_in_campaign").cast(StringType))
      .withColumn("projection_inr",col("projection_inr").cast(DoubleType))
    output_date_paths_reg=final_funnel_df
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.reg_job_output_path + "/date_int=" + path + "/part*",path))

    output_date_paths_reg.foreach(println)
    final_funnel_df.as[FunnelSchemaBQ](mapping)
  }

  val query_alias  =
    s""" (SELECT *
                ,to_date(concat(year_month,'01'),'yyyyMMdd') as date
                ,concat(year_month,'01') as date_int
         FROM   ${props.ent_job_input_path} a WHERE year_month in (${refresh_dates}) )t""".stripMargin


  val step1 = SparkReadTransformWriteStep[FunnelSchemaPostgre,FunnelSchemaBQ](
    name                    = "Load_Jdbc_Ent_Funnel_GCP",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = revenueFunnelTransformEnt( props),
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )


  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_Ent_Funnel_BQ",
    input_location = Right(output_date_paths_ent),
    input_type           = ORC,
    output_dataset     = props.ent_output_dataset,
    output_table       = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val query_alias_reg  =
    s""" (SELECT *
                ,to_date(concat(year_month,'01'),'yyyyMMdd') as date
                ,concat(year_month,'01') as date_int
         FROM   ${props.reg_job_input_path} a WHERE year_month in (${refresh_dates}) )t""".stripMargin


  val step3 = SparkReadTransformWriteStep[FunnelSchemaPostgre,FunnelSchemaBQ](
    name                    = "Load_Jdbc_Reg_Funnel_GCP",
    input_location          = Seq(query_alias_reg),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = revenueFunnelTransformReg(props),
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )


  val step4 = BQLoadStep(
    name                    = "Load_Jdbc_Reg_Funnel_BQ",
    input_location          = Right(output_date_paths_reg),
    input_type              = ORC,
    output_dataset          = props.reg_output_dataset,
    output_table            = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = {
    if (props.bu == "ent") EtlStepList(step1,step2)
    else if (props.bu == "reg") EtlStepList(step3,step4)
    else EtlStepList(step1,step2,step3,step4)
  }
}

