package schema.revenue

object DistManagement {

  case class DistManagementAllocation (year:Int,
                                       month:Int,
                                       bouquet_name:String,
                                       channel_name:String,
                                       management_allocation:Float,
                                       management_allocation_total:Float,
                                       management_allocation_wt:Float
                                )

}
