package etljobs.master

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEnt
import org.apache.spark.sql.SaveMode
import schema.master.BarcImpactTaggings
import util.MintGlobalProperties
// Spark Imports
import org.apache.log4j.{Level, Logger}

case class EtlJobEntRegBarcImpactTaggings(
                                           val job_properties: MintEtlJobProps,
                                           val global_properties: Option[GlobalProperties]
                            )
  extends  SequentialEtlJob with SparkUDF with SparkManager {
  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val props : RevenuePropsForRegOrEnt = job_properties.asInstanceOf[RevenuePropsForRegOrEnt]

  val query_alias =
    """ (SELECT * FROM ent_barc_impact_taggings) t """.stripMargin

  val step1 = SparkReadWriteStep[BarcImpactTaggings](
    name                    = "Load_barc_ent_impact_taggings_gcs",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step2 = BQLoadStep(
    name                    = "Load_ent_barc_impact_taggings_BQ",
    input_location          = Left(props.ent_job_output_path + "/part*"),
    input_type              = ORC,
    output_dataset          = props.ent_output_dataset,
    output_table            = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step3 = SparkReadWriteStep[BarcImpactTaggings](
    name                    = "Load_barc_reg_impact_taggings_gcs",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val step4 = BQLoadStep(
    name                    = "Load_reg_barc_impact_taggings_BQ",
    input_location          = Left(props.reg_job_output_path + "/part*"),
    input_type              = ORC,
    output_dataset          = props.reg_output_dataset,
    output_table            = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = {
    if (props.bu == "ent") EtlStepList(step1,step2)
    else if (props.bu == "reg") EtlStepList(step3,step4)
    else EtlStepList(step1,step2,step3,step4)
  }
}
