package schema.channel_master

import java.sql.Date

object ChannelMasterMapping {

  case class SprChannelMasterMapping(On_Air_Channel_ID: Int,
                                     Channel_Name: String,
                                     SOURCE: String,
                                     Channel_Group_name: String,
                                     Business_Unit: String,
                                     Type_Of_Beam:String,
                                     main_channel_tag: Boolean,
                                     Business_Unit_Genre: String,
                                     STAR_Genre: String,
                                     Start_Day: String,
                                     End_Day: String,
                                     Live_hrs_ST:String,
                                     Live_hrs_ET:String,
                                     PT_Start_Time:String,
                                     PT_End_Time:String,
                                     TG_Market_1:String,
                                     TG_Market_2:String,
                                     TG_Market_3:String
                                    )
}