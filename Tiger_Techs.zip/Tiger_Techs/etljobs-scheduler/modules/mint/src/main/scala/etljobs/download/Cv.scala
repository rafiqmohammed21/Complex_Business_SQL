package etljobs.download

import etlflow.spark.ReadApi
import etlflow.utils.{JSON, ORC}
import master.CustomJdbcConn
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import schema.download.CVDownloadCriteriaMapper
import schema.Format.{DDCvOutput, DDCvOutputAgg, DDCvWegihtCat}
import util.MintGlobalProperties
import udfs.Download
import etljobs.download.PostEval.Download

import scala.annotation.tailrec

object Cv extends CustomJdbcConn with Download with Serializable {

  @transient val cvdd_logger = Logger.getLogger(getClass.getName)


  def apply(module: String, criteria_path: String, input_path: String, output_path:String, jdbc_conn: Map[String, String], cvColumns: Seq[String], conf: MintGlobalProperties)(spark: SparkSession, ip: Unit) = {

    val dataset = ReadApi.LoadDS[CVDownloadCriteriaMapper](Seq(criteria_path),input_type=JSON(true))(spark).distinct
    val criteria = dataset.head
    val deals_criteria = dataset.select(explode(col("deals"))).distinct

    cvdd_logger.info(s"CilentView Criteria is " + criteria)

    val CVDealGrpTGMapper = cv_criteraia_parser(deals_criteria)
    val deal_numbers = CVDealGrpTGMapper.values.flatten.map(deal_grp => deal_grp._1)

    val where_clause = s"""date between '${criteria.start_date}' and '${criteria.end_date}' and deal_number in (${(deal_numbers).mkString(",")})"""

    val SourceDF = ReadApi.LoadDF(Seq(input_path),input_type=ORC,where_clause = where_clause, select_clause=cvColumns)(spark).distinct

    val CVFormattedSourceDF = Download(SourceDF,module,jdbc_conn,spark,conf)
    val CVFormattedOutputDF = ClientViewDownload(CVFormattedSourceDF,CVDealGrpTGMapper,criteria,spark,conf)
    val CVAggOutputDF       = ClientViewAggregated(module,CVFormattedOutputDF,CVDealGrpTGMapper,spark,conf)(jdbc_conn)

    CVFormattedOutputDF.repartition(1).write.format("csv").mode("overwrite").option("header","true").save(output_path + "/raw")
    CVAggOutputDF.repartition(1).write.format("csv").mode("overwrite").option("header","true").save(output_path + "/aggregated")
    FileNameFormatting(output_path + "/raw",spark)
    FileNameFormatting(output_path + "/aggregated",spark)
  }


  /*def CriteriaDealandGRPParserToMap(CVCriteriaParser: DataFrame) = {
    val deal_grp_tg_comb = CVCriteriaParser.deal_and_grp_type.split(',')
    cv_criteraia_parser(deal_grp_tg_comb)
  }*/


  @tailrec
  def df_recursive(df:DataFrame,criteria:Map[String,List[(Long,String)]],spark:SparkSession):DataFrame= criteria match {
    case map if(map.isEmpty) => df
    case _ => {
      import spark.implicits._
      val tg_market   = criteria.head._1
      val criteria_df = criteria.head._2.toDF("Deal Number", tg_market)
      var grp_df      = df.join(criteria_df, Seq("Deal Number"), "left")
        .withColumn(tg_market,type_grp_decider(col(tg_market)))
        .na.fill(0.0,Seq(tg_market))
      df_recursive(grp_df, criteria.tail,spark)
    }
  }

  def WeightsSchemaGeneration(WeightSource:DataFrame,spark:SparkSession) ={

    var weights_schema = scala.collection.mutable.Map[String, StructType]()
    val weights_schema_ds = WeightSource.select("hour_type","part_of_day").distinct.collect()

    val hour_daypart = weights_schema_ds.map(r=>(r(0),r(1))).groupBy(_._1).map{case(k,v)=> k.toString -> v.map(_._2.toString).toList}
    val hour_daypart_concat = hour_daypart.map{case(k,v)=>k.toString ->  v.map(x=>k.toString.concat("."+x))}.values.flatten
    val hour = weights_schema_ds.map(r=>(r(0).toString)).toList.distinct
    val part_of_day = weights_schema_ds.map(r=>(r(1).toString)).toList.distinct

    val weight_comb = DDCvWegihtCat map { weigh_cat => hour_daypart_concat map {weight_cla => weigh_cat concat "." concat weight_cla}} flatten
    val filtered_weights_comb = weight_comb filter(_.split('.').length > 2)

    hour_daypart.foreach{case (k,v) => weights_schema += (k -> DynamicStructSchema(v)(spark))}
    weights_schema += ("hour" -> DynamicStructSchema(hour)(spark))

    (weights_schema,filtered_weights_comb)
  }

  def WeightsAddition(WeightSource:DataFrame,spark:SparkSession) = {

    val Weights =   WeightsSchemaGeneration(WeightSource,spark)

    val weight_source = WeightSource
      .withColumn("cl",from_json(col("cl"),Weights._1("hour")))
      .withColumn("ch",from_json(col("ch"),Weights._1("hour")))

    MultipleWeightedColToAdd(weight_source,Weights._1,Weights._2).drop("cl","ch","hour_type","part_of_day").distinct
  }

  def ClientViewDownload(CVFinalSource:DataFrame,deal_grp_tg_mapper:Map[String, List[(Long,String)]],criteria_map:CVDownloadCriteriaMapper,spark:SparkSession,conf:MintGlobalProperties)= {

 /*   var CVSourceRawDF         = CVFinalSource
    val ClientViewFinalDF     = df_recursive(CVSourceRawDF, deal_grp_tg_mapper,spark)
    val ClientViewFinalSchema = DDCvOutput ++ deal_grp_tg_mapper.keys.toSeq
    val ClientViewRawFinalDF  = ClientViewFinalDF
      .select(ClientViewFinalSchema.head,ClientViewFinalSchema.tail:_*)
      .drop(Seq("Cl_Pr_GRP","Cl_Sec_GRP","Ch_Pr_GRP","Ch_Gen_GRP"):_*)
    criteria_map.weights_required.toUpperCase match {
      case "TRUE"   => WeightsAddition(ClientViewRawFinalDF,spark)
      case "FALSE"  => ClientViewRawFinalDF.drop("cl","ch","hour_type","part_of_day")
      case "-"      => throw new Exception("Weights addition requirement is not specified in criteria file")
    }*/

    var CVSourceRawDF         = CVFinalSource
    val ClientViewFinalDF     = df_recursive(CVSourceRawDF, deal_grp_tg_mapper,spark)
    val ClientViewFinalSchema = DDCvOutput ++ deal_grp_tg_mapper.keys.toSeq
        ClientViewFinalDF
          .select(ClientViewFinalSchema.head,ClientViewFinalSchema.tail:_*)
          .drop(Seq("Cl_Pr_GRP","Cl_Sec_GRP","Ch_Pr_GRP","Ch_Gen_GRP"):_*)

      }

  def ClientViewAggregated(module:String,cvsource:DataFrame,deal_grp_tg_mapper:Map[String, List[(Long,String)]],spark:SparkSession,conf:MintGlobalProperties)(implicit jdbc_conn:Map[String,String])= {

    import spark.implicits._

    val tg_market                 = deal_grp_tg_mapper.keys.toSeq
    val cvTobeAggSchema           = Seq("Consumed Outlay", "Spot Length") ++ tg_market

    cvsource.head(2).isEmpty || tg_market.length > 2 match {

      case true => Seq.empty[(String,String,String,String,Double,Double,Int)].toDF(DDCvOutputAgg:_*)
      case _ => {

        val CVMonthlySourceDF     = cvsource.withColumn("Month",concat(date_format(col("Aired Date"), "MMMM"),lit(" "),date_format(col("Aired Date"), "y")))
          .withColumn("Spot Actual Amount",col("Spot Actual Amount").cast(DecimalType(16,7)))
          .withColumn("Rate",get_conversion_rate(col("Spot Actual Amount"), col("Spot Length")))


        val ProposalBkngEntriesDF = FetchDDMasterData(module,conf.MM_proposal_booking_entries_table,spark = spark,conf = conf)
        val CVAggSourceDF         = CVMonthlySourceDF
          .join(ProposalBkngEntriesDF   , CVMonthlySourceDF("Deal Number") === ProposalBkngEntriesDF("deal_number"),"left")
          .join(FetchDDMasterData(module,conf.MM_proposals_table,spark = spark,conf = conf)         , Seq("proposal_id"), "left")
          .withColumn("Consumed Outlay",outlay(col("Spot Actual Amount"),col("currency_conversion_rate")))
          .drop(Seq("deal_number", "proposal_id","sales_app_deal_number", "sales_app_deal_name","currency_conversion_rate"):_*)


        val CVAggDF               = CVAggSourceDF.groupBy("Deal Number", "Deal Name", "Sales Unit ID", "Month", "Rate").sum(cvTobeAggSchema:_*)
        CVAggDF.toDF(DDCvOutputAgg ++ tg_market :_*)
      }
    }
  }

}
