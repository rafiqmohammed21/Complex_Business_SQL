package schema.regional

import java.sql.Date

object RegionalTimeBand30 {

case class QcTimeBand30 (row_num:Int,
                         region_qc:String,
                         target_qc:String,
                         channel_qc:String,
                         year_qc:Int,
                         week_qc:Int,
                         duration_qc:Int,
                         target_sum_qc:String,
                         imp_sum_qc:String,
                         rat_sum_qc:String
                        )

case class RegTimeBand30(region:String,
                         target:String,
                         channel:String,
                         date:String,
                         week_day:String,
                         week:Int,
                         year:Int,
                         time_band:String,
                         start_time:String,
                         end_time:String,
                         ratings:Double,
                         impressions:Double,
                         target_audience:Double
                        )

  case class RegTimeBand30Enriched(region:String,
                                      target:String,
                                      channel:String,
                                      date:Date,
                                      week:Int,
                                      year:Int,
                                      time_band:String,
                                      start_time:String,
                                      end_time:String,
                                      ratings:Double,
                                      impressions:Double,
                                      target_audience:Double,
                                      real_length_sec_sum:Int,
                                      date_int:String
                                  )
  case class EntTimeBand30(
                            row_num:Int,
                            region:String,
                            target:String,
                            channel:String,
                            date:String,
                            year:Int,
                            week:Int,
                            start_time:String,
                            end_time:String,
                            time_band:String,
                            real_length_sec_sum:Int,
                            target_audience:String,
                            impressions:String,
                            ratings:String
                          )

}
