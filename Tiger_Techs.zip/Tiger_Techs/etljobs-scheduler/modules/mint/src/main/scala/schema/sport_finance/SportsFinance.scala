package schema.sport_finance

import java.sql.Date
object SportsFinance {

  case class SportsFinanceRevenueMatchWiseGCP(channel: String,
                                           date: Date,
                                           month: Int,
                                           event: String,
                                           edition: String,
                                           `match`:String,
                                           Team_1: String,
                                           Team_2: String,
                                           teams: String,
                                           spot_tag: Int,
                                           revenue: Double,
                                           spots:Double,
                                           Edition_number:Int,
                                           event_start:Date,
                                           event_end:Date,
                                           league:String
                                    )

  case class SportsFinanceRevenueMatchWiseBQ(channel: String,
                                           date: Date,
                                           month: Int,
                                           event: String,
                                           edition: String,
                                           `match`:String,
                                           Team_1: String,
                                           Team_2: String,
                                           teams: String,
                                           spot_tag: Boolean,
                                           revenue: Double,
                                           spots:Double,
                                           Edition_number:Int,
                                           event_start:Date,
                                           event_end:Date,
                                           league:Boolean
                                          )


  case class SportsFinanceRevenueMonthWise(Business_Unit: String,
                                           Year: Int,
                                           Month: Int,
                                           Start_Date: Date,
                                           End_Date: Date,
                                           Revenue:Double
                                          )
}
