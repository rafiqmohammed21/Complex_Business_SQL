//package etljobs.hotstar.mapping
//
//
//import etlflow.EtlStepList
//import etlflow.etljobs.SequentialEtlJob
//import etlflow.etlsteps.EtlStep
//import etlflow.utils.GlobalProperties
//import etljobs.MintEtlJobProps
//import etljobs.MintEtlJobProps.CommonProps
//import etljobs.etlsteps.RedisQueryStep
//
//
//case  class EtlJobHotstarMasterMapping(
//                                        job_properties:MintEtlJobProps,
//                                        global_properties: Option[GlobalProperties]
//                                      )
//  extends SequentialEtlJob {
//  val props : CommonProps = job_properties.asInstanceOf[CommonProps]
//
//  val step1 = RedisQueryStep(
//    name  = "Flush all the keys",
//    query = "flushall",
//  )
//  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)
//}
