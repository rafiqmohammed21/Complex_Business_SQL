package etljobs.viewership.pricing_onemin

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import schema.Format.DIOffsetRankSchema
import udfs.Common

class Offset extends udfs.PricingOneMin with udfs.Pricing with Common  {


  def addTempCol(InputDataSet:Dataset[Row])={
    InputDataSet.where("advertiser_group is not null")
      .withColumn("channel",RemCharConvertToCap(col("channel"),"\\s+",""))
      .withColumn("advertiser_group",RemCharConvertToCap(col("advertiser_group"),"\\s+",""))
      .withColumn("timeband",HourBand(col("timeband")))
  }


  def rankAssign(InputDataSet:DataFrame, Schema: Seq[String], OrderCol:String)={
    val WindowSpec           = Window.partitionBy(Schema.head,Schema.tail:_*).orderBy(OrderCol)
    val inputDataSetModified = InputDataSet.withColumn("rank",dense_rank().over(WindowSpec))
    inputDataSetModified.filter("rank==1")
  }

  def offsetDerivation(SPRDataset:DataFrame,BARCDataset:DataFrame)={
    val RankedBARCDataSet  = rankAssign(addTempCol(BARCDataset),DIOffsetRankSchema,"barc_aired_time").drop("rank")
    val RankedSPRDataSet   = rankAssign(addTempCol(SPRDataset),DIOffsetRankSchema,"spr_aired_time").filter("rank==1").drop("rank")
    val RankedDataSet      = RankedBARCDataSet.join(RankedSPRDataSet,Seq("year","week","advertiser_group","channel","date","timeband","length"),"inner")
    val RankedDataSetFinal = rankAssign(RankedDataSet,Seq("channel","date","timeband"),"barc_aired_time").filter("rank==1")
    val OffSetDataSet      = RankedDataSetFinal.withColumn("offset",OffSet(col("barc_aired_time"),col("spr_aired_time"))).filter("offset <= 10").drop("rank")
    val IntermOffSet       = OffSetDataSet.select("year","week","channel","date","offset","timeband","advertiser_group").withColumn("timeband",split(col("timeband"),"-").getItem(0)).distinct
    val Rightoffset        = rankAssign(IntermOffSet,Seq("channel","date"),"timeband").filter("rank==1")
    val StandardDateChannel= addTempCol(BARCDataset).select("year","week","channel","date").distinct
    StandardDateChannel.join(Rightoffset,Seq("year","week","channel","date"),"left")
  }

  def assignDefalutOffset(OffsetDataset:DataFrame) = {
    val DefaultOffset = OffsetDataset.withColumn("audit",when(col("offset").isNull,lit("F")).otherwise(lit("T")))
      .withColumn("offset",when( col("offset") > 10,lit(10)).when(col("offset").isNull,lit(7)).otherwise(col("OFFSET")))
      .na.fill("NA",Seq("timeband"))
      .withColumnRenamed("timeband","hour")
    DefaultOffset.select("year","week","channel","offset","audit","hour","date")
  }


}
