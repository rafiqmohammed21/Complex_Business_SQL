package schema.distribution

import java.sql.Date

object Distribution {
  case class Distribution_data (
                                 customer_nbr:Int,
                                 alacarte_bouquet:String,
                                 service_name:String,
                                 sms_op_hdr_id:Int,
                                 billable_product_id: Int,
                                 month_year: String,
                                 final_dpo_rate:Double,
                                 quantity:Double,
                                 charge_amount:Double,
                                 tag:String,
                                 sub_tag:String,
                                 star:String,
                                 sd_hd:String,
                                 vp:String,
                                 state:String,
                                 disney_Star:String
                                )

  case class Distribution_data_enriched (
                                          customer_nbr:Int,
                                          alacarte_bouquet:String,
                                          service_name:String,
                                          sms_op_hdr_id:Int,
                                          billable_product_id: Int,
                                          month_year: String,
                                          final_dpo_rate:Double,
                                          quantity:Double,
                                          charge_amount:Double,
                                          tag:String,
                                          sub_tag:String,
                                          star:String,
                                          sd_hd:String,
                                          vp:String,
                                          state:String,
                                          disney_Star:String,
                                          date:Date,
                                          display_state:String,
                                          display_group_state:String,
                                          display_channel_name:String,
                                          date_int:String
                                        )
  case class Distribution_active_universe(
                                           operator: String,
                                           states: String,
                                           month:Int,
                                           year:Int,
                                           active_universe:Double
                                         )
  case class Distribution_active_universe_enriched(
                                                    operator: String,
                                                    states: String,
                                                    month:Int,
                                                    year:Int,
                                                    active_universe:Double,
                                                    date:Date,
                                                    display_state:String,
                                                    display_group_state:String
                                                  )

  case class Distribution_channel_state_master(
                                                display_channel_name: String,
                                                relevant_state: String
                                              )

  case class Distribution_state_master(
                                            State: String,
                                            display_state: String,
                                            display_group_state: String
                                      )

  case class Distribution_channel_master(
                                          service_name: String,
                                          display_channel_name: String
                                      )

}