package etljobs.revenue

import _root_.util.MintGlobalProperties
import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenueProps
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, _}
import schema.revenue.SalesUnitProduct.{SalesUnitProductBQ, SalesUnitProductPostgre}

// Job specific imports
/** Object EtlJobSalesUnit gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobSalesUnit(
                            val job_properties: MintEtlJobProps,
                            val global_properties: Option[GlobalProperties]
                     )
  extends SequentialEtlJob with SparkManager {

  Logger.getLogger("org").setLevel(Level.WARN)

  var output_date_paths : Seq[(String,String)] = Seq()
  val props : RevenueProps = job_properties.asInstanceOf[RevenueProps]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  def revenueSalesUnitTransform(props:RevenueProps)(spark: SparkSession,dataset: Dataset[SalesUnitProductPostgre]) : Dataset[SalesUnitProductBQ]={
    import spark.implicits._

    val mapping = Encoders.product[SalesUnitProductBQ]
    output_date_paths=dataset
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    dataset.show()
    dataset.as[SalesUnitProductBQ](mapping)

  }

  val refresh_dates = props.refresh_dates.replaceAll(":",",")
  etl_job_logger.info("comma_sep_views_string : " + refresh_dates)
  val months = refresh_dates.split(",").toList

  val query_alias  = s""" (SELECT * FROM (SELECT *, to_date(concat(year_month,'01'),'yyyyMMdd') as date
                ,concat(year_month,'01') as date_int
                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) as channel_daypart_pt
                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) as channel_daypart_npt
                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) as channel_weekpart_wd
                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float)  as channel_weekpart_we
                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) as channel_dayparttwo_cpt
                FROM  ${props.job_input_path}) a WHERE year_month in (${refresh_dates}) ) t""".stripMargin

  val step1 =  SparkReadTransformWriteStep[SalesUnitProductPostgre, SalesUnitProductBQ](
    name                    = "Load_Jdbc_Sales_Unit_GCP",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = revenueSalesUnitTransform( props),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )

  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_Sales_Unit_BQ",
    input_location = Right(output_date_paths),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]]  = EtlStepList(step1,step2)

}

