package etljobs

import etlflow.EtlJobProps

sealed trait MintEtlJobProps extends EtlJobProps

object  MintEtlJobProps {


  case class CommonProps(
                          job_input_path: String="",
                          job_output_path: String="",
                          output_file_name:String="",
                          output_dataset: String="",
                          output_table_name: String="",
                          override val job_send_slack_notification: Boolean = true,
                          override val job_deploy_mode: String = "remote"
                        ) extends MintEtlJobProps

  case class SpotratingsProps(
                               job_input_path: String="",
                               job_output_path: String="",
                               output_dataset: String="",
                               output_table_name: String="",
                               channel_tg_table_name: String="",
                               override val job_send_slack_notification: Boolean = true,
                               override val job_deploy_mode: String = "remote"

                             ) extends MintEtlJobProps

  case class RevenueProps(
                           job_input_path: String="",
                           job_output_path: String="",
                           output_dataset: String="",
                           output_table_name: String="",
                           refresh_dates: String="",
                           override val job_send_slack_notification: Boolean = true,
                           override val job_deploy_mode: String = "remote"

                         ) extends MintEtlJobProps

  case class RevenuePropsWithOutRefreshDates(
                           job_input_path: String="",
                           job_output_path: String="",
                           output_dataset: String="",
                           output_table_name: String="",
                           override val job_send_slack_notification: Boolean = true,
                           override val job_schedule: String,
                           override val job_deploy_mode: String = "remote"
                                            ) extends MintEtlJobProps

  case class RevenuePropsWithRegAndEntWithoutRefreshDates(
                                        ent_job_input_path: String="",
                                        ent_job_output_path: String="",
                                        ent_output_dataset: String="",
                                        ent_output_table_name: String="",
                                        reg_job_input_path: String="",
                                        reg_job_output_path: String="",
                                        reg_output_dataset: String="",
                                        reg_output_table_name: String="",
                                        override val job_send_slack_notification: Boolean = true,
                                        override val job_deploy_mode: String = "remote"
                                                         ) extends MintEtlJobProps

  case class RevenuePropsForRegOrEnt(
                                                           ent_job_input_path: String="",
                                                           ent_job_output_path: String="",
                                                           ent_output_dataset: String="",
                                                           ent_output_table_name: String="",
                                                           reg_job_input_path: String="",
                                                           reg_job_output_path: String="",
                                                           reg_output_dataset: String="",
                                                           reg_output_table_name: String="",
                                                           bu: String="",
                                                           override val job_send_slack_notification: Boolean = true,
                                                           override val job_schedule: String,
                                                           override val job_deploy_mode: String = "remote"

                                    ) extends MintEtlJobProps

  case class RevenuePropsForRegOrEntWithRefreshDates(
                                                           ent_job_input_path: String="",
                                                           ent_job_output_path: String="",
                                                           ent_output_dataset: String="",
                                                           ent_output_table_name: String="",
                                                           reg_job_input_path: String="",
                                                           reg_job_output_path: String="",
                                                           reg_output_dataset: String="",
                                                           reg_output_table_name: String="",
                                                           bu: String="",
                                                           refresh_dates: String="",
                                                           override val job_send_slack_notification: Boolean = true,
                                                           override val job_deploy_mode: String = "remote"

                                                    ) extends MintEtlJobProps

  case class RevenuePropsMintBqSdb(

                                    job_input_path: String="",
                                    job_output_path: String="",
                                    output_dataset: String="",
                                    output_table_name: String="",
                                    override val job_send_slack_notification: Boolean = true,
                                    override val job_schedule: String,
                                    override val job_deploy_mode: String = "remote"

                                  ) extends MintEtlJobProps

  case class RevenuePropsWithRegEntAndSalesWithoutRefreshDates(
                                                           ent_job_input_path: String="",
                                                           ent_job_output_path: String="",
                                                           ent_output_dataset: String="",
                                                           ent_output_table_name: String="",
                                                           reg_job_input_path: String="",
                                                           reg_job_output_path: String="",
                                                           reg_output_dataset: String="",
                                                           reg_output_table_name: String="",
                                                           override val job_send_slack_notification: Boolean = true,
                                                           override val job_deploy_mode: String = "remote"

                                                              ) extends MintEtlJobProps

  case class RevenuePropsForRegOrEntWithSalesDB(

                                                                ent_job_input_path: String="",
                                                                ent_job_output_path: String="",
                                                                ent_output_dataset: String="",
                                                                ent_output_table_name: String="",
                                                                reg_job_input_path: String="",
                                                                reg_job_output_path: String="",
                                                                reg_output_dataset: String="",
                                                                reg_output_table_name: String="",
                                                                bu: String="",
                                                                override val job_send_slack_notification: Boolean = true,
                                                                override val job_schedule:String,
                                                                override val job_deploy_mode: String = "remote"

                                               ) extends MintEtlJobProps

  case class RevSRAndSales(

                                                                rev_job_input_path: String="",
                                                                rev_job_output_path: String="",
                                                                rev_output_dataset: String="",
                                                                rev_output_table_name: String="",
                                                                sr_job_input_path: String="",
                                                                sr_job_output_path: String="",
                                                                sr_output_dataset: String="",
                                                                sr_output_table_name: String="",
                                                                override val job_send_slack_notification: Boolean = true,
                                                                override val job_schedule: String,
                                                                override val job_deploy_mode: String = "local"


                          ) extends MintEtlJobProps

  case class RevenueOnAirSprProps(

                                   job_output_path: String="",
                                   output_dataset: String="",
                                   output_table_name: String="",
                                   currency_input_data_path: String="",
                                   current_date: String="",
                                   spr_history_load_input_path:String="",
                                   champ_history_load_input_path:String="",
                                   override val job_send_slack_notification: Boolean = true,
                                   override val job_deploy_mode: String = "remote"

                                 ) extends MintEtlJobProps

  case class DistributionProps(
                               job_input_path: String="",
                               job_output_path: String="",
                               output_file_name: String="",
                               output_dataset: String="",
                               output_table_name: String="",
                               override val job_send_slack_notification: Boolean = true,
                               override val job_schedule: String,
                               override val job_deploy_mode: String = "remote"

                              ) extends MintEtlJobProps


  case class QcJobProps(
                         job_type:String="",
                         job_input_path: String="",
                         job_output_path: String="",
                         qc_result_path:String="",
                         debug_mode:String="",
                         ingestion_output_path:String="",

                         override val job_send_slack_notification: Boolean = true,
                         override val job_deploy_mode: String = "remote"
                       ) extends MintEtlJobProps

  case class MasterFileProps(
                              job_input_path: String="",
                              job_output_path: String="",
                              output_dataset: String="",
                              output_table_name: String="",
                              override val job_send_slack_notification: Boolean = true,
                              override val job_deploy_mode: String = "remote"

                            ) extends MintEtlJobProps

  case class RevenueSportsPrismTournamentProps(
                                 job_input_path: String="",
                                 job_output_path: String="",
                                 output_dataset: String="",
                                 output_table_name: String="",
                                 refresh_start_date: String="",
                                 override val job_send_slack_notification: Boolean = true,
                                 override val job_deploy_mode: String = "local"
                                              ) extends MintEtlJobProps

  case class RevenueSportsProgLogsProps(
                                 job_input_path: String="",
                                 job_output_path: String="",
                                 output_dataset: String="",
                                 output_table_name: String="",
                                 override val job_send_slack_notification: Boolean = true,
                                 override val job_deploy_mode: String = "remote"
                                       ) extends MintEtlJobProps

  case class DistributionChannelMasterProps(
                                              job_input_path: String="",
                                              job_output_path: String="",
                                              distribution_channel_state_master_input_path:String="",
                                              job_channel_state_output_path:String="",
                                              distribution_output_dataset: String="",
                                              distribution_output_table_name: String="",
                                              distribution_output_channel_state_master_table_name: String="",
                                              channel_master_input_path: String="",
                                              distribution_state_master_input_path: String="",
                                              output_dataset: String="",
                                              override val job_send_slack_notification: Boolean = true,
                                              override val job_deploy_mode: String = "remote"
                                           ) extends MintEtlJobProps

  case class PricingJobProps(

                              job_type: String="",
                              job_run_year: String="",
                              job_run_week: String="",
                              job_output_dataset: String="",
                              job_output_table_name: String="",
                              bucket_name: String="star-dl-temp-mint",
                              raw_path_prefix:String="landingzone/pricing",
                              qc_path_prefix:String="landingzone/pricing_qc",
                              key_file:String="SUCCESS.txt",
                              override val job_send_slack_notification: Boolean = true,
                              override val job_schedule: String,
                              override val job_deploy_mode: String = "remote"
                            ) extends MintEtlJobProps

  case class PricingOneMinJobProps(
                                    job_type: String="",
                                    job_run_year: String="",
                                    job_run_week: String="",
                                    bucket_name: String="star-dl-temp-mint",
                                    path_prefix:String="landingzone/posteval/raw_files",
                                    key_file:String="SUCCESS.txt",
                                    override val job_send_slack_notification: Boolean = true,
                                    override val job_schedule: String,
                                    override val job_deploy_mode: String = "remote"
                                  ) extends MintEtlJobProps

  case class DownloadJobProps(

                             job_module: String="",
                             job_token: String="",
                             job_business: String="",
                             override val job_send_slack_notification: Boolean = true,
                             override val job_deploy_mode: String = "remote"

                             ) extends MintEtlJobProps
  case class DataTransferProps(

                                job_transfer_required: String="",
                                job_transfer_data_btw: String="",
                                job_description1: String="",
                                job_source_bucket: String="",
                                job_dest_bucket: String="",
                                job_data_path_prefix:String="",
                                job_dl_source_folder:Boolean=false,
                                job_ow_dest_folder:Boolean=false,
                                override val job_send_slack_notification: Boolean = true,
                                override val job_deploy_mode: String = "local"

                              ) extends MintEtlJobProps

  case class HotstarEntProps(
                             daily_channel_job_input_path: Option[String]=Some(""),
                             daily_show_job_input_path: Option[String]=Some(""),
                             weekly_channel_job_input_path: Option[String]=Some(""),
                             weekly_show_job_input_path: Option[String]=Some(""),

                             daily_channel_job_output_path: Option[String]=Some(""),
                             daily_show_job_output_path: Option[String]=Some(""),
                             weekly_channel_job_output_path: Option[String]=Some(""),
                             weekly_show_job_output_path: Option[String]=Some(""),

                             daily_channel_output_file_name:Option[String]=Some(""),
                             daily_show_output_file_name:Option[String]=Some(""),
                             weekly_channel_output_file_name:Option[String]=Some(""),
                             weekly_show_output_file_name:Option[String]=Some(""),

                             output_dataset: Option[String]=Some(""),

                             daily_channel_output_table_name: Option[String]=Some(""),
                             daily_show_output_table_name: Option[String]=Some(""),
                             weekly_channel_output_table_name: Option[String]=Some(""),
                             weekly_show_output_table_name: Option[String]=Some(""),
                             override val job_send_slack_notification: Boolean = true,
                             override val job_deploy_mode: String = "local",
                             override val job_schedule: String
                            ) extends MintEtlJobProps


  case class HotstarSptProps(
                             daily_cum_viewers_job_input_path: Option[String]=Some(""),
                             daily_video_viewers_job_input_path: Option[String]=Some(""),
                             match_wise_peak_concurrency_job_input_path: Option[String]=Some(""),
                             match_wise_video_viewers_job_input_path: Option[String]=Some(""),

                             daily_cum_viewers_job_output_path: Option[String]=Some(""),
                             daily_video_viewers_job_output_path: Option[String]=Some(""),
                             match_wise_peak_concurrency_job_output_path: Option[String]=Some(""),
                             match_wise_video_viewers_job_output_path: Option[String]=Some(""),

                             daily_cum_viewers_output_file_name:Option[String]=Some(""),
                             daily_video_viewers_output_file_name:Option[String]=Some(""),
                             match_wise_peak_concurrency_output_file_name:Option[String]=Some(""),
                             match_wise_video_viewers_output_file_name:Option[String]=Some(""),

                             output_dataset: Option[String]=Some(""),

                             daily_cum_viewers_output_table_name: Option[String]=Some(""),
                             daily_video_viewers_output_table_name: Option[String]=Some(""),
                             match_wise_peak_concurrency_output_table_name: Option[String]=Some(""),
                             match_wise_video_viewers_output_table_name: Option[String]=Some(""),
                             override val job_send_slack_notification: Boolean = true,
                             override val job_deploy_mode: String = "local",
                             override val job_schedule: String
                            ) extends MintEtlJobProps

}
