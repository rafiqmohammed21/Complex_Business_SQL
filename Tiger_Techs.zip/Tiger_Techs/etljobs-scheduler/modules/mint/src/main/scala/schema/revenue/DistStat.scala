package schema.revenue

object DistStat {

case class DistStatAllocation (  year:Int,
                                 month:Int,
                                 bouquet_name:String,
                                 channel_name:String,
                                 stat_allocation:Float,
                                 stat_allocation_total:Float,
                                 stat_allocation_wt:Float
                                )

}
