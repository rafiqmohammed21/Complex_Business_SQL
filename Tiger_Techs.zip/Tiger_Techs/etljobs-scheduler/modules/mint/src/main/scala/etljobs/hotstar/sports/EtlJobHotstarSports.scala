package etljobs.hotstar.sports

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, DataprocSparkJobStep, EtlStep, GCSPutStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.HotstarSptProps
import org.apache.spark.sql.SaveMode
import schema.hotstar.HotstarSports.{HotstarDailyCumViewerBQ, HotstarDailyVideoViewersBQ, HotstarMatchwisePeakConcurrencyBQ, HotstarMatchwiseVideoViewersBQ}
import util.Configs


case class EtlJobHotstarSports(
                                val job_properties: MintEtlJobProps,
                                val global_properties: Option[GlobalProperties]
                                  )

  extends  SequentialEtlJob with SparkUDF with SparkManager {

  val props : HotstarSptProps = job_properties.asInstanceOf[HotstarSptProps]
  val canonical_path: String          = new java.io.File(".").getCanonicalPath

  val mr_file = Configs.mr_file
  etl_job_logger.info("mr_file  : " + mr_file)
  val local_docker_path = "/tmp"
  etl_job_logger.info("local_docker_path  : " + local_docker_path)

  val daily_video_viewers_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_video_viewers_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_video_viewers_gcs_bucket_prefix").get
  val daily_cum_viewers_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_cum_viewers_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_cum_viewers_gcs_bucket_prefix").get
  val matchwise_video_viewers_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_spt_info.get("hotstar_matchwise_video_viewers_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_spt_info.get("hotstar_matchwise_video_viewers_gcs_bucket_prefix").get
  val match_wise_peak_concurrency_mintreporting_path = "gs://" + Configs.hotstar_mintreporting_spt_info.get("hotstar_match_wise_peak_concurrency_gcs_bucket").get + "/" + Configs.hotstar_mintreporting_spt_info.get("hotstar_match_wise_peak_concurrency_gcs_bucket_prefix").get

  etl_job_logger.info("daily_video_viewers_mintreporting_path  : " + daily_video_viewers_mintreporting_path)
  etl_job_logger.info("daily_cum_viewers_mintreporting_path  : " + daily_cum_viewers_mintreporting_path)
  etl_job_logger.info("matchwise_video_viewers_mintreporting_path  : " + matchwise_video_viewers_mintreporting_path)
  etl_job_logger.info("match_wise_peak_concurrency_mintreporting_path  : " + match_wise_peak_concurrency_mintreporting_path)
  etl_job_logger.info("match_wise_peak_concurrency_mintreporting_path  : " + match_wise_peak_concurrency_mintreporting_path)

  val hotstar_spt_job = DataprocSparkJobStep(
    name     = "DataProc Job Submission for EtlJobHotstarSport",
    job_name = "EtlJobHotstarSportSteps",
    props    = Map(),
    global_properties = global_properties
  )

  val load_daily_video_viewers_locally = SparkReadWriteStep[HotstarDailyVideoViewersBQ](
    name                    = "load_daily_video_viewers_locally",
    input_location          = Seq(props.daily_video_viewers_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_daily_video_viewers",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_daily_video_viewers.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val loda_daily_cum_viewers_locally = SparkReadWriteStep[HotstarDailyCumViewerBQ](
    name                    = "loda_daily_cum_viewers_locally",
    input_location          = Seq(props.daily_cum_viewers_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_daily_cum_viewers",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_daily_cum_viewers.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,


  )


  val load_matchwise_video_viewer_locally = SparkReadWriteStep[HotstarMatchwiseVideoViewersBQ](
    name                    = "load_matchwise_video_viewer_locally",
    input_location          = Seq(props.match_wise_video_viewers_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_matchwise_video_viewer",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_matchwise_video_viewer.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val load_match_wise_peak_concurrency_locally = SparkReadWriteStep[HotstarMatchwisePeakConcurrencyBQ](
    name                    = "load_match_wise_peak_concurrency_locally",
    input_location          = Seq(props.match_wise_peak_concurrency_job_output_path.get),
    input_type              = ORC,
    output_location         = s"$local_docker_path/ht_match_wise_peak_concurrency",
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some("ht_match_wise_peak_concurrency.orc"),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val gcsput_step_for_daily_video_viewers = GCSPutStep(
    name    = "gcsput_step_for_daily_video_viewers",
    bucket  = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_video_viewers_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_video_viewers_gcs_bucket_prefix").get + "/" + "ht_daily_video_viewers.orc",
    file    = s"$local_docker_path/ht_daily_video_viewers/ht_daily_video_viewers.orc",
    credentials = mr_file
  )

  val gcsput_step_for_daily_cum_viewers = GCSPutStep(
    name    = "gcsput_step_for_daily_cum_viewers",
    bucket  = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_cum_viewers_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_cum_viewers_gcs_bucket_prefix").get + "/" + "ht_daily_cum_viewers.orc",
    file    = s"$local_docker_path/ht_daily_cum_viewers/ht_daily_cum_viewers.orc",
    credentials = mr_file
  )

  val gcsput_step_for_matchwise_video_viewer = GCSPutStep(
    name    = "gcsput_step_for_matchwise_video_viewer",
    bucket  = Configs.hotstar_mintreporting_spt_info.get("hotstar_matchwise_video_viewers_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_spt_info.get("hotstar_matchwise_video_viewers_gcs_bucket_prefix").get + "/" + "ht_matchwise_video_viewer.orc",
    file    = s"$local_docker_path/ht_matchwise_video_viewer/ht_matchwise_video_viewer.orc",
    credentials = mr_file
  )


  val gcsput_step_for_match_wise_peak_concurrency = GCSPutStep(
    name    = "gcsput_step_for_match_wise_peak_concurrency",
    bucket  = Configs.hotstar_mintreporting_spt_info.get("hotstar_match_wise_peak_concurrency_gcs_bucket").get,
    key     = Configs.hotstar_mintreporting_spt_info.get("hotstar_match_wise_peak_concurrency_gcs_bucket_prefix").get + "/" + "ht_match_wise_peak_concurrency.orc",
    file    = s"$local_docker_path/ht_match_wise_peak_concurrency/ht_match_wise_peak_concurrency.orc",
    credentials = mr_file
  )


  val daily_video_viewers_mintreporting_bq_ingestion = BQLoadStep[HotstarDailyVideoViewersBQ](
    name                            = "daily_video_viewers_mintreporting_bq_ingestion",
    input_location                  = Left(daily_video_viewers_mintreporting_path + "/" + "ht_daily_video_viewers.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_video_viewers").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )

  val daily_cum_viewers_mintreporting_bq_ingestion = BQLoadStep[HotstarDailyCumViewerBQ](
    name                            = "daily_cum_viewers_mintreporting_bq_ingestion",
    input_location                  = Left(daily_cum_viewers_mintreporting_path +  "/" + "ht_daily_cum_viewers.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_spt_info.get("hotstar_daily_cum_viewers").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )


  val matchwise_video_viewers_mintreporting_bq_ingestion = BQLoadStep[HotstarMatchwiseVideoViewersBQ](
    name                            = "matchwise_video_viewers_mintreporting_bq_ingestion",
    input_location                  = Left(matchwise_video_viewers_mintreporting_path + "/" + "ht_matchwise_video_viewer.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_spt_info.get("hotstar_matchwise_video_viewers").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials =mr_file
  )


  val match_wise_peak_concurrency_mintreporting_bq_ingestion = BQLoadStep[HotstarMatchwisePeakConcurrencyBQ](
    name                            = "match_wise_peak_concurrency_mintreporting_bq_ingestion",
    input_location                  = Left(match_wise_peak_concurrency_mintreporting_path + "/" + "ht_match_wise_peak_concurrency.orc"),
    input_type                      = ORC,
    output_dataset                  = Configs.hotstar_mintreporting_dataset.get("hotstar_mintreporting_dataset").get,
    output_table                    = Configs.hotstar_mintreporting_spt_info.get("hotstar_match_wise_peak_concurrency").get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED ,
    credentials = mr_file
  )



  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(
    hotstar_spt_job,
    load_daily_video_viewers_locally,
    loda_daily_cum_viewers_locally,
    load_matchwise_video_viewer_locally,
    load_match_wise_peak_concurrency_locally,
    gcsput_step_for_daily_video_viewers,
    gcsput_step_for_daily_cum_viewers,
    gcsput_step_for_matchwise_video_viewer,
    gcsput_step_for_match_wise_peak_concurrency,
    daily_video_viewers_mintreporting_bq_ingestion,
    daily_cum_viewers_mintreporting_bq_ingestion,
    matchwise_video_viewers_mintreporting_bq_ingestion,
    match_wise_peak_concurrency_mintreporting_bq_ingestion
  )


}