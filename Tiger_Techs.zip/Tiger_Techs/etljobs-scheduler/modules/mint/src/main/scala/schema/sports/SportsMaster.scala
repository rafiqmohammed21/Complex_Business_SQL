package schema.sports

import java.sql.Date

object SportsMasters {

  case class Season_Event (
                            event_prism:String,
                            edition_prism:String,
                            event_epm:String,
                            F_year:String,
                            star_property:Boolean,
                            edition_epm:String,
                            edition_number:Integer,
                            DD_Network:Boolean
                          )
  case class Onair_Till_Barc(
                              On_air_channel_name:String,
                              BARC_Date:Date,
                              F_year:Integer,
                              BARC_programme_name:String,
                              BARC_Start_Time:String,
                              BARC_End_Time:String,
                              Final_Name:String,
                              programme_genre:String,
                              broad_event:String,
                              event:String,
                              edition:String,
                              Match:String,
                              Team_1:String,
                              Team_2:String,
                              Teams:String,
                              spot_tag:Boolean,
                              Edition_number:Integer,
                              event_start:Date,
                              event_end:Date )
  case class Onair_After_Barc(
                               channel_name:String,
                               date:Date,
                               F_year:Integer,
                               programme_name:String,
                               broad_event:String,
                               event:String,
                               edition:String,
                               Match:String,
                               Team_1:String,
                               Team_2:String,
                               Teams:String,
                               spot_tag:Boolean,
                               Edition_number:Integer,
                               event_start:Date,
                               event_end:Date)
  case class Sports_Viewership_Master(
                                       BARC_name:String,
                                       broad_event:String,
                                       event:String,
                                       edition:String,
                                       F_year:Integer,
                                       programme_genre:String,
                                       Match:String,
                                       Team_1:String,
                                       Team_2:String,
                                       Teams:String,
                                       star_property:Boolean,
                                       Edition_number:Integer,
                                       DD_Network:Boolean
                                     )
  case class Sports_Barc_Week (
                                BARC_Year:Integer,
                                BARC_Week:Integer,
                                BARC_Month:Integer,
                                Start_date:Date,
                                End_date:Date,
                                Quarter:String,
                                F_Year:String
                              )
}
