package schema.distribution

object DistributionChannelBouquet {

  case class DistributionChannelBouquetBQ(
                                           bouquet_code:String,
                                           bouquet_name:String,
                                           channel_code:String,
                                           channel_name:String
                                         )

}