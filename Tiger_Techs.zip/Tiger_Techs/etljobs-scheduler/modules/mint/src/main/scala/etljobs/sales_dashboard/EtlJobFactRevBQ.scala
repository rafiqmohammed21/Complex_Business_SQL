package etljobs.sales_dashboard

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, DBQueryStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsWithOutRefreshDates
import org.apache.spark.sql.SaveMode
import schema.revenue.SalesDB.{FactRevSchema, FactRevSpdSchema}
import util.MintGlobalProperties

// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobFactRevBQ(
                            val job_properties: MintEtlJobProps,
                            val global_properties: Option[GlobalProperties]
                     )
  extends SequentialEtlJob  with SparkManager{

  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val query  = "SELECT * FROM `mint-bi-reporting.revenue_reports.ent_fact_revenue`"
  val query_spd  = "SELECT * FROM `mint-bi-reporting.test_reports.ent_fact_revenue_spd`"


  val step1 = BQLoadStep(
    name                            = "UPDATE_BQ_FACT_REV",
    input_location                  =  Left(query),
    input_type                      = BQ,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step2 = SparkReadWriteStep[ FactRevSchema](
    name                    = "LOAD_FACT_REV_POSTGRES_TEMP",
    input_location          = Seq(s"${props.output_dataset}.${props.output_table_name}"),
    input_type              = BQ,
    output_location         = "ent_fact_revenue_temp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )
  val step3 = DBQueryStep(
    name  = "POSTGRES_UPDATE_FACT_REV_TABLE",
    query = "Begin; delete from ent_fact_revenue where 1 =1; insert into ent_fact_revenue  select * from ent_fact_revenue_temp; commit;",
    credentials = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver)
  )
  val step4 = BQLoadStep(
    name                            = "UPDATE_BQ_FACT_REV_SPD",
    input_location                  =  Left(query_spd),
    input_type                      = BQ,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name+"_spd",
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step5 = SparkReadWriteStep[FactRevSpdSchema](
    name                    = "LOAD_FACT_REV_SPD_POSTGRES_TEMP",
    input_location          = Seq(s"${props.output_dataset}.${props.output_table_name}_spd"),
    input_type              = BQ,
    output_location         = "ent_fact_revenue_spd_temp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )
  val step6 = DBQueryStep(
    name  = "POSTGRES_UPDATE_FACT_REV_SPD_TABLE",
    query = "Begin; delete from ent_fact_revenue_spd where 1 =1; insert into ent_fact_revenue_spd  select * from ent_fact_revenue_spd_temp; commit;",
    credentials = JDBC(mint_global_properties.sales_db_postgre_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver)
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2,step3,step4,step5,step6)

}