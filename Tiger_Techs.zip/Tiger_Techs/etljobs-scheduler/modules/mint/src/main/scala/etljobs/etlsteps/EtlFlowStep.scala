package etljobs.etlsteps

import etlflow.etlsteps.EtlStep
import etljobs.MintEtlJobName.{EtlJobPricing => EJP}
import zio.Task

class EtlFlowStep(
                val name:String  ,
                val job_name: String,
                val props: Map[String,String]
              )
  extends EtlStep[Unit,Unit] {


  final def process(in: =>Unit): Task[Unit] = {
    etl_logger.info("#"*100)
    etl_logger.info(s"Starting Job Submission for : $job_name")

    val etl_job =  etljobs.viewership.pricing.EtlJobPricing(EJP.getActualProperties(props),None)
    etl_job.job_name = job_name.toString
    etl_job.execute()
  }

  override def getStepProperties(level: String): Map[String, String] = Map("query" -> "")
}




