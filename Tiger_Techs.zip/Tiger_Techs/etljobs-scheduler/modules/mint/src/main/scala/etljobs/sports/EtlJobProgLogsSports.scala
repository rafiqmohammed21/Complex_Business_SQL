package etljobs.sports

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, ORC, PARQUET}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenueSportsProgLogsProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.sports.BarcPP.{BarcProgLog, BarcProgLogEnriched}

case class EtlJobProgLogsSports(
                                 val job_properties:MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                          )
  extends  SequentialEtlJob  with udfs.Download with SparkManager {

  var start_date : String = ""
  var end_date : String = ""
  var output_date_paths : Seq[(String,String)] = Seq()
  lazy val reg_logger = Logger.getLogger(getClass.getName)

  val props : RevenueSportsProgLogsProps = job_properties.asInstanceOf[RevenueSportsProgLogsProps]

  def enrichBarcPP(spark: SparkSession,dataset: Dataset[BarcProgLog]) : Dataset[BarcProgLogEnriched] = {
    import spark.implicits._

    val barc_pp_enriched_mapping = Encoders.product[BarcProgLogEnriched]
    val enrichedPP = dataset
      .withColumn("date_int" , expr(""" REPLACE( CAST (`week_date` as String), "-","") """))
      .as[BarcProgLogEnriched](barc_pp_enriched_mapping)
    output_date_paths = enrichedPP
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))
    start_date = enrichedPP.selectExpr("min(week_date)").first().getDate(0).toString
    end_date = enrichedPP.selectExpr("max(week_date)").first().getDate(0).toString
    reg_logger.info(s"start_date is: $start_date  and end_date is $end_date")

    enrichedPP
  }

  val step1 = SparkReadTransformWriteStep[BarcProgLog, BarcProgLogEnriched](
    name                    = "load_barc_prog_logs_gcs",
    input_location          = Seq(props.job_input_path),
    input_type              = PARQUET,
    output_location         = props.job_output_path,
    transform_function      = enrichBarcPP,
    output_type             = ORC,
    output_partition_col    = Seq("date_int"),
    output_save_mode        = SaveMode.Overwrite,
    output_repartitioning   = true
  )

  val step2 = BQLoadStep(
    name                    = "load_barc_prog_logs_gcs_BQ",
    input_location = Right(output_date_paths),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}