package schema.master

object BIAdvertiserMaster {
  case class BIAdvertiserMaster (
                                  Sr_No:Int,
                                  ADVERTISER:String,
                                  ADVERTISER_GROUP_name:String,
                                  NEW_CATEGORY:String,
                                  Region:String,
                                  OLD_ECS:String,
                                  NEW_ECS:String
                                )
}