package schema.distribution

import java.sql.{Date, Timestamp}

object DistributionRevenue {
  case class DistributionRevenueOracle (
                                         customer_nbr:String,
                                         bouquet_alacarte:String,
                                         bouquet_alacarte_name: String,
                                         monthly_average:String,
                                         charge_amount:String,
                                         type_of_billing: String,
                                         total_amount: String,
                                         month_year: String,
                                         vertical:String,
                                         is_pushed_to_billing:String,
                                         dpo_name:String,
                                         date:Timestamp,
                                         date_int: String
                                        )

  case class DistributionRevenueBQ (
                                     customer_nbr:String,
                                     bouquet_alacarte:String,
                                     bouquet_alacarte_name: String,
                                     monthly_average:Double,
                                     charge_amount:Double,
                                     type_of_billing: String,
                                     total_amount: Double,
                                     vertical:String,
                                     is_pushed_to_billing:String,
                                     dpo_name:String,
                                     date:Date,
                                     month:Int,
                                     year:Int,
                                     date_int: String
                                   )


}
