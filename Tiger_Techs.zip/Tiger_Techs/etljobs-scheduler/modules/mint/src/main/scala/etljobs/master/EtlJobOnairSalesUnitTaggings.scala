package etljobs.master

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEnt
import org.apache.log4j.{Level, Logger}
import schema.master.{OnairSalesUnitTaggings, OnairSalesUnitTaggingsBQ}
import util.MintGlobalProperties
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, _}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

case class EtlJobOnairSalesUnitTaggings(
                                         val job_properties: MintEtlJobProps,
                                         val global_properties: Option[GlobalProperties]
                                  )
  extends  SequentialEtlJob with SparkUDF with SparkManager {

  Logger.getLogger("org").setLevel(Level.WARN)

  var output_date_paths : Seq[(String,String)] = Seq()
  val props : RevenuePropsForRegOrEnt = job_properties.asInstanceOf[RevenuePropsForRegOrEnt]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  def enrichDfOnairSalesUnitTaggings(spark: SparkSession,dataset: Dataset[OnairSalesUnitTaggings]) : Dataset[OnairSalesUnitTaggingsBQ]={
    val mapping  = Encoders.product[OnairSalesUnitTaggingsBQ]
    dataset
      .withColumn("month",col("month").cast(IntegerType))
      .as[OnairSalesUnitTaggingsBQ](mapping)
  }

  val query_alias =
    """ (SELECT * FROM onair_sales_unit_taggings) t """.stripMargin

  val step1 =  SparkReadTransformWriteStep[OnairSalesUnitTaggings, OnairSalesUnitTaggingsBQ](
    name                    = "Load_Jdbc_onair_sales_unit_taggings_ent",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichDfOnairSalesUnitTaggings,
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_onair_sales_unit_taggings_BQ_ent",
    input_location             = Left(props.ent_job_output_path+ "/part*"),
    input_type           = ORC,
    output_dataset     = props.ent_output_dataset,
    output_table       = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step3 =  SparkReadTransformWriteStep[OnairSalesUnitTaggings, OnairSalesUnitTaggingsBQ](
    name                    = "Load_Jdbc_onair_sales_unit_taggings_reg",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = enrichDfOnairSalesUnitTaggings,
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step4 = BQLoadStep(
    name                    = "Load_Jdbc_onair_sales_unit_taggings_BQ_reg",
    input_location             = Left(props.reg_job_output_path+ "/part*"),
    input_type           = ORC,
    output_dataset     = props.reg_output_dataset,
    output_table       = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = {
    if (props.bu == "ent") EtlStepList(step1,step2)
    else if (props.bu == "reg") EtlStepList(step3,step4)
    else EtlStepList(step1,step2,step3,step4)
  }
}
