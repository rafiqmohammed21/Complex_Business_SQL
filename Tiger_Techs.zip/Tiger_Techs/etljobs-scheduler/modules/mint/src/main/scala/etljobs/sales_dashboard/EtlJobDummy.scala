package etljobs.sales_dashboard


import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQQueryStep, EtlStep}
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps

case class EtlJobDummy(
  val job_properties: MintEtlJobProps,
  val global_properties: Option[GlobalProperties]
)
  extends SequentialEtlJob  {
  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val step1 = BQQueryStep(
    name                    = "",
    query                   = " delete from test.reg_funnel where year_month in ('201907'); "
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1)


}