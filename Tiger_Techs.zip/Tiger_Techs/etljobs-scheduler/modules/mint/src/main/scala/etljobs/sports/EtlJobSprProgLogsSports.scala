package etljobs.sports

import java.text.SimpleDateFormat
import java.util.Calendar

import com.google.cloud.bigquery.{FormatOptions, JobInfo}
import com.google.cloud.bigquery.JobInfo.CreateDisposition.CREATE_IF_NEEDED
import com.google.cloud.bigquery.JobInfo.WriteDisposition.WRITE_TRUNCATE
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, BQQueryStep, EtlStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{BQ, GlobalProperties}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps


// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobSprProgLogsSports(
                                    val job_properties:MintEtlJobProps,
                                    val global_properties: Option[GlobalProperties]
                             )
  extends  SequentialEtlJob with udfs.Download with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val date_format = new SimpleDateFormat("yyyy-MM-dd")
  val cal = Calendar.getInstance()
  cal.add(Calendar.DATE, -15)
  val start_date = date_format.format(cal.getTime())
  cal.add(Calendar.DATE, 45)
  val end_date : String = date_format.format(cal.getTime())
  var result_seq :Seq[(String,String)] = Seq()
  def getSeqOfQueryAndTable(props:CommonProps):Seq[(String,String)]= {
    for (i <- 0 to 45) {
      val cal = Calendar.getInstance()
      cal.add(Calendar.DATE, -15 + i)
      val date_format = new SimpleDateFormat("yyyy-MM-dd")
      val updateDate = date_format.format(cal.getTime())
      val partitionDate = "$" + updateDate.replace("-", "")
      val query  = s"""  SELECT * FROM revenue_reports.view_spr_prog_logs_sports WHERE telecast_date = '$updateDate' """
      result_seq = result_seq:+(query,props.output_table_name + s"$partitionDate")
    }
    //result_seq.foreach(x=>println(x))
    result_seq
  }

//  val step1 = BQLoadStep(
//    name = "UpdateBQTable",
//    input_location = Left(getSeqOfQueryAndTable(props)),
//    destination_dataset = props.output_dataset,
//    destination_table = props.output_table_name,
//    source_format = FormatOptions.bigtable(),
//    write_disposition = WRITE_TRUNCATE,
//    create_disposition = CREATE_IF_NEEDED
//  )

  val step1 = BQLoadStep(
    name = "UpdateBQTable",
    input_location = Right(getSeqOfQueryAndTable(props)),
    input_type           = BQ,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)

}