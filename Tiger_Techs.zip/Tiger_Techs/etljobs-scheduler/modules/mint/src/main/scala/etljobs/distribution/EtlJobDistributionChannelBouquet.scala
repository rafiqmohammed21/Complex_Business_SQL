package etljobs.distribution

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DistributionProps
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SaveMode
import schema.distribution.DistributionChannelBouquet.DistributionChannelBouquetBQ
import util.MintGlobalProperties

// Job specific imports
/** Object EtlJobDistributionChannelBouquet gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobDistributionChannelBouquet(
                                             val job_properties: MintEtlJobProps,
                                             val global_properties: Option[GlobalProperties]
                                      )
  extends SequentialEtlJob with SparkUDF with SparkManager {

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : DistributionProps = job_properties.asInstanceOf[DistributionProps]

  val query_alias=s""" ( SELECT A.BOUQUET_CODE as "bouquet_code"
                                 ,(SELECT DISTINCT(SERVICE_NAME) FROM oneview.SERVICE WHERE SERVICE_CODE=A.BOUQUET_CODE AND IS_BOUQUET='Y') "bouquet_name"
                                 ,A.CHANNEL_CODE as "channel_code"
                                 ,(SELECT DISTINCT CHANNEL_NAME FROM oneview.CHANNEL WHERE CHANNEL_CODE=A.CHANNEL_CODE) "channel_name"
                           FROM oneview.BOUQUET_CHANNEL A WHERE A.STATUS='A' ORDER BY 1
                              ) f """.stripMargin

  val step1 = SparkReadWriteStep[DistributionChannelBouquetBQ](
    name                    = "Load_distribution_channel_bouquet",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.oracle_jdbc_jdbc, mint_global_properties.oracle_user, mint_global_properties.oracle_password, mint_global_properties.oracle_driver),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_filename         = Some(props.output_file_name),
    output_save_mode        = SaveMode.Overwrite,
    output_repartitioning   = true,
    output_repartitioning_num = 1
  )

  val step2 = BQLoadStep(
    name                         = "Load_distribution_channel_bouquet_BQ",
    input_location               = Left(props.job_output_path + "/" + props.output_file_name),
    input_type                   = ORC,
    output_dataset               = props.output_dataset,
    output_table                 = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]]  = EtlStepList(step1,step2)
}