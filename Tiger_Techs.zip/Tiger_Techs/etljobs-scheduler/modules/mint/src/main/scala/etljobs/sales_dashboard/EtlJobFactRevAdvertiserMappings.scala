package etljobs.sales_dashboard

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, DBQueryStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.SaveMode
import schema.revenue.SalesDB.FactRevAdvertiserMappingSchema
import util.MintGlobalProperties

// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobFactRevAdvertiserMappings(
                                            val job_properties: MintEtlJobProps,
                                            val global_properties: Option[GlobalProperties]
                                     )
  extends SequentialEtlJob with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val input_table = props.output_dataset + "." + props.job_input_path
  val query  =
    s"""SELECT distinct d_year, d_month, d_fin_year,
               pt_npt as Time_Slot,
               impact_regular as Program_type,
               advertiser_group as Advertiser_Group,
               region as Region,
               channel_name as Channel_Name
               FROM `mint-bi-reporting.dev.fact_revenue_common` """.stripMargin

  println("query is :" + query)

  val step1 = BQLoadStep(
    name                            = "UpdateBQTable",
    input_location                  =  Left(query),
    input_type                      = BQ,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step2 = SparkReadWriteStep[FactRevAdvertiserMappingSchema](
    name                    = "load_jdbc_revenue_fact_advertiser_mapping",
    input_location          = Seq(props.output_dataset + "." + props.output_table_name),
    input_type              = BQ,
    output_location         = props.output_table_name+"_temp",
    output_type             = JDBC(mint_global_properties.sales_db_postgre_filter_api_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver),
    output_save_mode        = SaveMode.Overwrite,
  )

  val step3 = DBQueryStep(
    name  = "POSTGRES_UPDATE_FACT_ADVERTISER_MAPPING",
    query = "Begin; delete from fact_revenue_advertiser_mappings ; insert into fact_revenue_advertiser_mappings  select * from fact_revenue_advertiser_mappings_temp; commit;",
    credentials = JDBC(mint_global_properties.sales_db_postgre_filter_api_jdbc_url, mint_global_properties.sales_db_postgre_user, mint_global_properties.sales_db_postgre_password, mint_global_properties.postgre_driver)
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2,step3)

}