package schema.hotstar

import java.sql.Date

object HotstarEntertainment {

  case class HotstarEntWeeklyShowPerformanceAws (channelname:String,
                                                 showname:String,
                                                 wvv:BigInt,
                                                 wwt:BigInt,
                                                 week_starting_on:Date,
                                                 year:Int,
                                                 week:Int
                                                )

  case class HotstarEntWeeklyShowPerformanceBQ (channelname:String,
                                                showname:String,
                                                wvv:Int,
                                                wwt:Int,
                                                week_starting_on:Date,
                                                year:Int,
                                                week:Int
                                               )

  case class HotstarEntWeeklyChannelPerformanceAws (_col0:String,
                                                    _col1:BigInt,
                                                    _col2:BigInt,
                                                    _col3:Date,
                                                    year:Int,
                                                    week:Int
                                                   )

  case class HotstarEntWeeklyChannelPerformanceBQ (channel_name:String,
                                                   weekly_video_views:Int,
                                                   weekly_watch_time:Int,
                                                   week_starting_on:Date,
                                                   year:Int,
                                                   week:Int
                                                  )

  case class HotstarEntDailyChannelPerformanceAws (_col0:Int,
                                                   _col1:String,
                                                   _col2:BigInt,
                                                   _col3:BigInt,
                                                   cd:Date
                                                  )

  case class HotstarEntDailyChannelPerformanceBQ (channel_id:Int,
                                                  channel_name:String,
                                                  daily_video_views:Int,
                                                  daily_watch_time:Int,
                                                  date:Date
                                                 )

  case class HotstarEntDailyShowPerformanceAws (_col0:String,
                                                _col1:String,
                                                _col2:BigInt,
                                                _col3:BigInt,
                                                cd:Date
                                               )

  case class HotstarEntDailyShowPerformanceBQ (channel_name:String,
                                               show_name:String,
                                               daily_video_views:Int,
                                               daily_watch_time:Int,
                                               date:Date
                                              )


}
