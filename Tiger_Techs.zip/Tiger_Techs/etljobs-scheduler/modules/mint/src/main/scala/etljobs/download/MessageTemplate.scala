package etljobs.download
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object MessageTemplate {

   def finalMessageTemplate(run_env: String, business: String, module: String, token: String,csv_path:String,status:String): String = {
    val exec_time = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm").format(LocalDateTime.now)
    val data_download_mail_template =
      s"""
         | **Please do not reply to this mail**. \n
         | 'Data Download' for business $business of module $module token is $token is $status. \n
         | Time of Execution: $exec_time. \n
         | S3 Data Download Location: $csv_path. \n
         | Time Taken for Excel Conversion: None. \n
         |""".stripMargin
    data_download_mail_template
  }
}
