//package etljobs.redis
//
//import com.google.cloud.bigquery.JobInfo
//import etlflow.EtlStepList
//import etlflow.etljobs.SequentialEtlJob
//import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
//import etlflow.spark.SparkManager
//import etlflow.utils.{GlobalProperties, JDBC, ORC}
//import etljobs.MintEtlJobProps
//import etljobs.MintEtlJobProps.RevenuePropsForRegOrEntWithRefreshDates
//import etljobs.etlsteps.RedisQueryStep
//import org.apache.log4j.{Level, Logger}
//import org.apache.spark.sql.functions.col
//import org.apache.spark.sql.types.{DoubleType, StringType}
//import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
//import schema.revenue.Funnel.{FunnelSchemaBQ, FunnelSchemaPostgre}
//import util.MintGlobalProperties
//
//// Job specific imports
///** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
// * RunEtlJob executes both etlstep mentioned in list returned by it.
// *
// * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
// * and writes in ORC format at given output path
// *
// * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
// */
//
//case class EtlJobFunnel(
//                         val job_properties: MintEtlJobProps,
//                         val global_properties: Option[GlobalProperties]
//                  )
//  extends SequentialEtlJob with SparkManager  {
//
//  val props : RevenuePropsForRegOrEntWithRefreshDates = job_properties.asInstanceOf[RevenuePropsForRegOrEntWithRefreshDates]
//
//  val refresh_dates = props.refresh_dates.replaceAll(":",",")
//  etl_job_logger.info("comma_sep_views_string : " + refresh_dates)
//
//
//  val step1 = RedisQueryStep(
//    name  = "Flush all the keys",
//    query = "flushall",
//  )
//
//  val etlStepList: List[EtlStep[Unit,Unit]] = {
//    if (props.bu == "ent") EtlStepList(step2)
//    else if (props.bu == "reg") EtlStepList(step2)
//    else EtlStepList(step1,step2,step3,step4,step5)
//  }
//}
//
