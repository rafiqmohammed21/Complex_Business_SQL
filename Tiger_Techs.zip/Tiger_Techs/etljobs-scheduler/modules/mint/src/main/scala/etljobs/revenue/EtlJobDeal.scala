package etljobs.revenue

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenueProps
import org.apache.log4j.{Level, Logger}
import schema.revenue.Deal.{DealBQ, DealPostgre}
import util.MintGlobalProperties
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, _}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType

// Job specific imports
/** Object EtlJobFunnel gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobDeal(
                       val job_properties: MintEtlJobProps,
                       val global_properties: Option[  GlobalProperties]
                )
  extends SequentialEtlJob  with SparkManager {

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenueProps = job_properties.asInstanceOf[RevenueProps]

  def revenueDealTransform(props:RevenueProps)(spark: SparkSession,dataset: Dataset[DealPostgre]) : Dataset[DealBQ]={
    import spark.implicits._

    val transformed_dataset=dataset.withColumn("channel_primary",col("channel_tgmarkets").getItem(0))
      .withColumn("channel_secondary",col("channel_tgmarkets").getItem(1))
      .withColumn("channel_genre",col("channel_tgmarkets").getItem(2))
      .withColumn("monthly_outlay",col("monthly_outlay").cast(DoubleType))
      .withColumn("monthly_fct",col("monthly_fct").cast(DoubleType))
      .withColumn("weight",col("weight").cast(DoubleType))
      .withColumn("channel_tgmarkets",col("channel_tgmarkets").cast(org.apache.spark.sql.types.StringType))
      .withColumn("week_days",col("week_days").cast(org.apache.spark.sql.types.StringType))
      .withColumnRenamed("advertiser_group_name","advertiser_group")

    val mapping = Encoders.product[DealBQ]
    output_date_paths=dataset
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    transformed_dataset.as[DealBQ](mapping)

  }

  val refresh_dates = props.refresh_dates.replaceAll(":",",")
  etl_job_logger.info("comma_sep_views_string : " + refresh_dates)

  val months = refresh_dates.split(",").toList

  val query_alias  = s""" (SELECT * FROM (SELECT *
                ,to_date(concat(year_month,'01'),'yyyyMMdd') as date
                ,concat(year_month,'01') as date_int
                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) * (monthly_outlay) as channel_pt_revenue
                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) * (monthly_outlay) as channel_npt_revenue
                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) * (monthly_outlay) as channel_wd_revenue
                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float) * (monthly_outlay)  as channel_we_revenue
                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) * (monthly_outlay) as channel_cpt_revenue
                ,((channel_skew_weight -> 'dayparttwo' ->> 'Afternoon')::Float) * (monthly_outlay) as channel_afternoon_revenue
                ,((channel_skew_weight -> 'daypart' ->> 'PT')::Float) * (monthly_fct) as channel_pt_fct
                ,((channel_skew_weight -> 'daypart' ->> 'NPT')::Float) * (monthly_fct) as channel_npt_fct
                ,((channel_skew_weight -> 'weekpart' ->> 'WD')::Float) * (monthly_fct) as channel_wd_fct
                ,((channel_skew_weight -> 'weekpart' ->> 'WE' )::Float) * (monthly_fct)  as channel_we_fct
                ,((channel_skew_weight -> 'dayparttwo' ->> 'CPT')::Float) * (monthly_fct) as channel_cpt_fct
                ,((channel_skew_weight -> 'dayparttwo' ->> 'Afternoon')::Float) * (monthly_fct) as channel_afternoon_fct
                from ${props.job_input_path})
                a WHERE year_month in (${refresh_dates}) )  t""".stripMargin


  val step1 = SparkReadTransformWriteStep[DealPostgre, DealBQ](
    name                    = "Load_Jdbc_deal_GCP",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    transform_function      = revenueDealTransform( props),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )


  val step2 = BQLoadStep[DealBQ](
    name                    = "Load_Jdbc_Sales_Unit_BQ",
    input_location          = Right(output_date_paths),
    input_type              = ORC,
    output_dataset          = props.output_dataset,
    output_table            = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}
