package util

import etlflow.utils.GlobalProperties
import org.flywaydb.core.Flyway
import org.slf4j.{Logger, LoggerFactory}

class DbMigration {

  val logger: Logger = LoggerFactory.getLogger(getClass.getName)

  def apply(global_properties: Option[GlobalProperties]) =
  {
    val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

    Flyway
      .configure(this.getClass.getClassLoader)
      .dataSource(mint_global_properties.log_db_url, mint_global_properties.log_db_user, mint_global_properties.log_db_pwd)
      .locations("db/migration")
      .connectRetries(Int.MaxValue)
      .baselineOnMigrate(true)
      .load()
      .migrate()
  }
}