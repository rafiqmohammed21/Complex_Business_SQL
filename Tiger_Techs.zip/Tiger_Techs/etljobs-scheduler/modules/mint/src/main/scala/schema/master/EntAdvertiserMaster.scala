package schema.master

import java.sql.Date

object EntAdvertiserMaster {

  case class AdvertiserDetailInfoPostGre (advertiser_name:String,
                                   onair_id:Int,
                                   source:String,
                                   region:String,
                                   advertiser_group_name:String,
                                   segment:String,
                                   advertiser_category:String,
                                   agency_group_name:String,
                                   year_month:String,
                                   date:Date
                                  )

  case class AdvertiserDetailInfoBQ (advertiser_name:String,
                                   onair_id:Int,
                                   source:String,
                                   region:String,
                                   advertiser_group_name:String,
                                   segment:String,
                                   advertiser_category:String,
                                   agency_group_name:String,
                                   year_month:String,
                                   date:Date
                                  )
}
