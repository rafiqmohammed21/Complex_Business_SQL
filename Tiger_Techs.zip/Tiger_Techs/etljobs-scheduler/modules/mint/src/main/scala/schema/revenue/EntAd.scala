package schema.revenue

import java.sql.{Date, Timestamp}

object EntAd {

  case class EntAdRevenueTarget (id : BigInt,
                                 year: Int,
                                 month: String,
                                 genre: String,
                                 channel_group: String,
                                 branch: String,
                                 region: String,
                                 regular_impact: String,
                                 value: String,
                                 created_at: String,
                                 updated_at: String
                                )
  case class EntAdRevenueTargetEnriched (id : BigInt,
                                         year: Int,
                                         month: Int,
                                         genre: String,
                                         channel_name: String,
                                         branch: String,
                                         region: String,
                                         impact_regular: String,
                                         value: Double,
                                         created_at: String,
                                         updated_at: String
                                        )
  case class ViewEntAdRevenueTarget (
                                      year: BigInt,
                                      month: BigInt,
                                      genre: String,
                                      channel: String,
                                      branch: String,
                                      region: String,
                                      impact_regular: String,
                                      value: Double,
                                      channel_name: String
                                    )
  case class ViewEntAdRevenueTargetCPRP (
                                     year: BigInt,
                                     month: BigInt,
                                     pt_npt:String,
                                     channel:String ,
                                     regular_impact:String,
                                     value:String,
                                     channel_name: String
                                    )
  case class DisneyFyCal (
                                          year: BigInt,
                                          month: BigInt,
                                          week: BigInt,
                                          start_date: Date,
                                          end_date: Date,
                                          fin_year:String,
                                          quarter:String
                                        )

  case class EntAdRevenueTargetCPRP (id :BigInt,
                                     year: Int,
                                     month: String,
                                     channel_group:String ,
                                     pt_npt:String,
                                     regular_impact:String,
                                     value:String,
                                     created_at:String,
                                     updated_at:String
                                    )
  case class EntAdRevenueTargetCPRPEnriched (id :BigInt,
                                             year: Int,
                                             month: Int,
                                             channel_name:String ,
                                             pt_npt:String,
                                             regular_impact:String,
                                             value:Double,
                                             created_at:String,
                                             updated_at:String
                                            )
}
