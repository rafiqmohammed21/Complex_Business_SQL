package etljobs.distribution

import com.google.cloud.bigquery.JobInfo
import etlflow.{EtlJobProps, EtlStepList}
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DistributionProps
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import util.MintGlobalProperties
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.types.{DateType, DoubleType, IntegerType}
import schema.distribution.DistributionRevenue.{DistributionRevenueBQ, DistributionRevenueOracle}
import org.apache.spark.sql.functions.{col, split}
/** Object EtlJobDistributionRevenue gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobDistributionRevenue (
                                       val job_properties: MintEtlJobProps,
                                       val global_properties: Option[GlobalProperties]                                )
  extends  SequentialEtlJob with SparkUDF   with SparkManager {

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  var output_date_paths : Seq[(String,String)] = Seq()
  val master_etl_logger = Logger.getLogger(getClass.getName)
  val props : DistributionProps = job_properties.asInstanceOf[DistributionProps]


  master_etl_logger.info(s"Loaded ${getClass.getName}")

  def DistributionSubTransform(props:DistributionProps)(spark: SparkSession,dataset: Dataset[DistributionRevenueOracle]) : Dataset[DistributionRevenueBQ]={
    import spark.implicits._
    val mapping = Encoders.product[DistributionRevenueBQ]
    val transformed_dataset=dataset
      .withColumn("month",split(col("month_year"),"\\-").getItem(0).cast(IntegerType))
      .withColumn("year",split(col("month_year"),"\\-").getItem(1).cast(IntegerType))
      .withColumn("charge_amount",col("charge_amount").cast(DoubleType))
      .withColumn("total_amount",col("total_amount").cast(DoubleType))
      .withColumn("monthly_average",col("monthly_average").cast(DoubleType))
      .withColumn("date",col("date").cast(DateType))
      .drop("month_year")

    output_date_paths=transformed_dataset
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    output_date_paths.foreach(println)

    transformed_dataset.as[DistributionRevenueBQ](mapping)
  }


  val table_query  = s""" (SELECT customer_nbr,
                                    "BOUQUET/ALACARTE" as bouquet_alacarte,
                                    "BOUQUET/ALACARTE NAME" as bouquet_alacarte_name ,
                                    "Monthly Average" as monthly_average,
                                    "Charge Amount" as charge_amount,
                                     type_of_billing,
                                     total_amount,
                                     to_char(to_date(month_year,'MON-YYYY'),'MM-YYYY') as month_year,
                                     vertical,
                                     is_pushed_to_billing,
                                     dpo_name,
                                     to_date(concat('01-',month_year),'dd-mm-yyyy') as "date",
                                     to_char(to_date(concat('01-',month_year),'dd-mm-yyyy'),'yyyymmdd')  as "date_int"
                                     FROM  ${props.job_input_path}
                             ) t""".stripMargin


    //WHERE UPPER(to_char(to_date(month_year,'MON-YYYY'),'MON-YYYY')) IN (${months})
  val orig_oracle_url= mint_global_properties.oracle_jdbc_jdbc.concat(mint_global_properties.oracle_jdbc_credential).concat(mint_global_properties.oracle_jdbc_host_name)

  val slack_jdbc_url = mint_global_properties.oracle_jdbc_jdbc.concat(mint_global_properties.oracle_jdbc_host_name)

  val step1 = SparkReadTransformWriteStep[DistributionRevenueOracle, DistributionRevenueBQ](
    name                    = "Load_Jdbc_Distribution_Revenue_GCP",
    input_location          = Seq(table_query),
    input_type              = JDBC(orig_oracle_url, mint_global_properties.oracle_user, mint_global_properties.oracle_password, mint_global_properties.oracle_driver),
    output_location         = props.job_output_path,
    transform_function      = DistributionSubTransform( props) ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )

  val step2 = BQLoadStep[DistributionRevenueBQ](
    name                             = "Load_Jdbc_Distribution_Revenue_BQ",
    input_location                   = Right(output_date_paths),
    input_type                       = ORC,
    output_dataset                   = props.output_dataset,
    output_table                     = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)
}