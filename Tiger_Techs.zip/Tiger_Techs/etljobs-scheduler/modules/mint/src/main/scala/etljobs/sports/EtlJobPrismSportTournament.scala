package etljobs.sports

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, ORC, PARQUET}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenueSportsPrismTournamentProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{DateType, DoubleType}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.sports.BarcPP.{PrismSportTournament, PrismSportTournamentEnriched}

case class EtlJobPrismSportTournament(
                                       val job_properties:MintEtlJobProps,
                                       val global_properties: Option[GlobalProperties]
                                )
  extends  SequentialEtlJob with udfs.Download with SparkManager {

  var start_date : String = ""
  var end_date : String = ""
  var output_date_paths : Seq[(String,String)] = Seq()

  lazy val reg_logger = Logger.getLogger(getClass.getName)

  val props : RevenueSportsPrismTournamentProps = job_properties.asInstanceOf[RevenueSportsPrismTournamentProps]

  /** Object EtlJobPrismSportTournament gets executed when it is passed in RunEtlJob from LoadData object.
   * RunEtlJob executes etlstep mentioned in list returned by it.
   *
   * In first etlstep it reads barc pp's data from parquet datasource mentioned in input parameters
   * and writes in ORC format at given output path
   *
   */

  def enrichPP(props:RevenueSportsPrismTournamentProps)(spark: SparkSession,dataset: Dataset[PrismSportTournament]) : Dataset[PrismSportTournamentEnriched] = {
    import spark.implicits._

    val mapping  = Encoders.product[PrismSportTournamentEnriched]
    val enrichedPP = dataset
      .withColumn("grps",col("grps").cast(DoubleType))
      .withColumn("gvt_in_thousand",col("gvt_in_thousand").cast(DoubleType))
      .withColumn("reach_pct",col("reach_pct").cast(DoubleType))
      .withColumn("reach_in_thousand",col("reach_in_thousand").cast(DoubleType))
      .withColumn("target_in_thousand",col("target_in_thousand").cast(DoubleType))
      .withColumn("duration_min",col("duration_min").cast(DoubleType))
      .withColumn("tvr",col("tvr").cast(DoubleType))
      .withColumn("average_tvt_in_thousand",col("average_tvt_in_thousand").cast(DoubleType))
      .withColumn("tsv",col("tsv").cast(DoubleType))
      .withColumn("share_pct",col("share_pct").cast(DoubleType))
      .withColumn("weighted_dur_tsv",col("weighted_dur_tsv").cast(DoubleType))
      .withColumn("weighted_dur_share",col("weighted_dur_share").cast(DoubleType))
      .withColumn("date",col("date").cast(DateType))
      .withColumn("date_int" , get_formatted_date("date","yyyy-MM-dd","yyyyMMdd"))
      .filter(col("date")>=props.refresh_start_date)
      .repartition(1)
      .as[PrismSportTournamentEnriched](mapping)


    output_date_paths=enrichedPP
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    output_date_paths.foreach(println)
    enrichedPP
  }


  val step1 =  SparkReadTransformWriteStep[PrismSportTournament, PrismSportTournamentEnriched](
    name                    = "LoadS3ParquetToGcsOrc",
    input_location          = Seq(props.job_input_path),
    input_type              = PARQUET,
    output_location         = props.job_output_path,
    transform_function      = enrichPP(props) ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int")
  )

  val step2 = BQLoadStep(
    name                    = "LoadGcsToBq",
    input_location = Right(output_date_paths),
    input_type           = ORC,
    output_dataset     = props.output_dataset,
    output_table       = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}