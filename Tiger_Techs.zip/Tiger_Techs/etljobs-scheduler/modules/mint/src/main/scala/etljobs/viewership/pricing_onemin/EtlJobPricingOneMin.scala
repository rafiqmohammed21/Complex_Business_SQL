package etljobs.viewership.pricing_onemin

import java.io.Serializable

import etlflow.LoggerResource
import etlflow.etljobs.{GenericEtlJob}
import etlflow.etlsteps.{GenericETLStep, ParallelETLStep, SparkETLStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.PricingOneMinJobProps
import org.apache.spark.sql.SparkSession
import udfs.Common
import util.MintHelper._
import util.{Configs, MintGlobalProperties}
import zio.ZIO

case class EtlJobPricingOneMin (
                                 val job_properties:MintEtlJobProps,
                                 val global_properties: Option[GlobalProperties]
                               )
   extends Serializable with  GenericEtlJob with SparkUDF with Common with SparkManager {

  val mint_global_properties  = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : PricingOneMinJobProps = job_properties.asInstanceOf[PricingOneMinJobProps]

  var year = "2020"
  var year_week_list:List[(String,String)] = List.empty
  val week = props.job_run_week
  year_week_list=year_week_list:+((year,week))

  etl_job_logger.info("Bucket_name : " + props.bucket_name)
  etl_job_logger.info("Prefix : " + props.path_prefix + "/year=" + props.job_run_year + "/week=" + props.job_run_week)
  etl_job_logger.info("key : " + props.key_file)
  etl_job_logger.info("Job type : " + props.job_type)

  lazy val daily_raw_path =  Configs.pricing_ingestion_var.get("pricing_output_path").get + s"/year=${year}/week="
  lazy val historical_raw_path =  Configs.pricing_1min_ingestion_var.get("pricing_1min_raw_historical_path").get + s"/year=${year}/week="

  val daily_year_week_list =  GenericETLStep[Unit,List[(String,String)]](
    name = "Daily_Year_Week_Calculation",
    transform_function = getYearWeekList(Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get,daily_raw_path,year,props.job_type)
  )

  val historical_year_week_list = GenericETLStep[Unit,List[(String,String)]](
    name = "Historical_Year_Week_Calculation",
    transform_function = getYearWeekList(Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get,historical_raw_path,year,props.job_type)
  )


  def step1(year_week_list:List[(String,String)]):List[SparkETLStep[Unit,Unit]] = year_week_list.map{ values =>
    new SparkETLStep[Unit,Unit](
      name = "ETLJobOffSetCalculation" + "_" + values,
      transform_function = new Processor(values._1,values._2,mint_global_properties)(spark,Unit).OffsetStep
    )
  }
  def step2(year_week_list:List[(String,String)]):List[SparkETLStep[Unit,Unit]]  = year_week_list.map{ values =>
    new SparkETLStep[Unit,Unit](
      name = "ETLJobGRPCalculation" + "_" + values,
      transform_function = new Processor(values._1,values._2, mint_global_properties)(spark,Unit).GrpStep
    )
  }
  def offset_cal_parstep(year_week_list:List[(String,String)]) = ParallelETLStep("ETLJobOffSetCalculation")(step1(year_week_list):_*)
  def grp_cal_parstep(year_week_list:List[(String,String)]) = ParallelETLStep("ETLJobGRPCalculation")(step2(year_week_list):_*)

  val job: ZIO[LoggerResource, Throwable, Unit] = props.job_type match {
    case "daily" => {
      for {
        daily_year_week_list <- daily_year_week_list.execute()
        _ <- offset_cal_parstep(daily_year_week_list).execute()
        _ <- grp_cal_parstep(daily_year_week_list).execute()
      } yield ()
    }

    case "historical" => {
      for {
        historical_year_week_list <- historical_year_week_list.execute()
        _ <- offset_cal_parstep(historical_year_week_list).execute()
        _ <- grp_cal_parstep(historical_year_week_list).execute()
      } yield ()
    }

    case "weekly" => {
      for {
        _ <- offset_cal_parstep(year_week_list).execute()
        _ <- grp_cal_parstep(year_week_list).execute()
      } yield ()
    }
  }
}
