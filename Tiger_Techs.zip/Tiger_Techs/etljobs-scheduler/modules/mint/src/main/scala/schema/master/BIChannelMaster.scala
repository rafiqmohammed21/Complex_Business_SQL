package schema.master

object BIChannelMaster {
  case class BIChannelMaster (
                               channel_name:String,
                               Channel_group_name:String,
                               Source:String,
                               genre:String
                             )
}