package etljobs.viewership.pricing_onemin

import org.apache.spark.sql.{Dataset, Row, SparkSession}
import org.apache.spark.sql.functions.{col, concat}
import udfs.{Common, PricingOneMin}
import util.{MasterJdbcConn, MintGlobalProperties}
import schema.Format.{MMAdvertisers,MMAdvertiserGroups}
class Pricing(spark:SparkSession, conf: MintGlobalProperties)(implicit jdbc_conn:Map[String,String]) extends PricingOneMin with udfs.Pricing with Common with MasterJdbcConn {

  def barcOffSetDataPreparation(source:Dataset[Row])= {

    val AdvertiserSourceDataSet = FetchMasterData(conf.MM_advertiser_table,select_clause=MMAdvertisers,spark=spark,conf=conf)
      .select("name","txn_group_id","brand")
      .toDF("advertiser", "txn_group_id", "brand").distinct()
      .join(FetchMasterData(conf.MM_advertiser_group_table,select_clause=MMAdvertiserGroups,spark=spark,conf=conf)
        .select("id", "name")
        .toDF("txn_group_id", "advertiser_group").distinct()
        ,Seq("txn_group_id"),
        "inner")
      .select("advertiser", "brand", "advertiser_group").distinct()

    val ModifiedBarcSourceDF   = source.withColumn("barc_aired_time",FormattedTime(col("start_time")))
    val BarcWithAdvMasterDF    = ModifiedBarcSourceDF.join(AdvertiserSourceDataSet,Seq("advertiser","brand"),"left")
      .orderBy("start_time")
    BarcWithAdvMasterDF.select("year","week","channel","date","length","barc_aired_time","timeband","advertiser_group")

  }


  def barcGRPDataPreparation(source:Dataset[Row]) = {
    source.withColumn("date",newdateformat(col("date")))
      .withColumn("timeband",RemCharConvertToCap(col("timeband"),":",""))
      .withColumn("tgmarket",concat(col("target"),col("region")))
      .withColumn("tvr",TVR(RemCharConvertToCap(col("impressions_000"),",",""),RemCharConvertToCap(col("target_000"),",","")))
      .withColumn("channel",RemCharConvertToCap(col("channel"),"\\s+",""))
      .withColumn("tgmarket",RemCharConvertToCap(col("tgmarket"),"\\s+",""))
  }


}
