package etljobs.distribution

import com.google.cloud.bigquery.JobInfo
import etlflow.{EtlJobProps, EtlStepList}
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DistributionProps
import org.apache.spark.sql.{Dataset, Encoders, Row, SaveMode, SparkSession}
import util.MintGlobalProperties
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.types.{DateType, DoubleType, IntegerType}
import schema.distribution.DistributionRevenue.{DistributionRevenueBQ, DistributionRevenueOracle}
import org.apache.spark.sql.functions.{col, split}
import schema.distribution.DistributionIncentive.{DistributionIncentiveBQ, DistributionIncentiveOracle}

/** Object EtlJobDistributionRevenue gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobDistributionIncentive(
                                        job_properties: MintEtlJobProps,
                                        global_properties: Option[GlobalProperties]
                                 )
  extends SequentialEtlJob with SparkUDF   with SparkManager {

  var output_date_paths : Seq[(String,String)] = Seq()
  val master_etl_logger = Logger.getLogger(getClass.getName)
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val props : DistributionProps = job_properties.asInstanceOf[DistributionProps]

  master_etl_logger.info(s"Loaded ${getClass.getName}")


  def DistributionIncentiveTransform(props : DistributionProps)(spark: SparkSession,dataset: Dataset[DistributionIncentiveOracle]) : Dataset[DistributionIncentiveBQ]={
    import spark.implicits._
    val mapping = Encoders.product[DistributionIncentiveBQ]
    val transformed_inc_dataset=dataset
      .withColumn("seq_no", col("seq_no").cast(DoubleType))
      .withColumn("sms_input_hdr_id", col("sms_input_hdr_id").cast(DoubleType))
      .withColumn("penetration_incentive", col("penetration_incentive").cast(DoubleType))
      .withColumn("lcn_incentive", col("lcn_incentive").cast(DoubleType))
      .withColumn("volume_incentive", col("volume_incentive").cast(DoubleType))
      .withColumn("premiumization_incentive", col("premiumization_incentive").cast(DoubleType))
      .withColumn("lead_incentive", col("lead_incentive").cast(DoubleType))
      .withColumn("total_incentive", col("total_incentive").cast(DoubleType))
      .withColumn("additional_inc", col("additional_inc").cast(DoubleType))
      .withColumn("revised_inc", col("revised_inc").cast(DoubleType))
      .withColumn("mini_bouquet_incentive", col("mini_bouquet_incentive").cast(DoubleType))
      .withColumn("ala_incentive", col("ala_incentive").cast(DoubleType))
      .withColumn("market_revenue", col("market_revenue").cast(DoubleType))
      .withColumn("incentive_amount", col("incentive_amount").cast(DoubleType))
      .withColumn("old_incentive_amount", col("old_incentive_amount").cast(DoubleType))
      .withColumn("prev_ref_nbr", col("prev_ref_nbr").cast(DoubleType))
      .withColumn("hindi_speaking_universe_count", col("hindi_speaking_universe_count").cast(DoubleType))
      .withColumn("telugu_universe_count", col("telugu_universe_count").cast(DoubleType))
      .withColumn("marathi_universe_count", col("marathi_universe_count").cast(DoubleType))
      .withColumn("kannada_universe_count", col("kannada_universe_count").cast(DoubleType))
      .withColumn("malayalam_universe_count", col("malayalam_universe_count").cast(DoubleType))
      .withColumn("tamil_universe_count", col("tamil_universe_count").cast(DoubleType))
      .withColumn("nesa_universe_count", col("nesa_universe_count").cast(DoubleType))
      .withColumn("universe", col("universe").cast(DoubleType))
      .withColumn("invoice_id", col("invoice_id").cast(DoubleType))
      .withColumn("westbengal_universe_count", col("westbengal_universe_count").cast(DoubleType))
      .withColumn("penetration_per", col("penetration_per").cast(DoubleType))
      .withColumn("lead_penetration_per", col("lead_penetration_per").cast(DoubleType))
      .withColumn("incentive_refno", col("incentive_refno").cast(DoubleType))
      .withColumn("broadcaster", col("broadcaster").cast(org.apache.spark.sql.types.StringType))
      .withColumn("date", col("date").cast(DateType))

    output_date_paths=transformed_inc_dataset
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))

    output_date_paths.foreach(println)

    transformed_inc_dataset.as[DistributionIncentiveBQ](mapping)
  }

  def getMetaStarDates(dataset:Dataset[Row])={
    dataset
      .select("date_int")
      .distinct()
      .collect()
      .map(path =>  path.getString(0))
  }


  val table_query=s""" (SELECT       seq_no,
                                       sms_input_hdr_id,
                                       customer_nbr,
                                       penetration_incentive,
                                       lcn_incentive,
                                       volume_incentive,
                                       premiumization_incentive,
                                       lead_incentive,
                                       total_incentive,
                                       max_elg_inc,
                                       additional_inc,
                                       revised_inc,
                                       start_date,
                                       end_date,
                                       to_char(to_date(par_month,'Mon'),'MM') as par_month,
                                       par_year,
                                       mini_bouquet_incentive,
                                       ala_incentive,
                                       mkt_code,
                                       mkt_name,
                                       market_revenue,
                                       incentive_amount,
                                       old_incentive_amount,
                                       prev_ref_nbr,
                                       penetration_type,
                                       hindi_speaking_universe_count,
                                       telugu_universe_count,
                                       marathi_universe_count,
                                       kannada_universe_count,
                                       malayalam_universe_count,
                                       tamil_universe_count,
                                       nesa_universe_count,
                                       universe,
                                       incentive_version,
                                       invoice_nbr,
                                       invoice_id,
                                       westbengal_universe_count,
                                       penetration_per,
                                       lead_penetration_per,
                                       incentive_refno,
                                       broadcaster,
                                       to_date(concat('01',concat(par_month,par_year)),'ddmmyyyy') AS "date",
                                       to_char(to_date(concat('01',concat(par_month,par_year)),'ddmmyyyy'),'yyyymmdd')  AS "date_int"
                               FROM  ${props.job_input_path}
                              ) f """.stripMargin


  //WHERE UPPER(to_char(to_date(month_year,'MON-YYYY'),'MON-YYYY')) IN (${months})
  val orig_oracle_url= mint_global_properties.oracle_jdbc_jdbc.concat(mint_global_properties.oracle_jdbc_credential).concat(mint_global_properties.oracle_jdbc_host_name)

  val slack_jdbc_url = mint_global_properties.oracle_jdbc_jdbc.concat(mint_global_properties.oracle_jdbc_host_name)

  val step1 = SparkReadTransformWriteStep[DistributionIncentiveOracle, DistributionIncentiveBQ](
    name                    = "Load_Jdbc_Distribution_Incentive_GCP",
    input_location          = Seq(table_query),
    input_type              = JDBC(orig_oracle_url, mint_global_properties.oracle_user, mint_global_properties.oracle_password, mint_global_properties.oracle_driver),
    output_location         = props.job_output_path,
    transform_function      = DistributionIncentiveTransform( props) ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_partition_col    = Seq("date_int"),
  )

  val step2 = BQLoadStep[DistributionIncentiveBQ](
    name                          = "Load_Jdbc_Distribution_Incentive_BQ",
    input_location                =  Right(output_date_paths),
    input_type                    = ORC,
    output_dataset                = props.output_dataset,
    output_table                  = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)
}