package etljobs.sales_dashboard

import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, CSV, GlobalProperties}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.SaveMode
import schema.revenue.SalesDB.SprReg

// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobSprReg(
                         val job_properties: MintEtlJobProps,
                         val global_properties: Option[GlobalProperties]
                  )
  extends SequentialEtlJob  with SparkManager  {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val step1 = SparkReadWriteStep[SprReg](
    name                    = "LOAD_SPR_REG_HISTORICAL",
    input_location          = Seq("test.spr_reg_api"),
    input_type              = BQ,
    output_location         = "gs://star-dl-temp/spr_reg",
    output_type             = CSV(),
    output_save_mode        = SaveMode.Overwrite,
    output_repartitioning   = true,
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1)

}