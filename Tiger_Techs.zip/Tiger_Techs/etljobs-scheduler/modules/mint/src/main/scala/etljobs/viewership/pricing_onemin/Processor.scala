package etljobs.viewership.pricing_onemin

import etlflow.spark.ReadApi
import etlflow.utils.{CSV, ORC}
import etljobs.MintEtlJobProps.PricingOneMinJobProps
import org.apache.log4j.Logger
import org.apache.spark.sql.{Dataset, Row, SparkSession}
import schema.Format.{DIPricingCMinuteSchema, DIPricingMinuteRawSchema, DIPricingOffSetSchema, DISPROffSetSchema}
import schema.revenue.Revenue.IngestionSprDestination
import schema.viewership.PricingOneMin.{DIPricingOffSetSchema, DISPROffSetSchema, PricingOffsetSchema, PricingOneMinGRPSchema, PricingOneMinOffsetSchema, SprOffsetSchema}
import udfs.Common
import util.MintGlobalProperties


class Processor(job_run_year:String,job_run_week:String, conf: MintGlobalProperties)(spark:SparkSession,ip:Unit) extends Common {

  import spark.implicits._
  val logger = Logger.getLogger(getClass.getName)

  val migration          = new Migration(spark, conf)
  var offset_empty_df    = spark.emptyDataset[PricingOneMinOffsetSchema].toDF
  var grp_empty_df       = spark.emptyDataset[PricingOneMinGRPSchema].toDF


  def OffsetStep(spark: SparkSession,ip:Unit) = {

    val spr_where_clause   = s"year=$job_run_year and week=$job_run_week and aired_time is not null and aired_time > '059999' and event_status = 'Primary' and revenue_classification != 'Stings'"
    val barc_where_clase   = s"year=$job_run_year and week=$job_run_week and start_time > '059999' and level = 'Level 4'"

    logger.info(s"Ingestion is using the following jdbc connection : ${getJBDCConn(conf)}")
    logger.info(s"STEP 1) => Starting to read OFFSET data from ${conf.DI_output_spr_path} and ${conf.DI_output_pricing_path} for year => $job_run_year}  and week=$job_run_week")
    val SPROffsetSourceDF  = ReadApi.LoadDS[DISPROffSetSchema](Seq(conf.DI_output_spr_path),ORC,where_clause=spr_where_clause)(spark).distinct()
    val BARCOffsetSourceDF = ReadApi.LoadDS[DIPricingOffSetSchema](Seq(conf.DI_output_pricing_path),ORC,where_clause=barc_where_clase)(spark).distinct()
    val OffsetFinalDF      = migration.DataSegregatedByBusiness("offset",SPROffsetSourceDF.asInstanceOf[Dataset[Row]],BARCOffsetSourceDF.asInstanceOf[Dataset[Row]],Seq("").toDF,getJBDCConn(conf),conf.business.split(','), offset_empty_df)

    logger.info(s"STEP 2) => Writing OFFSET data to ${conf.DI_output_offset_path} for year => $job_run_year and week=$job_run_week")
    OffsetFinalDF.repartition(1)
      .write
      .format("ORC")
      .mode("overwrite")
      .partitionBy("year","week","date")
      .option("header","true")
      .save(s"${conf.DI_output_offset_path}")
  }

  def GrpStep(spark: SparkSession,ip:Unit) = {

    logger.info(s"STEP 3) => Starting to read GRP data from ${conf.DI_output_spr_path}, ${conf.DI_output_pricing_path} and ${conf.DI_output_offset_path} for year => $job_run_year and week=$job_run_week")
    val SPRGRPSourceDF     = ReadApi.LoadDS[IngestionSprDestination](Seq(conf.DI_output_spr_path),ORC, where_clause = s"year=$job_run_year and week=$job_run_week")(spark)
    var BARCGrpSourceDF    = ReadApi.LoadDF(Seq(conf.DI_input_posteval_path),CSV(delimiter=",",header_present = true,quotechar="\""),where_clause = s"year=$job_run_year and week='$job_run_week' and date != 'Date'",select_clause = DIPricingMinuteRawSchema)(spark).toDF(DIPricingCMinuteSchema:_*)
    val OffsetGRPSourceDF  = ReadApi.LoadDS[PricingOneMinOffsetSchema](Seq(conf.DI_output_offset_path),ORC,where_clause=s"year=$job_run_year and week=$job_run_week")(spark)
    val GRPFinalDF         = migration.DataSegregatedByBusiness("grp",SPRGRPSourceDF.asInstanceOf[Dataset[Row]],BARCGrpSourceDF.asInstanceOf[Dataset[Row]],OffsetGRPSourceDF.asInstanceOf[Dataset[Row]],getJBDCConn(conf),conf.business.split(','),grp_empty_df)

    logger.info(s"STEP 4) => Writing GRP data in path ${conf.DI_output_posteval_path} for year => $job_run_year week=$job_run_week")
    GRPFinalDF.repartition(1)
      .write
      .format("ORC")
      .mode("overwrite")
      .partitionBy("year","week","date")
      .option("header","true")
      .save(s"${conf.DI_output_posteval_path}")

  }

}
