package etljobs.viewership.pricing

import etljobs.MintEtlJobProps.PricingJobProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, SparkSession}
import schema.viewership.Pricing._
import udfs.Common
import util.MintGlobalProperties

class Report(spark:SparkSession, props : PricingJobProps, conf: MintGlobalProperties,BusinessType:String, year_week_df:DataFrame) extends Common {

  @transient val pricing_logger = Logger.getLogger(getClass.getName)
  val master_list = getMasterListPath(BusinessType,conf.DI_output_pricing_reports,conf.DI_output_pricing_reports_path)

  pricing_logger.info("here is the master list")
  pricing_logger.info(master_list)

  def AdvBrandDF(spark:SparkSession,dataset:Dataset[PricingRawDestination]) = {
    val encoder = Encoders.product[PricingRptAdvBrand]
    val Dataset = dataset.asInstanceOf[DataFrame].join(year_week_df,Seq("year","week"),"inner").cache()
    BusinessDataSegregation(Dataset,BusinessType, "channel",spark,conf)
      .select("advertiser","brand").distinct.as(encoder)
  }

  def MasterPrgmDF(spark:SparkSession,dataset:Dataset[PricingRawDestination]) = {
    val encoder = Encoders.product[PricingRptMasterPrgm]
    val Dataset = dataset.asInstanceOf[DataFrame].join(year_week_df,Seq("year","week"),"inner")
    BusinessDataSegregation(Dataset,BusinessType, "channel",spark,conf)
      .select("channel","master_program").distinct.as(encoder)
  }

  def TGMarketDF(spark:SparkSession,dataset:Dataset[PricingRawDestination]) = {
    val encoder = Encoders.product[PricingRptTGMarker]
    val Dataset = dataset.asInstanceOf[DataFrame].join(year_week_df,Seq("year","week"),"inner")
    BusinessDataSegregation(Dataset,BusinessType, "channel",spark,conf)
      .join(year_week_df,Seq("year","week"),"inner")
      .select("channel","target","region").distinct.as(encoder)
  }

  def YearWeekDateDF(spark:SparkSession,dataset:Dataset[PricingRawDestination]) = {
    val encoder = Encoders.product[PricingRptYearWeekDate]
    val Dataset = dataset.asInstanceOf[DataFrame].join(year_week_df,Seq("year","week"),"inner")
    val DataSetBusiness = BusinessDataSegregation(Dataset,BusinessType, "channel",spark,conf)
    val WeekStateDate     = DataSetBusiness.select("year","week","date").groupBy("year","week").agg(min(col("date"))).withColumnRenamed("min(date)","weekend_start_date")
    val WeekEndDate       = DataSetBusiness.select("year","week","date").groupBy("year","week").agg(max(col("date"))).withColumnRenamed("max(date)","week_end_date")
    WeekStateDate.join(WeekEndDate,Seq("year","week"),"inner").as(encoder)
  }

}
