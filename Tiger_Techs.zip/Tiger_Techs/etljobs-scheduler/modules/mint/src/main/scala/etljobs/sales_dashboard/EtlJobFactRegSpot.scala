package etljobs.sales_dashboard

import com.google.cloud.bigquery.{FormatOptions, JobInfo}
import com.google.cloud.bigquery.JobInfo.CreateDisposition.CREATE_IF_NEEDED
import com.google.cloud.bigquery.JobInfo.WriteDisposition.WRITE_TRUNCATE
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.SparkManager
import etlflow.utils.{BQ, GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.SaveMode
import schema.distribution.DistributionSubscription.DistributionSubBQ
import schema.revenue.SalesDB.FactRegSpotSchema

// Spark Imports

/** Object EtlJobSprProgLogsSports gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobFactRegSpot(
                              val job_properties: MintEtlJobProps,
                              val global_properties: Option[GlobalProperties]
                       )
  extends SequentialEtlJob with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val query  = "SELECT * FROM `mint-bi-reporting.viewership_reports.reg_spot_ratings_south_reports`"


  val step1 = BQLoadStep(
    name                            = "UpdateBQTable",
    input_location                  =  Left(query),
    input_type                      = BQ,
    output_dataset                  = props.output_dataset,
    output_table                    = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )
  val step2 = SparkReadWriteStep[FactRegSpotSchema](
    name                    = "Load_Jdbc_Fact_Reg_Spot",
    input_location          = Seq("viewership.ent_fact_reg_spot"),
    input_type              = BQ,
    output_location         = "ent_fact_reg_spot",
    output_type             = JDBC("jdbc:postgresql://10.40.32.20:5432/sales_dashboard", "mintrw", "$tar@MintRW2o2o", "org.postgresql.Driver"),
    output_save_mode        = SaveMode.Overwrite,
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)

}