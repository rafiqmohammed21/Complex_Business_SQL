package schema.barc_week_month_to_date

import java.sql.Date

object BarcWeekMonthToDate {

  case class BarcWeekMonthToDateMapping(BARC_Year:Int,
                                        BARC_Week: Int,
                                        BARC_Month: Int,
                                        Start_date:Date,
                                        End_date: Date,
                                        Quarter: String,
                                        F_Year: String
                                    )
}