package util

import etlflow.utils.GCP

import scala.io.Source

object Configs {
  lazy val ENV: String = Source.fromResource("ENV.txt").getLines.toList.head
  val mr_file = Option(GCP("/opt/docker/conf/gcsCred_mr.json"))

  var data_download_mail_reciepients = List("swapnil.sonawane@startv.com")
  val barc_week_month_date_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "barc_week_month_date_input_path" -> "gs://star-dl-mappings-uat/static-data/barc-week-month-date/",
        "barc_week_month_date_output_path" -> "gs://star-dl-mappings-uat/transformed/barc-week-month-date",
        "barc_week_month_date_output_file_name" -> "barc_week_month-date.orc",
        "barc_week_month_date_output_dataset" -> "test",
        "barc_week_month_date_output_table_name" -> "barc_week_month_to_date"
      )
    }
    case "uat" => {
      Map(
        "barc_week_month_date_input_path" -> "gs://star-dl-mappings-uat/static-data/barc-week-month-date/",
        "barc_week_month_date_output_path" -> "gs://star-dl-mappings-uat/transformed/barc-week-month-date",
        "barc_week_month_date_output_file_name" -> "barc_week_month-date.orc",
        "barc_week_month_date_output_dataset" -> "test",
        "barc_week_month_date_output_table_name" -> "barc_week_month_to_date"
      )
    }
    case "prod" => {
      Map(
        "barc_week_month_date_input_path" -> "gs://star-dl-mappings/static-data/barc-week-month-date/",
        "barc_week_month_date_output_path" -> "gs://star-dl-mappings/transformed/barc-week-month-date",
        "barc_week_month_date_output_file_name" -> "barc_week_month-date.orc",
        "barc_week_month_date_output_dataset" -> "master",
        "barc_week_month_date_output_table_name" -> "barc_week_month_to_date"
      )
    }
  }

  val sales_db_fact_revenue_advertiser_mappings_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "sales_db_fact_revenue_advertiser_mappings_input_path" -> "fact_revenue_common",
        "sales_db_fact_revenue_advertiser_mappings_output_file_name" -> "fact_rev_advertiser_mappings.csv",
        "sales_db_fact_revenue_advertiser_mappings_dataset" -> "test",
        "sales_db_fact_revenue_advertiser_mappings_table_name" -> "ent_fact_revenue_advertiser_mappings",
        "sales_db_fact_revenue_advertiser_mappings_output_path" -> "gs://star-dl-temp/ent_rev_fact_advertiser_mapping/dev_transformed",
      )
    }
    case "uat" => {
      Map(
        "sales_db_fact_revenue_advertiser_mappings_input_path" -> "ent_fact_revenue",
        "sales_db_fact_revenue_advertiser_mappings_output_file_name" -> "fact_rev_advertiser_mappings",
        "sales_db_fact_revenue_advertiser_mappings_dataset" -> "test",
        "sales_db_fact_revenue_advertiser_mappings_table_name" -> "ent_fact_revenue_advertiser_mappings",
        "sales_db_fact_revenue_advertiser_mappings_output_path" -> "gs://star-dl-temp/ent_rev_fact_advertiser_mapping/uat_transformed",

      )
    }
    case "prod" => {
      Map(
        "sales_db_fact_revenue_advertiser_mappings_input_path" -> "ent_fact_revenue",
        "sales_db_fact_revenue_advertiser_mappings_output_file_name" -> "fact_rev_advertiser_mappings.csv",
        "sales_db_fact_revenue_advertiser_mappings_dataset" -> "revenue",
        "sales_db_fact_revenue_advertiser_mappings_table_name" -> "ent_fact_revenue_advertiser_mappings",
        "sales_db_fact_revenue_advertiser_mappings_output_path" -> "gs://star-dl-temp/ent_rev_fact_advertiser_mapping/prod_transformed",

      )
    }
  }

  val revenue_calender_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "revenue_calender_input_path" -> "gs://star-dl-mappings-uat/static-data/revenue_calender",
        "revenue_calender_output_path" -> "gs://star-dl-mappings-uat/transformed/revenue_calender",
        "revenue_calender_output_file_name" -> "revenue_calender.orc",
        "revenue_calender_output_dataset" -> "test",
        "revenue_calender_output_table_name" -> "revenue_calender",
      )
    }
    case "uat" => {
      Map(
        "revenue_calender_input_path" -> "gs://star-dl-mappings-uat/static-data/revenue_calender",
        "revenue_calender_output_path" -> "gs://star-dl-mappings-uat/transformed/revenue_calender",
        "revenue_calender_output_file_name" -> "revenue_calender.orc",
        "revenue_calender_output_dataset" -> "test",
        "revenue_calender_output_table_name" -> "revenue_calender",
      )
    }
    case "prod" => {
      Map(
        "revenue_calender_input_path" -> "gs://star-dl-mappings/static-data/revenue_calender",
        "revenue_calender_output_path" -> "gs://star-dl-mappings/transformed/revenue_calender",
        "revenue_calender_output_file_name" -> "revenue_calender.orc",
        "revenue_calender_output_dataset" -> "master",
        "revenue_calender_output_table_name" -> "revenue_calender",
      )
    }
  }

  val finance_month_wise_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "finance_month_wise_input_path" -> "gs://star-dl-mappings-uat/static-data/sports_finance_month_wise",
        "finance_month_wise_output_path" -> "gs://star-dl-mappings-uat/transformed/sports_finance_month_wise",
        "finance_month_wise_output_file_name" -> "sports_finance_month_wise.orc",
        "finance_month_wise_output_dataset" -> "test",
        "finance_month_wise_output_table_name" -> "finance_revenue_monthwise",
      )
    }
    case "uat" => {
      Map(
        "finance_month_wise_input_path" -> "gs://star-dl-mappings-uat/static-data/sports_finance_month_wise",
        "finance_month_wise_output_path" -> "gs://star-dl-mappings-uat/transformed/sports_finance_month_wise",
        "finance_month_wise_output_file_name" -> "sports_finance_month_wise.orc",
        "finance_month_wise_output_dataset" -> "test",
        "finance_month_wise_output_table_name" -> "finance_revenue_monthwise",
      )
    }
    case "prod" => {
      Map(
        "finance_month_wise_input_path" -> "gs://star-dl-mappings/static-data/sports_finance_month_wise",
        "finance_month_wise_output_path" -> "gs://star-dl-mappings/transformed/sports_finance_month_wise",
        "finance_month_wise_output_file_name" -> "sports_finance_month_wise.orc",
        "finance_month_wise_output_dataset" -> "master",
        "finance_month_wise_output_table_name" -> "finance_revenue_monthwise",
      )
    }
  }

  val finance_match_wise_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "finance_match_wise_input_path" -> "gs://star-dl-mappings-uat/static-data/sports_finance_match_wise/",
        "finance_match_wise_output_path" -> "gs://star-dl-mappings-uat/transformed/sports_finance_match_wise",
        "finance_match_wise_output_file_name" -> "sports_finance_match_wise.orc",
        "finance_match_wise_output_dataset" -> "test",
        "finance_match_wise_output_table_name" -> "finance_revenue_matchwise",
      )
    }
    case "uat" => {
      Map(
        "finance_match_wise_input_path" -> "gs://star-dl-mappings-uat/static-data/sports_finance_match_wise/",
        "finance_match_wise_output_path" -> "gs://star-dl-mappings-uat/transformed/sports_finance_match_wise",
        "finance_match_wise_output_file_name" -> "sports_finance_match_wise.orc",
        "finance_match_wise_output_dataset" -> "test",
        "finance_match_wise_output_table_name" -> "finance_revenue_matchwise",
      )
    }
    case "prod" => {
      Map(
        "finance_match_wise_input_path" -> "gs://star-dl-mappings/static-data/sports_finance_match_wise/",
        "finance_match_wise_output_path" -> "gs://star-dl-mappings/transformed/sports_finance_match_wise",
        "finance_match_wise_output_file_name" -> "sports_finance_match_wise.orc",
        "finance_match_wise_output_dataset" -> "master",
        "finance_match_wise_output_table_name" -> "finance_revenue_matchwise"
      )
    }
  }

  val pricing_1min_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "pricing_1min_raw_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_raw_historical_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_dest_path" -> "1_min/transformed"
      )
    }
    case "uat" => {
      Map(
        "pricing_1min_raw_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_raw_historical_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_dest_path" -> "1_min/transformed"
      )
    }
    case "prod" => {
      Map(
        "pricing_1min_raw_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_raw_historical_path" -> "landingzone/posteval/raw_files",
        "pricing_1min_dest_path" -> "1_min/transformed"
      )
    }
  }

  val pricing_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "pricing_bucket_aws" -> "star-dl-barc-ad",
        "pricing_bucket_gcs" -> "star-dl-temp-mint",
        "pricing_output_path" -> "pricing/transformed",
        "pricing_newtg_raw_path" -> "landingzone/pricing_newtg/RAW",
        "pricing_newtg_qc_path" -> "landingzone/pricing_newtg/QC",
        "pricing_callback_url" -> "https://uat-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_ur_callback_url" -> "https://stage-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_stg_callback_url" -> "https://stage-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_output_dataset" -> "test",
        "pricing_output_table" -> "pricing"
      )
    }
    case "uat" => {
      Map(
        "pricing_bucket_aws" -> "star-dl-barc-ad",
        "pricing_bucket_gcs" -> "star-dl-timeband-uat",
        "pricing_output_path" -> "pricing/transformed",
        "pricing_newtg_raw_path" -> "landingzone/pricing_newtg/RAW",
        "pricing_newtg_qc_path" -> "landingzone/pricing_newtg/QC",
        "pricing_callback_url" -> "https://uat-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_ur_callback_url" -> "https://uat-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_stg_callback_url" -> "https://stage-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_output_dataset" -> "test",
        "pricing_output_table" -> "pricing"
      )
    }
    case "prod" => {
      Map(
        "pricing_bucket_aws" -> "star-dl-barc-ad",
        "pricing_bucket_gcs" -> "star-dl-timeband",
        "pricing_output_path" -> "pricing/transformed",
        "pricing_newtg_raw_path" -> "landingzone/pricing_newtg/RAW",
        "pricing_newtg_qc_path" -> "landingzone/pricing_newtg/QC",
        "pricing_callback_url" -> "https://mintapi.startv.com/api/v1/files/import_barc_data?",
        "pricing_ur_callback_url" -> "https://uat-rep-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_stg_callback_url" -> "https://stage-api.startv.com/api/v1/files/import_barc_data?",
        "pricing_output_dataset" -> "viewership",
        "pricing_output_table" -> "pricing"
      )
    }
  }

  val hotstar_mintreporting_ent_info: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "hotstar_ent_daily_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_daily_show_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_show_gcs_bucket" -> "hotstar_data",

        "hotstar_ent_daily_channel_gcs_bucket_prefix" -> "dev_transformed/entertainment/daily_channel_performance",
        "hotstar_ent_weekly_channel_gcs_bucket_prefix" -> "dev_transformed/entertainment/weekly_channel_performance",
        "hotstar_ent_daily_show_gcs_bucket_prefix" -> "dev_transformed/entertainment/daily_show_performance",
        "hotstar_ent_weekly_show_gcs_bucket_prefix" -> "dev_transformed/entertainment/weekly_show_performance",

        "hotstar_ent_daily_channel_performance" -> "dev_entertainment_daily_channel_performance",
        "hotstar_ent_weekly_channel_performance" -> "dev_entertainment_weekly_channel_performance",
        "hotstar_ent_daily_show_performance" -> "dev_entertainment_daily_show_performance",
        "hotstar_ent_weekly_show_performance" -> "dev_entertainment_weekly_show_performance"
      )
    }
    case "uat" => {
      Map(
        "hotstar_ent_daily_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_daily_show_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_show_gcs_bucket" -> "hotstar_data",

        "hotstar_ent_daily_channel_gcs_bucket_prefix" -> "uat_transformed/entertainment/daily_channel_performance",
        "hotstar_ent_weekly_channel_gcs_bucket_prefix" -> "uat_transformed/entertainment/weekly_channel_performance",
        "hotstar_ent_daily_show_gcs_bucket_prefix" -> "uat_transformed/entertainment/daily_show_performance",
        "hotstar_ent_weekly_show_gcs_bucket_prefix" -> "uat_transformed/entertainment/weekly_show_performance",

        "hotstar_ent_daily_channel_performance" -> "dev_entertainment_daily_channel_performance",
        "hotstar_ent_weekly_channel_performance" -> "dev_entertainment_weekly_channel_performance",
        "hotstar_ent_daily_show_performance" -> "dev_entertainment_daily_show_performance",
        "hotstar_ent_weekly_show_performance" -> "dev_entertainment_weekly_show_performance"
      )
    }
    case "prod" => {
      Map(
        "hotstar_ent_daily_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_channel_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_daily_show_gcs_bucket" -> "hotstar_data",
        "hotstar_ent_weekly_show_gcs_bucket" -> "hotstar_data",

        "hotstar_ent_daily_channel_gcs_bucket_prefix" -> "prod_transformed/entertainment/daily_channel_performance",
        "hotstar_ent_weekly_channel_gcs_bucket_prefix" -> "prod_transformed/entertainment/weekly_channel_performance",
        "hotstar_ent_daily_show_gcs_bucket_prefix" -> "prod_transformed/entertainment/daily_show_performance",
        "hotstar_ent_weekly_show_gcs_bucket_prefix" -> "prod_transformed/entertainment/weekly_show_performance",

        "hotstar_ent_daily_channel_performance" -> "entertainment_daily_channel_performance",
        "hotstar_ent_weekly_channel_performance" -> "entertainment_weekly_channel_performance",
        "hotstar_ent_daily_show_performance" -> "entertainment_daily_show_performance",
        "hotstar_ent_weekly_show_performance" -> "entertainment_weekly_show_performance"

      )
    }
  }

  val hotstar_mintreporting_spt_info: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "hotstar_daily_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_daily_cum_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_matchwise_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_match_wise_peak_concurrency_gcs_bucket" -> "hotstar_data",

        "hotstar_daily_video_viewers_gcs_bucket_prefix" -> "dev_transformed/sports/daily_video_viewers",
        "hotstar_daily_cum_viewers_gcs_bucket_prefix" -> "dev_transformed/sports/daily_cum_viewers",
        "hotstar_matchwise_video_viewers_gcs_bucket_prefix" -> "dev_transformed/sports/matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency_gcs_bucket_prefix" -> "dev_transformed/sports/match_wise_peak_concurrency",

        "hotstar_daily_video_viewers" -> "dev_hotstar_daily_video_viewers",
        "hotstar_daily_cum_viewers" -> "dev_hotstar_daily_cum_viewers",
        "hotstar_matchwise_video_viewers" -> "dev_hotstar_matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency" -> "dev_match_wise_peak_concurrency"
      )
    }
    case "uat" => {
      Map(
        "hotstar_daily_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_daily_cum_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_matchwise_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_match_wise_peak_concurrency_gcs_bucket" -> "hotstar_data",

        "hotstar_daily_video_viewers_gcs_bucket_prefix" -> "uat_transformed/sports/daily_video_viewers",
        "hotstar_daily_cum_viewers_gcs_bucket_prefix" -> "uat_transformed/sports/daily_cum_viewers",
        "hotstar_matchwise_video_viewers_gcs_bucket_prefix" -> "uat_transformed/sports/matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency_gcs_bucket_prefix" -> "uat_transformed/sports/match_wise_peak_concurrency",

        "hotstar_daily_video_viewers" -> "dev_hotstar_daily_video_viewers",
        "hotstar_daily_cum_viewers" -> "dev_hotstar_daily_cum_viewers",
        "hotstar_matchwise_video_viewers" -> "dev_hotstar_matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency" -> "dev_match_wise_peak_concurrency"
      )
    }
    case "prod" => {
      Map(
        "hotstar_daily_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_daily_cum_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_matchwise_video_viewers_gcs_bucket" -> "hotstar_data",
        "hotstar_match_wise_peak_concurrency_gcs_bucket" -> "hotstar_data",

        "hotstar_daily_video_viewers_gcs_bucket_prefix" -> "prod_transformed/sports/daily_video_viewers",
        "hotstar_daily_cum_viewers_gcs_bucket_prefix" -> "prod_transformed/sports/daily_cum_viewers",
        "hotstar_matchwise_video_viewers_gcs_bucket_prefix" -> "prod_transformed/sports/matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency_gcs_bucket_prefix" -> "prod_transformed/sports/match_wise_peak_concurrency",

        "hotstar_daily_video_viewers" -> "hotstar_daily_video_viewers",
        "hotstar_daily_cum_viewers" -> "hotstar_daily_cum_viewers",
        "hotstar_matchwise_video_viewers" -> "hotstar_matchwise_video_viewers",
        "hotstar_match_wise_peak_concurrency" -> "match_wise_peak_concurrency"
      )
    }
  }

  val hotstar_mintreporting_dataset: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "hotstar_mintreporting_dataset" -> "test_ds",
      )
    }
    case "uat" => {
      Map(
        "hotstar_mintreporting_dataset" -> "test_ds",
      )
    }
    case "prod" => {
      Map(
        "hotstar_mintreporting_dataset" -> "epm_historical",
      )
    }
  }

  val spr_channel_master_view: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "channel_master_view_input_path" -> "gs://star-dl-revenue-uat/raw/spr/master/channel_master",
        "channel_master_view_output_path" -> "gs://star-dl-revenue-uat/transformed/spr/master/channel_master",
        "channel_master_view_output_file_name" -> "spr_channel_master_mapping.orc",
        "channel_master_view_dataset" -> "test",
        "channel_master_view_table_name" -> "spr_channel_master"
      )
    }
    case "uat" => {
      Map(
        "channel_master_view_input_path" -> "gs://star-dl-revenue-uat/raw/spr/master/channel_master",
        "channel_master_view_output_path" -> "gs://star-dl-revenue-uat/transformed/spr/master/channel_master",
        "channel_master_view_output_file_name" -> "spr_channel_master_mapping.orc",
        "channel_master_view_dataset" -> "test",
        "channel_master_view_table_name" -> "spr_channel_master"
      )
    }
    case "prod" => {
      Map(
        "channel_master_view_input_path" -> "gs://star-dl-revenue/raw/spr/master/channel_master",
        "channel_master_view_output_path" -> "gs://star-dl-revenue/transformed/spr/master/channel_master",
        "channel_master_view_output_file_name" -> "spr_channel_master_mapping.orc",
        "channel_master_view_dataset" -> "master",
        "channel_master_view_table_name" -> "spr_channel_master"
      )
    }
  }

  val hotstar_match_wise_viewership_view: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "match_wise_viewership_view_input_path" -> "gs://star-dl-hotstar-uat/raw/master/",
        "match_wise_viewership_view_output_path" -> "gs://star-dl-hotstar-uat/transformed/master",
        "match_wise_viewership_view_output_file_name" -> "hotstar_master_mapping.orc",
        "match_wise_viewership_view_dataset" -> "test",
        "match_wise_viewership_view_table_name" -> "ht_master_mapping"
      )
    }
    case "uat" => {
      Map(
        "match_wise_viewership_view_input_path" -> "gs://star-dl-hotstar-uat/raw/master/",
        "match_wise_viewership_view_output_path" -> "gs://star-dl-hotstar-uat/transformed/master",
        "match_wise_viewership_view_output_file_name" -> "hotstar_master_mapping.orc",
        "match_wise_viewership_view_dataset" -> "test",
        "match_wise_viewership_view_table_name" -> "ht_master_mapping"
      )
    }
    case "prod" => {
      Map(
        "match_wise_viewership_view_input_path" -> "gs://star-dl-hotstar/raw/master/",
        "match_wise_viewership_view_output_path" -> "gs://star-dl-hotstar/transformed/master",
        "match_wise_viewership_view_output_file_name" -> "hotstar_master_mapping.orc",
        "match_wise_viewership_view_dataset" -> "master",
        "match_wise_viewership_view_table_name" -> "ht_master_mapping"
      )
    }
  }

  val hotstar_ent_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "daily_channel_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/daily_channel_performance/",
        "daily_channel_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/daily_channel_performance",
        "daily_channel_output_file_name" -> "daily_channel_performance.orc",
        "daily_channel_dataset" -> "test",
        "daily_channel_table_name" -> "ht_ent_daily_channel_performance",
        "daily_channel_folder_name" -> "daily_channel_performance",
        "daily_channel_gcs_folder_name" -> "transformed/entertainment/daily_channel_performance/ ",

        "daily_show_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/daily_show_performance/",
        "daily_show_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/daily_show_performance",
        "daily_show_output_file_name" -> "daily_show_performance.orc",
        "daily_show_dataset" -> "test",
        "daily_show_table_name" -> "ht_ent_daily_show_performance",
        "daily_show_folder_name" -> "daily_show_performance",
        "daily_show_gcs_folder_name" -> "transformed/entertainment/daily_show_performance/",

        "weekly_channel_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/weekly_channel_performance/",
        "weekly_channel_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/weekly_channel_performance",
        "weekly_channel_output_file_name" -> "weekly_channel_performance.orc",
        "weekly_channel_dataset" -> "test",
        "weekly_channel_table_name" -> "ht_ent_weekly_channel_performance",
        "weekly_channel_folder_name" -> "weekly_channel_performance",
        "weekly_channel_gcs_folder_name" -> "transformed/entertainment/weekly_channel_performance/",

        "weekly_show_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/weekly_show_performance/",
        "weekly_show_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/weekly_show_performance",
        "weekly_show_output_file_name" -> "weekly_show_performance.orc",
        "weekly_show_dataset" -> "test",
        "weekly_show_table_name" -> "ht_ent_weekly_show_performance",
        "weekly_show_folder_name" -> "weekly_show_performance",
        "weekly_show_gcs_folder_name" -> "transformed/entertainment/weekly_show_performance/",
      )
    }
    case "uat" => {
      Map(
        "daily_channel_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/daily_channel_performance/ ",
        "daily_channel_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/daily_channel_performance ",
        "daily_channel_output_file_name" -> "daily_channel_performance.orc ",
        "daily_channel_dataset" -> "test ",
        "daily_channel_table_name" -> "ht_ent_daily_channel_performance ",
        "daily_channel_folder_name" -> "daily_channel_performance/ ",
        "daily_channel_gcs_folder_name" -> "transformed/entertainment/daily_channel_performance/ ",

        "daily_show_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/daily_show_performance/ ",
        "daily_show_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/daily_show_performance",
        "daily_show_output_file_name" -> "daily_show_performance.orc ",
        "daily_show_dataset" -> "test ",
        "daily_show_table_name" -> "ht_ent_daily_show_performance ",
        "daily_show_folder_name" -> "daily_show_performance/ ",
        "daily_show_gcs_folder_name" -> "transformed/entertainment/daily_show_performance/ ",

        "weekly_channel_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/weekly_channel_performance/ ",
        "weekly_channel_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/weekly_channel_performance ",
        "weekly_channel_output_file_name" -> "weekly_channel_performance.orc ",
        "weekly_channel_dataset" -> "test ",
        "weekly_channel_table_name" -> "ht_ent_weekly_channel_performance ",
        "weekly_channel_folder_name" -> "weekly_channel_performance/ ",
        "weekly_channel_gcs_folder_name" -> "transformed/entertainment/weekly_channel_performance/ ",

        "weekly_show_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/weekly_show_performance/ ",
        "weekly_show_output_path" -> "gs://star-dl-hotstar-uat/transformed/entertainment/weekly_show_performance ",
        "weekly_show_output_file_name" -> "weekly_show_performance.orc ",
        "weekly_show_dataset" -> "test ",
        "weekly_show_table_name" -> "ht_ent_weekly_show_performance ",
        "weekly_show_folder_name" -> "weekly_show_performance/ ",
        "weekly_show_gcs_folder_name" -> "transformed/entertainment/weekly_show_performance/ ",
      )
    }
    case "prod" => {
      Map(
        "daily_channel_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/daily_channel_performance/",
        "daily_channel_output_path" -> "gs://star-dl-hotstar/transformed/entertainment/daily_channel_performance",
        "daily_channel_output_file_name" -> "daily_channel_performance.orc",
        "daily_channel_dataset" -> "viewership",
        "daily_channel_table_name" -> "ht_ent_daily_channel_performance",
        "daily_channel_folder_name" -> "daily_channel_performance/",
        "daily_channel_gcs_folder_name" -> "transformed/entertainment/daily_channel_performance/",

        "daily_show_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/daily_show_performance/",
        "daily_show_output_path" -> "gs://star-dl-hotstar/transformed/entertainment/daily_show_performance",
        "daily_show_output_file_name" -> "daily_show_performance.orc",
        "daily_show_dataset" -> "viewership",
        "daily_show_table_name" -> "ht_ent_daily_show_performance",
        "daily_show_folder_name" -> "daily_show_performance/",
        "daily_show_gcs_folder_name" -> "transformed/entertainment/daily_show_performance/",


        "weekly_channel_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/weekly_channel_performance/",
        "weekly_channel_output_path" -> "gs://star-dl-hotstar/transformed/entertainment/weekly_channel_performance",
        "weekly_channel_output_file_name" -> "weekly_channel_performance.orc",
        "weekly_channel_dataset" -> "viewership",
        "weekly_channel_table_name" -> "ht_ent_weekly_channel_performance",
        "weekly_channel_folder_name" -> "weekly_channel_performance/",
        "weekly_channel_gcs_folder_name" -> "transformed/entertainment/weekly_channel_performance/",

        "weekly_show_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/weekly_show_performance/",
        "weekly_show_output_path" -> "gs://star-dl-hotstar/transformed/entertainment/weekly_show_performance",
        "weekly_show_output_file_name" -> "weekly_show_performance.orc",
        "weekly_show_dataset" -> "viewership",
        "weekly_show_table_name" -> "ht_ent_weekly_show_performance",
        "weekly_show_folder_name" -> "weekly_show_performance/",
        "weekly_show_gcs_folder_name" -> "transformed/entertainment/weekly_show_performance/",
      )
    }
  }

  val hotstar_sports_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "daily_cum_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/hotstar_daily_cum_viewers",
        "daily_cum_viewers_output_file_name" -> "hotstar_daily_cum_viewers.orc",
        "daily_cum_viewers_dataset" -> "test",
        "daily_cum_viewers_table_name" -> "ht_spt_daily_cum_viewers",
        "daily_cum_viewers_folder_name" -> "sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_gcs_folder_name" -> "transformed/sports/hotstar_daily_cum_viewers/",

        "daily_video_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_vv_wt/",
        "daily_video_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_day_wise_vv_wt",
        "daily_video_viewers_output_file_name" -> "hotstar_daily_video_viewers.orc",
        "daily_video_viewers_dataset" -> "test",
        "daily_video_viewers_table_name" -> "ht_spt_daily_video_viewers",
        "daily_video_viewers_folder_name" -> "sports_season_day_wise_vv_wt/",
        "daily_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_day_wise_vv_wt/",

        "match_wise_peak_concurrency_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_match_wise_concurrency",
        "match_wise_peak_concurrency_output_file_name" -> "match_wise_peak_concurrency.orc",
        "match_wise_peak_concurrency_dataset" -> "test",
        "match_wise_peak_concurrency_table_name" -> "ht_spt_match_wise_peak_concurrency",
        "match_wise_peak_concurrency_folder_name" -> "sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_concurrency/",

        "match_wise_video_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_match_wise_vv_wt",
        "match_wise_video_viewers_output_file_name" -> "hotstar_matchwise_video_viewers.orc",
        "match_wise_video_viewers_dataset" -> "test",
        "match_wise_video_viewers_table_name" -> "ht_spt_matchwise_video_viewers",
        "match_wise_video_viewers_folder_name" -> "sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_vv_wt/"

      )
    }
    case "uat" => {
      Map(
        "daily_cum_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/hotstar_daily_cum_viewers",
        "daily_cum_viewers_output_file_name" -> "hotstar_daily_cum_viewers.orc",
        "daily_cum_viewers_dataset" -> "test",
        "daily_cum_viewers_table_name" -> "ht_spt_daily_cum_viewers",
        "daily_cum_viewers_folder_name" -> "sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_gcs_folder_name" -> "transformed/sports/hotstar_daily_cum_viewers/",

        "daily_video_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_vv_wt/",
        "daily_video_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_day_wise_vv_wt",
        "daily_video_viewers_output_file_name" -> "hotstar_daily_video_viewers.orc",
        "daily_video_viewers_dataset" -> "test",
        "daily_video_viewers_table_name" -> "ht_spt_daily_video_viewers",
        "daily_video_viewers_folder_name" -> "sports_season_day_wise_vv_wt/",
        "daily_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_day_wise_vv_wt/",

        "match_wise_peak_concurrency_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_match_wise_concurrency",
        "match_wise_peak_concurrency_output_file_name" -> "match_wise_peak_concurrency.orc",
        "match_wise_peak_concurrency_dataset" -> "test",
        "match_wise_peak_concurrency_table_name" -> "ht_spt_match_wise_peak_concurrency",
        "match_wise_peak_concurrency_folder_name" -> "sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_concurrency/",

        "match_wise_video_viewers_input_path" -> "gs://star-dl-hotstar-uat/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_output_path" -> "gs://star-dl-hotstar-uat/transformed/sports/sports_season_match_wise_vv_wt",
        "match_wise_video_viewers_output_file_name" -> "hotstar_matchwise_video_viewers.orc",
        "match_wise_video_viewers_dataset" -> "test",
        "match_wise_video_viewers_table_name" -> "ht_spt_matchwise_video_viewers",
        "match_wise_video_viewers_folder_name" -> "sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_vv_wt/"

      )
    }
    case "prod" => {
      Map(
        "daily_cum_viewers_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_output_path" -> "gs://star-dl-hotstar/transformed/sports/hotstar_daily_cum_viewers",
        "daily_cum_viewers_output_file_name" -> "hotstar_daily_cum_viewers.orc",
        "daily_cum_viewers_dataset" -> "viewership",
        "daily_cum_viewers_table_name" -> "ht_spt_daily_cum_viewers ",
        "daily_cum_viewers_folder_name" -> "sports_season_day_wise_cumulative_video_viewers/",
        "daily_cum_viewers_gcs_folder_name" -> "transformed/sports/hotstar_daily_cum_viewers/",

        "daily_video_viewers_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/sports_season_day_wise_vv_wt/",
        "daily_video_viewers_output_path" -> "gs://star-dl-hotstar/transformed/sports/sports_season_day_wise_vv_wt",
        "daily_video_viewers_output_file_name" -> "hotstar_daily_video_viewers.orc",
        "daily_video_viewers_dataset" -> "viewership",
        "daily_video_viewers_table_name" -> "ht_spt_daily_video_viewers",
        "daily_video_viewers_folder_name" -> "sports_season_day_wise_vv_wt/",
        "daily_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_day_wise_vv_wt/",

        "match_wise_peak_concurrency_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_output_path" -> "gs://star-dl-hotstar/transformed/sports/sports_season_match_wise_concurrency",
        "match_wise_peak_concurrency_output_file_name" -> "match_wise_peak_concurrency.orc",
        "match_wise_peak_concurrency_dataset" -> "viewership",
        "match_wise_peak_concurrency_table_name" -> "ht_spt_match_wise_peak_concurrency",
        "match_wise_peak_concurrency_folder_name" -> "sports_season_match_wise_concurrency/",
        "match_wise_peak_concurrency_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_concurrency/",

        "match_wise_video_viewers_input_path" -> "gs://star-dl-hotstar/raw/hive_internal_database/hotstar_star.db/sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_output_path" -> "gs://star-dl-hotstar/transformed/sports/sports_season_match_wise_vv_wt",
        "match_wise_video_viewers_output_file_name" -> "hotstar_matchwise_video_viewers.orc",
        "match_wise_video_viewers_dataset" -> "viewership",
        "match_wise_video_viewers_table_name" -> "ht_spt_matchwise_video_viewers",
        "match_wise_video_viewers_folder_name" -> "sports_season_match_wise_vv_wt/",
        "match_wise_video_viewers_gcs_folder_name" -> "transformed/sports/sports_season_match_wise_vv_wt/"
      )
    }
  }

  val distribution_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        //Parameters for distribution packs
        "packs_output_dataset" -> "test",
        "active_universe_output_dataset" -> "test",

        //Parameters for distribution revenue
        "revenue_oracle_table_name" -> "oneview.CUSTOM_CRN_REPLICA_REPORT_BI",
        "revenue_output_path" -> "gs://star-dl-revenue-uat/revenue_matrix",
        "revenue_dataset" -> "test",
        "revenue_output_table_name" -> "dist_revenue",

        //Parameters for distribution incentive
        "incentive_oracle_table_name" -> "oneview.CUSTOM_INCENTIVE_BI",
        "incentive_output_path" -> "gs://star-dl-revenue-uat/incentive_matrix",
        "incentive_dataset" -> "test",
        "incentive_output_table_name" -> "dist_incentive",

        //Parameters for distribution subscription
        "subscription_oracle_table_name" -> "oneview.SUBSCRIBER_NO_UPLOAD_BI",
        "subscription_output_path" -> "gs://star-dl-revenue-uat/subscription_matrix",
        "subscription_dataset" -> "test",
        "subscription_output_table_name" -> "dist_subscription",

        // Parameters for distribution channel bouquet
        "channel_bouquet_oracle_table_name" -> "oneview.BOUQUET_CHANNEL",
        "channel_bouquet_output_path" -> "gs://star-dl-revenue-uat/channel_bouquet_matrix",
        "channel_bouquet_dataset" -> "test",
        "channel_bouquet_output_table_name" -> "dist_channel_bouquet_mapping"

      )
    }
    case "uat" => {
      Map(
        //Parameters for distribution packs
        "packs_output_dataset" -> "test",
        "active_universe_output_dataset" -> "test",

        //Parameters for distribution revenue
        "revenue_oracle_table_name" -> "oneview.CUSTOM_CRN_REPLICA_REPORT_BI",
        "revenue_output_path" -> "gs://star-dl-revenue-uat/revenue_matrix",
        "revenue_dataset" -> "test",
        "revenue_output_table_name" -> "dist_revenue",

        //Parameters for distribution incentive
        "incentive_oracle_table_name" -> "oneview.CUSTOM_INCENTIVE_BI",
        "incentive_output_path" -> "gs://star-dl-revenue-uat/incentive_matrix",
        "incentive_dataset" -> "test",
        "incentive_output_table_name" -> "dist_incentive",

        //Parameters for distribution subscription
        "subscription_oracle_table_name" -> "oneview.SUBSCRIBER_NO_UPLOAD_BI",
        "subscription_output_path" -> "gs://star-dl-revenue-uat/subscription_matrix",
        "subscription_dataset" -> "test",
        "subscription_output_table_name" -> "dist_subscription",

        // Parameters for distribution channel bouquet
        "channel_bouquet_oracle_table_name" -> "oneview.BOUQUET_CHANNEL",
        "channel_bouquet_output_path" -> "gs://star-dl-revenue-uat/channel_bouquet_matrix",
        "channel_bouquet_dataset" -> "test",
        "channel_bouquet_output_table_name" -> "dist_channel_bouquet_mapping"
      )
    }
    case "prod" => {
      Map(
        //Parameters for distribution packs
        "packs_output_dataset" -> "revenue",
        "active_universe_output_dataset" -> "revenue",

        //Parameters for distribution revenue
        "revenue_oracle_table_name" -> "oneview.CUSTOM_CRN_REPLICA_REPORT_BI ",
        "revenue_output_path" -> "gs://star-dl-revenue/revenue_matrix ",
        "revenue_dataset" -> "revenue ",
        "revenue_output_table_name" -> "dist_revenue ",

        //Parameters for distribution incentive
        "incentive_oracle_table_name" -> "oneview.CUSTOM_INCENTIVE_BI ",
        "incentive_output_path" -> "gs://star-dl-revenue/incentive_matrix ",
        "incentive_dataset" -> "revenue ",
        "incentive_output_table_name" -> "dist_incentive ",

        //Parameters for distribution subscription
        "subscription_oracle_table_name" -> "oneview.SUBSCRIBER_NO_UPLOAD_BI ",
        "subscription_output_path" -> "gs://star-dl-revenue/subscription_matrix ",
        "subscription_dataset" -> "viewership ",
        "subscription_output_table_name" -> "dist_subscription ",

        // Parameters for distribution channel bouquet
        "channel_bouquet_oracle_table_name" -> "oneview.BOUQUET_CHANNEL ",
        "channel_bouquet_output_path" -> "gs://star-dl-revenue/channel_bouquet_matrix ",
        "channel_bouquet_dataset" -> "revenue ",
        "channel_bouquet_output_table_name" -> "dist_channel_bouquet_mapping "
      )
    }
  }

  val regional_entertainment_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "viewership"
      )
    }
  }

  val prism_sport_tournament_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "viewership"
      )
    }
  }

  val prog_logs_sports_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "viewership"
      )
    }
  }

  val wooqer: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "viewership"
      )
    }
  }

  val master_onair_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "master"
      )
    }
  }

  val master_month_wise_agency_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "master"
      )
    }
  }

  val ent_reg_ad_revenue_target123: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "revenue"
      )
    }
  }

  val channel_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test"
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "master"
      )
    }
  }

  val spr_eaca_outlay_cube_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "spr_eaca_job_name" -> "EtlJobSprEaCaCube",
        "spr_outlay_job_name" -> "EtlJobSprOutLayCube",
        "spr_eaca_outlay_cube_input_path" -> "s3://star-dl-dev/transformed",
        "spr_eaca_outlay_cube_output_path" -> "gs://star-dl-temp-mint/transformed",
        "spr_eaca_outlay_cube_output_dataset" -> "test",
      )
    }
    case "uat" => {
      Map(
        "spr_eaca_job_name" -> "EtlJobSprEaCaCube",
        "spr_outlay_job_name" -> "EtlJobSprOutLayCube",
        "spr_eaca_outlay_cube_input_path" -> "s3://star-dl-dev/transformed",
        "spr_eaca_outlay_cube_output_path" -> "gs://star-dl-temp-mint/transformed",
        "spr_eaca_outlay_cube_output_dataset" -> "test",
      )
    }
    case "prod" => {
      Map(
        "spr_eaca_job_name" -> "EtlJobSprEaCaCube",
        "spr_outlay_job_name" -> "EtlJobSprOutLayCube",
        "spr_eaca_outlay_cube_input_path" -> "s3://star-dl-spr/transformed",
        "spr_eaca_outlay_cube_output_path" -> "gs://star-dl-revenue/transformed",
        "spr_eaca_outlay_cube_output_dataset" -> "revenue",
      )
    }
  }

  val barc_1min_qc_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "barc_1min_qc_job_name" -> "EtlJobBarcTb1Qc",
        "barc_1min_qc_job_input_path" -> "gs://star-dl-temp-mint/landingzone/posteval/raw_files",
        "barc_1min_qc_job_output_path" -> "s3://star-dl-dev/barc_1min_qc/qc_result"
      )
    }
    case "uat" => {
      Map(
        "barc_1min_qc_job_name" -> "EtlJobBarcTb1Qc",
        "barc_1min_qc_job_input_path" -> "gs://star-dl-temp-mint/landingzone/posteval/raw_files",
        "barc_1min_qc_job_output_path" -> "s3://star-dl-dev/barc_1min_qc/qc_result"
      )
    }
    case "prod" => {
      Map(
        "barc_1min_qc_job_name" -> "EtlJobBarcTb1Qc",
        "barc_1min_qc_job_input_path" -> "gs://star-dl-dev/landingzone/posteval/raw_files",
        "barc_1min_qc_job_output_path" -> "s3://star-dl-dev/barc_1min_qc/qc_result"
      )
    }
  }

  val deal_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "deal_postgre_table_name" -> "disney_deal_month_wise_info",
        "deal_output_path" -> "gs://star-dl-revenue-uat/mint_dump/disney_deal_data",
        "deal_dataset" -> "test",
        "deal_output_table_name" -> "deal"
      )
    }
    case "uat" => {
      Map(
        "deal_postgre_table_name" -> "disney_deal_month_wise_info",
        "deal_output_path" -> "gs://star-dl-revenue-uat/mint_dump/disney_deal_data",
        "deal_dataset" -> "test",
        "deal_output_table_name" -> "deal"
      )
    }
    case "prod" => {
      Map(
        "deal_postgre_table_name" -> "disney_deal_month_wise_info",
        "deal_output_path" -> "gs://star-dl-revenue/mint_dump/disney_deal_data",
        "deal_dataset" -> "revenue",
        "deal_output_table_name" -> "deal"
      )
    }
  }

  val master_barc_impact_taggings: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "output_dataset" -> "test",
        "ent_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_ent.csv",
        "reg_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_reg.csv",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_Barc_Impact_Taggings_ent",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_Barc_Impact_Taggings_reg",
        "output_file_name" -> "part-00000",
        "ent_output_dataset" -> "test",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_barc_impact_taggings",
        "ent_output_table_name" -> "ent_barc_impact_taggings",
      )
    }
    case "uat" => {
      Map(
        "output_dataset" -> "test",
        "ent_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_ent.csv",
        "reg_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_reg.csv",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/uat_Barc_Impact_Taggings_ent",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/uat_Barc_Impact_Taggings_reg",
        "output_file_name" -> "part-00000",
        "ent_output_dataset" -> "test",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_barc_impact_taggings",
        "ent_output_table_name" -> "ent_barc_impact_taggings",
      )
    }
    case "prod" => {
      Map(
        "output_dataset" -> "master",
        "ent_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_ent.csv",
        "reg_job_input_path" -> "gs://star-dl-temp/test/Barc_Impact_Taggings/BARC_Impact_tagging_reg.csv",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/uat_Barc_Impact_Taggings_ent",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/uat_Barc_Impact_Taggings_reg",
        "output_file_name" -> "part-00000",
        "ent_output_dataset" -> "master",
        "reg_output_dataset" -> "master",
        "reg_output_table_name" -> "reg_barc_impact_taggings",
        "ent_output_table_name" -> "ent_barc_impact_taggings",

      )
    }
  }

  val ent_provisions_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "datalake_provisions_data",
        "job_output_path" -> "gs://star-dl-revenue/dev_datalake_provisions_data",
        "output_dataset" -> "test",
        "output_table_name" -> "datalake_provisions_data",
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "datalake_provisions_data",
        "job_output_path" -> "gs://star-dl-revenue/uat_datalake_provisions_data",
        "output_dataset" -> "test",
        "output_table_name" -> "datalake_provisions_data",
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "datalake_provisions_data",
        "job_output_path" -> "gs://star-dl-revenue/prod_datalake_provisions_data",
        "output_dataset" -> "revenue",
        "output_table_name" -> "datalake_provisions_data",
      )
    }
  }


  val sales_db_fact_tables_output_dataset: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "revenue_or_test" -> "dev",
        "viewership_or_test" -> "dev"
      )
    }
    case "uat" => {
      Map(
        "revenue_or_test" -> "uat",
        "viewership_or_test" -> "uat"
      )
    }
    case "prod" => {
      Map(
        "revenue_or_test" -> "revenue",
        "viewership_or_test" -> "viewership"
      )
    }
  }

  val advertiser_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "advertiser_postgre_table_name" -> "advertiser_detail_info",
        "advertiser_output_path" -> "gs://star-dl-revenue-uat/mint_dump/advertiser_detail_info",
        "output_dataset" -> "test",
        "advertiser_output_table_name" -> "advertiser"
      )
    }
    case "uat" => {
      Map(
        "advertiser_postgre_table_name" -> "advertiser_detail_info",
        "advertiser_output_path" -> "gs://star-dl-revenue-uat/mint_dump/advertiser_detail_info",
        "output_dataset" -> "test",
        "advertiser_output_table_name" -> "advertiser"
      )
    }
    case "prod" => {
      Map(
        "advertiser_postgre_table_name" -> "advertiser_detail_info",
        "advertiser_output_path" -> "gs://star-dl-revenue/mint_dump/advertiser_detail_info",
        "output_dataset" -> "master",
        "advertiser_output_table_name" -> "advertiser"
      )
    }
  }

  val ro_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ro_postgre_table_name" -> "release_order_info",
        "ro_output_path" -> "gs://star-dl-revenue-uat/mint_dump/ro_data",
        "ro_dataset" -> "test",
        "ro_output_table_name" -> "ro"
      )
    }
    case "uat" => {
      Map(
        "ro_postgre_table_name" -> "release_order_info",
        "ro_output_path" -> "gs://star-dl-revenue-uat/mint_dump/ro_data",
        "ro_dataset" -> "test",
        "ro_output_table_name" -> "ro"
      )
    }
    case "prod" => {
      Map(
        "ro_postgre_table_name" -> "release_order_info",
        "ro_output_path" -> "gs://star-dl-revenue/mint_dump/ro_data",
        "ro_dataset" -> "test",
        "ro_output_table_name" -> "ro"
      )
    }
  }

  val sale_unit_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "sales_unit_postgre_table_name" -> "sales_unit_product_info",
        "sales_unit_output_path" -> "gs://star-dl-revenue-uat/mint_dump/sales_unit",
        "sales_unit_output_dataset" -> "test",
        "sales_unit_output_table_name" -> "sales_unit"
      )
    }
    case "uat" => {
      Map(
        "sales_unit_postgre_table_name" -> "sales_unit_product_info",
        "sales_unit_output_path" -> "gs://star-dl-revenue-uat/mint_dump/sales_unit",
        "sales_unit_output_dataset" -> "test",
        "sales_unit_output_table_name" -> "sales_unit"
      )
    }
    case "prod" => {
      Map(
        "sales_unit_postgre_table_name" -> "sales_unit_product_info",
        "sales_unit_output_path" -> "gs://star-dl-revenue/mint_dump/sales_unit",
        "sales_unit_output_dataset" -> "revenue",
        "sales_unit_output_table_name" -> "sales_unit"
      )
    }
  }

  val funnel_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "funnel_input_postgre_table_name" -> "funnel_info",
        "funnel_output_path" -> "gs://star-dl-revenue-uat/mint_dump/funnel",
        "funnel_output_dataset" -> "test",
        "funnel_output_table_name" -> "ent_funnel",

        "funnel_reg_input_postgre_table_name" -> "funnel_info",
        "funnel_reg_output_path" -> "gs://star-dl-revenue-uat/mint_dump/funnel_reg",
        "funnel_reg_output_dataset" -> "test",
        "funnel_reg_output_table_name" -> "reg_funnel"
      )
    }
    case "uat" => {
      Map(
        "funnel_input_postgre_table_name" -> "funnel_info",
        "funnel_output_path" -> "gs://star-dl-revenue-uat/mint_dump/funnel",
        "funnel_output_dataset" -> "test",
        "funnel_output_table_name" -> "ent_funnel",

        "funnel_reg_input_postgre_table_name" -> "funnel_info",
        "funnel_reg_output_path" -> "gs://star-dl-revenue-uat/mint_dump/funnel_reg",
        "funnel_reg_output_dataset" -> "test",
        "funnel_reg_output_table_name" -> "reg_funnel"
      )
    }
    case "prod" => {
      Map(
        "funnel_input_postgre_table_name" -> "funnel_info",
        "funnel_output_path" -> "gs://star-dl-revenue/mint_dump/funnel",
        "funnel_output_dataset" -> "revenue",
        "funnel_output_table_name" -> "ent_funnel",

        "funnel_reg_input_postgre_table_name" -> "funnel_info",
        "funnel_reg_output_path" -> "gs://star-dl-revenue/mint_dump/funnel_reg",
        "funnel_reg_output_dataset" -> "revenue",
        "funnel_reg_output_table_name" -> "reg_funnel"
      )
    }
  }

  val kylin_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "kylin_url" -> "https://devkylinjob.startv.com/kylin/api",
        "kylin_project_name" -> "MINT_DEV",
        "Authorization" -> "Basic QURNSU46S1lMSU4=",
        "Content-Type" -> "application/json",
        "reg_pricing_pgm" -> "dev_reg_pricing_pgm",
        "reg_pricing_adv_brand" -> "dev_reg_pricing_adv_brand",
        "ent_pricing_pgm" -> "dev_ent_pricing_pgm",
        "ent_pricing_adv_brand" -> "dev_ent_pricing_adv_brand",
        "pricing_repair_table_path" -> "/opt/kylin/dev/pricing_msck_table.sh",
        "spr_repair_table_path" -> "./revenue_msck_table.sh"
      )
    }
    case "uat" => {
      Map(
        "kylin_url" -> "http->//34.93.251.173->7070//kylin/api",
        "kylin_project_name" -> "MINT_UAT",
        "Authorization" -> "Basic QURNSU46S1lMSU4=",
        "Content-Type" -> "application/json",
        "reg_pricing_pgm" -> "uat_reg_pricing_pgm",
        "reg_pricing_adv_brand" -> "uat_reg_pricing_adv_brand",
        "ent_pricing_pgm" -> "uat_ent_pricing_pgm",
        "ent_pricing_adv_brand" -> "uat_ent_pricing_adv_brand",
        "pricing_repair_table_path" -> "/opt/kylin/uat/pricing_msck_table.sh",
        "spr_repair_table_path" -> "./revenue_msck_table.sh"
      )
    }
    case "prod" => {
      Map(
        "kylin_url" -> "http->//34.93.251.173->7070//kylin/api",
        "kylin_project_name" -> "MINT_PROD",
        "Authorization" -> "Basic QURNSU46S1lMSU4=",
        "Content-Type" -> "application/json",
        "reg_pricing_pgm" -> "prod_reg_pricing_pgm",
        "reg_pricing_adv_brand" -> "prod_reg_pricing_adv_brand",
        "ent_pricing_pgm" -> "prod_ent_pricing_pgm",
        "ent_pricing_adv_brand" -> "prod_ent_pricing_adv_brand",
        "pricing_repair_table_path" -> "/opt/kylin/prod/pricing_msck_table.sh",
        "spr_repair_table_path" -> "./revenue_msck_table.sh"
      )
    }
  }

  val data_ingestion_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "data_ingestion_cb_url_spr" -> "https->//uat-api.startv.com/api/v1/files/import_spr_data?type=spr&",
        "data_ingestion_cb_url_spr_reports" -> "https->//uat-api.startv.com/api/v1/files/import_spr_data?type=modified_spr&",
        "onair_spr_raw_path" -> "star-dl-temp-mint/staging/onair",
        "onair_spr_orc_path" -> "star-dl-temp-mint/transformed/onair",
        "post_eval_raw_path" -> "star-dl-temp-mint/landingzone/posteval/raw_files",
        "post_eval_qc_path" -> "star-dl-temp-mint/landingzone/posteval/qc_files",
        "post_eval_orc_path" -> "star-dl-temp-mint/transformed/post_eval_onair_spr_grp_orc",
        "pre_ingestion_onair_raw_path" -> "star-dl-temp-mint/raw/onair/daily",
        "pre_ingestion_champ_raw_path" -> "star-dl-temp-mint/raw/champ/daily",
        "post_eval_raw_historical_path" -> "s3://star-dl-dev/landingzone/posteval_newtg/raw_files",
        "post_eval_qc_historical_path" -> "s3://star-dl-dev/landingzone/posteval_newtg/qc_files"
      )
    }
    case "uat" => {
      Map(
        "data_ingestion_cb_url_spr" -> "https->//uat-api.startv.com/api/v1/files/import_spr_data?type=spr&",
        "data_ingestion_cb_url_spr_reports" -> "https->//uat-api.startv.com/api/v1/files/import_spr_data?type=modified_spr&",
        "onair_spr_raw_path" -> "star-dl-temp-mint/staging/onair",
        "onair_spr_orc_path" -> "star-dl-temp-mint/transformed/onair",
        "post_eval_raw_path" -> "star-dl-temp-mint/landingzone/posteval/raw_files",
        "post_eval_qc_path" -> "star-dl-temp-mint/landingzone/posteval/qc_files",
        "post_eval_orc_path" -> "star-dl-temp-mint/transformed/post_eval_onair_spr_grp_orc",
        "pre_ingestion_onair_raw_path" -> "star-dl-temp-mint/raw/onair/daily",
        "pre_ingestion_champ_raw_path" -> "star-dl-temp-mint/raw/champ/daily",
        "post_eval_raw_historical_path" -> "s3://star-dl-dev/landingzone/posteval_newtg/raw_files",
        "post_eval_qc_historical_path" -> "s3://star-dl-dev/landingzone/posteval_newtg/qc_files"
      )
    }
    case "prod" => {
      Map(
        "data_ingestion_cb_url_spr" -> "https://mintapi.startv.com/api/v1/files/import_spr_data?type=spr&",
        "data_ingestion_cb_url_spr_reports" -> "https://mintapi.startv.com/api/v1/files/import_spr_data?type=modified_spr&",
        "onair_spr_raw_path" -> "star-dl-dev/staging/onair",
        "onair_spr_orc_path" -> "star-dl-dev/transformed/onair",
        "post_eval_raw_path" -> "star-dl-dev/landingzone/posteval/raw_files",
        "post_eval_qc_path" -> "star-dl-dev/landingzone/posteval/qc_files",
        "post_eval_orc_path" -> "star-dl-dev/transformed/post_eval_onair_spr_grp_orc",
        "pre_ingestion_onair_raw_path" -> "star-dl-dev/raw/onair/daily",
        "pre_ingestion_champ_raw_path" -> "star-dl-dev/raw/champ/daily"
      )
    }
  }

  val data_download_var: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "data_download_cb_url" -> "https://stage-api.startv.com/api/v1/files",
        "data_download_ur_cb_url" -> "https://stage-api.startv.com/api/v1/files",
        "data_download_bucket" -> "star-dl-temp-mint"
      )
    }
    case "uat" => {
      Map(
        "data_download_cb_url" -> "https://uat-api.startv.com/api/v1/files",
        "data_download_ur_cb_url" -> "https->//uat-rep-api.startv.com/v1/files",
        "data_download_bucket" -> "star-dl-download-uat"
      )
    }
    case "prod" => {
      Map(
        "data_download_cb_url" -> "https->//mintapi.startv.com/api/v1/files",
        "data_download_ur_cb_url" -> "https->//uat-rep-api.startv.com/v1/files",
        "data_download_bucket" -> "star-dl-download"
      )
    }
  }

  val common_variables: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "landing_bucket" -> "star-dl-temp-mint",
        "transformed_bucket" -> "star-dl-temp-mint",
        "spr_bucket" -> "star-dl-dev",
        "business" -> "['entertainment','regional']",
        "hotstar_bucket_name" -> "hotstar-dp-datalake-processed-us-east-1-prod",
        "hotstar_bucket_prefix" -> "hive_internal_database/hotstar_star.db",
        "hotstar_gcs_bucket_name" -> "gs://star-dl-hotstar-uat/raw/",
        "hotstar_gcs_transformed_bucket_name" -> "star-dl-hotstar-uat",
        "hotstar_s3_transformed_bucket_name" -> "s3://star-dl-dev/hotstar_data/dev/",
        "dataproc_image_url" -> "asia.gcr.io/mint-bi-reporting/dev/etljobs_testing->0.7.7",
        "kubenates_namespace" -> "dev",
        "docker_cred_file" -> "conf/gcsCred_m-b-r.json"
      )
    }
    case "uat" => {
      Map(
        "landing_bucket" -> "star-dl-temp-mint",
        "transformed_bucket" -> "star-dl-temp-mint",
        "spr_bucket" -> "star-dl-dev",
        "business" -> "['entertainment','regional']",
        "hotstar_bucket_name" -> "hotstar-dp-datalake-processed-us-east-1-prod",
        "hotstar_bucket_prefix" -> "hive_internal_database/hotstar_star.db",
        "hotstar_gcs_bucket_name" -> "gs://star-dl-hotstar-uat/raw/",
        "hotstar_gcs_transformed_bucket_name" -> "star-dl-hotstar-uat",
        "hotstar_s3_transformed_bucket_name" -> "s3://star-dl-dev/hotstar_data/uat/",
        "dataproc_image_url" -> "asia.gcr.io/mint-bi-reporting/uat/etljobs_testing->0.7.7",
        "kubenates_namespace" -> "uat",
        "docker_cred_file" -> "conf/gcsCred_m-b-r.json"
      )
    }
    case "prod" => {
      Map(
        "landing_bucket" -> "star-dl-dev",
        "transformed_bucket" -> "star-dl-dev",
        "spr_bucket" -> "star-dl-dev",
        "business" -> "['entertainment','regional']",
        "hotstar_bucket_name" -> "hotstar-dp-datalake-processed-us-east-1-prod",
        "hotstar_bucket_prefix" -> "hive_internal_database/hotstar_star.db",
        "hotstar_gcs_bucket_name" -> "gs://star-dl-hotstar/raw/",
        "hotstar_gcs_transformed_bucket_name" -> "star-dl-hotstar",
        "hotstar_s3_transformed_bucket_name" -> "s3://star-dl-dev/hotstar_data/prod/",
        "dataproc_image_url" -> "asia.gcr.io/mint-bi-reporting/prod/etljobs_testing->0.7.7",
        "kubenates_namespace" -> "prod",
        "docker_cred_file" -> "conf/gcsCred_m-b-r.json"
      )
    }
  }

  val ent_reg_adveriser_master: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "advertiser_detail_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_advertiser_detail_info_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_advertiser_master",
        "reg_job_input_path" -> "advertiser_detail_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_advertiser_detail_info_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_advertiser"
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "advertiser_detail_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/uat_advertiser_detail_info_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_advertiser_master",
        "reg_job_input_path" -> "advertiser_detail_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/uat_advertiser_detail_info_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_advertiser",
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "advertiser_detail_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/prod_advertiser_detail_info_ent",
        "ent_output_dataset" -> "master",
        "ent_output_table_name" -> "ent_advertiser_master",
        "reg_job_input_path" -> "advertiser_detail_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/prod_advertiser_detail_info_reg",
        "reg_output_dataset" -> "master",
        "reg_output_table_name" -> "reg_advertiser",
      )
    }
  }

  val ent_reg_channel_master: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "channel_master_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_ent_channel_master_info",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_channel_master",
        "reg_job_input_path" -> "channel_master_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_reg_channel_master_info",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_channel"
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "channel_master_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/uat_ent_channel_master_info",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_channel_master",
        "reg_job_input_path" -> "channel_master_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/uat_reg_channel_master_info",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_channel"
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "channel_master_info",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/prod_ent_channel_master_info",
        "ent_output_dataset" -> "master",
        "ent_output_table_name" -> "ent_channel_master",
        "reg_job_input_path" -> "channel_master_info",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/prod_reg_channel_master_info",
        "reg_output_dataset" -> "master",
        "reg_output_table_name" -> "reg_channel"
      )
    }
  }

  val ent_reg_month_wise_agency: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "month_wise_agency_mappings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_month_wise_agency_mappings_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "month_wise_agency_mappings",
        "reg_job_input_path" -> "month_wise_agency_mappings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_month_wise_agency_mappings_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_month_wise_agency_mappings"
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "month_wise_agency_mappings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/uat_month_wise_agency_mappings_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "month_wise_agency_mappings",
        "reg_job_input_path" -> "month_wise_agency_mappings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/uat_month_wise_agency_mappings_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_month_wise_agency_mappings"
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "month_wise_agency_mappings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/prod_month_wise_agency_mappings_ent",
        "ent_output_dataset" -> "master",
        "ent_output_table_name" -> "month_wise_agency_mappings",
        "reg_job_input_path" -> "month_wise_agency_mappings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/prod_month_wise_agency_mappings_reg",
        "reg_output_dataset" -> "master",
        "reg_output_table_name" -> "reg_month_wise_agency_mappings"
      )
    }
  }

  val ent_spot_ratings: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/dev_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_spot_ratings"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/uat_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_spot_ratings"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/prod_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "viewership",
        "output_table_name" -> "ent_spot_ratings"
      )
    }
  }

  val reg_spot_ratings: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/dev_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "reg_spot_ratings"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/uat_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "reg_spot_ratings"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/transformed/prod_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "viewership",
        "output_table_name" -> "reg_spot_ratings"
      )
    }
  }

  val ent_timeband_30: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/dev_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_time_band_30"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/uat_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_time_band_30"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/prod_entertainment",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "viewership",
        "output_table_name" -> "ent_time_band_30"
      )
    }
  }

  val reg_timeband_30: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/dev_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "reg_time_band_30"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/uat_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "test",
        "output_table_name" -> "reg_time_band_30"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/transformed/prod_regional",
        "output_file_name" -> "partEtlJobEntSpotRatings.orc",
        "output_dataset" -> "viewership",
        "output_table_name" -> "reg_time_band_30"
      )
    }
  }

  val ent_reg_ad_revenue_cprp: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target_cprp",
        "ent_job_output_path" -> "gs://star-dl-revenue/dev_ent_ad_revenue_target_cprp",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_ad_revenue_target_cprp",
        "reg_job_input_path" -> "ent_ad_revenue_target_cprp",
        "reg_job_output_path" -> "gs://star-dl-revenue/dev_reg_ad_revenue_target_cprp",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_ad_revenue_target_cprp"
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target_cprp",
        "ent_job_output_path" -> "gs://star-dl-revenue/uat_ent_ad_revenue_target_cprp",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_ad_revenue_target_cprp",
        "reg_job_input_path" -> "ent_ad_revenue_target_cprp",
        "reg_job_output_path" -> "gs://star-dl-revenue/uat_reg_ad_revenue_target_cprp",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_ad_revenue_target_cprp"
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target_cprp",
        "ent_job_output_path" -> "gs://star-dl-revenue/prod_ent_ad_revenue_target_cprp",
        "ent_output_dataset" -> "revenue",
        "ent_output_table_name" -> "ent_ad_revenue_target_cprp",
        "reg_job_input_path" -> "ent_ad_revenue_target_cprp",
        "reg_job_output_path" -> "gs://star-dl-revenue/prod_reg_ad_revenue_target_cprp",
        "reg_output_dataset" -> "revenue",
        "reg_output_table_name" -> "reg_ad_revenue_target_cprp"
      )
    }
  }

  val ent_reg_ad_revenue_target: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target",
        "ent_job_output_path" -> "gs://star-dl-revenue/dev_ent_ad_revenue_target",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_ad_revenue_target",
        "reg_job_input_path" -> "ent_ad_revenue_target",
        "reg_job_output_path" -> "gs://star-dl-revenue/dev_reg_ad_revenue_target",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_ad_revenue_target"
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target",
        "ent_job_output_path" -> "gs://star-dl-revenue/uat_ent_ad_revenue_target",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "ent_ad_revenue_target",
        "reg_job_input_path" -> "ent_ad_revenue_target",
        "reg_job_output_path" -> "gs://star-dl-revenue/uat_reg_ad_revenue_target",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_ad_revenue_target"
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "ent_ad_revenue_target",
        "ent_job_output_path" -> "gs://star-dl-revenue/prod_ent_ad_revenue_target",
        "ent_output_dataset" -> "revenue",
        "ent_output_table_name" -> "ent_ad_revenue_target",
        "reg_job_input_path" -> "ent_ad_revenue_target_cprp",
        "reg_job_output_path" -> "gs://star-dl-revenue/prod_reg_ad_revenue_target",
        "reg_output_dataset" -> "revenue",
        "reg_output_table_name" -> "reg_ad_revenue_target"
      )
    }
  }

  val reg_spot_rating_qc: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/dev_regional",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/dev_regional",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/dev_regional"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/uat_regional",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/uat_regional",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/uat_regional"

      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/regional",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/prod_regional",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/prod_regional",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/prod_regional"
      )
    }
  }

  val ent_spot_rating_qc: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/dev_entertainment",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/dev_entertainment",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/dev_entertainment"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/uat_entertainment",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/uat_entertainment",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/uat_entertainment"

      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-spot-ratings/entertainment",
        "job_output_path" -> "gs://star-dl-spot-ratings/qc_result/prod_entertainment",
        "qc_result_path" -> "gs://star-dl-spot-ratings/qc_result/prod_entertainment",
        "ingestion_output_path" -> "gs://star-dl-spot-ratings/transformed/prod_entertainment"

      )
    }
  }

  val ent_timeband_30_qc: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/dev_entertainment",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/dev_entertainment",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/dev_entertainment"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/uat_entertainment",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/uat_entertainment",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/uat_entertainment"

      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/entertainment",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/prod_entertainment",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/prod_entertainment",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/prod_entertainment"

      )
    }
  }

  val reg_timeband_30_qc: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/dev_regional",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/dev_regional",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/dev_regional"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/uat_regional",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/uat_regional",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/uat_regional"

      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-timeband/30_min/regional",
        "job_output_path" -> "gs://star-dl-timeband/30_min/qc_result/prod_regional",
        "qc_result_path" -> "gs://star-dl-timeband/30_min/qc_result/prod_regional",
        "ingestion_output_path" -> "gs://star-dl-timeband/30_min/transformed/prod_regional"

      )
    }
  }

  val wooqer_ingestion: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer",
        "job_output_path" -> "gs://star-dl-temp-mint/dev_wooqer",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "wooqer"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer",
        "job_output_path" -> "gs://star-dl-temp-mint/uat_wooqer",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "wooqer"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer",
        "job_output_path" -> "gs://star-dl-temp-mint/prod_wooqer",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "viewership",
        "output_table_name" -> "wooqer"
      )
    }
  }

  val wooqer_universe_ingestion: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer_universe",
        "job_output_path" -> "gs://star-dl-temp-mint/dev_wooqer_universe",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "wooqer_universe"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer_universe",
        "job_output_path" -> "gs://star-dl-temp-mint/uat_wooqer_universe",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "viewership",
        "output_table_name" -> "wooqer_universe"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "postgre_table_wooqer_universe",
        "job_output_path" -> "gs://star-dl-temp-mint/prod_wooqer_universe",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "viewership",
        "output_table_name" -> "wooqer_universe"
      )
    }
  }

  val fact_revenue_bq: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_revenue/dev_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_revenue"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_revenue/uat_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_revenue"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_revenue/prod_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_revenue"
      )
    }
  }

  val fact_revenue_view_bq: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_viewership_from_etljob/dev_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_viewership"

      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_viewership_from_etljob/uat_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_viewership"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "BQ_query",
        "job_output_path" -> "gs://star-dl-temp/ent_fact_viewership_from_etljob/prod_transformed",
        "output_file_name" -> "part-00000",
        "output_dataset" -> "test",
        "output_table_name" -> "ent_fact_viewership"
      )
    }
  }

  val fact_revenue_v1: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_v1",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_v1/dev_transformed",
        "rev_output_dataset" -> "dev",
        "rev_output_table_name" -> "fact_revenue_v1",
        "sr_job_input_path" -> "fact_spot_ratings_v1",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_v1/dev_transformed",
        "sr_output_dataset" -> "dev",
        "sr_output_table_name" -> "fact_spot_ratings_v1",
      )
    }
    case "uat" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_v1",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_v1/uat_transformed",
        "rev_output_dataset" -> "uat",
        "rev_output_table_name" -> "fact_revenue_v1",
        "sr_job_input_path" -> "fact_spot_ratings_v1",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_v1/uat_transformed",
        "sr_output_dataset" -> "uat",
        "sr_output_table_name" -> "fact_spot_ratings_v1",
      )
    }
    case "prod" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_v1",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_v1/prod_transformed",
        "rev_output_dataset" -> "revenue",
        "rev_output_table_name" -> "fact_revenue_v1",
        "sr_job_input_path" -> "fact_spot_ratings_v1",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_v1/prod_transformed",
        "sr_output_dataset" -> "revenue",
        "sr_output_table_name" -> "fact_spot_ratings_v1",
      )
    }
  }

  val fact_revenue_table_common: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_common",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_common/dev_transformed",
        "rev_output_dataset" -> "dev",
        "rev_output_table_name" -> "fact_revenue_common",
        "sr_job_input_path" -> "fact_spot_ratings_common",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_common/dev_transformed",
        "sr_output_dataset" -> "dev",
        "sr_output_table_name" -> "fact_spot_ratings_common",
      )
    }
    case "uat" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_common",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_common/uat_transformed",
        "rev_output_dataset" -> "uat",
        "rev_output_table_name" -> "fact_revenue_common",
        "sr_job_input_path" -> "fact_spot_ratings_common",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_common/uat_transformed",
        "sr_output_dataset" -> "uat",
        "sr_output_table_name" -> "fact_spot_ratings_common",
      )
    }
    case "prod" => {
      Map(
        "rev_job_input_path" -> "fact_revenue_common",
        "rev_job_output_path" -> "gs://star-dl-revenue/fact_revenue_common/prod_transformed",
        "rev_output_dataset" -> "viewership",
        "rev_output_table_name" -> "fact_revenue_common",
        "sr_job_input_path" -> "fact_spot_ratings_common",
        "sr_job_output_path" -> "gs://star-dl-revenue/fact_spot_ratings_common/prod_transformed",
        "sr_output_dataset" -> "viewership",
        "sr_output_table_name" -> "fact_spot_ratings_common",
      )
    }
  }

  val onair_sales_unit_taggigs: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "ent_job_input_path" -> "onair_sales_unit_taggings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "onair_sales_unit_taggings",
        "reg_job_input_path" -> "onair_sales_unit_taggings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_onair_sales_unit_taggings",
      )
    }
    case "uat" => {
      Map(
        "ent_job_input_path" -> "onair_sales_unit_taggings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_ent",
        "ent_output_dataset" -> "test",
        "ent_output_table_name" -> "onair_sales_unit_taggings",
        "reg_job_input_path" -> "onair_sales_unit_taggings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_reg",
        "reg_output_dataset" -> "test",
        "reg_output_table_name" -> "reg_onair_sales_unit_taggings",
      )
    }
    case "prod" => {
      Map(
        "ent_job_input_path" -> "onair_sales_unit_taggings",
        "ent_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_ent",
        "ent_output_dataset" -> "master",
        "ent_output_table_name" -> "onair_sales_unit_taggings",
        "reg_job_input_path" -> "onair_sales_unit_taggings",
        "reg_job_output_path" -> "gs://star-dl-revenue/master/dev_onair_sales_unit_taggings_reg",
        "reg_output_dataset" -> "master",
        "reg_output_table_name" -> "reg_onair_sales_unit_taggings",

      )
    }
  }

  val email_variables: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "mail.smtp.port" -> "587",
        "mail.transport.protocol" -> "smtp",
        "mail.smtp.starttls.enable" -> "true",
        "mail.host" -> "smtp.office365.com",
        "mail.user" -> "noreply-mint@in.startv.com",
        "mail.password" -> "Passw0rd@1234313",
        "mail.smtp.auth" -> "true",
      )
    }
    case "uat" => {
      Map(
        "mail.smtp.port" -> "587",
        "mail.transport.protocol" -> "smtp",
        "mail.smtp.starttls.enable" -> "true",
        "mail.host" -> "smtp.office365.com",
        "mail.user" -> "noreply-mint@in.startv.com",
        "mail.password" -> "Passw0rd@1234313",
        "mail.smtp.auth" -> "true",
      )
    }
    case "prod" => {
      Map(
        "mail.smtp.port" -> "587",
        "mail.transport.protocol" -> "smtp",
        "mail.smtp.starttls.enable" -> "true",
        "mail.host" -> "smtp.office365.com",
        "mail.user" -> "noreply-mint@in.startv.com",
        "mail.password" -> "Passw0rd@1234313",
        "mail.smtp.auth" -> "true",

      )
    }
  }

  val bi_channel_master: Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Channel_Master/BI_Channel_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/dev_BI_Channel_Master",
        "output_dataset" -> "test",
        "output_table_name" -> "bi_channel_master"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Channel_Master/BI_Channel_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/uat_BI_Channel_Master",
        "output_dataset" -> "test",
        "output_table_name" -> "bi_channel_master"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Channel_Master/BI_Channel_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/prod_BI_Channel_Master",
        "output_dataset" -> "true",
        "output_table_name" -> "master"

      )
    }
  }


  val bi_advertiser_master:  Map[String, String] = ENV match {
    case "dev" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Advertiser_Master/BI_Advertiser_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/dev_BI_Advertiser_Master",
        "output_dataset" -> "test",
        "output_table_name" -> "bi_advertiser_master"
      )
    }
    case "uat" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Advertiser_Master/BI_Advertiser_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/uat_BI_Advertiser_Master",
        "output_dataset" -> "test",
        "output_table_name" -> "bi_advertiser_master"
      )
    }
    case "prod" => {
      Map(
        "job_input_path" -> "gs://star-dl-temp/test/BI_Advertiser_Master/BI_Advertiser_Master.csv",
        "job_output_path" -> "gs://star-dl-revenue/master/prod_BI_Advertiser_Master",
        "output_dataset" -> "master",
        "output_table_name" -> "bi_advertiser_master"

      )
    }
  }

}