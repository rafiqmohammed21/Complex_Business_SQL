package etljobs.master.revenue_calender

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.SaveMode
import schema.revenue_calender.RevenueCalender.RevenueCalenderMapping


case class EtlJobRevenueCalender(
                                  val job_properties: MintEtlJobProps,
                                  val global_properties: Option[GlobalProperties]
                                )
  extends  SequentialEtlJob with SparkUDF with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  val step1 = SparkReadWriteStep[RevenueCalenderMapping](
    name                    = "load_revenue_calender_GCP",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(",",true),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.output_file_name),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val step2 = BQLoadStep[RevenueCalenderMapping](
    name                           = "load_revenue_calender_BQ",
    input_location                 = Left(props.job_output_path + "/" + props.output_file_name),
    input_type                     = ORC,
    output_dataset                 = props.output_dataset,
    output_table                   = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)
}
