package schema.master

object ChannelMaster {
  case class ChannelMasterEnt (source_name:String,
                                   channel_name:String,
                                   channel_group_name:String,
                                   genre:String,
                                   sub_genre:String,
                                   type_of_beam:String,
                                   subscription:String,
                                   network:String,
                                   hour_type:String,
                                   part_of_day:String,
                                   from_day:String,
                                   to_day:String,
                                   start_time:String,
                                   end_time:String,
                                   channel_primary_tg:String,
                                   channel_secondary_tg:String,
                                   genre_tg:String,
                                   language:String
                                  )
}
