/*
 * Copyright 2015 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// [START all]
package etljobs.datatransfer;

import com.google.api.services.storagetransfer.Storagetransfer;
import com.google.api.services.storagetransfer.model.*;
import java.io.IOException;
import java.util.Arrays;

/**
 * Creates a daily transfer from a standard Cloud Storage bucket to a Cloud Storage Nearline
 * bucket for files untouched for 30 days.
 */
public final class NearlineRequester {

  /**
   * Creates and executes a request for a TransferJob to Cloud Storage Nearline.
   *
   * <p>The {@code startDate} and {@code startTime} parameters should be set according to the UTC
   * Time Zone. See:
   * https://developers.google.com/resources/api-libraries/documentation/storagetransfer/v1/java/latest/com/google/api/services/storagetransfer/v1/model/Schedule.html#getStartTimeOfDay()
   *
   * @return the response TransferJob if the request is successful
   * @throws InstantiationException
   *           if instantiation fails when building the TransferJob
   * @throws IllegalAccessException
   *           if an illegal access occurs when building the TransferJob
   * @throws IOException
   *           if the client failed to complete the request
   */
  public static TransferJob createNearlineTransferJob(
      String projectId,
      String jobDescription,
      String gcsSourceBucket,
      String gcsNearlineSinkBucket,
      java.util.List<String> ListOfPrefix,
      Boolean delete_source_folder,
      Boolean overwrite_dest_folder,
      String startDate,
      String startTime)
      throws InstantiationException, IllegalAccessException, IOException {
    Date date = TransferJobUtils.createDate(startDate);
    TimeOfDay time = TransferJobUtils.createTimeOfDay(startTime);
    TransferJob transferJob =
        new TransferJob()
            .setDescription(jobDescription)
            .setProjectId(projectId)
            .setTransferSpec(
                new TransferSpec()
                    .setGcsDataSource(new GcsData().setBucketName(gcsSourceBucket))
                    .setGcsDataSink(new GcsData().setBucketName(gcsNearlineSinkBucket))
                    .setObjectConditions(
                        new ObjectConditions().setIncludePrefixes(ListOfPrefix))
                    .setTransferOptions(
                        new TransferOptions()
                            .setDeleteObjectsFromSourceAfterTransfer(delete_source_folder)
                            .setOverwriteObjectsAlreadyExistingInSink(true)
                            .setDeleteObjectsUniqueInSink(overwrite_dest_folder)))
            .setSchedule(
                new Schedule().setScheduleStartDate(date).setStartTimeOfDay(time))
            .setStatus("ENABLED");

    Storagetransfer client = TransferClientCreator.createStorageTransferClient();
    return client.transferJobs().create(transferJob).execute();
  }

    public static void run(String projectId,
                           String jobDescription,
                           String gcsSourceBucket,
                           String gcsNearlineSinkBucket,
                           java.util.List<String> listOfPrefix,
                           Boolean delete_source_folder,
                           Boolean overwrite_dest_folder,
                           String date,
                           String time)
            throws InstantiationException, IllegalAccessException, IOException {

        java.util.List  prefix = Arrays.asList(listOfPrefix);
        TransferJob responseT =
                createNearlineTransferJob(
                        projectId,
                        jobDescription,
                        gcsSourceBucket,
                        gcsNearlineSinkBucket,
                        prefix,
                        delete_source_folder,
                        overwrite_dest_folder,
                        date,
                        time);
        System.out.println("Return transferJob: " + responseT.toPrettyString());
    }

  /**
   * Output the contents of a successfully created TransferJob.
   *
   * @param args
   *          arguments from the command line
   */

  public static void main(String[] args) {
      try {
          run(     args[0]
                  ,args[1]
                  ,args[2]
                  ,args[3]
                  ,Arrays.asList(args[4])
                  ,Boolean.parseBoolean(args[5])
                  ,Boolean.parseBoolean(args[6])
                  ,args[7]
                  ,args[8]
          );
      } catch (Exception e) {
          e.printStackTrace();
      }
  }
}
//[END all]
