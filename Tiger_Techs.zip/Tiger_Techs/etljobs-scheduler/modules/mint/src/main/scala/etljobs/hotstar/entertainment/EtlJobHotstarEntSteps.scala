package etljobs.hotstar.entertainment

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.HotstarEntProps
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.hotstar.HotstarEntertainment._
import util.Configs



case class EtlJobHotstarEntSteps(
                             val job_properties: MintEtlJobProps,
                             val global_properties: Option[GlobalProperties]
                      )
  extends SequentialEtlJob with SparkUDF with SparkManager{


  val props : HotstarEntProps = job_properties.asInstanceOf[HotstarEntProps]


  def hotstar_ent_daily_channel_transform(spark: SparkSession,dataset: Dataset[HotstarEntDailyChannelPerformanceAws]) : Dataset[HotstarEntDailyChannelPerformanceBQ] = {

    val mapping  = Encoders.product[HotstarEntDailyChannelPerformanceBQ]
    val df_daily_channel_performance = dataset.withColumnRenamed("cd", "date")
    .withColumnRenamed("_col0", "channel_id")
    .withColumnRenamed("_col1", "channel_name")
    .withColumnRenamed("_col2", "daily_video_views")
    .withColumnRenamed("_col3", "daily_watch_time")
    .withColumn("daily_video_views",col("daily_video_views").cast(IntegerType))
    .withColumn("daily_watch_time",col("daily_watch_time").cast(IntegerType))
    .as[HotstarEntDailyChannelPerformanceBQ](mapping)

    df_daily_channel_performance.printSchema()
    df_daily_channel_performance.show(10)
    df_daily_channel_performance
  }

  def hotstar_ent_daily_show_transform(spark: SparkSession,dataset: Dataset[HotstarEntDailyShowPerformanceAws]) : Dataset[HotstarEntDailyShowPerformanceBQ] = {

    val mapping  = Encoders.product[HotstarEntDailyShowPerformanceBQ]
    val df_daily_show_performance = dataset.withColumnRenamed("_col0", "channel_name")
      .withColumnRenamed("_col1", "show_name")
      .withColumnRenamed("_col2", "daily_video_views")
      .withColumnRenamed("_col3", "daily_watch_time")
      .withColumn("daily_video_views",col("daily_video_views").cast(IntegerType))
      .withColumn("daily_watch_time",col("daily_watch_time").cast(IntegerType))
      .withColumnRenamed("cd", "date")
      .as[HotstarEntDailyShowPerformanceBQ](mapping)

    df_daily_show_performance.printSchema()
    df_daily_show_performance.show(10)
    df_daily_show_performance
  }

  def hotstar_ent_weekly_channel_transform(spark: SparkSession,dataset: Dataset[HotstarEntWeeklyChannelPerformanceAws]) : Dataset[HotstarEntWeeklyChannelPerformanceBQ] = {

    val mapping = Encoders.product[HotstarEntWeeklyChannelPerformanceBQ]
    val df_weekly_channel_performance = dataset
      .withColumnRenamed("_col0", "channel_name")
      .withColumnRenamed("_col1", "weekly_video_views")
      .withColumnRenamed("_col2", "weekly_watch_time")
      .withColumnRenamed("_col3", "week_starting_on")
      .withColumnRenamed("year", "year")
      .withColumnRenamed("week", "week")

    val df_weekly_channel_performance_transform = df_weekly_channel_performance
      .withColumn("new_week",get_week(df_weekly_channel_performance("week"),df_weekly_channel_performance("year")))
      .withColumn("new_year",get_year(df_weekly_channel_performance("week"),df_weekly_channel_performance("year")))
      .withColumn("weekly_video_views",col("weekly_video_views").cast(IntegerType))
      .withColumn("weekly_watch_time",col("weekly_watch_time").cast(IntegerType))
      .drop("year","week")
      .withColumnRenamed("new_year", "year")
      .withColumnRenamed("new_week", "week")


    df_weekly_channel_performance_transform.printSchema()
    df_weekly_channel_performance_transform.show(10)
    df_weekly_channel_performance_transform.as[HotstarEntWeeklyChannelPerformanceBQ](mapping)
  }

  def hotstar_ent_weekly_show_transform(spark: SparkSession,dataset: Dataset[HotstarEntWeeklyShowPerformanceAws]) : Dataset[HotstarEntWeeklyShowPerformanceBQ] = {

    val mapping = Encoders.product[HotstarEntWeeklyShowPerformanceBQ]
    val df_weekly_show_performance = dataset.withColumnRenamed("_col0", "channel_name")
      .withColumnRenamed("_col1", "show_name")
      .withColumnRenamed("_col2", "wvv")
      .withColumnRenamed("_col3", "wwt")
      .withColumnRenamed("_col4", "week_starting_on")
      .withColumnRenamed("year", "year")
      .withColumnRenamed("week", "week")

    val df_weekly_show_performance_transform = df_weekly_show_performance
      .withColumn("new_week",get_week(df_weekly_show_performance("week"),df_weekly_show_performance("year")))
      .withColumn("new_year",get_year(df_weekly_show_performance("week"),df_weekly_show_performance("year")))
      .withColumn("wvv",col("wvv").cast(IntegerType))
      .withColumn("wwt",col("wwt").cast(IntegerType))
      .drop("year","week")
      .withColumnRenamed("new_week", "week")
      .withColumnRenamed("new_year", "year")

    df_weekly_show_performance_transform.printSchema()
    df_weekly_show_performance_transform.show(10)
    df_weekly_show_performance_transform.as[HotstarEntWeeklyShowPerformanceBQ](mapping)

  }

  def get_adhoc_week: (Int,Int) => Int = { (x,y) =>
    if (x == 1 && y == 2020) 53
    else if (x > 1 && y == 2020) x-1
    else x
  }

  def get_adhoc_year: (Int,Int) => Int= { (x,y) =>
    if (x == 1 && y == 2020) 2019
    else y
  }

  val get_week = udf(get_adhoc_week)
  val get_year = udf(get_adhoc_year)

  val hotstar_bucket = "s3a://" + Configs.common_variables.get("hotstar_bucket_name").get + "/" + Configs.common_variables.get("hotstar_bucket_prefix").get
  etl_job_logger.info("Accessing hotstar bucket :" + hotstar_bucket)

  val daily_channel_performance_data_transfer = SparkReadWriteStep[HotstarEntDailyChannelPerformanceAws](
    name                    = "Aws data transfer for daily_channel_performance ",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_ent_ingestion_var.get("daily_channel_folder_name").get),
    input_type              = ORC,
    output_location         = props.daily_channel_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val daily_show_performance_data_transfer = SparkReadWriteStep[HotstarEntDailyShowPerformanceAws](
    name                    = "Aws data transfer for daily_show_performancee",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_ent_ingestion_var.get("daily_show_folder_name").get),
    input_type              = ORC,
    output_location         = props.daily_show_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val weekly_channel_performance_data_transfer = SparkReadWriteStep[HotstarEntWeeklyChannelPerformanceAws](
    name                    = "Aws data transfer for weekly_channel_performance",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_ent_ingestion_var.get("weekly_channel_folder_name").get),
    input_type              = ORC,
    output_location         = props.weekly_channel_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )

  val weekly_show_performance_data_transfer = SparkReadWriteStep[HotstarEntWeeklyShowPerformanceAws](
    name                    = "Aws data transfer for weekly_show_performance",
    input_location          = Seq( hotstar_bucket + "/" + Configs.hotstar_ent_ingestion_var.get("weekly_show_folder_name").get),
    input_type              = ORC,
    output_location         = props.weekly_show_job_input_path.get,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val daily_channel_ingestion =  SparkReadTransformWriteStep[HotstarEntDailyChannelPerformanceAws, HotstarEntDailyChannelPerformanceBQ](
      name                    = "load_hostar_Entertainment_daily_channel_performance_GCP",
      input_location          = Seq(props.daily_channel_job_input_path.get),
      input_type              = ORC,
      output_location         = props.daily_channel_job_output_path.get,
      transform_function      = hotstar_ent_daily_channel_transform,
      output_type             = ORC,
      output_save_mode        = SaveMode.Overwrite,
      output_filename         = Some(props.daily_channel_output_file_name.get),
      output_repartitioning   = true,
      output_repartitioning_num = 1,
    )

  val daily_channel_bq_ingestion = BQLoadStep[HotstarEntDailyChannelPerformanceBQ](
    name                            = "load_hostar_Entertainment_daily_channel_performance_BQ",
    input_location                  = Left(props.daily_channel_job_output_path.get + "/" + props.daily_channel_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.daily_channel_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED,

  )

  val daily_show_ingestion = SparkReadTransformWriteStep[HotstarEntDailyShowPerformanceAws, HotstarEntDailyShowPerformanceBQ](
    name                    = "load_hostar_Entertainment_daily_show_performance_GCP",
    input_location          = Seq(props.daily_show_job_input_path.get),
    input_type              = ORC,
    output_location         = props.daily_show_job_output_path.get,
    transform_function      = hotstar_ent_daily_show_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.daily_show_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val daily_show_bq_ingestion = BQLoadStep[HotstarEntDailyShowPerformanceBQ](
    name                            = "load_hostar_Entertainment_daily_show_performance_BQ",
    input_location                  = Left(props.daily_show_job_output_path.get + "/" + props.daily_show_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.daily_show_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val weekly_channel_ingestion= SparkReadTransformWriteStep[HotstarEntWeeklyChannelPerformanceAws, HotstarEntWeeklyChannelPerformanceBQ](
    name                    = "load_hostar_Entertainment_weekly_channel_performance",
    input_location          = Seq(props.weekly_channel_job_input_path.get),
    input_type              = ORC,
    output_location         = props.weekly_channel_job_output_path.get,
    transform_function      = hotstar_ent_weekly_channel_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.weekly_channel_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val weekly_channel_bq_ingestion = BQLoadStep[HotstarEntWeeklyChannelPerformanceBQ](
    name                            = "load_hostar_Entertainment_weekly_channel_performance_BQ",
    input_location                  = Left(props.weekly_channel_job_output_path.get + "/" + props.weekly_channel_output_file_name.get),
    input_type                      = ORC,
    output_dataset                  = props.output_dataset.get,
    output_table                    = props.weekly_channel_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val weekly_show_ingestion = SparkReadTransformWriteStep[HotstarEntWeeklyShowPerformanceAws, HotstarEntWeeklyShowPerformanceBQ](
    name                    = "load_hostar_Entertainment_weekly_show_performance_GCP",
    input_location          = Seq(props.weekly_show_job_input_path.get),
    input_type              = ORC,
    output_location         = props.weekly_show_job_output_path.get,
    transform_function      = hotstar_ent_weekly_show_transform ,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.weekly_show_output_file_name.get),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )

  val weekly_show_bq_ingestion = BQLoadStep[HotstarEntWeeklyShowPerformanceBQ](
    name                          = "load_hostar_Entertainment_weekly_show_performance_BQ",
    input_location                = Left(props.weekly_show_job_output_path.get + "/" + props.weekly_show_output_file_name.get),
    input_type                    = ORC,
    output_dataset                = props.output_dataset.get,
    output_table                  =  props.weekly_show_output_table_name.get,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val etlStepList : List[EtlStep[Unit,Unit]] = EtlStepList(
    daily_channel_performance_data_transfer,
    daily_show_performance_data_transfer,
    weekly_channel_performance_data_transfer,
    weekly_show_performance_data_transfer,
    daily_channel_ingestion,
    daily_show_ingestion,
    weekly_channel_ingestion,
    weekly_show_ingestion,
    daily_channel_bq_ingestion,
    daily_show_bq_ingestion,
    weekly_channel_bq_ingestion,
    weekly_show_bq_ingestion
   )

}
