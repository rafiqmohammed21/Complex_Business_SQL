package etljobs.datatransfer

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.{Calendar, TimeZone}

trait utils {

  def currentDateTime()= {
    val date = new Date(System.currentTimeMillis())
    val sdf  = new SimpleDateFormat("yyyy-MM-dd")
    val stf  = new SimpleDateFormat("HH:mm:ss")
    sdf.setTimeZone(TimeZone.getTimeZone("UTC"))
    stf.setTimeZone(TimeZone.getTimeZone("UTC"))
    val cal  = Calendar.getInstance()
    cal.add(Calendar.SECOND,5)
    (sdf.format(date),stf.format(cal.getTime))
  }

}



