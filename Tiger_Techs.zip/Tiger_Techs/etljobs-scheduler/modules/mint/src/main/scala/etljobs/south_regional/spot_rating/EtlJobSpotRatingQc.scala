package etljobs.south_regional.spot_rating

import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{EtlStep, SparkETLStep}
import etlflow.spark.{ReadApi, SparkManager}
import etlflow.utils.{CSV, GlobalProperties}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.QcJobProps
import etljobs.etlsteps.{DataprocSparkJobSpotRatingEnt, DataprocSparkJobSpotRatingReg}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{Dataset, Row, SaveMode, SparkSession}
import schema.regional.RegionalSpotRating.{QCSchema, RegSpotRatings}
import udfs.Common
import util.MintGlobalProperties


/**
 * Object EtlJobRegionalQc gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes etlstep mentioned in list returned by it.
 *
 * In etlstep1 it performs validation on regional dataset by comparing its aggregated form with qc dataframe
 */

case class EtlJobSpotRatingQc(
                          val job_properties: MintEtlJobProps,
                          val global_properties: Option[GlobalProperties]
                        )
  extends SequentialEtlJob  with Common  with SparkManager {

  lazy val reg_logger = Logger.getLogger(getClass.getName)
  val props: QcJobProps = job_properties.asInstanceOf[QcJobProps]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  /**
   * Aggregates raw data on the columns year,week, region, channel, event_type, level, target
   * and returns aggregated dataframe comparable to qc dataframe
   *
   * @param spark               spark session
   * @param regional_input_path string containing input path for regional data
   * @return dfAgg aggregated raw dataframe comparable to qc dataframe
   */
  def getRawData(spark: SparkSession, regional_input_path: String): Dataset[Row] = {
    implicit val spark_implicit = spark
    val ds: Dataset[RegSpotRatings] = ReadApi.LoadDS[RegSpotRatings](Seq(regional_input_path), CSV("|", true))(spark)
    val df_enriched = ds.filter(col("level") notEqual " ")
      .withColumn("ratings", col("ratings") * col("duration"))
      .withColumn("impressions", col("impressions") * col("duration"))

    df_enriched.createOrReplaceTempView("df_enriched")

    // aggregate dfBarc in order to compare it with qc data
    val dfAgg = spark.sql(
      """SELECT year,week,target, region, channel, event_type, level
            , sum(duration) as duration
            , sum(ratings)/sum(duration) as rat_av
            , sum(impressions)/sum(duration) as imp_av
        FROM (
              SELECT substring(date, length(date)-3,length(date)) as year, week, region, channel, event_type, level, target, duration, ratings, impressions
              FROM df_enriched
             ) a
        GROUP BY year,week, region, channel, event_type, level, target
      """.stripMargin)
    dfAgg

  }

  def getQcData(spark: SparkSession, qc_input_path: String): Dataset[Row] = {
    implicit val spark_implicit = spark
    val dfQC: Dataset[QCSchema] = ReadApi.LoadDS[QCSchema](Seq(qc_input_path), CSV("|", true))(spark)
    val dfQCWithOutRowNum = dfQC.drop("row_num")
    dfQCWithOutRowNum
  }

  def getQcPathFromRaw(input_path: String): String = {
    val qc_path = input_path.replace("raw", "qc")
    reg_logger.info(s"QC Path is $qc_path")
    qc_path
  }


  /**
   * Performs validation on raw dataset by comparing its aggregated form with qc dataframe
   * If validation fails then it writes qc comparison results to given location in property qc_result_path
   *
   * @param spark     spark session
   * @param input_dir string containing input path for regional data
   */
  def spotRatingQCCheck(region: String, input_dir: String, qc_result_path: String, debug_mode: String = "false")(spark: SparkSession, ip: Unit): Unit = {

    implicit val spark_implicit = spark
    val qc_input_path = getQcPathFromRaw(input_dir)

    // STEP 1 => read raw data and prepare aggregated data to compare it with qc data
    val dfAgg = getRawData(spark, input_dir)

    // STEP 2 => read QC data and remove row_num col
    val dfQCWithOutRowNum = getQcData(spark, qc_input_path)

    // STEP 3 => full outer join qc df with aggregated raw df and cache the joined df
    val joined_df = dfQCWithOutRowNum
      .join(dfAgg,
        col("year") === col("year_qc") &&
          col("week") === col("week_qc") &&
          lower(col("target")) === lower(col("target_qc")) &&
          lower(col("region")) === lower(col("region_qc")) &&
          lower(col("level")) === lower(col("level_qc")) &&
          lower(col("channel")) === lower(col("channel_qc")) &&
          lower(col("event_type")) === lower(col("event_type_qc"))
        , "full")
      .where(""" rat_av_wg_qc != 'n.s' and imp_av_wg_qc != 'n.s' and target_av_wg_qc != 'n.s'   """)
      .select(
        col("year_qc"),
        col("year"),
        col("week_qc"),
        col("week"),
        col("target_qc"),
        col("target"),
        col("region_qc"),
        col("region"),
        col("level_qc"),
        col("level"),
        col("channel_qc"),
        col("channel"),
        col("event_type_qc"),
        col("event_type"),
        round(col("duration") - col("duration_qc"), 2).as("duration_diff"),
        round(col("rat_av") - col("rat_av_wg_qc").cast(DoubleType), 2).as("rat_av_wg_diff"),
        round(col("imp_av") - col("imp_av_wg_qc").cast(DoubleType), 2).as("imp_av_wg_diff")
      )

    joined_df.cache()

    // STEP 4 => find distinct rows which are present in qc df but missed in raw aggregated df
    val raw_missing = joined_df
      .where(col("channel") isNull)
      .select(
        col("year_qc"),
        col("week_qc"),
        col("target_qc"),
        col("region_qc"),
        col("level_qc"),
        col("channel_qc"),
        col("event_type_qc"))
      .distinct()

    // STEP 5 => find distinct rows which are present in raw aggregated df but missed in qc df
    val qc_missing = joined_df
      .where(col("channel_qc") isNull)
      .select(
        col("year"),
        col("week"),
        col("target"),
        col("region"),
        col("level"),
        col("channel"),
        col("event_type"))
      .distinct()

    // STEP 6 => find rows which have impermissible differences in duration and rating
    val raw_qc_diff = joined_df.where(
      ((col("duration_diff") notEqual 0)
        or (col("rat_av_wg_diff") notEqual 0)
        or (col("imp_av_wg_diff") notEqual 0))
        and ((col("channel") isNotNull) and (col("channel_qc") isNotNull)))

    if (debug_mode == "true") {
      println("======================sample aggregated raw data===================")
      dfAgg.show(10, false)
      println("======================qc data schema===================")
      dfQCWithOutRowNum.printSchema()
      println("======================sample qc data===================")
      dfQCWithOutRowNum.show(10, false)
      println("======================sample aggRaw qc joined data===================")
      joined_df.show(10, false)
      println("======================sample raw missing data===================")
      raw_missing.show(10, false)
      println("======================sample qc missing data===================")
      qc_missing.show(10, false)
      println("======================sample raw qc diff data===================")
      raw_qc_diff.show(10, false)
    }

    // save qc comparison result in case exception has occurred
    def save_qc_result(qc_result_path: String): Unit = {
      qc_missing.write.option("header", "true").option("delimiter", "|").mode(SaveMode.Overwrite).csv(qc_result_path + "/" + region + "/qc_missing")
      raw_missing.write.option("header", "true").option("delimiter", "|").mode(SaveMode.Overwrite).csv(qc_result_path + "/" + region + "/raw_missing")
      raw_qc_diff.write.option("header", "true").option("delimiter", "|").mode(SaveMode.Overwrite).csv(qc_result_path + "/" + region + "/raw_qc_diff_missing")
      joined_df.write.option("header", "true").option("delimiter", "|").mode(SaveMode.Overwrite).csv(qc_result_path + "/" + region + "/raw_agg_qc_join")
    }

    // check if joined df have permissible differences in duration and rating
    def validate_duration_rat_permissible_limit(): Boolean = {
      val max_limit_duration_diff = joined_df.agg(max("duration_diff")).first().getLong(0).toInt
      val min_limit_duration_diff = joined_df.agg(min("duration_diff")).first().getLong(0).toInt
      val max_limit_rat_av_wg_diff = joined_df.agg(max("rat_av_wg_diff")).first().getDouble(0)
      val min_limit_rat_av_wg_diff = joined_df.agg(min("rat_av_wg_diff")).first().getDouble(0)
      if (max_limit_duration_diff > 0 || min_limit_duration_diff < 0 || max_limit_rat_av_wg_diff > 0.001 || min_limit_rat_av_wg_diff < -0.001) true
      else false
    }

    if (qc_missing.count > 0) {
      save_qc_result(qc_result_path)
      throw new Exception(s"Exception occurred! QC validation for regional_spot_rating failed for ${region}. Count of qc_missing is more than 0. \n Please find data comparison at path: " + qc_result_path + "/" + region)
    }
    else if (raw_missing.count > 0) {
      save_qc_result(qc_result_path)
      throw new Exception(s"Exception occurred! QC validation for regional_spot_rating failed for ${region}. Count of raw_missing is more than 0. \n Please find data comparison at path: " + qc_result_path + "/" + region)
    }
    else if (validate_duration_rat_permissible_limit()) {
      save_qc_result(qc_result_path)
      throw new Exception(s"Exception occurred! QC validation for regional_spot_rating failed for ${region}. Reason: duration_diff or rat_av_wg_diff are out of permissible limit. \n Please find data comparison at path: " + qc_result_path + "/" + region)
    }
  }

  val regions_list: List[String] = List("bengali", "kannada", "malayalam", "marathi", "tamil", "telugu")
  //val region_dir_pair_list : List[(String,String)] = getInputDirsVariable(job_properties("job_input_path"),spark)
  if (props.job_input_path.contains("entertainment")) {
    reg_logger.info("Entertainment data input dirs are: ")
    reg_logger.info(props.job_input_path + "/gec")
  } else {
    reg_logger.info("Regional data input dirs are: ")
    regions_list.foreach(x => reg_logger.info(props.job_input_path + "/" + x))
  }


  val step0 = new SparkETLStep[Unit,Unit](
    name = "PreIngestionQCSpotRatings",
    transform_function = spotRatingQCCheck("gec", props.job_input_path + "/gec/*", props.qc_result_path, props.debug_mode)
  )

  val steps = regions_list.map { region =>
    new SparkETLStep[Unit,Unit](
      name = "PreIngestionQCSpotRatings_" + region,
      transform_function = spotRatingQCCheck(region, props.job_input_path + "/" + region + "/*", props.qc_result_path, props.debug_mode)
    )
  }

  val spot_rating_ent_ingestion = DataprocSparkJobSpotRatingEnt(
    name = "DataProc Job Submission for Spot rating entertainment",
    job_name = "EtlJobEntSpotRatings",
    props = Map("job_input_path" -> props.job_input_path, "job_output_path" -> props.ingestion_output_path),
    conf = Some(mint_global_properties)
  )

  val spot_rating_reg_ingestion = DataprocSparkJobSpotRatingReg(
    name = "DataProc Job Submission for Spot rating regional",
    job_name = "EtlJobRegSpotRatings",
    props = Map("job_input_path" -> props.job_input_path, "job_output_path" -> props.ingestion_output_path),
    conf = Some(mint_global_properties)
  )


  val etlStepList: List[EtlStep[Unit, Unit]] = props.job_type match {
    case "qc_ingestion" => {
      if (props.job_input_path.contains("entertainment"))
        EtlStepList(step0, spot_rating_ent_ingestion)
      else
        steps ++ EtlStepList(spot_rating_reg_ingestion)
    }
    case "qc" => {
      if (props.job_input_path.contains("entertainment"))
        EtlStepList(step0)
      else
        steps
    }
  }
}
