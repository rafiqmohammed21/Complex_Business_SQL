package etljobs.download

import java.util.Calendar

import etlflow.spark.ReadApi
import etlflow.utils.ORC
import master.CustomJdbcConn
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{col, concat, date_format, lit}
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, SparkSession}
import schema.Format.{DDBarcOutput, DDBarcTemp}
import schema.download.{BarcDownloadCriteriaMapper, DDBarc}
import udfs.{Common, Download}
import util.MintGlobalProperties

import scala.collection.mutable.ArrayBuffer

object Barc extends CustomJdbcConn with Download with Common with Serializable {

  @transient val barcdd_logger = Logger.getLogger(getClass.getName)

  def apply(module: String, criteria_path: String, input_path: String, jdbc_conn:Map[String,String], barcColumns: Seq[String],conf: MintGlobalProperties)(spark:SparkSession,dataset: Dataset[BarcDownloadCriteriaMapper]) = {

    val encoder  = Encoders.product[DDBarc]
    val criteria = dataset.collect

    barcdd_logger.info(s"BARC Criteria is " + criteria.mkString)

    var Initial_Table_Name = ArrayBuffer[String]()

    for (criteria <- criteria) {

      var where_clause = if (criteria.channel_name.length <= 0 && criteria.tg_market.length <= 0) {
          s"`date`>=${retrofit(criteria.start_date)} and " +
          s"`date`<=${retrofit(criteria.end_date)} and " +
          s"upper(regexp_replace(concat_ws('',level,ev_type),' ','')) in (${retrofit(criteria.level.mkString(","))})"
      } else if (criteria.advertiser.length <= 0) {
          s"`date`>=${retrofit(criteria.start_date)} and " +
          s"`date`<=${retrofit(criteria.end_date)} and " +
          s"upper(regexp_replace(channel,' ','')) in (${retrofit(criteria.channel_name.mkString(","))}) and " +
          s"upper(regexp_replace(concat_ws('',target,region),' ','')) in (${retrofit(criteria.tg_market.mkString(","))}) and " +
          s"upper(regexp_replace(concat_ws('',level,ev_type),' ','')) in (${retrofit(criteria.level.mkString(","))})"
      } else if (criteria.tg_market.length <= 0) {
          s"`date`>=${retrofit(criteria.start_date)} and " +
          s"`date`<=${retrofit(criteria.end_date)} and " +
          s"upper(regexp_replace(channel,' ','')) in (${retrofit(criteria.channel_name.mkString(","))}) and " +
          s"upper(regexp_replace(regexp_replace(advertiser,' ',''),'\\'','')) in (${retrofit(criteria.advertiser.mkString(","))}) and " +
          s"upper(regexp_replace(concat_ws('',level,ev_type),' ','')) in (${retrofit(criteria.level.mkString(","))})"
      } else s"`date`>=${retrofit(criteria.start_date)} and `date`<=${retrofit(criteria.end_date)} and " +
          s"upper(regexp_replace(channel,' ','')) in (${retrofit(criteria.channel_name.mkString(","))}) and " +
          s"upper(regexp_replace(regexp_replace(advertiser,' ',''),'\\'','')) in (${retrofit(criteria.advertiser.mkString(","))}) and " +
          s"upper(regexp_replace(concat_ws('',target,region),' ','')) in (${retrofit(criteria.tg_market.mkString(","))}) and " +
          s"upper(regexp_replace(concat_ws('',level,ev_type),' ','')) in (${retrofit(criteria.level.mkString(","))})"

      val barc_df = ReadApi.LoadDF(Seq(input_path), input_type = ORC, where_clause = where_clause, select_clause = barcColumns)(spark).distinct

      val UID = Calendar.getInstance().getTime.getTime.toString
      val Temp_Table_Name = "barc_data_download_" + UID
      barc_df.createOrReplaceTempView(s"$Temp_Table_Name")
      Initial_Table_Name += Temp_Table_Name
    }

    val final_df = for (i <- Initial_Table_Name) yield {
      val condition = "UNION ALL"
      var select = s"select * from ${i.mkString}"
      select + s" $condition "
    }

    val select_query_final = final_df.mkString("").dropRight(10)

    spark.sql(s"$select_query_final")

    Download(spark.sql(s"$select_query_final"),module,jdbc_conn,spark = spark,conf = conf).as(encoder)

  }

  def Download(barc_df:DataFrame,module : String,jdbc_conn:Map[String,String],spark:SparkSession,conf: MintGlobalProperties) = {

    val barc_source = barc_df
      .withColumn("week day"        ,date_format(col("date"),"EEEE"))
      .withColumn("month"           ,date_format(col("date"),"MMMM"))
      .withColumn("TGMarket"        ,concat(col("target"),col("region")))
      .withColumn("Channel TMP"     ,RemCharConvertToCap(col("channel")," ",""))
      .withColumn("Advertiser TMP"  ,RemCharConvertToCap(col("advertiser")," ",""))
      .withColumn("Brand TMP"       ,RemCharConvertToCap(col("brand")," ",""))
      .withColumn("start_time"      ,get_12hr_formatted_udf(col("start_time")))
      .withColumn("rat_percent"     ,get_round_value(col("rat_percent")))
      .withColumn("impressions_000" ,get_round_value(col("impressions_000")))
      .withColumn("GRPs"            ,get_round_value(get_grp_tvt(col("rat_percent"),col("length"))))
      .withColumn("TVTs"            ,get_round_value(get_grp_tvt(col("impressions_000"),col("length"))))
      .withColumn("level",concat(col("level"),lit(" ("),col("ev_type"),lit(")")))
      .join(FetchDDMasterData(module,conf.MM_channel_source_table,spark = spark,conf = conf)(jdbc_conn)  ,Seq("Channel TMP"),"inner")
      .join(FetchDDMasterData(module,conf.MM_channel_table,spark = spark,conf = conf)(jdbc_conn)       ,Seq("channel_id"),"left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_table,spark = spark,conf = conf)(jdbc_conn)      ,Seq("Advertiser TMP","Brand TMP"),"left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_group_table,spark = spark,conf = conf)(jdbc_conn),Seq("txn_group_id"),"left")
      .join(FetchDDMasterData(module,conf.MM_advertiser_cat_table,spark = spark,conf = conf)(jdbc_conn)   ,Seq("advertiser_category_id"),"left")
      .na.fill("n.a")
      .drop(Seq("target","region", "segment","txn_group_id",
        "Channel TMP","Advertiser TMP","Brand TMP","channel_name",
        "advertiser_category_id", "channel_id","channel","region"):_*)
      .distinct

    val barc_formatted = barc_source.select(DDBarcTemp.head,DDBarcTemp.tail:_*)
    barc_formatted.toDF(DDBarcOutput: _*)
  }
}
