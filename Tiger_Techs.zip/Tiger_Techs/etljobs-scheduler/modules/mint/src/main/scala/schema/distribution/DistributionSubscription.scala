package schema.distribution

import java.sql.{Date, Timestamp}

object DistributionSubscription {
  case class DistributionSubOracle (
                                     customer_code:String,
                                     bouquet_alacarte:String,
                                     bouquet_alacarte_name: String,
                                     count_on_seventh_week:String,
                                     count_on_fourteenth_WEEK:String,
                                     count_on_twentifirst_WEEK:String,
                                     count_on_twentieight_WEEK:String,
                                     type_of_billing: String,
                                     month_year: String,
                                     vertical:String,
                                     state:String,
                                     is_pushed_to_billing:String,
                                     dpo_name:String,
                                     date:Timestamp,
                                     date_int: String
                                    )

  case class DistributionSubBQ (
                                 customer_code:String,
                                 bouquet_alacarte:String,
                                 bouquet_alacarte_name: String,
                                 count_on_seventh_week:String,
                                 count_on_fourteenth_WEEK:String,
                                 count_on_twentifirst_WEEK:String,
                                 count_on_twentieight_WEEK:String,
                                 type_of_billing: String,
                                 vertical:String,
                                 state:String,
                                 is_pushed_to_billing:String,
                                 dpo_name:String,
                                 date:Date,
                                 MONTH:Int,
                                 YEAR:Int,
                                 date_int: String
                               )


}
