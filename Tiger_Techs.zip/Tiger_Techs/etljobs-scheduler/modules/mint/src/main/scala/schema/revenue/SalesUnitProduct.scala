package schema.revenue

import java.sql.Date

object SalesUnitProduct {

  case class SalesUnitProductPostgre (on_air_sales_unit:String,
                                      product_name:String,
                                      product_id:BigInt,
                                      impact_regular:String,
                                      channel_skew_weight:String,
                                      year_month:String,
                                      date: Date,
                                      channel_daypart_pt:Double,
                                      channel_daypart_npt:Double,
                                      channel_weekpart_wd:Double,
                                      channel_weekpart_we:Double,
                                      channel_dayparttwo_cpt:Double,
                                      date_int: String
                                     )

  case class SalesUnitProductBQ (on_air_sales_unit:String,
                                 product_name:String,
                                 product_id:BigInt,
                                 impact_regular:String,
                                 channel_skew_weight:String,
                                 year_month:String,
                                 date: Date,
                                 channel_daypart_pt:Double,
                                 channel_daypart_npt:Double,
                                 channel_weekpart_wd:Double,
                                 channel_weekpart_we:Double,
                                 channel_dayparttwo_cpt:Double,
                                 date_int: String
                                )
}
