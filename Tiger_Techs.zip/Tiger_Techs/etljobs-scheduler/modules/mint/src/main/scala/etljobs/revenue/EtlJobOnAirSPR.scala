//package etljobs.revenue
//
//import java.text.SimpleDateFormat
//
//import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
//import etljobs.{EtlJob, EtlJobName, EtlProps, MyEtlJobProps}
//import org.apache.log4j.Logger
//import org.apache.spark.sql.expressions.Window
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.types.DoubleType
//import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
//import java.util.{Calendar, UUID}
//
//import etlflow.bigquery.BigQueryManager
//import etlflow.etljobs.SequentialEtlJob
//import etlflow.spark.SparkManager
//import etlflow.utils.GlobalProperties
//import etljobs.EtlJobProps.RevenueOnAirSprProps
//import etljobs.bigquery.BigQueryManager
//import etljobs.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
//import etljobs.spark.{SparkManager, SparkUDF}
//import schema.revenue.Revenue.{OnairRawSchema, SprBQ, SprTransformed}
//import etljobs.utils.{GlobalProperties, ORC}
//import udfs.Common
//import util.MintGlobalProperties
//
///** Object EtlJobOnAirSPR gets executed when it is passed in RunEtlJob from LoadData object.
// * RunEtlJob executes both etlstep mentioned in list returned by it.
// *
// * In first etlstep it reads regional data from regional_input_path mentioned in input parameters
// * then enrich it using function EtlJobOnAirSPR and writes in ORC format at given output path
// * by partitioning it on date
// *
// * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery partitioned table by date
// *
// *
// * QC Queries:
// *   1. Below query will fetch the count of distinct telecast date in the date range of 2018-01-01 and 2018-02-28.
// *      We can specify any date range to get result.
// *      SELECT telecast_date,count(*)
// *      FROM mintbireporting.revenue.spr
// *      where telecast_date between DATE("2018-01-01") AND DATE("2018-02-28")
// *      group by telecast_date
// *      order by telecast_date
// *
// *   2. Below query will fetch the sum of PITCHED_PRICE,DURATION,CONVERSION_RATE for every distinct telecast date provided in the date range.
// *      SELECT telecast_date,SUM(PITCHED_PRICE),SUM( DURATION),SUM(CONVERSION_RATE)
// *      FROM mintreporting.revenue.spr
// *      where telecast_date between "2018-01-01" AND "2018-02-28"
// *
// *   3. Below query is related to specific channel id to check whether data for mentioned channel_id is correctly loaded or not.
// *      select  SUM(PITCHED_PRICE),SUM(DURATION),SUM(CONVERSION_RATE)
// *      FROM mintbireporting.revenue.spr
// *      where channel_id is not null
// *            and channel_id="10937"
// *            and telecast_date='2018-08-29'
// *            limit 10;
// *
// *
// *    4. select count(*) from revenue.spr_history_load_today where telecast_date='2018-12-22'
// *
// *
// *    5. Below query will compare the data for provided channel_id and telecast date. Purpose of this query is to check whether history data is loaded
// *       properly or not
// *       select count(*) from revenue_reports.spr_historical_flatten_daily_parts where telecast_date="20180207" and channel_id="9690"
// *       select count(*) from revenue.spr_history_load_today where telecast_date='2018-02-07' and channel_id="9690"
// *
// *    6. Purpose of below query is to get aggregated result of pitched_price,duration,and conversion rate for specific channel_id and telecast date
// *        select  SUM(PITCHED_PRICE),SUM(DURATION),SUM(CONVERSION_RATE) FROM mintbireporting.revenue.spr_history_load_today where channel_id is not null  and channel_id="9690" and telecast_date='2018-02-07' limit 10;
// *        select  SUM(PITCHED_PRICE),SUM(DURATION),SUM(CONVERSION_RATE) FROM revenue_reports.spr_historical_flatten_daily_parts where channel_id is not null  and channel_id="9690" and telecast_date='20180207' limit 10;
// *
// *
// *    7.  Purpose of below query is to get aggregated result of pitched_price,duration,and conversion rate for specific channel_id and telecast date,sales_unit_pull_id and  advertiser_id_master
// *       select  SUM(PITCHED_PRICE),SUM(DURATION),SUM(CONVERSION_RATE) FROM mintbireporting.revenue.spr_history_load_today where channel_id <> ''  and telecast_date='2018-02-07' and advertiser_id_master=18876 and sales_unit_pool_id="70136"
// *       select SUM(PITCHED_PRICE),SUM(DURATION),SUM(CONVERSION_RATE) FROM revenue_reports.spr_historical_flatten_daily_parts where channel_id is not null  and telecast_date='20180207' and advertiser_id_master=18876 and sales_unit_pool_id="70136" limit 10;
// *
// *
// *
// */
//class EtlJobOnAirSPR (
//                       val job_properties: MyEtlJobProps,
//                       val global_properties: Option[GlobalProperties]
//                     )
//  extends SequentialEtlJob with SparkManager with BigQueryManager {
//  import spark.implicits._
//
//  val currency_etl_logger = Logger.getLogger(getClass.getName)
//  currency_etl_logger.info(s"Loaded ${getClass.getName}")
//  var file_paths : Seq[(String,String)] = Seq()
//
//  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
//  val props : RevenueOnAirSprProps = job_properties.asInstanceOf[RevenueOnAirSprProps]
//
//  /** Adding columns time_band(if not exists), date_int, barc_year,barc week
//   * and casting columns
//   * It also generates output paths partitioned by date_int for saving data in ORC format.This ETL method is related to history load and normal run.
//   * @param spark spark session
//   * @param dataset raw dataset which needs to be enriched
//   * @return air_spr enriched dataframe
//   */
//  def spr_transform(spark: SparkSession,where_clause:String)(dataset: Dataset[OnairRawSchema]) : Dataset[SprBQ] = {
//    import spark.implicits._
//    var orig_dataset=dataset
//    val spr_schama_with_datatypes=List(("channel_id","String"),("channel_name","String"),("telecast_date","Date"),("advertiser_id_master","Int"),("advertiser_name_master","String"),
//      ("agency_id","String"),("agency_name","String"),("program_id","string"),("program_name","String"),("sales_unit_pool_id","string"),("sales_unit_pool_name","String"),("aired_time","string"),
//      ("duration","Int"),("pitched_price","Double"),("rc_name","String"),("rc_price","Double"),("commercial_material","String"),("brand","String"),("deal_name","String"),("deal_number","string"),
//      ("sales_location","String"),("spot_status","String"),("revenue_classification","String"),("currency","String"),("event_status","String"),("commercial_type","String"),("currency_id","Int"),
//      ("advertiser_name_child","String"),("gstin_number_buyer","String"),("house_no","String"),("prod_cat","String"),("plan","String"),("plan_number","String"),("po_no","String"),("deal_type","String"),
//      ("sales_team","String"),("sales_executive","String"),("entity_state","String"),("entity_gstin_number","String")
//      ,("deal_status","String"),("plan_status","String"),("break_block_type","String")
//      ,("content_type","String"),("spot_id","String"),("spot_rate_in_inr","Double"),("time_band","String"),("date_int","String"))
//
//    val columnTimeBandExists=orig_dataset.columns.contains("time_band")
//
//    val rawMapping  = Encoders.product[OnairRawSchema]
//    if ("false"==columnTimeBandExists)
//      orig_dataset=orig_dataset.withColumn("time_band", time_band_split_udf(col("aired_time"))).as[OnairRawSchema](rawMapping)
//
//    val mapping  = Encoders.product[SprTransformed]
//
//    val spr_ds_temp = orig_dataset
//      .where(where_clause)
//      .withColumn("date_int", col("telecast_date"))
//      .withColumn("telecast_date",get_formatted_date("telecast_date","yyyyMMdd","yyyy-MM-dd"))
//
//    val spr_ds = spr_schama_with_datatypes
//      .foldLeft(spr_ds_temp){case(tempdf,x) => tempdf.withColumn(x._1,col(x._1).cast(x._2))}
//      .as[SprTransformed](mapping)
//      .distinct()
//
//    val generateUUID = udf(() => UUID.randomUUID().toString)
//    val primaryColors = List("",null)
//
//    //loading the champ dataset
//    val champ_ds_temp=spark.read.orc(props.champ_history_load_input_path)
//      .where(where_clause)
//      .withColumn("date_int", col("telecast_date"))
//      .withColumn("telecast_date",get_formatted_date("telecast_date","yyyyMMdd","yyyy-MM-dd"))
//      .withColumn("spot_id", when('spot_id isin(primaryColors:_*) ,generateUUID()) .otherwise(col("spot_id")))
//
//    val champ_ds = spr_schama_with_datatypes
//      .foldLeft(champ_ds_temp){case(tempdf,x) => tempdf.withColumn(x._1,col(x._1).cast(x._2))}
//      .as[SprTransformed](mapping)
//      .distinct()
//    //performing the union of spr data and champ data
//
//    val sprChampUnionDataset = spr_ds.union(champ_ds)
//
//    file_paths = sprChampUnionDataset
//      .select("date_int")
//      .distinct()
//      .as[String]
//      .collect()
//      .map((path)=> (props.job_output_path + "/date_int=" + path + "/part*",path))
//
//    currency_etl_logger.info("Filepaths generated are: ")
//
//    file_paths.foreach(path => println(path))
//
//    val currency_ds=spark.read.orc(props.currency_input_data_path).distinct()
//
//    val join_condition = $"spr.telecast_date" >= $"curr.currency_date" && lower($"spr.currency") === lower($"curr.currency_name")
//
//    val bqMapping  = Encoders.product[SprBQ]
//
//    val final_df =  sprChampUnionDataset.as('spr)
//      .join(currency_ds.select("currency_date","currency_name","conversion").as('curr),join_condition,"Left")
//      .withColumn("rank",row_number() over Window.partitionBy("spot_id").orderBy(col("currency_date").desc))
//      .where("rank = 1")
//      .withColumn("conversion_rate", when('conversion isNotNull ,col("conversion")) .otherwise(lit(1.0)).cast(DoubleType))
//      .drop("rank","conversion","barc_year","barc_week","currency_name","year","week","date")
//      .withColumn("inserted_at",lit(current_date()))
//      .as[SprBQ](bqMapping)
//
//    final_df
//  }
//
//  def getPlusMinusDays(current_date: String,days: Int):(String, String, String)={
//    val sdf = new SimpleDateFormat("yyyy-MM-dd");
//    val c = Calendar.getInstance
//    c.setTime(sdf.parse(current_date))
//    c.add(Calendar.DATE, days)
//    val calculated_date=sdf.format(c.getTime)
//    val calculated_year=get_barc_year(calculated_date)
//    val calculated_week=get_barc_week(calculated_date)
//    (calculated_date,calculated_week,calculated_year)
//  }
//
//
//   //call method getPlusMinusDays to get start_time,start_week and start_year by subtracting 15 days from current date
//  val start_date=getPlusMinusDays(props.current_date,-15)
//
//  // call method getPlusMinusDays to get start_time,start_week and start_year by adding 30 days from current date
//  val end_date=getPlusMinusDays(props.current_date,30)
//
//  val formatted_start_date="\'"+start_date._1 + "\'"
//  val formatted_end_date="\'"+end_date._1 + "\'"
//
//  var where_clause = $"year".between(start_date._3,end_date._3) && $"week".between(start_date._2,end_date._2)  && $"date".between(formatted_start_date,formatted_end_date)
//  if (end_date._3 != start_date._3){
//    where_clause = $"year".between(start_date._3,end_date._3) &&  $"date".between(formatted_start_date,formatted_end_date)
//  }
//
//  val step1= SparkReadWriteStep[OnairRawSchema, SprBQ](
//    name                    = "LoadSPRDataGCB",
//    input_location          = Seq(props.spr_history_load_input_path),
//    input_type              = ORC,
//    transform_function      = Some(spr_transform(spark, where_clause.toString())),
//    output_location         = props.output_dataset,
//    output_type             = ORC,
//    output_partition_col    = Seq("date_int"),
//    output_save_mode        = SaveMode.Overwrite,
//    output_repartitioning   = true
//  )(spark)
//
//  val step2 = BQLoadStep(
//    name                    = "LoadRatingBQ",
//    input_location = Right(file_paths),
//    input_type           = ORC,
//    output_dataset     = props.output_dataset,
//    output_table       = props.output_table_name,
//    output_table_write_disposition = WriteDisposition.WRITE_TRUNCATE,
//    output_table_create_disposition      = CreateDisposition.CREATE_IF_NEEDED
//  )(bq)
//
//  val etl_step_list : List[EtlStep[Unit,Unit]] = List(step1,step2)
//}
//
//val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)