package schema.revenue

object RegAdRevenueDeployed {

  case class RegAdRevenueDeployed (
                                 Channel_name : String,
                                 year: Int,
                                 month: String,
                                 region: String,
                                 ecs_group: String,
                                 week: Int,
                                 value: Double
                                )
  case class RegAdRevenueDeployedEnriched (
                                            Channel_name : String,
                                            year: Int,
                                            month: Int,
                                            region: String,
                                            ecs_group: String,
                                            week: Int,
                                            value: Double
                                        )
}
