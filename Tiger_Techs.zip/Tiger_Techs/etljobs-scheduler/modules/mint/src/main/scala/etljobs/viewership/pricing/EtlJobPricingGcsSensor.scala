package etljobs.viewership.pricing

import etlflow.LoggerResource
import etlflow.etljobs.GenericEtlJob
import etlflow.etlsteps.{DataprocSparkJobStep, GCSSensorStep, GenericETLStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.PricingJobProps
import etljobs.datatransfer.DataTransferStep
import udfs.Common
import util.MintHelper._
import util.{Configs, MintGlobalProperties}
import zio.ZIO

import scala.concurrent.duration._

case class EtlJobPricingGcsSensor(
                           val job_properties:MintEtlJobProps,
                           val global_properties: Option[GlobalProperties]
                    )
  extends  GenericEtlJob with SparkUDF with Common with SparkManager {

  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val props: PricingJobProps = job_properties.asInstanceOf[PricingJobProps]

  var run_type = props.job_type

  import spark.implicits._

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val Year_Week_DF = Seq((props.job_run_year, props.job_run_week)).toDF("year", "week")

  if (run_type.equalsIgnoreCase("weekly"))
      run_type = "Ingestion_Weekly"

    def get_default_year(ip: Unit): String = {
      props.job_run_year
    }

    def get_default_week(ip: Unit): String = {
      props.job_run_week
    }

    etl_job_logger.info(" Key : " + props.key_file)
    etl_job_logger.info(" Run_type : " + run_type)

    val year_calculation =
      if (props.job_run_year.equalsIgnoreCase("NA") && props.job_run_week.equalsIgnoreCase("NA")) {
        GenericETLStep[Unit, String](
          name = "Year_Calculation",
          transform_function = getMaxPartitionValue(Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get, "pricing/transformed/year", "year")
        )
      } else {
        GenericETLStep[Unit, String](
          name = "Year_Calculation",
          transform_function = get_default_year
        )
      }

    def week_calculation(year: String) =
      if (props.job_run_year.equalsIgnoreCase("NA") && props.job_run_week.equalsIgnoreCase("NA")) {
        GenericETLStep[Unit, String](
          name = "Week_Calculation",
          transform_function = getMaxPartitionValue(Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get, s"pricing/transformed/year=${year}/week=", "week")
        )
      } else {
        GenericETLStep[Unit, String](
          name = "Week_Calculation",
          transform_function = get_default_week
        )
      }

    def DataTransferStep1(job_run_year: String, job_run_week: String) = DataTransferStep(
      name = s"DataTransfer For EtlJobPricing Raw Data ",
      job_description = "pricing_data_copy",
      source_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_aws").get,
      dest_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get,
      prefix = props.raw_path_prefix + "/year=" + job_run_year + "/week=" + job_run_week,
      job_type = "awstogcs",
      dl_source_folder = false,
      ow_dest_folder = false,
      access_key = "AKIAIMVJOLSKVH7BPFVQ",
      secret_key = "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",
    )

    def DataTransferStep2(job_run_year: String, job_run_week: String) = DataTransferStep(
      name = s"DataTransfer For EtlJobPricing Qc Data",
      job_description = "pricing_data_copy",
      source_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_aws").get,
      dest_bucket = Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get,
      prefix = props.qc_path_prefix + "/year=" + job_run_year + "/week=" + job_run_week,
      job_type = "awstogcs",
      dl_source_folder = false,
      ow_dest_folder = false,
      access_key = "AKIAIMVJOLSKVH7BPFVQ",
      secret_key = "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",
    )

    def step_qc_file_check(job_run_year: String, job_run_week: String) = GCSSensorStep(
      name = "EtlJobPricingQc_Qc_Success_File_Check",
      bucket = props.bucket_name,
      prefix = props.qc_path_prefix + "/year=" + job_run_year + "/week=" + job_run_week,
      key = props.key_file,
      retry = 10,
      spaced = 1800.seconds
    )

    def step_raw_file_check(job_run_year: String, job_run_week: String) = GCSSensorStep(
      name = "EtlJobPricingQc_Raw_Success_File_Check",
      bucket = props.bucket_name,
      prefix = props.raw_path_prefix + "/year=" + job_run_year + "/week=" + job_run_week,
      key = props.key_file,
      retry = 10,
      spaced = 1800.seconds
    )

    def  pricing_weekly_ingestion(year:String,week:String) = DataprocSparkJobStep(
      name = "DataProc Job Submission for Pricing weekly Ingestion",
      job_name = "EtlJobPricing",
      props = Map("job_run_year" -> year, "job_run_week" -> week, "job_type" -> props.job_type),
      global_properties = Some(mint_global_properties)
    )

    val job: ZIO[LoggerResource, Throwable, Unit] = run_type match {
      case "Ingestion_Weekly" => {
          for {
            year <- year_calculation.execute()
            week <- week_calculation(year).execute()
            _ <- DataTransferStep1(year, week).execute()
            _ <- DataTransferStep2(year, week).execute()
            _ <- step_qc_file_check(year, week).execute()
            _ <- step_raw_file_check(year, week).execute()
            _ <- pricing_weekly_ingestion(year,week).execute()
          } yield ()
        }
    }
}
