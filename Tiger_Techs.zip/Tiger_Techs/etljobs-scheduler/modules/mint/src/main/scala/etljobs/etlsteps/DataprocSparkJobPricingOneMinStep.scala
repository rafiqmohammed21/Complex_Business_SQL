package etljobs.etlsteps

import etlflow.etlsteps.EtlStep
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobName.{EtlJobNamePricingOneMin => EJP}
import zio.Task

class DataprocSparkJobPricingOneMinStep(
                val name:String  ,
                val job_name: String,
                val props: Map[String,String],
                val conf: Option[GlobalProperties]
              )
  extends EtlStep[Unit,Unit] {



  final def process(in: =>Unit): Task[Unit] = {
    etl_logger.info("#"*100)
    etl_logger.info(s"Starting Job Submission for : $job_name")

    val etl_job =  etljobs.viewership.pricing_onemin.EtlJobPricingOneMin(EJP.getActualProperties(props),conf)
    etl_job.job_name = job_name.toString
    etl_job.execute()
  }

  override def getStepProperties(level: String): Map[String, String] = Map("query" -> "")
}


object DataprocSparkJobPricingOneMinStep {
  def apply(name:String,job_name: String,props: Map[String,String],conf: Option[GlobalProperties]): DataprocSparkJobPricingOneMinStep =
    new DataprocSparkJobPricingOneMinStep(name,job_name,props,conf)
}


