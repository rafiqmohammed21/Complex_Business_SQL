package udfs

import java.util.Calendar

import org.apache.spark.sql.functions._
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.functions.{regexp_replace, upper}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import util.{MasterJdbcConn, MintGlobalProperties}

trait Common extends MasterJdbcConn {

  val get_formatted_date_without_existing_format = (ColumnName:String,NewFormat:String) => {
    val result:String  = s"""  case when $ColumnName like '%-%-%' then from_unixtime(unix_timestamp($ColumnName, "MM-dd-yyyy"), "$NewFormat")  when date like '%/%/%' then from_unixtime(unix_timestamp(date, "MM/dd/yyyy"), "$NewFormat") end as $ColumnName  """
    result
  }

  val get_barc_year = (current_day : String ) => {
    val inputFormat = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val calendar_instance = Calendar.getInstance()
    calendar_instance.setTime(inputFormat.parse(current_day))

    var week = calendar_instance.get(Calendar.WEEK_OF_YEAR)
    val day = calendar_instance.get(Calendar.DAY_OF_WEEK)
    var year = calendar_instance.get(Calendar.YEAR)
    val month = calendar_instance.get(Calendar.MONTH)

    if (day == 7) week = week + 1
    if (week == 53 || (week == 1 && month == 11)) {
      week = 1
      year = year + 1
    }

    year.toString
  }

  val get_barc_week = (current_day : String ) => {
    val inputFormat = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val calendar_instance = Calendar.getInstance()
    calendar_instance.setTime(inputFormat.parse(current_day))

    var week = calendar_instance.get(Calendar.WEEK_OF_YEAR)
    val day = calendar_instance.get(Calendar.DAY_OF_WEEK)
    var year = calendar_instance.get(Calendar.YEAR)
    val month = calendar_instance.get(Calendar.MONTH)

    if (day == 7) week = week + 1
    if (week == 53 || (week == 1 && month == 11)) {
      week = 1
      year = year + 1
    }

    week.toString
  }

  val time_band_split = (air_time : String) => {
    if(air_time=="NULL" || air_time=="0" || air_time=="null" || air_time==""){
      "0000-0030"
    }
    else{
      val air_time_split = if(air_time.length==6) air_time.splitAt(2) else air_time.splitAt(1)
      val hours = if(air_time_split._1.length>1) air_time_split._1 else "0"+air_time_split._1
      var minutes = air_time_split._2.splitAt(2)._1
      if (minutes.splitAt(1)._1 == 0.toString)
        minutes = minutes.splitAt(1)._2
      else
        minutes
      val start_time_hours = hours
      if (minutes.toInt >= 0 && minutes.toInt < 30) {
        val start_time_start_minutes = "00"
        val start_time_end_minutes = "30"
        start_time_hours + "" + start_time_start_minutes + "-" + start_time_hours + "" + start_time_end_minutes
      }
      else {
        val start_time_start_minutes = "30"
        val start_time_end_minutes = "00"
        val end_hours=if((start_time_hours.toInt + 1).toString.length==2) (start_time_hours.toInt + 1) else "0"+(start_time_hours.toInt + 1)
        start_time_hours + "" + start_time_start_minutes + "-" + end_hours  + "" + start_time_end_minutes
      }}
  }

  def RemCharConvertToCap(col:Column,val_to_be_replaced:String,val_to_replace:String):Column={
    upper(regexp_replace(col,val_to_be_replaced,val_to_replace))
  }

  def FileNameFormatting(output_path:String,spark : SparkSession)(): Unit = {
    val path = s"$output_path/"
    val fs = FileSystem.get(new java.net.URI(path), spark.sparkContext.hadoopConfiguration)
    val fileName = fs.globStatus(new Path(path + "part*"))(0).getPath.getName
    fs.rename(new Path(path + fileName), new Path(path + "part-00000"))
  }


  def getJBDCConn(conf:MintGlobalProperties)= {

    var business_map: Map[String, Map[String, String]] = Map.empty
    var jdbc_map: Map[String, String] = Map.empty

    conf.business_jdbc_conn.split(',').map {
      conn => {
        val connection = conn.split('?')
        jdbc_map += "jdbc_url" -> (connection(1) + "/" + connection(2))
        jdbc_map += "jdbc_user" -> connection(3)
        jdbc_map += "jdbc_password" -> connection(4)
        business_map += connection(0) -> jdbc_map
      }
    }
    business_map
  }

  def getMasterListPath(business_type:String,master_list:String,master_list_path:String)={
    val list_names = master_list.split(',')
    var list_map:Map[String,String] = Map.empty
    list_names.map{
      name => list_map += name -> (master_list_path + '/' + name + '/' + business_type)
    }
    list_map
  }

  def MultipleWithColtoRetrofit(df_to_be_modified:DataFrame,col_to_be_modified:Seq[String]) ={
    col_to_be_modified.foldLeft(df_to_be_modified)((df_to_be_modified,c) =>
      df_to_be_modified.withColumn(s"tmp_$c",RemCharConvertToCap(col(c),"\\s","")))
  }

  def BusinessDataSegregation(SourceDF:DataFrame,BusinessType:String,filter_col:String,spark:SparkSession,conf:MintGlobalProperties)={
    val ReportSourceDF            = BifurcateSourceForBusiness(SourceDF, filter_col, conf.MM_channel_source_table,"channel_name",getJBDCConn(conf)(BusinessType), spark, conf)
    ReportSourceDF
  }

  def BifurcateSourceForBusiness(dl_source_df:DataFrame,dl_col_to_get_filtered:String,mint_app_table_to_filter:String,mint_app_col_to_filter:String,jdbc_conn:Map[String,String],spark:SparkSession,conf:MintGlobalProperties)={
    import spark.implicits._
    val values_to_filter   = FetchMasterData(mint_app_table_to_filter,where_clause="1=1",select_clause=Seq("*"),spark,conf)(jdbc_conn)
      .select(mint_app_col_to_filter).as[String].distinct.collect()
      .map(row=>row.replace(" ","").toUpperCase())
    dl_source_df.filter(upper(regexp_replace(col(dl_col_to_get_filtered)," ","")).isin(values_to_filter:_*))
  }

  val time_band_split_udf = udf(time_band_split)
  val get_barc_year_udf = udf(get_barc_year)
  val get_barc_week_udf = udf(get_barc_week)

}
