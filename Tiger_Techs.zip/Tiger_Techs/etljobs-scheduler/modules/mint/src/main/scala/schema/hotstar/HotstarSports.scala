package schema.hotstar

import java.sql.Date

object HotstarSports {


  case class HotstarDailyVideoViewersAWS (_col0:BigInt,
                                          _col1:String,
                                          _col2:BigInt,
                                          _col3:String,
                                          _col4:String,
                                          _col5:BigInt,
                                          _col6:BigInt,
                                          cd:Date
                                         )
  case class HotstarDailyVideoViewersBQ (tournament_id:Int,
                                         tournament_name:String,
                                         season_id:Int,
                                         season_name:String,
                                         game_name:String,
                                         daily_watch_time:Int,
                                         daily_video_viewers:Int,
                                         date:Date
                                        )

  case class HotstarMatchwiseVideoViewersAWS (_col0: BigInt,
                                              _col1: String,
                                              _col2: BigInt,
                                              _col3: String,
                                              _col4: String,
                                              _col5: String,
                                              _col6: String,
                                              _col7: String,
                                              _col8: String,
                                              cd: Date
                                             )

  case class HotstarMatchwiseVideoViewersBQ (tournament_id: Int,
                                             tournament_name: String,
                                             season_id: Int,
                                             season_name: String,
                                             game_name: String,
                                             match_id: Int,
                                             match_name: String,
                                             daily_watch_time: Int,
                                             daily_video_viewers: Int,
                                             date: Date
                                            )

  case class HotstarMatchwisePeakConcurrencyAWS (_col0:BigInt,
                                                 _col1:String,
                                                 _col2:BigInt,
                                                 _col3:String,
                                                 _col4:String,
                                                 _col5:BigInt,
                                                 _col6:String,
                                                 _col7:String,
                                                 _col8:BigInt,
                                                 cd:Date
                                                )

  case class HotstarMatchwisePeakConcurrencyBQ (tournament_id: Int,
                                                tournament_name: String,
                                                season_id: Int,
                                                season_name: String,
                                                game_name: String,
                                                match_id: Int,
                                                match_name: String,
                                                content_id: String,
                                                peak_concurrency: Int,
                                                date: Date
                                               )

  case class HotstarDailyCumViewerAws (_col0: BigInt,
                                       _col1: String,
                                       _col2: BigInt,
                                       _col3: String,
                                       _col4: String,
                                       _col5: BigInt,
                                       cd: Date
                                      )

  case class HotstarDailyCumViewerBQ (tournament_id: Int,
                                      tournament_name: String,
                                      season_id: Int,
                                      season_name: String,
                                      game_name: String,
                                      cumulative_video_viewers: Int,
                                      date: Date
                                     )

}
