//package etljobs.revenue
//
//import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
//import etlflow.bigquery.BigQueryManager
//import etlflow.etljobs.SequentialEtlJob
//import etlflow.spark.SparkManager
//import etlflow.utils.GlobalProperties
//import etljobs.EtlJobProps.{RevenueProps, RevenuePropsWithOutRefreshDates}
//import etljobs.bigquery.BigQueryManager
//import etljobs.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
//import etljobs.spark.{SparkManager, SparkUDF}
//import etljobs.utils.{GlobalProperties, JDBC, ORC}
//import etljobs.{EtlJob, EtlJobName, EtlProps, MyEtlJobProps}
//import org.apache.log4j.Logger
//import org.apache.spark.sql.{Dataset, Encoders, SaveMode}
//import schema.revenue.Revenue.{AirRawBq, AirRawPostgre}
//import udfs.Common
//import util.MintGlobalProperties
//
///** Object EtlJobOnAirCurrency gets executed when it is passed in RunEtlJob from LoadData object.
// * RunEtlJob executes both etlstep mentioned in list returned by it.
// *
// * In first etlstep it reads regional data from regional_input_path mentioned in input parameters
// * then enrich it using function enrichRegionalSpotRating and writes in ORC format at given output path
// * by partitioning it on date
// *
// * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery partitioned table by date
// */
//
//class EtlJobOnAirCurrency (
//                            val job_properties: MyEtlJobProps,
//                            val global_properties: Option[GlobalProperties]
//                          )
//  extends SequentialEtlJob with SparkManager with BigQueryManager  with Common {
//
//  val currency_etl_logger = Logger.getLogger(getClass.getName)
//  currency_etl_logger.info(s"Loaded ${getClass.getName}")
//
//  val props : RevenuePropsWithOutRefreshDates = job_properties.asInstanceOf[RevenuePropsWithOutRefreshDates]
//
//  def currency_transform()(dataset: Dataset[AirRawPostgre]) : Dataset[AirRawBq] = {
//
//    val bqMapping  = Encoders.product[AirRawBq]
//    val transformed_data=dataset.withColumnRenamed("name", "currency_name")
//      .withColumnRenamed("onair_currency_id", "currency_id")
//      .withColumnRenamed("onair_currency_date", "currency_date")
//      .withColumnRenamed("conversion_rate", "conversion")
//      .as[AirRawBq](bqMapping)
//
//   transformed_data
//
//  }
//
//  val query_alias  = s""" (SELECT onair_currency_id,name, onair_currency_date,conversion_rate FROM  ${props.job_input_path} ) t""".stripMargin
//
//
//  val step1 = SparkReadWriteStep[AirRawPostgre, AirRawBq](
//    name                    = "load_jdbc_currency_gcp",
//    input_location          = Seq(query_alias),
//    input_type              = JDBC(props.postgre_jdbc_url, props.postgre_user, props.postgre_password, props.postgre_driver),
//    transform_function      = Some(currency_transform()),
//    output_location         = props.job_output_path,
//    output_type             = ORC,
//    output_save_mode        = SaveMode.Overwrite
//
//  )(spark)
//
//  val step2 = BQLoadStep(
//    name                    =  "LoadRatingBQ",
//    input_location             =  Left(props.job_output_path + "/part*"),
//    input_type           =  ORC,
//    output_dataset     =  props.output_dataset,
//    output_table       =  props.output_table_name,
//    output_table_write_disposition = WriteDisposition.WRITE_TRUNCATE,
//    output_table_create_disposition      = CreateDisposition.CREATE_IF_NEEDED
//  )(bq)
//
//  val etl_step_list : List[EtlStep[Unit,Unit]] = List(step1,step2)
//
//}
//
//val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)
//
////deleteMode = Some(true),delete_file_list = Some(job_properties("job_inter_output_path")))