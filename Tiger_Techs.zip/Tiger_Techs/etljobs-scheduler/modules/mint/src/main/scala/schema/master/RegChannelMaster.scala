package schema.master

object RegChannelMaster {
  case class RegChannelMaster (
                                TYPE_OF_BEAM:String,
                                IS_ACTIVE:Boolean,
                                IS_SOUTH_CHANNEL:Boolean,
                                SUB_GENRE_NAME:String,
                                SOURCE:String,
                                GENRE_NAME:String,
                                CHANNEL_ID: Int,
                                CHANNEL_GROUP_NAME:String,
                                SHORT_NAME:String,
                                CHANNEL_NAME:String,
                                SUBSCRIPTION:String,
                                LANGUAGE:String,
                                NETWORK_NAME:String
                              )
}