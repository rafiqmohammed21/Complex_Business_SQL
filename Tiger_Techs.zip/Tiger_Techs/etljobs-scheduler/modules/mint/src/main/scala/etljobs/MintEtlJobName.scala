package etljobs

import etlflow.EtlJobName
import etljobs.MintEtlJobProps._
import util.Configs
import util.MintHelper._

sealed trait  MintEtlJobName[+EJP] extends EtlJobName[EJP]

object MintEtlJobName {

  val default_ratings_input_path = "data/movies/ratings_parquet/*"
  val default_ratings_input_path_csv = "data/movies/ratings/*"
  val default_output_dataset = "test"
  val my_job_package: String = getClass.getName

  case object EtlJobEntProvisions extends MintEtlJobName[RevenuePropsMintBqSdb] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsMintBqSdb = RevenuePropsMintBqSdb(
      job_properties.getOrElse("job_input_path",Configs.ent_provisions_var.get("job_input_path").get),
      job_properties.getOrElse("job_output_path",Configs.ent_provisions_var.get("job_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.ent_provisions_var.get("output_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.ent_provisions_var.get("output_table_name").get),
      true,
      "0 40 01 ? * *"
    )
  }


  case object EtlJobFunnel extends MintEtlJobName[RevenuePropsForRegOrEntWithRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEntWithRefreshDates = RevenuePropsForRegOrEntWithRefreshDates(
      job_properties.getOrElse("ent_job_input_path",Configs.funnel_ingestion_var.get("funnel_input_postgre_table_name").get),
      job_properties.getOrElse("ent_job_output_path",Configs.funnel_ingestion_var.get("funnel_output_path").get),
      job_properties.getOrElse("ent_output_dataset",Configs.funnel_ingestion_var.get("funnel_output_dataset").get),
      job_properties.getOrElse("ent_output_table_name",Configs.funnel_ingestion_var.get("funnel_output_table_name").get),
      job_properties.getOrElse("reg_job_input_path",Configs.funnel_ingestion_var.get("funnel_reg_input_postgre_table_name").get),
      job_properties.getOrElse("reg_job_output_path",Configs.funnel_ingestion_var.get("funnel_reg_output_path").get),
      job_properties.getOrElse("reg_output_dataset",Configs.funnel_ingestion_var.get("funnel_reg_output_dataset").get),
      job_properties.getOrElse("reg_output_table_name",Configs.funnel_ingestion_var.get("funnel_reg_output_table_name").get),
      job_properties.getOrElse("bu","all"),
      job_properties.getOrElse("refresh_dates","")
    )
  }

  case object EtlJobAdvertiserDetails extends MintEtlJobName[RevenueProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueProps = RevenueProps(
      job_properties.getOrElse("job_input_path",Configs.advertiser_ingestion_var.get("advertiser_postgre_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.advertiser_ingestion_var.get("advertiser_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.advertiser_ingestion_var.get("output_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.advertiser_ingestion_var.get("advertiser_output_table_name").get),
      job_properties.getOrElse("refresh_dates","")
    )
  }

  case object EtlJobDealInfo extends MintEtlJobName[RevenueProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueProps = RevenueProps(
      job_properties.getOrElse("job_input_path",Configs.deal_ingestion_var.get("deal_postgre_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.deal_ingestion_var.get("deal_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.deal_ingestion_var.get("deal_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.deal_ingestion_var.get("deal_output_table_name").get),
      job_properties.getOrElse("refresh_dates","")
    )
  }

  case object EtlJobSalesUnit extends MintEtlJobName[RevenueProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueProps = RevenueProps(
      job_properties.getOrElse("job_input_path",Configs.sale_unit_ingestion_var.get("sales_unit_postgre_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.sale_unit_ingestion_var.get("sales_unit_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.sale_unit_ingestion_var.get("sales_unit_output_path").get),
      job_properties.getOrElse("output_table_name",Configs.sale_unit_ingestion_var.get("sales_unit_output_table_name").get),
      job_properties.getOrElse("refresh_dates","")
    )
  }

  case object EtlJobRO extends MintEtlJobName[RevenueProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueProps = RevenueProps(
      job_properties.getOrElse("job_input_path",Configs.ro_ingestion_var.get("ro_postgre_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.ro_ingestion_var.get("ro_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.ro_ingestion_var.get("ro_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.ro_ingestion_var.get("ro_output_table_name").get),
      job_properties.getOrElse("refresh_dates","")
    )
  }

  case object EtlJobOnAirCurrency extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",""),
      job_properties.getOrElse("job_output_path",""),
      job_properties.getOrElse("output_dataset","test"),
      job_properties.getOrElse("output_table_name",""),
      true,
      ""
    )
  }

  case object EtlJobOnAirSPR extends MintEtlJobName[RevenueOnAirSprProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueOnAirSprProps = RevenueOnAirSprProps(
      job_properties.getOrElse("job_output_path",""),
      job_properties.getOrElse("output_dataset","test"),
      job_properties.getOrElse("output_table_name",""),
      job_properties.getOrElse("currency_input_data_path",""),
      job_properties.getOrElse("current_date",""),
      job_properties.getOrElse("spr_history_load_input_path",""),
      job_properties.getOrElse("champ_history_load_input_path",""),
    )
  }
  case object EtlJobDistributionRevenue extends MintEtlJobName[DistributionProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionProps = DistributionProps(
      job_properties.getOrElse("job_input_path",Configs.distribution_ingestion_var.get("revenue_oracle_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.distribution_ingestion_var.get("revenue_output_path").get),
      job_properties.getOrElse("output_file_name","part-0000"),
      job_properties.getOrElse("output_dataset",Configs.distribution_ingestion_var.get("revenue_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.distribution_ingestion_var.get("revenue_output_table_name").get),
      true,
      "0 00 02 ? * *"
    )
  }
  case object EtlJobDistributionSubscription extends MintEtlJobName[DistributionProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionProps = DistributionProps(
      job_properties.getOrElse("job_input_path",Configs.distribution_ingestion_var.get("subscription_oracle_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.distribution_ingestion_var.get("subscription_output_path").get),
      job_properties.getOrElse("output_file_name","part-00000"),
      job_properties.getOrElse("output_dataset",Configs.distribution_ingestion_var.get("subscription_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.distribution_ingestion_var.get("subscription_output_table_name").get),
      true,
      "0 00 02 ? * *"
    )
  }
  case object EtlJobDistributionIncentive extends MintEtlJobName[DistributionProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionProps = DistributionProps(
      job_properties.getOrElse("job_input_path",Configs.distribution_ingestion_var.get("incentive_oracle_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.distribution_ingestion_var.get("incentive_output_path").get),
      job_properties.getOrElse("output_file_name","part-00000"),
      job_properties.getOrElse("output_dataset",Configs.distribution_ingestion_var.get("incentive_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.distribution_ingestion_var.get("incentive_output_table_name").get),
      true,
      "0 00 02 ? * *"
    )
  }
  case object EtlJobDistributionActiveUniverse extends MintEtlJobName[DistributionChannelMasterProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionChannelMasterProps = DistributionChannelMasterProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("distribution_channel_state_master_input_path","")
      , job_properties.getOrElse("job_channel_state_output_path","")
      , job_properties.getOrElse("distribution_output_dataset","")
      , job_properties.getOrElse("distribution_output_table_name","")
      , job_properties.getOrElse("distribution_output_channel_state_master_table_name","")
      , job_properties.getOrElse("channel_master_input_path","")
      , job_properties.getOrElse("distribution_state_master_input_path","")
      , job_properties.getOrElse("output_dataset","")
    )
  }
  case object EtlJobDistributionChannelBouquet extends MintEtlJobName[DistributionProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionProps = DistributionProps(
      job_properties.getOrElse("job_input_path",Configs.distribution_ingestion_var.get("channel_bouquet_oracle_table_name").get),
      job_properties.getOrElse("job_output_path",Configs.distribution_ingestion_var.get("channel_bouquet_output_path").get),
      job_properties.getOrElse("output_file_name","part-00000"),
      job_properties.getOrElse("output_dataset",Configs.distribution_ingestion_var.get("channel_bouquet_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.distribution_ingestion_var.get("channel_bouquet_output_table_name").get),
      true,
      "0 00 02 ? * *"
    )
  }

  case object EtlJobHotstarEnt extends MintEtlJobName[HotstarEntProps] {
    def getActualProperties(job_properties: Map[String, String]): HotstarEntProps = HotstarEntProps(
      Some(job_properties.getOrElse("daily_channel_job_input_path",Configs.hotstar_ent_ingestion_var.get("daily_channel_input_path").get)),
      Some(job_properties.getOrElse("daily_show_job_input_path",Configs.hotstar_ent_ingestion_var.get("daily_show_input_path").get)),
      Some(job_properties.getOrElse("weekly_channel_job_input_path",Configs.hotstar_ent_ingestion_var.get("weekly_channel_input_path").get)),
      Some(job_properties.getOrElse("weekly_show_job_input_path",Configs.hotstar_ent_ingestion_var.get("weekly_show_input_path").get)),
      Some(job_properties.getOrElse("daily_channel_job_output_path",Configs.hotstar_ent_ingestion_var.get("daily_channel_output_path").get)),
      Some(job_properties.getOrElse("daily_show_job_output_path",Configs.hotstar_ent_ingestion_var.get("daily_show_output_path").get)),
      Some(job_properties.getOrElse("weekly_channel_job_output_path",Configs.hotstar_ent_ingestion_var.get("weekly_channel_output_path").get)),
      Some(job_properties.getOrElse("weekly_show_job_output_path",Configs.hotstar_ent_ingestion_var.get("weekly_show_output_path").get)),
      Some(job_properties.getOrElse("daily_channel_output_file_name",Configs.hotstar_ent_ingestion_var.get("daily_channel_output_file_name").get)),
      Some(job_properties.getOrElse("daily_show_output_file_name",Configs.hotstar_ent_ingestion_var.get("daily_show_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_channel_output_file_name",Configs.hotstar_ent_ingestion_var.get("weekly_channel_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_show_output_file_name",Configs.hotstar_ent_ingestion_var.get("weekly_show_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_channel_dataset",Configs.hotstar_ent_ingestion_var.get("weekly_channel_dataset").get)),
      Some(job_properties.getOrElse("daily_channel_output_table_name",Configs.hotstar_ent_ingestion_var.get("daily_channel_table_name").get)),
      Some(job_properties.getOrElse("daily_show_output_table_name",Configs.hotstar_ent_ingestion_var.get("daily_show_table_name").get)),
      Some(job_properties.getOrElse("weekly_channel_output_table_name",Configs.hotstar_ent_ingestion_var.get("weekly_channel_table_name").get)),
      Some(job_properties.getOrElse("weekly_show_output_table_name",Configs.hotstar_ent_ingestion_var.get("weekly_show_table_name").get)),
      true,
      "local",
      "00 20,40 4,5,6 ? * *"
    )
  }

  case object EtlJobHotstarEntSteps extends MintEtlJobName[HotstarEntProps] {
    def getActualProperties(job_properties: Map[String, String]): HotstarEntProps = HotstarEntProps(
      Some(job_properties.getOrElse("daily_channel_job_input_path",Configs.hotstar_ent_ingestion_var.get("daily_channel_input_path").get)),
      Some(job_properties.getOrElse("daily_show_job_input_path",Configs.hotstar_ent_ingestion_var.get("daily_show_input_path").get)),
      Some(job_properties.getOrElse("weekly_channel_job_input_path",Configs.hotstar_ent_ingestion_var.get("weekly_channel_input_path").get)),
      Some(job_properties.getOrElse("weekly_show_job_input_path",Configs.hotstar_ent_ingestion_var.get("weekly_show_input_path").get)),
      Some(job_properties.getOrElse("daily_channel_job_output_path",Configs.hotstar_ent_ingestion_var.get("daily_channel_output_path").get)),
      Some(job_properties.getOrElse("daily_show_job_output_path",Configs.hotstar_ent_ingestion_var.get("daily_show_output_path").get)),
      Some(job_properties.getOrElse("weekly_channel_job_output_path",Configs.hotstar_ent_ingestion_var.get("weekly_channel_output_path").get)),
      Some(job_properties.getOrElse("weekly_show_job_output_path",Configs.hotstar_ent_ingestion_var.get("weekly_show_output_path").get)),
      Some(job_properties.getOrElse("daily_channel_output_file_name",Configs.hotstar_ent_ingestion_var.get("daily_channel_output_file_name").get)),
      Some(job_properties.getOrElse("daily_show_output_file_name",Configs.hotstar_ent_ingestion_var.get("daily_show_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_channel_output_file_name",Configs.hotstar_ent_ingestion_var.get("weekly_channel_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_show_output_file_name",Configs.hotstar_ent_ingestion_var.get("weekly_show_output_file_name").get)),
      Some(job_properties.getOrElse("weekly_channel_dataset",Configs.hotstar_ent_ingestion_var.get("weekly_channel_dataset").get)),
      Some(job_properties.getOrElse("daily_channel_output_table_name",Configs.hotstar_ent_ingestion_var.get("daily_channel_table_name").get)),
      Some(job_properties.getOrElse("daily_show_output_table_name",Configs.hotstar_ent_ingestion_var.get("daily_show_table_name").get)),
      Some(job_properties.getOrElse("weekly_channel_output_table_name",Configs.hotstar_ent_ingestion_var.get("weekly_channel_table_name").get)),
      Some(job_properties.getOrElse("weekly_show_output_table_name",Configs.hotstar_ent_ingestion_var.get("weekly_show_table_name").get)),
      true,
      "local",
      ""
    )
  }

  case object EtlJobHotstarSports extends MintEtlJobName[HotstarSptProps] {
    def getActualProperties(job_properties: Map[String, String]): HotstarSptProps = HotstarSptProps(
      Some(job_properties.getOrElse("daily_cum_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_input_path").get))
      , Some(job_properties.getOrElse("daily_video_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_input_path").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_job_input_path",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_input_path").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_input_path").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_output_path").get))
      , Some(job_properties.getOrElse("daily_video_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_output_path").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_job_output_path",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_output_path").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_output_path").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("daily_video_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_output_file_name",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_dataset",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_dataset").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_table_name").get))
      , Some(job_properties.getOrElse("daily_video_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_table_name").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_output_table_name",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_table_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_table_name").get))
      , true,
      "local",
      "00 20,40 4,5,6 ? * *"
    )
  }

  case object EtlJobHotstarSportSteps extends MintEtlJobName[HotstarSptProps] {
    def getActualProperties(job_properties: Map[String, String]): HotstarSptProps = HotstarSptProps(
      Some(job_properties.getOrElse("daily_cum_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_input_path").get))
      , Some(job_properties.getOrElse("daily_video_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_input_path").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_job_input_path",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_input_path").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_job_input_path",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_input_path").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_output_path").get))
      , Some(job_properties.getOrElse("daily_video_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_output_path").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_job_output_path",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_output_path").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_job_output_path",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_output_path").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("daily_video_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_output_file_name",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_output_file_name",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_output_file_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_dataset",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_dataset").get))
      , Some(job_properties.getOrElse("daily_cum_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("daily_cum_viewers_table_name").get))
      , Some(job_properties.getOrElse("daily_video_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("daily_video_viewers_table_name").get))
      , Some(job_properties.getOrElse("match_wise_peak_concurrency_output_table_name",Configs.hotstar_sports_ingestion_var.get("match_wise_peak_concurrency_table_name").get))
      , Some(job_properties.getOrElse("match_wise_video_viewers_output_table_name",Configs.hotstar_sports_ingestion_var.get("match_wise_video_viewers_table_name").get))
      ,true,
      "local",
      ""
    )
  }

  case object EtlJobHotstarMasterMapping extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.hotstar_match_wise_viewership_view.get("match_wise_viewership_view_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.hotstar_match_wise_viewership_view.get("match_wise_viewership_view_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.hotstar_match_wise_viewership_view.get("match_wise_viewership_view_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.hotstar_match_wise_viewership_view.get("match_wise_viewership_view_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.hotstar_match_wise_viewership_view.get("match_wise_viewership_view_table_name").get)
      , true
      , job_properties.getOrElse("job_deploy_mode","local")

    )
  }
  case object EtlJobChannelMasterMapping extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.spr_channel_master_view.get("channel_master_view_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.spr_channel_master_view.get("channel_master_view_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.spr_channel_master_view.get("channel_master_view_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.spr_channel_master_view.get("channel_master_view_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.spr_channel_master_view.get("channel_master_view_table_name").get)
    )
  }
  case object EtlJobEntRegAdvertiserMaster extends MintEtlJobName[RevenuePropsForRegOrEnt] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEnt = RevenuePropsForRegOrEnt(
      job_properties.getOrElse("ent_job_input_path",Configs.ent_reg_adveriser_master.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.ent_reg_adveriser_master.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.ent_reg_adveriser_master.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.ent_reg_adveriser_master.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.ent_reg_adveriser_master.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.ent_reg_adveriser_master.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.ent_reg_adveriser_master.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.ent_reg_adveriser_master.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 10 01 ? * *"
    )
  }
  case object EtlJobEntRegChannelMaster extends MintEtlJobName[RevenuePropsForRegOrEnt] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEnt = RevenuePropsForRegOrEnt(
      job_properties.getOrElse("ent_job_input_path",Configs.ent_reg_channel_master.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.ent_reg_channel_master.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.ent_reg_channel_master.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.ent_reg_channel_master.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.ent_reg_channel_master.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.ent_reg_channel_master.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.ent_reg_channel_master.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.ent_reg_channel_master.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 10 01 ? * *"
    )
  }

  case object EtlJobEntRegMonthWiseAgency extends MintEtlJobName[RevenuePropsForRegOrEnt] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEnt = RevenuePropsForRegOrEnt(
      job_properties.getOrElse("ent_job_input_path",Configs.ent_reg_month_wise_agency.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.ent_reg_month_wise_agency.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.ent_reg_month_wise_agency.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.ent_reg_month_wise_agency.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.ent_reg_month_wise_agency.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.ent_reg_month_wise_agency.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.ent_reg_month_wise_agency.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.ent_reg_month_wise_agency.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 30 01 ? * *"
    )
  }
  case object EtlJobEntSpotRatings extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.ent_spot_ratings.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path", Configs.ent_spot_ratings.get("job_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("output_file_name",Configs.ent_spot_ratings.get("output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.ent_spot_ratings.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.ent_spot_ratings.get("output_table_name").get)
    )
  }

  case object EtlJobRegSpotRatings extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.reg_spot_ratings.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path", Configs.reg_spot_ratings.get("job_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("output_file_name",Configs.reg_spot_ratings.get("output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.reg_spot_ratings.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.reg_spot_ratings.get("output_table_name").get)
    )
  }
  case object EtlJobRegTb30 extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.reg_timeband_30.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.reg_timeband_30.get("job_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("output_file_name",Configs.reg_timeband_30.get("output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.reg_timeband_30.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.reg_timeband_30.get("output_table_name").get)
    )
  }

  case object EtlJobEntTb30 extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.ent_timeband_30.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.ent_timeband_30.get("job_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("output_file_name",Configs.ent_timeband_30.get("output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.ent_timeband_30.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.ent_timeband_30.get("output_table_name").get)
    )
  }

  case object EtlJobEntRegAdRevenueCPRP extends MintEtlJobName[RevenuePropsForRegOrEntWithSalesDB] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEntWithSalesDB = RevenuePropsForRegOrEntWithSalesDB(
      job_properties.getOrElse("ent_job_input_path",Configs.ent_reg_ad_revenue_cprp.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.ent_reg_ad_revenue_cprp.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.ent_reg_ad_revenue_cprp.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.ent_reg_ad_revenue_cprp.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.ent_reg_ad_revenue_cprp.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.ent_reg_ad_revenue_cprp.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.ent_reg_ad_revenue_cprp.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.ent_reg_ad_revenue_cprp.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 00 01 ? * *"
    )
  }
  case object EtlJobEntRegAdRevenueTarget extends MintEtlJobName[RevenuePropsForRegOrEntWithSalesDB] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEntWithSalesDB = RevenuePropsForRegOrEntWithSalesDB(
      job_properties.getOrElse("ent_job_input_path",Configs.ent_reg_ad_revenue_target.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.ent_reg_ad_revenue_target.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.ent_reg_ad_revenue_target.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.ent_reg_ad_revenue_target.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.ent_reg_ad_revenue_target.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.ent_reg_ad_revenue_target.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.ent_reg_ad_revenue_target.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.ent_reg_ad_revenue_target.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 00 01 ? * *"
    )
  }
  case object EtlJobEntSpotRatingsQc extends MintEtlJobName[QcJobProps] {
    def getActualProperties(job_properties: Map[String, String]): QcJobProps = QcJobProps(
      job_properties.getOrElse("job_type","qc_ingestion")
      , job_properties.getOrElse("job_input_path",Configs.ent_spot_rating_qc.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.ent_spot_rating_qc.get("job_output_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("qc_result_path", Configs.ent_spot_rating_qc.get("qc_result_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("debug","false")
      , job_properties.getOrElse("ingestion_output_path",Configs.ent_spot_rating_qc.get("ingestion_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")

    )
  }
  case object EtlJobRegSpotRatingsQc extends MintEtlJobName[QcJobProps] {
    def getActualProperties(job_properties: Map[String, String]): QcJobProps = QcJobProps(
      job_properties.getOrElse("job_type","qc_ingestion")
      , job_properties.getOrElse("job_input_path",Configs.reg_spot_rating_qc.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.reg_spot_rating_qc.get("job_output_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("qc_result_path", Configs.reg_spot_rating_qc.get("qc_result_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("debug","false")
      , job_properties.getOrElse("ingestion_output_path",Configs.reg_spot_rating_qc.get("ingestion_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")

    )
  }
  case object EtlJobRegTb30Qc extends MintEtlJobName[QcJobProps] {
    def getActualProperties(job_properties: Map[String, String]): QcJobProps = QcJobProps(
      job_properties.getOrElse("job_type","qc_ingestion")
      , job_properties.getOrElse("job_input_path",Configs.reg_timeband_30_qc.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.reg_timeband_30_qc.get("job_output_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("qc_result_path", Configs.reg_timeband_30_qc.get("qc_result_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("debug","false")
      , job_properties.getOrElse("ingestion_output_path",Configs.reg_timeband_30_qc.get("ingestion_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")

    )
  }
  case object EtlJobEntTb30Qc extends MintEtlJobName[QcJobProps] {
    def getActualProperties(job_properties: Map[String, String]): QcJobProps = QcJobProps(
      job_properties.getOrElse("job_type","qc_ingestion")
      , job_properties.getOrElse("job_input_path",Configs.ent_timeband_30_qc.get("job_input_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}/raw")
      , job_properties.getOrElse("job_output_path",Configs.ent_timeband_30_qc.get("job_output_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("qc_result_path", Configs.ent_timeband_30_qc.get("qc_result_path").get + s"year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")
      , job_properties.getOrElse("debug","false")
      , job_properties.getOrElse("ingestion_output_path",Configs.ent_timeband_30_qc.get("ingestion_output_path").get + s"/year=${get_current_month_week_year._1}/week=${get_current_month_week_year._3}")

    )
  }

  case object EtlJobPrismSportTournament extends MintEtlJobName[RevenueSportsPrismTournamentProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueSportsPrismTournamentProps = RevenueSportsPrismTournamentProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
      , job_properties.getOrElse("refresh_start_date","")
    )
  }
  case object EtlJobProgLogsSports extends MintEtlJobName[RevenueSportsProgLogsProps] {
    def getActualProperties(job_properties: Map[String, String]): RevenueSportsProgLogsProps = RevenueSportsProgLogsProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }
  case object EtlJobDistributionData extends MintEtlJobName[DistributionChannelMasterProps] {
    def getActualProperties(job_properties: Map[String, String]): DistributionChannelMasterProps = DistributionChannelMasterProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("distribution_channel_state_master_input_path","")
      , job_properties.getOrElse("job_channel_state_output_path","")
      , job_properties.getOrElse("distribution_output_dataset","test")
      , job_properties.getOrElse("distribution_output_table_name","")
      , job_properties.getOrElse("distribution_output_channel_state_master_table_name","")
      , job_properties.getOrElse("channel_master_input_path","")
      , job_properties.getOrElse("distribution_state_master_input_path","")
      , job_properties.getOrElse("output_dataset","test")
    )
  }
  case object EtlJobPricing extends MintEtlJobName[PricingJobProps] {

    def getActualProperties(job_properties: Map[String, String]): PricingJobProps = PricingJobProps(
      job_properties.getOrElse("job_type","weekly")
      , job_properties.getOrElse("job_run_year","NA")
      , job_properties.getOrElse("job_run_week","NA")
      , job_properties.getOrElse("job_output_dataset",Configs.pricing_ingestion_var.get("pricing_output_dataset").get)
      , job_properties.getOrElse("job_output_table_name",Configs.pricing_ingestion_var.get("pricing_output_table").get)
      , job_properties.getOrElse("bucket_name",Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get)
      , job_properties.getOrElse("raw_path_prefix","landingzone/pricing")
      , job_properties.getOrElse("qc_path_prefix","landingzone/pricing_qc")
      , job_properties.getOrElse("key_file","SUCCESS.txt")
      , true
      , ""
    )
  }

  case object EtlJobPricingGcsSensor extends MintEtlJobName[PricingJobProps] {

    def getActualProperties(job_properties: Map[String, String]): PricingJobProps = PricingJobProps(
      job_properties.getOrElse("job_type","weekly")
      , job_properties.getOrElse("job_run_year","NA")
      , job_properties.getOrElse("job_run_week","NA")
      , job_properties.getOrElse("job_output_dataset",Configs.pricing_ingestion_var.get("pricing_output_dataset").get)
      , job_properties.getOrElse("job_output_table_name",Configs.pricing_ingestion_var.get("pricing_output_table").get)
      , job_properties.getOrElse("bucket_name",Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get)
      , job_properties.getOrElse("raw_path_prefix","landingzone/pricing")
      , job_properties.getOrElse("qc_path_prefix","landingzone/pricing_qc")
      , job_properties.getOrElse("key_file","SUCCESS.txt")
      , true
      , "0 0 10 ? * 4"
      , job_properties.getOrElse("job_deploy_mode","local")
    )
  }


  case object EtlJobPricingNewTG extends MintEtlJobName[PricingJobProps] {

    def getActualProperties(job_properties: Map[String, String]): PricingJobProps = PricingJobProps(
      job_properties.getOrElse("job_type","weekly")
      , job_properties.getOrElse("job_run_year","NA")
      , job_properties.getOrElse("job_run_week","NA")
      , job_properties.getOrElse("job_output_dataset",Configs.pricing_ingestion_var.get("pricing_output_dataset").get)
      , job_properties.getOrElse("job_output_table_name",Configs.pricing_ingestion_var.get("pricing_output_table").get)
      , job_schedule = ""
    )
  }
  case object EtlJobNamePricingOneMin extends MintEtlJobName[PricingOneMinJobProps] {
    def getActualProperties(job_properties: Map[String, String]): PricingOneMinJobProps = PricingOneMinJobProps(
      job_properties.getOrElse("job_type","daily"),
      job_properties.getOrElse("job_run_year",""),
      job_properties.getOrElse("job_run_week","") ,
      job_properties.getOrElse("bucket_name",Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get),
      job_properties.getOrElse("path_prefix",Configs.pricing_1min_ingestion_var.get("pricing_1min_raw_path").get),
      job_properties.getOrElse("key_file","SUCCESS.txt"),
      true,
      "0 0 17 ? * *"
    )
  }

  case object  EtlJobNamePricingOneMinGcsSensor extends MintEtlJobName[PricingOneMinJobProps] {
    def getActualProperties(job_properties: Map[String, String]): PricingOneMinJobProps = PricingOneMinJobProps(
      job_properties.getOrElse("job_type","weekly"),
      job_properties.getOrElse("job_run_year",""),
      job_properties.getOrElse("job_run_week","") ,
      job_properties.getOrElse("bucket_name",Configs.pricing_ingestion_var.get("pricing_bucket_gcs").get),
      job_properties.getOrElse("path_prefix",Configs.pricing_1min_ingestion_var.get("pricing_1min_raw_path").get),
      job_properties.getOrElse("key_file","SUCCESS.txt"),
      true,
      "",
      job_properties.getOrElse("job_deploy_mode","local"),
    )
  }

  case object EtlJobDownload extends MintEtlJobName[DownloadJobProps] {
    def getActualProperties(job_properties: Map[String, String]): DownloadJobProps = DownloadJobProps(
      job_properties.getOrElse("module","spr")
      , job_properties.getOrElse("token","234_20200615-105816")
      , job_properties.getOrElse("business","entertainment")
    )
  }
  case object EtlJobWooqer extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.wooqer_ingestion.get("job_input_path").get),
      job_properties.getOrElse("job_output_path",Configs.wooqer_ingestion.get("job_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.wooqer_ingestion.get("output_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.wooqer_ingestion.get("output_table_name").get),
      true,
      "0 30 06 ? * *"
    )
  }
  case object EtlJobWooqerUniverse extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.wooqer_universe_ingestion.get("job_input_path").get),
      job_properties.getOrElse("job_output_path",Configs.wooqer_universe_ingestion.get("job_output_path").get),
      job_properties.getOrElse("output_dataset",Configs.wooqer_universe_ingestion.get("output_dataset").get),
      job_properties.getOrElse("output_table_name",Configs.wooqer_universe_ingestion.get("output_table_name").get),
      true,
      "0 30 06 ? * *"
    )
  }
  case object EtlJobSportsSeasonEvent extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }
  case object EtlJobSportsOnairTillBarcDate extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }
  case object EtlJobSportsOnairAfterBarcDate extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }

  case object EtlJobSportsViewershipMapping extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }

  case object EtlJobSportsBarcMonth extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }
  case object DataTransfer extends MintEtlJobName[DataTransferProps] {
    def getActualProperties(job_properties: Map[String, String]): DataTransferProps = DataTransferProps(
      job_properties.getOrElse("","")
      , job_properties.getOrElse("job_transfer_data_btw","")
      , job_properties.getOrElse("job_description","")
      , job_properties.getOrElse("job_source_bucket","")
      , job_properties.getOrElse("job_dest_bucket","")
      , job_properties.getOrElse("job_data_path_prefix","")
      , job_properties.getOrElse("job_dl_source_folder",false).asInstanceOf[Boolean]
      , job_properties.getOrElse("job_ow_dest_folder", true ).asInstanceOf[Boolean]
    )
  }


  case object EtlJobFactRevBQ extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.fact_revenue_bq.get("job_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.fact_revenue_bq.get("job_output_path").get)
      , job_properties.getOrElse("output_dataset",Configs.fact_revenue_bq.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.fact_revenue_bq.get("output_table_name").get)
      ,true
      ,""
    )
  }
  case object EtlJobFactViewBQ extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.fact_revenue_view_bq.get("job_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.fact_revenue_view_bq.get("job_output_path").get)
      , job_properties.getOrElse("output_dataset",Configs.fact_revenue_view_bq.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.fact_revenue_view_bq.get("output_table_name").get)
      , true
      , ""
    )
  }

  case object EtlJobRegAdRevenueDeployed extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","BQ_query")
      , job_properties.getOrElse("job_output_path","gs://star-dl-temp/ent_fact_viewership_from_etljob/dev_transformed")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","ent_fact_viewership")
      , true
      , ""

    )
  }

  case object EtlJobRegAdRevenueBudget extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""

    )
  }
  case object EtlJobFactRegSpot extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","sample_sales")
    )
  }
  case object EtlJobFactRegTB30 extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","part_0000.orc")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }
  case object EtlJobRefreshViewsPG extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","funnel_info:release_order_info:disney_deal_month_wise_info")
      , job_properties.getOrElse("job_output_path","dummy")
      , job_properties.getOrElse("output_file_name","dummy")
      , job_properties.getOrElse("output_dataset","dummy")
      , job_properties.getOrElse("output_table_name","dummy")
    )
  }


  case object EtlJobFactTablesV1 extends MintEtlJobName[RevSRAndSales] {
    def getActualProperties(job_properties: Map[String, String]): RevSRAndSales = RevSRAndSales(
      job_properties.getOrElse("rev_job_input_path",Configs.fact_revenue_v1.get("rev_job_input_path").get)
      , job_properties.getOrElse("rev_job_output_path",Configs.fact_revenue_v1.get("rev_job_output_path").get)
      , job_properties.getOrElse("rev_output_dataset",Configs.fact_revenue_v1.get("rev_output_dataset").get)
      , job_properties.getOrElse("rev_output_table_name",Configs.fact_revenue_v1.get("rev_output_table_name").get)
      , job_properties.getOrElse("sr_job_input_path",Configs.fact_revenue_v1.get("sr_job_input_path").get)
      , job_properties.getOrElse("sr_job_output_path",Configs.fact_revenue_v1.get("sr_job_output_path").get)
      , job_properties.getOrElse("sr_output_dataset",Configs.fact_revenue_v1.get("sr_output_dataset").get)
      , job_properties.getOrElse("sr_output_table_name",Configs.fact_revenue_v1.get("sr_output_table_name").get)
      , true
      , ""
    )
  }


  case object EtlJobDistManagementAllocation extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""

    )
  }
  case object EtlJobDistStatAllocation extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""

    )
  }
  case object EtlJobDistUnbilledDeferred extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""
    )
  }
  case object EtlJobDistIncentiveAccrued extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""

    )
  }
  case object EtlJobBarcImpactTaggings extends MintEtlJobName[RevenuePropsForRegOrEnt] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEnt = RevenuePropsForRegOrEnt(
      job_properties.getOrElse("ent_job_input_path",Configs.master_barc_impact_taggings.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.master_barc_impact_taggings.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.master_barc_impact_taggings.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.master_barc_impact_taggings.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.master_barc_impact_taggings.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.master_barc_impact_taggings.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.master_barc_impact_taggings.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.master_barc_impact_taggings.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 30 01 ? * *"
    )
  }
  case object EtlJobSportsFinanceRevenueMatchWise extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.finance_match_wise_var.get("finance_match_wise_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.finance_match_wise_var.get("finance_match_wise_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.finance_match_wise_var.get("finance_match_wise_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.finance_match_wise_var.get("finance_match_wise_output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.finance_match_wise_var.get("finance_match_wise_output_table_name").get)
    )
  }
  case object EtlJobSportsFinanceRevenueMonthWise extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.finance_month_wise_var.get("finance_month_wise_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.finance_month_wise_var.get("finance_month_wise_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.finance_month_wise_var.get("finance_month_wise_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.finance_month_wise_var.get("finance_month_wise_output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.finance_month_wise_var.get("finance_month_wise_output_table_name").get)
    )
  }
  case object EtlJobRevenueCalender extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.revenue_calender_var.get("revenue_calender_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.revenue_calender_var.get("revenue_calender_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.revenue_calender_var.get("revenue_calender_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.revenue_calender_var.get("revenue_calender_output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.revenue_calender_var.get("revenue_calender_output_table_name").get)
    )
  }
  case object EtlJobBarcWeekMonthToDate extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_input_path = job_properties.getOrElse("job_input_path",Configs.barc_week_month_date_var.get("barc_week_month_date_input_path").get)
      , job_output_path=  job_properties.getOrElse("job_output_path",Configs.barc_week_month_date_var.get("barc_week_month_date_output_path").get)
      , output_file_name = job_properties.getOrElse("output_file_name",Configs.barc_week_month_date_var.get("barc_week_month_date_output_file_name").get)
      , output_dataset = job_properties.getOrElse("output_dataset",Configs.barc_week_month_date_var.get("barc_week_month_date_output_dataset").get)
      , output_table_name= job_properties.getOrElse("output_table_name",Configs.barc_week_month_date_var.get("barc_week_month_date_output_table_name").get)
    )
  }

  case object EtlJobFactRevAdvertiserMappings extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path",Configs.sales_db_fact_revenue_advertiser_mappings_var.get("sales_db_fact_revenue_advertiser_mappings_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.sales_db_fact_revenue_advertiser_mappings_var.get("sales_db_fact_revenue_advertiser_mappings_output_path").get)
      , job_properties.getOrElse("output_file_name",Configs.sales_db_fact_revenue_advertiser_mappings_var.get("sales_db_fact_revenue_advertiser_mappings_output_file_name").get)
      , job_properties.getOrElse("output_dataset",Configs.sales_db_fact_revenue_advertiser_mappings_var.get("sales_db_fact_revenue_advertiser_mappings_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.sales_db_fact_revenue_advertiser_mappings_var.get("sales_db_fact_revenue_advertiser_mappings_table_name").get)
    )
  }
  case object EtlJobSprReg extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","fact_revenue_common")
      , job_properties.getOrElse("job_output_path","gs://star-dl-temp/ent_rev_fact_advertiser_mapping/dev_transformed")
      , job_properties.getOrElse("output_file_name","fact_rev_advertiser_mappings.csv")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","fact_revenue_advertiser_mappings")
    )
  }
  case object EtlJobRegChannelMaster extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""
    )
  }

  case object EtlJobRegAdvertiserMaster extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_dataset","")
      , job_properties.getOrElse("output_table_name","")
      , true
      , ""

    )
  }

  case object EtlJobOnairSalesUnitTaggings extends MintEtlJobName[RevenuePropsForRegOrEnt] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsForRegOrEnt = RevenuePropsForRegOrEnt(
      job_properties.getOrElse("ent_job_input_path",Configs.onair_sales_unit_taggigs.get("ent_job_input_path").get)
      , job_properties.getOrElse("ent_job_output_path",Configs.onair_sales_unit_taggigs.get("ent_job_output_path").get)
      , job_properties.getOrElse("ent_output_dataset",Configs.onair_sales_unit_taggigs.get("ent_output_dataset").get)
      , job_properties.getOrElse("ent_output_table_name",Configs.onair_sales_unit_taggigs.get("ent_output_table_name").get)
      , job_properties.getOrElse("reg_job_input_path",Configs.onair_sales_unit_taggigs.get("reg_job_input_path").get)
      , job_properties.getOrElse("reg_job_output_path",Configs.onair_sales_unit_taggigs.get("reg_job_output_path").get)
      , job_properties.getOrElse("reg_output_dataset",Configs.onair_sales_unit_taggigs.get("reg_output_dataset").get)
      , job_properties.getOrElse("reg_output_table_name",Configs.onair_sales_unit_taggigs.get("reg_output_table_name").get)
      , job_properties.getOrElse("bu","all")
      , true
      , "0 30 01 ? * *"
    )
  }


  case object EtlJobBIAdvertiserMaster extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.bi_advertiser_master.get("job_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.bi_advertiser_master.get("job_output_path").get)
      , job_properties.getOrElse("output_dataset",Configs.bi_advertiser_master.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.bi_advertiser_master.get("output_table_name").get)
      , true
      , ""
    )
  }

  case object EtlJobFactTablesCommon extends MintEtlJobName[RevSRAndSales] {
    def getActualProperties(job_properties: Map[String, String]): RevSRAndSales = RevSRAndSales(
      job_properties.getOrElse("rev_job_input_path",Configs.fact_revenue_table_common.get("rev_job_input_path").get)
      , job_properties.getOrElse("rev_job_output_path",Configs.fact_revenue_table_common.get("rev_job_output_path").get)
      , job_properties.getOrElse("rev_output_dataset",Configs.fact_revenue_table_common.get("rev_output_dataset").get)
      , job_properties.getOrElse("rev_output_table_name",Configs.fact_revenue_table_common.get("rev_output_table_name").get)
      , job_properties.getOrElse("sr_job_input_path",Configs.fact_revenue_table_common.get("sr_job_input_path").get)
      , job_properties.getOrElse("sr_job_output_path",Configs.fact_revenue_table_common.get("sr_job_output_path").get)
      , job_properties.getOrElse("sr_output_dataset",Configs.fact_revenue_table_common.get("sr_output_dataset").get)
      , job_properties.getOrElse("sr_output_table_name",Configs.fact_revenue_table_common.get("sr_output_table_name").get)
      , true
      , "0 30 17 ? * *"
    )
  }

  case object EtlJobDummy extends MintEtlJobName[CommonProps] {
    def getActualProperties(job_properties: Map[String, String]): CommonProps = CommonProps(
      job_properties.getOrElse("job_input_path","")
      , job_properties.getOrElse("job_output_path","")
      , job_properties.getOrElse("output_file_name","")
      , job_properties.getOrElse("output_dataset","test")
      , job_properties.getOrElse("output_table_name","")
    )
  }

  case object EtlJobDataTransfer extends MintEtlJobName[DataTransferProps] {

    def getActualProperties(job_properties: Map[String, String]): DataTransferProps = DataTransferProps(
    job_properties.getOrElse("job_transfer_required",""),
    job_properties.getOrElse("job_transfer_data_btw",""),
    job_properties.getOrElse("job_description",""),
    job_properties.getOrElse("job_source_bucket",""),
    job_properties.getOrElse("job_dest_bucket",""),
    job_properties.getOrElse("job_data_path_prefix",""),
    job_properties.getOrElse("job_dl_source_folder", false).asInstanceOf[Boolean],
    job_properties.getOrElse("job_ow_dest_folder", true).asInstanceOf[Boolean],
    )
  }

  case object EtlJobBIChannelMaster extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path",Configs.bi_channel_master.get("job_input_path").get)
      , job_properties.getOrElse("job_output_path",Configs.bi_channel_master.get("job_output_path").get)
      , job_properties.getOrElse("output_dataset",Configs.bi_channel_master.get("output_dataset").get)
      , job_properties.getOrElse("output_table_name",Configs.bi_channel_master.get("output_table_name").get)
      , true
      , ""
    )
  }

  case object EtlJobDistPackageTagMaster extends MintEtlJobName[RevenuePropsWithOutRefreshDates] {
    def getActualProperties(job_properties: Map[String, String]): RevenuePropsWithOutRefreshDates = RevenuePropsWithOutRefreshDates(
      job_properties.getOrElse("job_input_path", "")
      , job_properties.getOrElse("job_output_path", "")
      , job_properties.getOrElse("output_dataset", "")
      , job_properties.getOrElse("output_table_name", "")
      , true
      , ""
    )
  }
}
