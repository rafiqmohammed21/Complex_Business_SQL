package etljobs.master

import com.google.cloud.bigquery.JobInfo
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{GlobalProperties, JDBC, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.RevenuePropsForRegOrEnt
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SaveMode
import schema.master.ChannelMaster.ChannelMasterEnt
import util.MintGlobalProperties

/** Object EtlJobEntChannelMaster gets executed when it is passed in RunEtlJob from LoadData object.
 * RunEtlJob executes both etlstep mentioned in list returned by it.
 *
 * In first etlstep it reads advertiser's data from jdbc datasource mentioned in input parameters
 * and writes in ORC format at given output path
 *
 * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery table
 */

case class EtlJobEntRegChannelMaster(
                                      val job_properties: MintEtlJobProps,
                                      val global_properties: Option[GlobalProperties]
                               )
  extends  SequentialEtlJob with SparkUDF  with SparkManager {

  var output_date_paths : Seq[(String,String)] = Seq()
  Logger.getLogger("org").setLevel(Level.WARN)

  val props : RevenuePropsForRegOrEnt = job_properties.asInstanceOf[RevenuePropsForRegOrEnt]
  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]

  val query_alias =
    """ (SELECT source_name, channel_name, channel_group_name, genre, sub_genre[1] as sub_genre, type_of_beam, subscription, network, hour_type, part_of_day, from_day, to_day, start_time, end_time, channel_tgmarket[1] as channel_primary_tg, channel_tgmarket[1] as channel_secondary_tg, channel_tgmarket[1] as genre_tg, language  from channel_master_info) t """.stripMargin

  val query_alias_reg =
    """ (SELECT source_name, channel_name, channel_group_name, genre, sub_genre[1] as sub_genre, type_of_beam, subscription,
network,
case when hour_type is null and start_time is null then 'daypart' else hour_type end as hour_type,
case when hour_type is null and start_time is null then 'PT' else part_of_day end as part_of_day,
case when hour_type is null and start_time is null then 'mon' else  from_day end as from_day,
case when hour_type is null and start_time is null then 'sun' else to_day end as to_day,
case when hour_type is null and start_time is null then 200 else start_time end as start_time,
case when hour_type is null and start_time is null then 2600 else end_time end as end_time,
channel_tgmarket[1] as channel_primary_tg,
channel_tgmarket[1] as channel_secondary_tg, channel_tgmarket[1] as genre_tg, language  from channel_master_info) t """.stripMargin

  val step1 = SparkReadWriteStep[ChannelMasterEnt](
    name                    = "Load_Jdbc_ent_channel_master",
    input_location          = Seq(query_alias),
    input_type              = JDBC(mint_global_properties.ent_postgre_jdbc_url, mint_global_properties.ent_postgre_user, mint_global_properties.ent_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.ent_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step2 = BQLoadStep(
    name                    = "Load_Jdbc_ent_channel_master_BQ",
    input_location             = Left(props.ent_job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.ent_output_dataset,
    output_table       = props.ent_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )

  val step3 = SparkReadWriteStep[ChannelMasterEnt](
    name                    = "Load_Jdbc_reg_channel_master",
    input_location          = Seq(query_alias_reg),
    input_type              = JDBC(mint_global_properties.reg_postgre_jdbc_url, mint_global_properties.reg_postgre_user, mint_global_properties.reg_postgre_password, mint_global_properties.postgre_driver),
    output_location         = props.reg_job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
  )


  val step4 = BQLoadStep(
    name                    = "Load_Jdbc_reg_channel_master_BQ",
    input_location             = Left(props.reg_job_output_path + "/part*"),
    input_type           = ORC,
    output_dataset     = props.reg_output_dataset,
    output_table       = props.reg_output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )



  val etlStepList: List[EtlStep[Unit,Unit]] = {
    if (props.bu == "ent") EtlStepList(step1,step2)
    else if (props.bu == "reg") EtlStepList(step3,step4)
    else EtlStepList(step1,step2,step3,step4)
  }
}
