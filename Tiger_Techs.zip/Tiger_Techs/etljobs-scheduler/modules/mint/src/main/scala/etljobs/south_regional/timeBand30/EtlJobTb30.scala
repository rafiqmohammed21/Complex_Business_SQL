package etljobs.south_regional.timeBand30

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, BQQueryStep, EtlStep, SparkETLStep, SparkReadTransformWriteStep, SparkReadWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.regional.RegionalTimeBand30.{RegTimeBand30, RegTimeBand30Enriched}
import udfs.Common
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import scala.sys.process._

 /** Object EtlJobRegional gets executed when it is passed in RunEtlJob from LoadData object.
   * RunEtlJob executes both etlstep mentioned in list returned by it.
   *
   * In first etlstep it reads regional timeband 30 min data from regional_input_path mentioned in input parameters
   * then enrich it using function enrichRegionalTimeBand30 and writes in ORC format at given output path
   * by partitioning it on date
   *
   * In second etlstep it reads ORC data stored by step1 and writes it to BigQuery partitioned table by date
   */

case class EtlJobTb30(
                  val job_properties: MintEtlJobProps,
                  val global_properties: Option[GlobalProperties]
                )
   extends SequentialEtlJob  with  SparkUDF with Common  with SparkManager{

   var output_date_paths : (Seq[(String,String)],String,String) = (Seq(),"","")
   var start_date : String = ""
   var end_date : String = ""
  lazy val reg_logger = Logger.getLogger(getClass.getName)
   val sdf = new SimpleDateFormat("yyyyMMddHHmmssss")
   val curr_time = sdf.format(new Date)

   val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  /** Enriches RegTimeBand30 dataset by adding columns real_length_sec_sum	as 1800,
    * drop week_day and casting date to date type
    *
    * It also generates output paths partitioned by date_int for saving data in ORC format
    * @param spark spark session
    * @param dataset raw dataset which needs to be enriched
    * @return reg_tb30 enriched dataframe
    */
  def enrichRegionalTimeBand30(spark: SparkSession,dataset: Dataset[RegTimeBand30]) : Dataset[RegTimeBand30Enriched] = {

    import spark.implicits._
    val mapping  = Encoders.product[RegTimeBand30Enriched]
    val reg_tb30 = dataset //real_length_sec_sum row_num batch_id week_day date type
      .withColumn("real_length_sec_sum",lit(1800).cast(IntegerType))
      .drop("week_day")
      .withColumn("date" , get_formatted_date("date","MM/dd/yyyy","yyyy-MM-dd").cast(DateType))
      .withColumn("date_int" , get_formatted_date("date","yyyy-MM-dd","yyyyMMdd"))

    start_date = reg_tb30.selectExpr("min(date)").first().getDate(0).toString
    end_date = reg_tb30.selectExpr("max(date)").first().getDate(0).toString
    reg_logger.info(s"start_date is: $start_date  and end_date is $end_date")

    val seq = reg_tb30
      .select("date_int")
      .distinct()
      .as[String]
      .collect()
      .map((path)=> (props.job_output_path+"_"+curr_time + "/date_int=" + path + "/part*",path))
    output_date_paths = (seq, start_date, end_date)

    start_date = reg_tb30.selectExpr("min(date)").first().getDate(0).toString
    end_date = reg_tb30.selectExpr("max(date)").first().getDate(0).toString
    reg_logger.info(s"start_date is: $start_date  and end_date is $end_date")
    reg_logger.info("Output file paths will be: ")
    output_date_paths._1.foreach(path => reg_logger.info(path))
    reg_tb30.as[RegTimeBand30Enriched](mapping)

  }

   def deleteTransformFolder(spark:SparkSession,ip:Unit):Unit={
     val x= s"gsutil rm -r ${props.job_output_path}".!
   }


    var var_api_name = ""
    val regions_list :List[String]=List("bengali","kannada","malayalam","marathi","tamil","telugu")
    if( job_name == "EtlJobEntTb30" ) {
      var_api_name = "ent_time_band_30"
      reg_logger.info("Entertainment data input dirs are: ")
      reg_logger.info(props.job_input_path + "/gec")
    } else {
      var_api_name = "reg_time_band_30"
      reg_logger.info("Regional data input dirs are: ")
      regions_list.foreach(region=> reg_logger.info(props.job_input_path + "/" + region))
    }


   val step1 =  SparkETLStep[Unit,Unit](
     name="GCS_TRANSFORMED_FOLDER_CLEAN_UP",
     transform_function=deleteTransformFolder
   )

   val step_ent= SparkReadTransformWriteStep[RegTimeBand30, RegTimeBand30Enriched](
     name                    = "LoadEntSpotRatingORC",
     input_location          = Seq(props.job_input_path + "/gec"),
     input_type              = CSV("|",true),
     transform_function      = enrichRegionalTimeBand30,
     output_location         = props.job_output_path+"_"+curr_time,
     output_type             = ORC,
     output_partition_col    = Seq("date_int"),
     output_save_mode        = SaveMode.Overwrite,
     output_repartitioning   = true
   )


   val steps_reg = regions_list.map { region =>
     SparkReadTransformWriteStep[RegTimeBand30, RegTimeBand30Enriched](
       name = "LoadRegionalSpotRatingORC",
       input_location = Seq(props.job_input_path + "/" + region),
       input_type = CSV("|", true),
       transform_function = enrichRegionalTimeBand30,
       output_location         = props.job_output_path+"_"+curr_time,
       output_type = ORC,
       output_partition_col = Seq("date_int"),
       output_save_mode = SaveMode.Append,
       output_repartitioning = true
     )
   }


   val step2 = BQLoadStep(
     name = "LoadRegionalTimeBand30BQ",
     input_location = Right(output_date_paths._1),
     input_type = ORC,
     output_dataset = props.output_dataset,
     output_table = props.output_table_name,
     output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
     output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
   )

   def  getQueryAlias(sd:String, ed:String):String = {
     f""" CALL `mint-bi-reporting.${props.output_dataset}_reports.sp_ent_time_band_30_channel_tg`(date '${sd}', date '${ed}');""".stripMargin
   }

   val step3 = BQQueryStep(
     name                    = "Load_ent_tb30_channel_tg",
     query        = getQueryAlias(output_date_paths._2,output_date_paths._3)
   )

   def  getQueryAliasReg(sd:String, ed:String):String = {
     f""" CALL `mint-bi-reporting.${props.output_dataset}_reports.sp_reg_time_band_30_channel_tg`(date '${sd}', date '${ed}');""".stripMargin
   }
   val step3_reg = BQQueryStep(
     name         = "Load_reg_tb30_channel_tg",
     query        = getQueryAliasReg(output_date_paths._2,output_date_paths._3)
   )


   val etlStepList : List[EtlStep[Unit,Unit]] = {
     if(props.job_input_path.contains("entertainment"))
       EtlStepList(step1,step_ent, step2,step3)
     else
       EtlStepList(step1) ++ steps_reg ++ List(step2,step3_reg)
   }

}