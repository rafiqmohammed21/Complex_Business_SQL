package schema.master

import java.sql.Date

sealed trait Master
final case class BarcImpactTaggings(channel:String, description:String, date:Date, start_time:String, end_time:String, Tag:String, created_at:String, updated_at:String)
final case class ChannelSources(channel_id:String,channel_name:String) extends Master
final case class Channels(id:String,Name:String,channel_tgmarket:String) extends Master
final case class Advertisers(onair_id:String,name:String,txn_group_id:String,brand:String,region:String) extends Master
final case class AdvertiserGroups(id:String,Name:String,segment:String,advertiser_category_id:String) extends Master
final case class AdvertiserCategories(id:String,Name:String) extends Master
final case class Agencies(onair_id:String,txn_group_id:String) extends Master
final case class AgencyGroups(id:String,Name:String) extends Master
final case class Deals(onair_id:String,name:String,updated_at:String) extends Master
final case class ProposalBookingEntries(deal_id:String,proposal_id:String) extends Master
final case class Proposals(id:String,Name:String,currency_conversion_rate:String,primary_tgmkt_id:String,secondary_tgmkt_id:String) extends Master
final case class ProductRevenues(sales_unit_pool_id:String,proposal_id:String,channel_skew_weight:String,client_skew_weight:String) extends Master
final case class DefinitionRules(channel_id:String,hour_type:String,part_of_day:String) extends Master
final case class Locations(name:String,region:String) extends Master
final case class SalesUnits(onair_id:String,product_id:String) extends Master
final case class Products(id:String,impact_regular:String) extends Master
final case class TgMarkets(id:String,name:String) extends Master
final case class MonthWiseAgency(id: BigInt,
                                 year: Int,
                                 month: String,
                                 channel:String,
                                 advertiser:String,
                                 region:String,
                                 regular_impact:String,
                                 agency_subgroup:String,
                                 agency_group:String,
                                 attribute_name:String,
                                 created_at:String,
                                 updated_at:String
                                ) extends Master

final case class RegDatalakeAgencyMappings(advertiser: String,
                                           agency_group:String
                                ) extends Master

final case class MonthWiseAgencyBQ(id: BigInt,
                                   year: Int,
                                   month: Int,
                                   channel:String,
                                   advertiser:String,
                                   region:String,
                                   regular_impact:String,
                                   agency_subgroup:String,
                                   agency_group:String,
                                   attribute_name:String,
                                   created_at:String,
                                   updated_at:String
                                  ) extends Master

final case class OnairSalesUnitTaggings(id: BigInt,
                                        year: Int,
                                        month: String,
                                        channel: String,
                                        sales_unit: String,
                                        tag: String,
                                        created_at: String,
                                        updated_at: String
                                       ) extends Master
final case class OnairSalesUnitTaggingsBQ(id: BigInt,
                                          year: Int,
                                          month: Int,
                                          channel: String,
                                          sales_unit: String,
                                          tag: String,
                                          created_at: String,
                                          updated_at: String
                                         ) extends Master

