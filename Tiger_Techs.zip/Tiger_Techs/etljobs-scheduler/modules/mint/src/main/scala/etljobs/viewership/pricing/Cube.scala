package etljobs.viewership.pricing

import etlflow.spark.SparkUDF
import etljobs.MintEtlJobProps.PricingJobProps
import etljobs.viewership.pricing.Cube.{ent_adv_brand_date_paths, ent_pgm_date_paths, reg_adv_brand_date_paths, reg_pgm_date_paths}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType}
import org.apache.spark.sql.{DataFrame, Dataset, Encoders, SparkSession}
import schema.Format.{DIPricingAdvViewerShip, DIPricingPgmViewerShip, MMChannelSources, MMTGMarkets}
import schema.viewership.Pricing.{PricingAdvViewerShip, PricingPgmViewerShip, PricingRawDestination}
import udfs.Common
import util.{MasterJdbcConn, MintGlobalProperties}


class Cube(spark:SparkSession, props : PricingJobProps, conf: MintGlobalProperties, BusinessType:String, year_week_df: DataFrame) extends MasterJdbcConn with Common with SparkUDF {

  def GenerateSourceDataset(jdbc_conn:Map[String,String])(spark:SparkSession,dataset:Dataset[PricingRawDestination])= {

    val DataSetFilter= dataset.join(year_week_df,Seq("year","week"),"inner").cache()

    val MMChannelDF  = FetchMasterData(conf.MM_channel_source_table, where_clause = "upper(name)='BARC'", select_clause = MMChannelSources, spark, conf)(jdbc_conn).withColumn("Channel TMP", RemCharConvertToCap(col("channel_name"), " ", ""))
    val MMTGMarketDF = FetchMasterData(conf.MM_tg_markets_table, where_clause = "1=1", select_clause = MMTGMarkets, spark, conf)(jdbc_conn).toDF("tgmarket_id","tgmarket").withColumn("tgmarket TMP",RemCharConvertToCap(col("tgmarket")," ",""))
    val DataSet      = BusinessDataSegregation(DataSetFilter.asInstanceOf[DataFrame],BusinessType, "channel",spark,conf)
      .filter(col("ev_type").isin("Ad Break", "Commercial") && col("level").isin("Level 2","Level 4"))
      .withColumn("Channel TMP", RemCharConvertToCap(col("channel"), " ", ""))
      .withColumn("tgmarket TMP",RemCharConvertToCap(concat(col("target"),col("region"))," ",""))

    DataSet.join(MMChannelDF,Seq("Channel TMP"),"inner")
      .join(MMTGMarketDF,Seq("tgmarket TMP"),"inner")
      .withColumn("grp",col("length")*col("rat_percent"))
      .withColumn("tvt",col("length")*col("impressions_000"))
  }

  def GeneratePgmViewerShip(jdbc_conn:Map[String,String], paths:scala.collection.mutable.Seq[(String,String)])(spark:SparkSession,dataset:Dataset[PricingRawDestination])= {
    import spark.implicits._
    val encoder = Encoders.product[PricingPgmViewerShip]
    val Dataset = GenerateSourceDataset(jdbc_conn)(spark,dataset)
      .select(col("channel_id"),
        col("tgmarket_id").cast(IntegerType),
        col("tgmarket"),
        col("master_program"),
        col("timeband"),
        col("channel"),
        split(col("timeband"),"-")(0).cast(IntegerType),
        split(col("timeband"),"-")(1).cast(IntegerType),
        col("week") cast(IntegerType),
        col("date"),
        col("year") cast(IntegerType),
        col("level"),
        col("ev_type"),
        lower(date_format(col("date"),"E")),
        lit(1),
        col("length"),
        col("grp") cast(DecimalType(16,6)),
        col("rat_percent"),
        col("tvt") cast(DecimalType(16,6)),
        col("impressions_000")
      )
      .toDF(DIPricingPgmViewerShip:_*)

    val Dataset_Agg = Dataset
      .groupBy("channel_id",
      "tgmarket_id",
      "tgmarket",
      "master_program",
      "timeband",
      "channel",
      "start_time",
      "end_time",
      "week",
      "rating_date",
      "barc_year",
      "level",
      "ev_type",
      "dow")
      .sum("simple_count",
      "length",
      "grp",
      "rat_percent",
      "tvt",
      "impressions_000")
      .toDF(DIPricingPgmViewerShip:_*)
      .as[PricingPgmViewerShip](encoder)


    BusinessType match {
      case "entertainment" => ent_pgm_date_paths =  Dataset.select("rating_date")
        .distinct()
        .as[String]
        .collect()
        .map((path)=> (conf.DI_output_pricing_cubes_path + "/"  + BusinessType.substring(0,3) + "_pgm" + "/rating_date=" + path + "/part*",path))
      case "regional" => reg_pgm_date_paths  =  Dataset.select("rating_date")
        .distinct()
        .as[String]
        .collect()
        .map((path)=> (conf.DI_output_pricing_cubes_path + "/"  + BusinessType.substring(0,3) + "_pgm" + "/rating_date=" + path + "/part*",path))
    }

    Dataset_Agg
  }

  def GenerateAdvViewerShip(jdbc_conn:Map[String,String], paths:scala.collection.mutable.Seq[(String,String)])(spark:SparkSession,dataset:Dataset[PricingRawDestination])= {
    import spark.implicits._
    val encoder = Encoders.product[PricingAdvViewerShip]
    val Dataset = GenerateSourceDataset(jdbc_conn)(spark,dataset)
      .select(col("channel_id"),
        col("tgmarket_id").cast(IntegerType),
        col("tgmarket"),
        col("master_program"),
        col("advertiser"),
        col("region"),
        col("brand"),
        col("timeband"),
        col("channel"),
        split(col("timeband"),"-")(0).cast(IntegerType),
        split(col("timeband"),"-")(1).cast(IntegerType),
        col("week").cast(IntegerType),
        col("date"),
        col("year").cast(IntegerType),
        col("level"),
        col("ev_type"),
        lower(date_format(col("date"),"E")),
        lit(1),
        col("length"),
        col("grp") cast(DecimalType(16,6)),
        col("rat_percent"),
        col("tvt") cast(DecimalType(16,6)),
        col("impressions_000")
      )
      .toDF(DIPricingAdvViewerShip:_*)

    val Dataset_Agg = Dataset
      .groupBy("channel_id",
        "tgmarket_id",
        "tgmarket",
        "master_program",
        "advertiser",
        "region",
        "brand",
        "timeband",
        "channel",
        "start_time",
        "end_time",
        "week",
        "rating_date",
        "barc_year",
        "level",
        "ev_type",
        "dow")
      .sum("simple_count",
        "length",
        "grp",
        "rat_percent",
        "tvt",
        "impressions_000")
      .toDF(DIPricingAdvViewerShip:_*)
      .as[PricingAdvViewerShip](encoder)


    BusinessType match {
      case "entertainment" => ent_adv_brand_date_paths = Dataset.select("rating_date")
        .distinct()
        .as[String]
        .collect()
        .map((path)=> (conf.DI_output_pricing_cubes_path + "/"  + BusinessType.substring(0,3) + "_adv_brand" + "/rating_date=" + path + "/part*",path))
      case "regional" => reg_adv_brand_date_paths = Dataset.select("rating_date")
        .distinct()
        .as[String]
        .collect()
        .map((path)=> (conf.DI_output_pricing_cubes_path + "/"  + BusinessType.substring(0,3) + "_adv_brand" + "/rating_date=" + path + "/part*",path))
    }

    Dataset_Agg
  }
}

object Cube {

  var ent_adv_brand_date_paths,
      ent_pgm_date_paths,
      reg_adv_brand_date_paths,
      reg_pgm_date_paths : scala.collection.mutable.Seq[(String,String)] = scala.collection.mutable.Seq.empty[(String,String)]

  def apply(spark:SparkSession
            , props : PricingJobProps
            , conf: MintGlobalProperties
            , BusinessType:String
            , year_week_df: DataFrame): Cube
  = new Cube(spark, props, conf, BusinessType, year_week_df)
}
