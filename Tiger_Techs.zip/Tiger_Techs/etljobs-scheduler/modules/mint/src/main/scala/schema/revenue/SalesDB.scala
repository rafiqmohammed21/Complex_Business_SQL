package schema.revenue

import java.sql.{Date, Timestamp}

object SalesDB {

  //ent_provisions_data
  case class EntProvisionsEnrichedSchema(
                                          id: BigInt,
                                          channel_name: String,
                                          advertiser_group_name: String,
                                          agency_group_name: String,
                                          advertiser_category: String,
                                          region: String,
                                          ecs_group: String,
                                          deal_name: String,
                                          premier_slot: String,
                                          net_revenue: String,
                                          spot_length: String,
                                          spot_status: String,
                                          segment_classification: String,
                                          type_of: String,
                                          channel_group_name: String,
                                          genre: String,
                                          year_month: String,
                                          disney_calender_year: BigInt,
                                          disney_calender_month: String,
                                          created_at:Timestamp,
                                          updated_at:Timestamp,
                                          d_month:BigInt
                                        )
  case class EntProvisionsCommonSchema(
                                          disney_calender_year: BigInt,
                                          d_month:BigInt,
                                          channel_group_name:String,
                                          advertiser_group_name: String,
                                          type_of: String,
                                          region:String,
                                          advertiser_category: String,
                                          agency_group:String,
                                          net_revenue:BigInt
                                        )
  case class EntProvisionsSchema(
                                  id: BigInt,
                                  channel_name: String,
                                  advertiser_group_name: String,
                                  agency_group_name: String,
                                  advertiser_category: String,
                                  region: String,
                                  ecs_group: String,
                                  deal_name: String,
                                  premier_slot: String,
                                  net_revenue: String,
                                  spot_length: String,
                                  spot_status: String,
                                  segment_classification: String,
                                  type_of: String,
                                  channel_group_name: String,
                                  genre: String,
                                  year_month: String,
                                  disney_calender_year: BigInt,
                                  disney_calender_month: String,
                                  created_at:Timestamp,
                                  updated_at:Timestamp
                                )


  case class SprReg(
                     channel_name: String,
                     telecast_date: Date,
                     advertiser_name_master: String,
                     advertiser_id_master: BigInt
                   )

  case class Disney_fy_cal(
                            year:BigInt,
                            month:BigInt,
                            week:BigInt,
                            start_date:Date,
                            end_date:Date,
                            fin_year:String,
                            quarter:String
                          )

  case class FactRevSchema(
                            advertiser_group:String,
                            channel_name:String,date:Date,
                            agency:String,
                            sub_agency:String,
                            region:String,
                            impact_regular:String,
                            pt_npt:String,
                            ro_revenue:Double,
                            actual_revenue:Double,
                            booked_revenue:Double,
                            total_revenue:Double,
                            deals_revenue:Double,
                            projection_revenue:Double
                          )

  case class FactRevSpdSchema(
                               advertiser_group:String,
                               channel_name:String,
                               date:Date,
                               agency:String,
                               sub_agency:String,
                               advertiser_category: String,
                               region:String,
                               impact_regular:String,
                               pt_npt:String,
                               ro_revenue:Double,
                               actual_revenue:Double,
                               actual_fct:Double,
                               booked_revenue:Double,
                               booked_fct:Double,
                               total_revenue:Double,
                               total_fct:Double,
                               deals_revenue:Double,
                               projection_revenue:Double
                             )

  case class FactRevCommonSchema(
                                  advertiser_group:String,
                                  channel_name:String,
                                  date:Date,
                                  agency:String,
                                  sub_agency:String,
                                  advertiser_category: String,
                                  region:String,
                                  impact_regular:String,
                                  pt_npt:String,
                                  ro_revenue:Double,
                                  actual_revenue:Double,
                                  actual_fct:Double,
                                  booked_revenue:Double,
                                  booked_fct:Double,
                                  total_revenue:Double,
                                  total_fct:Double,
                                  deals_revenue:Double,
                                  projection_revenue:Double,
                                  d_year:BigInt,
                                  d_month:BigInt,
                                  d_fin_year:String
                                )

  case class FactViewSchema (
                              channel_name:String,
                              channel_def_name:String,
                              advertiser_group:String,
                              date:Date,
                              region:String,
                              pt_npt:String,
                              impact_regular:String,
                              agency:String,
                              sub_agency:String,
                              genre:String,
                              sub_genre:String,
                              ad_grp:Double,
                              genre_grp:Double,
                              market_share:Double
                            )
  case class FactViewSpdSchema (
                                 channel_name:String,
                                 channel_def_name:String,
                                 advertiser_group:String,
                                 date:Date,
                                 region:String,
                                 pt_npt:String,
                                 impact_regular:String,
                                 agency:String,
                                 sub_agency:String,
                                 advertiser_category: String,
                                 genre:String,
                                 sub_genre:String,
                                 ad_grp:Double,
                                 genre_grp:Double,
                                 market_share:Double
                               )
  case class FactViewCommonSchema (
                                    channel_name:String,
                                    channel_def_name:String,
                                    advertiser_group:String,
                                    date:Date,
                                    region:String,
                                    pt_npt:String,
                                    impact_regular:String,
                                    agency:String,
                                    sub_agency:String,
                                    advertiser_category: String,
                                    genre:String,
                                    sub_genre:String,
                                    ad_grp:Double,
                                    genre_grp:Double,
                                    market_share:Double
                                  )

  case class FactRegSpotSchema (
                                 row_num:Int,
                                 target:String,
                                 region:String,
                                 sector:String,
                                 category:String,
                                 brand:String,
                                 advertiser:String,
                                 advertiser_group:String,
                                 master_programme:String,
                                 no:String,
                                 to:Int,
                                 position:String,
                                 level:String,
                                 event_type:String,
                                 promo_type:String,
                                 promo_category:String,
                                 promo_sponsor_name:String,
                                 promo_programme_name:String,
                                 pib:String,
                                 tib:String,
                                 pp_start_time:String,
                                 cp_start_time:String,
                                 channel:String,
                                 start_time_av_tm:String,
                                 end_time_av_tm:String,
                                 break_code:String,
                                 date:Date,
                                 week:Int,
                                 time_band:String,
                                 programme_genre:String,
                                 programme_theme:String,
                                 duration:Int,
                                 ratings:Double,
                                 impressions:Double,
                                 target_av:Double,
                                 year:Int,
                                 timeband_start_time:String,
                                 timeband_end_time:String,
                                 barc_year:String,
                                 channel_name:String,
                                 advertiser_name:String,
                                 genre_name:String,
                                 sub_genre_name:String,
                                 network_name:String,
                                 is_active:Boolean,
                                 subscription:String,
                                 short_name:String,
                                 is_south_channel:Boolean,
                                 language:String,
                                 type_of_beam:String,
                                 agency_name:String,
                                 advertiser_category:String,
                                 tamil_region:String,
                                 telugu_region:String,
                                 malayalam_region:String,
                                 kannada_region:String,
                                 marathi_region:String,
                                 bengali_region:String,
                                 grp:Double
                               )

  case class FactRegTB30Schema (
                                 region:String,
                                 target:String,
                                 channel:String,
                                 date:Date,
                                 week:Int,
                                 year:Int,
                                 time_band:String,
                                 start_time:String,
                                 end_time:String,
                                 ratings:Double,
                                 impressions:Double,
                                 target_audience:Double,
                                 real_length_sec_sum:Int,
                                 CHANNEL_ID:Int,
                                 CHANNEL_GROUP_NAME:String,
                                 GENRE_NAME:String,
                                 SUB_GENRE_NAME:String,
                                 NETWORK_NAME:String,
                                 IS_ACTIVE:Boolean,
                                 SUBSCRIPTION:String,
                                 SHORT_NAME:String,
                                 IS_SOUTH_CHANNEL:Boolean,
                                 LANGUAGE:String,
                                 TYPE_OF_BEAM:String
                               )

  case class FactRevAdvertiserMappingSchema(
                                             d_year:BigInt,
                                             d_month:BigInt,
                                             d_fin_year:String,
                                             time_slot:String,
                                             program_type:String,
                                             advertiser_group:String,
                                             region:String,
                                             channel_name:String
                                           )

}