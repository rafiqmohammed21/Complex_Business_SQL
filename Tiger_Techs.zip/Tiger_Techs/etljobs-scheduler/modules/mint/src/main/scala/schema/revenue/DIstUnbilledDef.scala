package schema.revenue

object DIstUnbilledDef {

  case class DistUnbilledDeferred (
                                       customer_nbr:String,
                                       revenue_category:String,
                                       month:Int,
                                       year:Int,
                                       revenue:Float
                                      )

}
