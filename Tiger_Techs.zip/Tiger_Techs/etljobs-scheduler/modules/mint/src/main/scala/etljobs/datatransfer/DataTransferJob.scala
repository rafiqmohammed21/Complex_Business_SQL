package etljobs.datatransfer

import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.EtlStep
import etlflow.spark.SparkUDF
import etlflow.utils.GlobalProperties
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.DataTransferProps
import udfs.Common
import util.MintGlobalProperties

case class DataTransferJob (
                             val job_properties:MintEtlJobProps,
                             val global_properties: Option[GlobalProperties]
                           )
  extends  SequentialEtlJob with SparkUDF with Common {

  val mint_global_properties = global_properties.get.asInstanceOf[MintGlobalProperties]
  val props : DataTransferProps = job_properties.asInstanceOf[DataTransferProps]

  val step1 = DataTransferStep(
    name = s"DataTransfer For ${props.job_transfer_required}",
    job_description = props.job_description,
    source_bucket = props.job_source_bucket,
    dest_bucket = props.job_dest_bucket,
    prefix = props.job_data_path_prefix,
    job_type = props.job_transfer_data_btw,
    dl_source_folder = props.job_dl_source_folder,
    ow_dest_folder = props.job_ow_dest_folder,
    access_key = "AKIAIMVJOLSKVH7BPFVQ",
    secret_key = "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",
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1)
}