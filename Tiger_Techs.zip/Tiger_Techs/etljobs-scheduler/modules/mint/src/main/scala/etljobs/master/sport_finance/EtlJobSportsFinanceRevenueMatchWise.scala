package etljobs.master.sport_finance

import com.google.cloud.bigquery.JobInfo
import com.google.cloud.bigquery.JobInfo.{CreateDisposition, WriteDisposition}
import etlflow.EtlStepList
import etlflow.etljobs.SequentialEtlJob
import etlflow.etlsteps.{BQLoadStep, EtlStep, SparkReadTransformWriteStep}
import etlflow.spark.{SparkManager, SparkUDF}
import etlflow.utils.{CSV, GlobalProperties, ORC}
import etljobs.MintEtlJobProps
import etljobs.MintEtlJobProps.CommonProps
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{Dataset, Encoders, SaveMode, SparkSession}
import schema.sport_finance.SportsFinance.{SportsFinanceRevenueMatchWiseBQ, SportsFinanceRevenueMatchWiseGCP}
import org.apache.spark.sql.functions._ // for `when`


case class EtlJobSportsFinanceRevenueMatchWise(
                                                val job_properties: MintEtlJobProps,
                                                val global_properties: Option[GlobalProperties]
                                )
  extends  SequentialEtlJob with SparkUDF with SparkManager {

  val props : CommonProps = job_properties.asInstanceOf[CommonProps]

  def matchWiseTransform(props:CommonProps)(spark: SparkSession,dataset: Dataset[SportsFinanceRevenueMatchWiseGCP]) : Dataset[SportsFinanceRevenueMatchWiseBQ]={

    val transformed_dataset=dataset
      .withColumn("spot_tag_temp",when(dataset("spot_tag") ===1, true).otherwise(false))
      .withColumn("league_temp",when(dataset("league") ==="Yes", true).otherwise(false))
      .drop("spot_tag","league")
      .withColumnRenamed("spot_tag_temp","spot_tag")
      .withColumnRenamed("league_temp","league")
      .withColumn("spot_tag",col("spot_tag").cast(org.apache.spark.sql.types.BooleanType))
      .withColumn("league",col("league").cast(org.apache.spark.sql.types.BooleanType))

    transformed_dataset.show(10)
    transformed_dataset.printSchema()
    val mapping = Encoders.product[SportsFinanceRevenueMatchWiseBQ]
    transformed_dataset.as[SportsFinanceRevenueMatchWiseBQ](mapping)
  }

  val step1 = SparkReadTransformWriteStep[SportsFinanceRevenueMatchWiseGCP, SportsFinanceRevenueMatchWiseBQ](
    name                    = "load_sports_finance_match_wise_GCP",
    input_location          = Seq(props.job_input_path),
    input_type              = CSV(",",true),
    transform_function      = matchWiseTransform( props),
    output_location         = props.job_output_path,
    output_type             = ORC,
    output_save_mode        = SaveMode.Overwrite,
    output_filename         = Some(props.output_file_name),
    output_repartitioning   = true,
    output_repartitioning_num = 1,
  )


  val step2 = BQLoadStep[SportsFinanceRevenueMatchWiseBQ](
    name                           = "load_sports_finance_match_wise_BQ",
    input_location                 = Left(props.job_output_path + "/" + props.output_file_name),
    input_type                     = ORC,
    output_dataset                 = props.output_dataset,
    output_table                   = props.output_table_name,
    output_write_disposition     = JobInfo.WriteDisposition.WRITE_TRUNCATE,
    output_create_disposition    = JobInfo.CreateDisposition.CREATE_IF_NEEDED
  )


  val etlStepList: List[EtlStep[Unit,Unit]] = EtlStepList(step1,step2)
}
