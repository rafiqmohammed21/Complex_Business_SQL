package util

import java.text.SimpleDateFormat
import java.util.Date

import io.circe.parser.parse
import io.circe.{HCursor, Json}
import org.slf4j.{Logger, LoggerFactory}
import scalaj.http.{Http, HttpOptions, HttpResponse}

import scala.util.control.Breaks._
case class kylinCubeDetail(
                            name: String,
                            segments: String,
                        )

case class kylinHttpInfo(
                            uuid: String,
                          )
case class Form(firstName: String, lastName: String, age: Int, email: Option[String])


object KylinHelper extends App {
  val logger: Logger = LoggerFactory.getLogger(getClass.getName)

  var date_list :List[(Date,Date)] = List.empty
  def convertStringToDate(s: String): Date = {
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
    dateFormat.parse(s)
  }

  def append_date_list(start_date:Date,end_date:Date): Unit ={
      date_list:+((date_list,end_date))
  }

    """
    Function to return cube name for respective module and business type

    :param moduleName: moduleName can be barc_daily, posteval_barc, spr_daily, posteval_spr
    :param business_type: business_type can be regional/entertainment

    :return: name of the kylin cube
    """

  def getKylinCubeName(moduleName:String, business_type:String) :String = {
    val businnes_type_reg = Configs.common_variables.get("business").get.split(",")(1).replaceAll("'","").replaceAll("]","").substring(0,3)
    val businnes_type_ent = Configs.common_variables.get("business").get.split(",")(0).replaceAll("'","").replaceAll("\\[","").substring(0,3)
    var cubeName = ""
    if(business_type.equalsIgnoreCase(businnes_type_reg)){
        cubeName = moduleName match {
          case "pricing_pgm" => Configs.kylin_var.get("reg_pricing_pgm").get
          case "pricing_adv_brand" => Configs.kylin_var.get("reg_pricing_adv_brand").get
          case _ => "Invalid module name"
        }
    }else if(business_type.equalsIgnoreCase(businnes_type_ent)){
        cubeName = moduleName match {
          case "pricing_pgm" => Configs.kylin_var.get("ent_pricing_pgm").get
          case "pricing_adv_brand" => Configs.kylin_var.get("ent_pricing_adv_brand").get
          case _ => "Invalid module name"
        }
    }
    cubeName
  }

  """
    Function to fetch the list of segments from given cube name in Kylin

    :param cubeName: kylin cube name

    :return: list of segments in ascending order
    """
  def getSegments(cubeName:String): List[String] ={
    val segment_list:List[String] = List.empty
    logger.info("-" * 50)

    val request = Http("https://devkylinjob.startv.com/kylin/api" + "/cubes/" )
      .timeout(connTimeoutMs = 10000, readTimeoutMs = 50000)
      .param("projectName",Configs.kylin_var.get("kylin_project_name").get)
      .param("cubeName","reg_pricing_pgm")
      .param("offset","0")
      .param("limit","0")
      .header("content-type","application/json")
      .header("Authorization","Basic QURNSU46S1lMSU4=")
      .option(HttpOptions.allowUnsafeSSL)

    val response = request.asString
    println("response : " + response.body)
    List.empty
  }


  """
    Function that returns the index of the segment where the given date lies

    :param cubeName: Kylin cubeName
    :param inputDate: date for which segment index is required

    :return: index of segment where the date lies
    """

  def getSegmentIndexForDate(cubeName:String,date:String): Int ={
    val segment_list = getSegments(cubeName)
    var segment_index = segment_list.length
    for( index  <- 0 until segment_list.length){
      val start_date = convertStringToDate(segment_list(index).split(",")(0).stripMargin)
      val end_date = convertStringToDate(segment_list(index).split(",")(1).stripMargin)
      val for_date = convertStringToDate(date)
      if(for_date.before(end_date)){
        segment_index = index
        break
      }
    }
    segment_index
  }
  """
    Function that returns the list of segments in a cube between given start and end dates

    :param cubeName: Kylin cube name
    :param startDate: start date from which the segments need to be fetched
    :param endDate: end date till which the segments need to be fetched

    :return: list of segments between mentioned start and end date
    """
  def getSegmentsBetweenDate(cubeName:String, startDate:String,endDate:String) :List[String] = {
    val segment_list = getSegments(cubeName)
    val start_index = getSegmentIndexForDate(cubeName, startDate)
    val end_index = getSegmentIndexForDate(cubeName, endDate)
    segment_list.drop(start_index).dropRight(end_index+1)
  }


  def cube_segments_refresh(moduleName:String, business_type:String, from_date:String, to_date:String) ={
    val cubeName = getKylinCubeName(moduleName, business_type)
    val segments = getSegmentsBetweenDate(cubeName, from_date, to_date).sortWith(_ < _)
    if(segments.length > 0){
        for(segment <- segments){
          val segment_start_date = convertStringToDate(segment.split(",")(0))
          val segment_end_date = convertStringToDate(segment.split(",")(1))
          append_date_list(segment_start_date, segment_end_date)

        }
    }else{
      val start_date = convertStringToDate(from_date)
      val end_date = convertStringToDate(to_date)
      append_date_list(start_date, end_date)
    }
    cube_segments_build(moduleName, business_type)
  }

    """
    Function that that is commonly called by spr and barc modules to build the segments being calculated

    :param moduleName: moduleName can be barc_daily, posteval_barc, spr_daily, posteval_spr
    :param business_type: business_type can be regional/entertainment
    """

  def convert_date_to_millisecs(start_date:Date, end_date:Date)= {
    (start_date,end_date)
  }

  """
    Function submits request for Kylin using REST API call

    :param url: kylin cube url
    :param data: information regarding cube and segments getting built
    :param headers: required headers for authorization

    :return: response from REST API
  """
  def build_kylin_cube(url:String, data:String): HttpResponse[String] = {

    logger.info("URL : " + url)
    val header = Configs.kylin_var.get("Authorization").get

    val request = Http(url)
      .timeout(connTimeoutMs = 10000, readTimeoutMs = 50000)
      .postData(data)
      .header("content-type","application/json")
      .header("Authorization",header)

    logger.info("-" * 50)
    val response = request.asString
    logger.info("-" * 50)
    response
  }

  """
    Function that calls build_cube to submit request for cube build and calls check_build_progress to poll for the completion

    :param cubeName: name of the kylin cube
    :param headers: headers required for kylin authorization
    :param start_time: start_time in millisecond for segment to be built
    :param end_time: end_time in millisecond for segment to be built
    :param buildType: build_type can either be BUILD/REFRESH
  """

  def build_cube(cubeName:String, start_time:Date, end_time:Date, buildType:String) ={

    val url = Configs.kylin_var.get("kylin_url").get + "/cubes/" + cubeName + "/build"
    val data =
      s"""
         |{
         | "startTime" : $start_time,
         | "endTime" : $end_time,
         | "buildType" : $buildType
         |}""".stripMargin

    val response = build_kylin_cube(url,data)
    val parsed = parse(response.body).getOrElse(Json.Null)
    val cursor: HCursor = parsed.hcursor
    val op   = cursor.get[Int]("uuid").toOption

  }

  def cube_segments_build(moduleName:String, business_type:String)={
    val cubeName = getKylinCubeName(moduleName, business_type)
    for(dates <- date_list){
      val start_date = dates._1
      val end_date = dates._2
      val (start_time, end_time) = convert_date_to_millisecs(start_date, end_date)
      logger.info("start_time : " + start_time)
      logger.info("end_time : " + end_time)
      build_cube(cubeName, start_time, end_time, "BUILD")
    }
  }

  getSegments("reg_pricing_pgm")
}
