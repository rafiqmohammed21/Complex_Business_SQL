package etljobs.datatransfer

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Calendar

trait UtilityFunctions {

  def currentDateTime()= {
    val date = new Date(System.currentTimeMillis())
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val stf = new SimpleDateFormat("HH:mm:ss")
    val cal = Calendar.getInstance()
    cal.setTimeInMillis(date.getTime());
    cal.add(Calendar.SECOND,3)
    (sdf.format(date),stf.format(cal.getTime))
  }
}



