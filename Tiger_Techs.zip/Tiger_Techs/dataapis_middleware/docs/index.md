---
layout: home
title:  "Home"
section: "home"
technologies:
 - first: ["Scala", "sbt-microsites plugin is completely written in Scala"]
 - second: ["Spark", "sbt-microsites plugin uses SBT and other sbt plugins to generate microsites easily"]
 - third: ["Caliban Graphql", "Jekyll allows for the transformation of plain text into static websites and blogs."]
 - fourth: ["Zio", "Jekyll allows for the transformation of plain text into static websites and blogs."]
 - fifth: ["Doobie", "Jekyll allows for the transformation of plain text into static websites and blogs."]
---

[![Build Status](https://travis-ci.org/jpzk/mockedstreams.svg?branch=master)](https://travis-ci.org/jpzk/mockedstreams)   [![Codacy Badge](https://api.codacy.com/project/badge/Grade/8abac3d072e54fa3a13dc3da04754c7b)](https://www.codacy.com/app/jpzk/mockedstreams?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=jpzk/mockedstreams&amp;utm_campaign=Badge_Grade)

Dataapis Middleware is a scala api library  which allows you to **fetch data related to Sales dashboard api's**

    libraryDependencies += "com.madewithtea" %% "mockedstreams" % "3.6.0" % "test"

## Getting Started

It wraps the [org.apache.kafka.streams.TopologyTestDriver](https://github.com/apache/kafka/blob/trunk/streams/test-utils/src/main/java/org/apache/kafka/streams/TopologyTestDriver.java) class, but adds more syntactic sugar to keep your test code simple:

    import com.madewithtea.mockedstreams.MockedStreams

    val input = Seq(("x", "v1"), ("y", "v2"))
    val exp = Seq(("x", "V1"), ("y", "V2"))
    val strings = Serdes.String()

    MockedStreams()
      .topology { builder => builder.stream(...) [...] } // Scala DSL
      .input("topic-in", strings, strings, input)
      .output("topic-out", strings, strings) shouldEqual exp

## Supported Libraries
* [Scala](https://www.scala-lang.org/)
* [Caliban Graphql](https://github.com/ghostdogpr/caliban/)
* [ZIO](https://github.com/zio/zio/)
* [Doobie](https://tpolecat.github.io/doobie/)
* [Rollbar](https://rollbar.com/)
* [Google Cloud](https://cloud.google.com/)
* [Flyway](https://flywaydb.org/)

## Version Compatibility

Please use the following dependant library versions.

| Technology           | Version     |
|----------------------|-------------|
| Scala                | 2.12        |
| Caliban Graphql      | 0.7.5       |
| ZIO                  | 1.0.0-RC18-2|
| Doobie               | 0.8.8       |
| Rollbar              | 1.3.1       |
| Google Cloud         | 1.98.0      |
| Flyway               | 6.4.1       | 
 
