package test
import Api.F
import cats.effect.ExitCode
//import com.typesafe.scalalogging.LazyLogging
import io.circe._
import org.http4s._
import org.http4s.circe._
import org.http4s.dsl._
import org.http4s.implicits._
import org.http4s.server.blaze.BlazeServerBuilder
import org.http4s.server.middleware.CORS
import zio._
import zio.clock.Clock
import zio.interop.catz._

object Main extends App {
  def run(args: List[String]): ZIO[Clock, Nothing, Int] = program.fold(_ => 1, _ => 0)

  val program: RIO[Clock, Unit] = for {
    implicit0(rtc: Runtime[Clock]) <- ZIO.runtime[Clock]
    server                         <- Api.createServer
  } yield server
}

case class Api()  {
  implicit def circeJsonEncoder[A](implicit decoder: Encoder[A]): EntityEncoder[F, A] = jsonEncoderOf[F, A]

  val dsl: Http4sDsl[F] = Http4sDsl[F]
  import dsl._

  def getHealth: Health = UP

  val routes: HttpRoutes[F] = HttpRoutes
    .of[F] {
      case GET -> Root / "health" => Ok(getHealth)
    }

  sealed abstract class Health(val health: String)
  object Health {
    implicit val encodeHealth: Encoder[Health] = Encoder.forProduct1("health")(u => u.health)
  }
  case object UP   extends Health("UP")
  case object DOWN extends Health("DOWN")
}

object Api {
  type F[A] = RIO[Clock, A]

  def createServer: F[Unit] =
    for {
      implicit0(rtc: Runtime[Clock]) <- ZIO.runtime[Clock]
      api = Api()
      server <- BlazeServerBuilder[F]
        .bindHttp(8080, "localhost")
        .withHttpApp(CORS(api.routes).orNotFound)
        .serve
        .compile[F, F, ExitCode]
        .drain
    } yield server
}
