package sales_dashboard_test_suite.cards

import backends.sales_dashboard.cards.TargetWithCprpPG
import backends.sales_dashboard.Schema._
import cats.effect.{Blocker, Resource}
import doobie.hikari.HikariTransactor
import test._
import zio.Task
import zio.test.Assertion._
import zio.test._
import zio.test.environment._
import doobie.util.ExecutionContexts
import zio.interop.catz._


object TargetWithCprpPGTest extends DefaultRunnableSpec( suite("OverAllMetricsPG")(

  testM("OverallMetricsPG sales_dashboard_test_suite.report data should be generated") {
    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }

  val expected_result = TargetWithCprp(
    target_with_cprp= PGTargetWithCPRP(target = Some(1), target_cprp= Some(1))
  )
    val actual_result : Task[TargetWithCprp] = dbResource.use{
      xa => TargetWithCprpPG(xa,SalesDashBoardReportArgsFlags(
        channel = "Star Plus"
        ,period = Period("2019-12-29","2020-01-25")
        ,deviation_period = List(Period("2019-12-01","2019-12-28"))
        ,regions = List("EAST", "WEST","NORTH","SOUTH")
        ,agency = None
        ,sub_agency = None
        ,pt_npt = List(DayPart.NPT,DayPart.PT)
        ,advertiser_group = Some(List("Asian Paints"))
        ,deviation_advertiser_group = Some(List("Asian Paints"))
        ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
        ,all_region_selected=true
        ,all_advertiser_selected=true
        ,all_agency_selected=true
        ,all_sub_agency_selected=true
      )
      )
    }
        for {
          res   <- actual_result
          _     <- TestConsole.output
        } yield assert(res, equalTo(expected_result))
      }
    )
  ){
  Main.unsafeRun(Main.run(List()).fork)
}
