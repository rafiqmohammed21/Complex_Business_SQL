package sales_dashboard_test_suite.cards

import backends.sales_dashboard.Schema.{BarcYearWeek, DayPart, FairShare, FctFills, ImpactRegular, InfoFillsFairShareResult, InfoFillsMarketShareResult, InfoSchema, Period, SPActualBooked, SPMarketShare, SalesDashBoardReportArgsFlags}
import backends.sales_dashboard.cards.InfoFillsFairShare
import test._
import zio.Task
import zio.test.Assertion._
import zio.test._
import zio.test.environment._


object InfoFillsFairShareTest extends DefaultRunnableSpec( suite("InfoFillsFairShare")(


  testM("InfoFillsFairShare sales_dashboard_test_suite.report data should be generated") {
  val expected_results = InfoFillsFairShareResult(
    Some(InfoSchema(
      BarcYearWeek(Some(9),Some(2020)),
      Some("2020-07-19"),
      Some("CS 15+ HSM (U)"),
      Some("2020-07-03"),
      Some("2020-07-17"),
      Some("2020-08-01"),
      Some("2020-08-19"),
      Some("2020-07-03"),
      Some("2020-07-03"),
      Some("Star Data Lake"))),
    Some(
      FctFills(
        Some(12.05),
        Some(8.81))),
    Some(
      FairShare(
        Some(713.53),
        Some(3711.49),
        Some(19.22))
    ))

  val info_fills_fair_share_res :Task[InfoFillsFairShareResult] =  InfoFillsFairShare(SalesDashBoardReportArgsFlags(
    channel = "Star Plus"
    ,period = Period("2019-12-29","2020-01-25")
    ,deviation_period = List(Period("2019-12-01","2019-12-28"))
    ,regions = List("EAST", "WEST","NORTH","SOUTH")
    ,agency = None
    ,sub_agency = None
    ,pt_npt = List(DayPart.NPT,DayPart.PT)
    ,advertiser_group = Some(List("Asian Paints"))
    ,deviation_advertiser_group = Some(List("Asian Paints"))
    ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
    ,all_region_selected=true
    ,all_advertiser_selected=true
    ,all_agency_selected=true
    ,all_sub_agency_selected=true
  )
  )
  for {
    res   <- info_fills_fair_share_res
    _     <- TestConsole.output
  } yield assert(res, equalTo(expected_results))
}


)
){
  Main.unsafeRun(Main.run(List()).fork)
}
