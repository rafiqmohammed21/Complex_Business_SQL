package sales_dashboard_test_suite.cards

import backends.sales_dashboard.cards.OverAllMetricsPG
import backends.sales_dashboard.Schema._
import cats.effect.{Blocker, Resource}
import doobie.hikari.HikariTransactor
import test._
import zio.Task
import zio.test.Assertion._
import zio.test._
import zio.test.environment._
import doobie.util.ExecutionContexts
import zio.interop.catz._


object OverallMetricsPGTest extends DefaultRunnableSpec( suite("OverAllMetricsPG")(


  testM("OverallMetricsPG sales_dashboard_test_suite.report data should be generated") {
    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }

    val expected_result = DataResultWithTotal(
      List(
        RevenueReportSchema(advertisers="Asian Paints",
          revenue=Some( 0),
          dev_revenue=Some( 0.01),
          revenue_deviation=Some( -75),
          actual_revenue=Some( 0),
          dev_actual_revenue=Some( 0.01),
          actual_revenue_deviation=Some( -75),
          booked_revenue=Some( null),
          grp=Some( 2.14),
          dev_grp=Some( 2.33),
          grp_deviation=Some( -8.15),
          genre_grp=Some( 263.25),
          dev_genre_grp=Some( 232.16),
          genre_grp_deviation=Some( 13.39),
          market_share=Some( 0.81),
          dev_market_share=Some( 1),
          market_share_deviation=Some( -19),
          exit_cprp=Some( 7570.09),
          dev_exit_cprp=Some( 27811.16),
          exit_cprp_deviation=Some( -72.78),
          exit_revenue=Some( 0),
          dev_exit_revenue=Some( 0.01),
          exit_grp=Some( 2.14),
          dev_exit_grp=Some( 2.33)
      )),
      List(
        FunnelReportSchema(advertisers="Asian Paints",
          projection=Some( 0),
          dev_projection=Some( null),
          projection_deviation=Some( null),
          deal=Some( 1.11),
          dev_deal=Some( 0.97),
          deal_deviation=Some( 14.07),
          ro=Some( 0),
          dev_ro=Some( 0.01),
          ro_deviation=Some( -75),
          revenue=Some( 0))
      ),
      TotalRevenueMetrics(
        deals =
          Some( PGDeals(
            revenue=Some( 1.11),
            dev_revenue=Some( 0.97),
            percentage_deviation=Some( 14.0)
        )),
        projection = Some(PGProjection(
          revenue=Some(0),
          dev_revenue=Some (null),
          percentage_deviation=Some (null)
        )),
      ro = Some(PGRo(
        revenue=Some( 0),
          dev_revenue=Some( 0.01),
          percentage_deviation=Some( -75)
      )),
    actual_booked=Some(PGActualBooked(
      actual_revenue=Some( 0),
      dev_actual_revenue=Some( 0.01),
      actual_percentage_deviation=Some( -75),
      total_revenue=Some( 0),
      dev_total_revenue=Some( 0.01),
      total_revenue_percentage_deviation=Some( -75),
      number_of_days_actualised=Some( 28),
      number_of_days_month=Some( 28),
      actual_revenue_internal=Some( null),
      total_revenue_internal=Some( null)
    )),
    exit_cprp =Some(NewExitCprp(
      total_revenue=Some( 0),
      total_ad_grp=Some( 2.14),
      total_deviation_revenue=Some( 0.01),
      total_deviation_ad_grp=Some( 2.33),
      total_exit_cprp=Some( 7570.09),
      total_deviation_exit_cprp=Some( 27811.16),
      total_percentage_deviation=Some( -72.78)
    )),
    market_share=Some(SPMarketShare(
      current_channel_ad_grp=Some( 2.14),
      current_genre_ad_grp=Some( 263.25),
      deviation_channel_ad_gr=Some( 2.33),
      deviation_genre_ad_grp=Some( 232.16),
      market_share=Some( 0.81),
      deviation_market_share=Some( 1),
      percentage_deviation_market_share=Some( -19)))
      )
    )
    val actual_result : Task[DataResultWithTotal] = dbResource.use {
      xa =>  OverAllMetricsPG (xa, SPDReportArgsWithCategory(
           channel = "Star Plus"
          ,period = Period("2020-01-01","2020-01-31")
          ,deviation_period = List(Period("2019-12-01","2019-12-31"))
          ,regions = List("EAST", "WEST","NORTH","SOUTH")
          ,agency = None
          ,sub_agency = None
          ,advertiser_category = Some(List("Unsp","Construction & Real Estate","FMCG"))
          ,pt_npt = List(DayPart.NPT,DayPart.PT)
          ,advertiser_group = Some(List("Asian Paints"))
          ,deviation_advertiser_group = Some(List("Asian Paints"))
          ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
          ,all_region_selected=true
          ,all_advertiser_selected=true
          ,all_agency_selected=true
          ,all_sub_agency_selected=true
          ,all_advertiser_category_selected=Some(true)
      )
      )
    }
    for {
          res   <- actual_result
          _     <- TestConsole.output
        } yield assert(res, equalTo(expected_result))
      }


    )
  ){
  Main.unsafeRun(Main.run(List()).fork)
}
