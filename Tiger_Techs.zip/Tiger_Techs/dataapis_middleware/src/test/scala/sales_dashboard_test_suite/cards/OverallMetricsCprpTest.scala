package sales_dashboard_test_suite.cards

import backends.sales_dashboard.Schema._
import backends.sales_dashboard.cards.OverallMetricsCprp
import cats.effect.{Blocker, Resource}
import doobie.hikari.HikariTransactor
import test._
import zio.Task
import zio.test.Assertion._
import zio.test._
import zio.test.environment._
import doobie.util.ExecutionContexts
import zio.interop.catz._

object OverallMetricsCprpTest extends  DefaultRunnableSpec( suite("OverallMetricsCprp")(


  testM("OverallMetricsCprp sales_dashboard_test_suite.report data should be generated") {
    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }

    val expected_result = OverallCprpMetricsResult(
      cprp = List(SPOverallCprpSchema(
        advertiser_group= "Asian Paints",
        ro_revenue=Some (0),
        ro_grp= Some(2.93),
        ro_cprp= Some(5532.11),
        dev_ro_revenue= Some(0.01),
        dev_ro_grp= Some(10.81),
        dev_ro_cprp= Some(5993.2),
        per_dev_ro_cprp= Some(-7.69),
        deal_revenue=Some (0.09),
        deal_grp= Some(29.72),
        deal_cprp= Some(30745.93),
        dev_deal_revenue= Some(0.08),
        dev_deal_grp= Some(25.46),
        dev_deal_cprp= Some(32124.05),
        per_dev_deal_cprp= Some(-4.29),
        executed_revenue=Some (0),
        executed_grp= Some(2.95),
        executed_cprp= Some(5489.8),
        dev_executed_revenue= Some(0.01),
        dev_executed_grp= Some(2.58),
        dev_executed_cprp= Some(25150.46),
        per_dev_executed_cprp= Some(-78.17)

      )),
        total_cprp = PricingToDateDataResult(
          deals_cprp=Some(DealCprp(
            total_revenue=Some( 0.09),
            total_ad_grp=Some( 29.72),
            deals_cprp=Some( 30745.93),
            total_deviation_revenue=Some( 0.08),
            total_deviation_ad_grp=Some( 25.46),
            deviation_deals_cprp=Some( 32124.05),
            total_percentage_deviation=Some( -4.29)))
          ,ro_cprp=Some(RoCprp(
              total_revenue=Some( 0),
              total_ad_grp=Some( 2.93),
              ro_cprp=Some( 5532.11),
              total_deviation_revenue=Some( 0.01),
              total_deviation_ad_grp=Some( 10.81),
              deviation_ro_cprp=Some( 5993.2),
              total_percentage_deviation=Some( -7.69)
          ))
          ,executed_cprp = Some(ExecutedCprp(
              total_revenue=Some( 0),
              total_ad_grp=Some( 2.95),
              executed_cprp=Some( 5489.8),
              total_deviation_revenue=Some( 0.01),
              total_deviation_ad_grp=Some( 2.58),
              deviation_executed_cprp=Some( 25150.46),
              total_percentage_deviation=Some( -78.17)
          ))
        )
    )

    val actual_result : Task[OverallCprpMetricsResult] = dbResource.use {
      xa => OverallMetricsCprp(xa, SPDReportArgsWithCategory(
        channel = "Star Plus"
        ,period = Period("2019-12-29","2020-01-25")
        ,deviation_period = List(Period("2019-12-01","2019-12-28"))
        ,regions = List("EAST", "WEST","NORTH","SOUTH")
        ,agency = None
        ,sub_agency = None
        ,advertiser_category = None
        ,pt_npt = List(DayPart.NPT,DayPart.PT)
        ,advertiser_group = Some(List("Asian Paints"))
        ,deviation_advertiser_group = Some(List("Asian Paints"))
        ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
        ,all_region_selected=true
        ,all_advertiser_selected=true
        ,all_agency_selected=true
        ,all_sub_agency_selected=true
        ,all_advertiser_category_selected=Some(true)
      )
      )
    }
    for {
    res   <- actual_result
    _     <- TestConsole.output
  } yield assert(res, equalTo(expected_result))
}


)
)
{
  Main.unsafeRun(Main.run(List()).fork)
}
