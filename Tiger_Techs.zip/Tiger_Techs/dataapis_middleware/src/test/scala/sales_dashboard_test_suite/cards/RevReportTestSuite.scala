package sales_dashboard_test_suite.cards

import backends.sales_dashboard.Schema.{ DayPart, ImpactRegular, Period, ReportResultCprp, SPDReportArgsRegFlagWithCategory}
import backends.sales_dashboard.cards.OverallMetricsCprp
import cats.effect.{Blocker, Resource}
import doobie.hikari.HikariTransactor
import test._
import zio.Task
import zio.test.Assertion._
import zio.test.{testM, _}
import zio.test.environment._
import doobie.util.ExecutionContexts
import zio.interop.catz._


object RevReportTestSuite extends DefaultRunnableSpec( suite("RevReport")(


  testM("Revenue sales_dashboard_test_suite.report url should be generated") {

    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }
    val actual_result : Task[ReportResultCprp] = dbResource.use{
      xa => OverallMetricsCprp.asGcsFilePath(List(),xa,SPDReportArgsRegFlagWithCategory(
          channel = "Star Plus"
          ,period = Period("2019-12-29","2020-01-25")
          ,deviation_period = List(Period("2019-12-01","2019-12-28"))
          ,regions = List("EAST", "WEST","NORTH","SOUTH")
          ,agency = None
          ,sub_agency = None
          ,advertiser_category = None
          ,pt_npt = List(DayPart.NPT,DayPart.PT)
          ,advertiser_group = Some(List("Asian Paints"))
          ,deviation_advertiser_group = Some(List("Asian Paints"))
          ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
          ,all_region_selected=true
          ,all_advertiser_selected=true
          ,all_agency_selected=true
          ,all_sub_agency_selected=true
          ,all_advertiser_category_selected=Some(true)
          ,is_regional=false
        )
        )
    }
        for {
          rev   <- actual_result
          _     <- TestConsole.output
        } yield assert(
          rev.revenue.take(67), equalTo("https://storage.googleapis.com/star-dl-temp-mint/csvUpload/Revenue_")
        )
      },


    testM("Funnel sales_dashboard_test_suite.report url should be generated") {

    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }
    val actual_result : Task[ReportResultCprp] = dbResource.use{
      xa => OverallMetricsCprp.asGcsFilePath(List(),xa,SPDReportArgsRegFlagWithCategory(
        channel = "Star Plus"
        ,period = Period("2019-12-29","2020-01-25")
        ,deviation_period = List(Period("2019-12-01","2019-12-28"))
        ,regions = List("EAST", "WEST","NORTH","SOUTH")
        ,agency = None
        ,sub_agency = None
        ,advertiser_category = None
        ,pt_npt = List(DayPart.NPT,DayPart.PT)
        ,advertiser_group = Some(List("Asian Paints"))
        ,deviation_advertiser_group = Some(List("Asian Paints"))
        ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
        ,all_region_selected=true
        ,all_advertiser_selected=true
        ,all_agency_selected=true
        ,all_sub_agency_selected=true
        ,all_advertiser_category_selected=Some(true)
        ,is_regional=false
      )
      )
    }
    for {
      rev   <- actual_result
      _     <- TestConsole.output
    } yield assert(
      rev.funnel.take(66), equalTo("https://storage.googleapis.com/star-dl-temp-mint/csvUpload/Funnel_")
    )
  }

  ,


  testM("Funnel sales_dashboard_test_suite.report url should be generated") {

    def dbResource: Resource[Task, HikariTransactor[Task]] = {
      for {
        connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
        xa        <- HikariTransactor.newHikariTransactor[Task](
          "org.postgresql.Driver",
          "jdbc:postgresql://10.40.32.44:5432/sales_dashboard",
          "mintrw",
          "$tar@MintRW2o2o",
          connectEC,                              // await connection here
          Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
        )
      } yield xa
    }
    val actual_result : Task[ReportResultCprp] = dbResource.use{
      xa => OverallMetricsCprp.asGcsFilePath(List(),xa,SPDReportArgsRegFlagWithCategory(
        channel = "Star Plus"
        ,period = Period("2019-12-29","2020-01-25")
        ,deviation_period = List(Period("2019-12-01","2019-12-28"))
        ,regions = List("EAST", "WEST","NORTH","SOUTH")
        ,agency = None
        ,sub_agency = None
        ,advertiser_category = None
        ,pt_npt = List(DayPart.NPT,DayPart.PT)
        ,advertiser_group = Some(List("Asian Paints"))
        ,deviation_advertiser_group = Some(List("Asian Paints"))
        ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
        ,all_region_selected=true
        ,all_advertiser_selected=true
        ,all_agency_selected=true
        ,all_sub_agency_selected=true
        ,all_advertiser_category_selected=Some(true)
        ,is_regional=false
      )
      )
    }
    for {
      rev   <- actual_result
      _     <- TestConsole.output
    } yield assert(
      rev.cprp.take(64), equalTo("https://storage.googleapis.com/star-dl-temp-mint/csvUpload/Cprp_")
    )
  }

    )
  ){
  Main.unsafeRun(Main.run(List()).fork)
}
