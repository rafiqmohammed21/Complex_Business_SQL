package sales_dashboard_test_suite.pgSyntaxChecker

import backends.sales_dashboard.Schema.{BarcYearWeek, DayPart, ImpactRegular, InfoSchema, NewExitCprp, Period, SalesDashBoardReportArgsFlags}
import backends.sales_dashboard.metrics.pg.PGTargetWithCprpSql
import cats.effect.{ContextShift, IO}
import doobie.util.transactor.Transactor
import doobie.scalatest.IOChecker
import oldcode.{PGExitCprpSql, PGMarketShareSql}
import zio.Task
import zio.test.{testM, _}
import zio.test.Assertion._
import zio.test.environment._

import scala.concurrent.ExecutionContext
import org.scalatest._
import zio.test.DefaultRunnableSpec

// Check that AnalysisSpec plays nice with Specs2 execution flow (issue #454)
class QuerySpec extends  FunSuite with Matchers with IOChecker {

  implicit def contextShift: ContextShift[IO] =
    IO.contextShift(ExecutionContext.global)

  val transactor = Transactor.fromDriverManager[IO](
    "org.postgresql.Driver",
    "jdbc:postgresql://localhost:5432/sales_dashboard",
    "postgres",
    "")

  val salesDashBoardReportArgsFlags = SalesDashBoardReportArgsFlags(channel = "Star Plus"
    ,period = Period("2020-01-01","2020-01-31")
    ,deviation_period = List(Period("2019-12-01","2019-12-31"))
    ,regions = List("EAST", "WEST","NORTH","SOUTH")
    ,agency = None
    ,sub_agency = None
    ,pt_npt = List(DayPart.NPT,DayPart.PT)
    ,advertiser_group = Some(List("Asian Paints"))
    ,deviation_advertiser_group = Some(List("Asian Paints"))
    ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
    ,all_region_selected =true
    ,all_advertiser_selected = true
    ,all_agency_selected= true
    ,all_sub_agency_selected= true
  )

  test("1"){
    check(PGExitCprpSql.getSqlQuery(salesDashBoardReportArgsFlags))
  }
  test("2"){check(PGMarketShareSql.getSqlQuery(salesDashBoardReportArgsFlags))}
  test("3"){check(PGTargetWithCprpSql.getSqlQuery(salesDashBoardReportArgsFlags))}

}

//object QuerySpec extends DefaultRunnableSpec with IOChecker {
//  def spec = suite("InfoObject")(
//    test("InfoObject sales_dashboard_test_suite.report data should be generated") {
//
//      implicit def contextShift: ContextShift[IO] =
//        IO.contextShift(ExecutionContext.global)
//
//      val transactor = Transactor.fromDriverManager[IO](
//          "org.postgresql.Driver",
//          "jdbc:postgresql://localhost:5432/sales_dashboard",
//          "postgres",
//          "")
//
//      val salesDashBoardReportArgsFlags = SalesDashBoardReportArgsFlags(channel = "Star Plus"
//          ,period = Period("2020-01-01","2020-01-31")
//          ,deviation_period = List(Period("2019-12-01","2019-12-31"))
//          ,regions = List("EAST", "WEST","NORTH","SOUTH")
//          ,agency = None
//          ,sub_agency = None
//          ,pt_npt = List(DayPart.NPT,DayPart.PT)
//          ,advertiser_group = Some(List("Asian Paints"))
//          ,deviation_advertiser_group = Some(List("Asian Paints"))
//          ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
//          ,all_region_selected =true
//          ,all_advertiser_selected = true
//          ,all_agency_selected= true
//          ,all_sub_agency_selected= true
//        )
//
//      check(PGExitCprpSql.getSqlQuery(salesDashBoardReportArgsFlags))
//    }
//  )
//}
