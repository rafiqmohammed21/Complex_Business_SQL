CREATE TABLE disney_fy_cal
(
    year BIGINT,
    month BIGINT,
    week BIGINT,
    start_date DATE,
    end_date DATE,
    fin_year TEXT,
    quarter TEXT
);

CREATE TABLE ent_ad_revenue_target
(
    year BIGINT,
    month BIGINT,
    genre TEXT,
    channel TEXT,
    branch TEXT,
    region TEXT,
    impact_regular TEXT,
    value DOUBLE PRECISION,
    channel_name TEXT
);

CREATE TABLE ent_ad_revenue_target_cprp
(
    year BIGINT,
    month BIGINT,
    pt_npt TEXT,
    channel TEXT,
    regular_impact TEXT,
    value DOUBLE PRECISION,
    channel_name TEXT
);

CREATE TABLE ent_fact_revenue
(
    advertiser_group TEXT,
    channel_name TEXT,
    date DATE,
    agency TEXT,
    sub_agency TEXT,
    region TEXT,
    impact_regular TEXT,
    pt_npt TEXT,
    ro_revenue DOUBLE PRECISION,
    actual_revenue DOUBLE PRECISION,
    booked_revenue DOUBLE PRECISION,
    total_revenue DOUBLE PRECISION,
    deals_revenue DOUBLE PRECISION,
    projection_revenue DOUBLE PRECISION
);


CREATE TABLE ent_fact_viewership
(
    channel_name TEXT,
    channel_def_name TEXT,
    advertiser_group TEXT,
    date DATE,
    region TEXT,
    pt_npt TEXT,
    impact_regular TEXT,
    agency TEXT,
    sub_agency TEXT,
    genre TEXT,
    sub_genre TEXT,
    ad_grp DOUBLE PRECISION,
    genre_grp DOUBLE PRECISION,
    market_share DOUBLE PRECISION
);