//package oldcode
//
//import backends.sales_dashboard.ProjectionReport
//import backends.sales_dashboard.Schema.{DayPart, FunnelReportSchema, ImpactRegular, Period}
//import zio.console.putStrLn
//import zio.{Task, ZIO}
//
//object Example extends zio.App {
//    def revenue_report(): Task[List[FunnelReportSchema]] = {
//        for {
//            results <- ProjectionReport(channel = "Star Plus"
//                            ,period = Period("2019-08-01","2019-08-31")
//                            ,deviation_period = List(Period("2019-05-01","2019-07-31"))
//                            ,regions = List("NORTH")
//                            ,agency = Some(List("starcomm"))
//                            ,sub_agency = Some(List("starcomm"))
//                            ,pt_npt = List(DayPart.NPT,DayPart.PT)
//                            ,advertiser_group = Some(List("Air India","Ashok & Company","Ashok Griha Udyog","B.P Oil Mills","Bectors Food Specialities","Bhola Food Products","Breakthrough Trust","Davp","Govt - India National Congress","HPCL","Indian Oil Corp","Kochar Sung Up Acrylic","Link Locks","Maharishi Markandeshwar University","Mahesh Edible Oil Industries","Ministry Of Ayush","Monte Carlo Fashions","National Handloom Development Corporation","Pawan Hosiery","Pnb Housing Finance","Reserve Bank Of India","Sbs Biotech","Shubham Goldiee Masala","Uttamchand Deshraj","Wonder Cement"))
//                            ,deviation_advertiser_group = Some(List("Air India","Ashok & Company","Ashok Griha Udyog","B.P Oil Mills","Bectors Food Specialities","Bhola Food Products","Breakthrough Trust","Davp","Govt - India National Congress","HPCL","Indian Oil Corp","Kochar Sung Up Acrylic","Link Locks","Maharishi Markandeshwar University","Mahesh Edible Oil Industries","Ministry Of Ayush","Monte Carlo Fashions","National Handloom Development Corporation","Pawan Hosiery","Pnb Housing Finance","Reserve Bank Of India","Sbs Biotech","Shubham Goldiee Masala","Uttamchand Deshraj","Wonder Cement"))
//                            ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
//                        )
//        } yield (results)
//    }
//    def run(args: List[String]): ZIO[zio.ZEnv,Nothing,Int] = {
//        for {
//            _ <- putStrLn(s"Starting to run revenue sales_dashboard_test_suite.report on main thread=${Thread.currentThread().getId} time=${System.currentTimeMillis()}")
//            error_code <- revenue_report().foldM(ex => {putStrLn(ex.getStackTrace.mkString("\n")); ZIO.succeed(500)}, res => {putStrLn(res.mkString); ZIO.succeed(200)})
//            _ <- putStrLn(s"Done creating revenue sales_dashboard_test_suite.report on main thread=${Thread.currentThread().getId} time=${System.currentTimeMillis()}")
//        } yield (error_code)
//    }
//}
