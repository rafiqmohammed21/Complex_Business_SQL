//package backends.sales_dashboard.metrics
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period}
//import zio.Task
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics.Utils._
//import utils.BQApi.getDataFromBQ
//
//object ActualBookedObject {
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[SPActualBooked] = Task {
//    println(s"===== Actual Booked object is started at ======")
//
//    var deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//    }
//
//    val (actual_date,booked_date) = getActualPeriod(period)
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//
//    val query  =
//      s"""CALL ${getSPName("sp_actual_booked")}('${actual_date.start_date}',
//         |'${actual_date.end_date}'
//         |,${getArrayOfStringForDates(deviation_period_dates_arr)},
//         |'${booked_date.start_date}',
//         |'${booked_date.end_date}',
//         |'${channel.toLowerCase}',
//         |${gerArrayOfStringForString(regions.toArray)},
//         |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//         |$value_for_impact_regular,
//         |${value_for_advertiser_group.map(_.toLower)},
//         |${value_for_deviation_advertiser_group.map(_.toLower)},
//         |${value_for_agency.map(_.toLower)},
//         |${value_for_sub_agency.map(_.toLower)},
//         |$all_region_selected,
//         |$all_advertiser_selected,
//         |$all_agency_selected,
//         |$all_sub_agency_selected
//         |)""".stripMargin
//
//    var total_revenue: Option[Double] = None
//    var actual_revenue: Option[Double] = None
//    var actual_deviation: Option[Double] = None
//    var actual_percentage_deviation: Option[Double] = None
//    var total_deviation: Option[Double] = None
//    var total_percentage_deviation: Option[Double] = None
//    var number_of_days_actualised: Option[Long] = None
//    var number_of_days_month:Option[Long] = None
//    var actual_revenue_internal:Option[Double] = None
//    var total_revenue_internal:Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//
//      actual_revenue={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      actual_deviation={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      actual_percentage_deviation={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      total_revenue={if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      total_deviation={if (!row.get(4).isNull) Some(row.get(4).getDoubleValue)  else None}
//      total_percentage_deviation={if (!row.get(5).isNull) Some(row.get(5).getDoubleValue)  else None}
//      number_of_days_actualised={if (!row.get(6).isNull) Some(row.get(6).getLongValue)  else None}
//      number_of_days_month={if (!row.get(7).isNull) Some(row.get(7).getLongValue)  else None}
//      actual_revenue_internal={if (!row.get("actual_revenue_internal").isNull) Some(row.get("actual_revenue_internal").getDoubleValue)  else None}
//      total_revenue_internal={if (!row.get("total_revenue_internal").isNull) Some(row.get("total_revenue_internal").getDoubleValue)  else None}
//    }
//    println(s"=====Actual Booked object is ended at ======")
//    SPActualBooked(actual_revenue, actual_deviation,actual_percentage_deviation, total_revenue, total_deviation, total_percentage_deviation,number_of_days_actualised,number_of_days_month,actual_revenue_internal,total_revenue_internal)
//  }
//}