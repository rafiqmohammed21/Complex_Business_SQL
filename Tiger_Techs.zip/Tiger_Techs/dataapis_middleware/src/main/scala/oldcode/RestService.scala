//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.{ActualReport, ProjectionReport}
//import zio.Task
//
//object RestService {
//
//  def getActualReport(channel: String, period: Period, deviation_period: List[Period], regions: List[String],agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[RevenueReportSchema]] = ActualReport(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//
//  def getProjectionReport(channel: String, period: Period, deviation_period: List[Period], regions: List[String],agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[FunnelReportSchema]] = ProjectionReport(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//}