//package backends.sales_dashboard.metrics
//
//import backends.sales_dashboard.metrics.Utils._
//import backends.sales_dashboard.Schema._
//import utils.BQApi.getDataFromBQ
//import org.json4s.DefaultFormats
//import zio.Task
//
//object SPDealObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[SPDeal] = Task {
//
//    var deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//    }
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//
//    val query = s"""CALL ${getSPName("sp_deals")}('${period.start_date}',
//                   |'${period.end_date}',
//                   | ${getArrayOfStringForDates(deviation_period_dates_arr)},
//                   |'${channel.toLowerCase}',
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |'${pt_npt.mkString("_")}',
//                   |$value_for_impact_regular,
//                   |$value_for_advertiser_group,
//                   |$value_for_deviation_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency,
//                   |$all_region_selected,
//                   |$all_advertiser_selected,
//                   |$all_agency_selected,
//                   |$all_sub_agency_selected
//                   |); """.stripMargin
//
//    var total_revenue:Option[Double] = None
//    var total_deviation_revenue:Option[Double] = None
//    var total_percentage_deviation:Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//      total_revenue={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      total_deviation_revenue={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      total_percentage_deviation={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//    }
//    SPDeal(total_revenue, total_deviation_revenue, total_percentage_deviation)
//  }
//}
