//package backends.sales_dashboard.metrics
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics.Utils._
//import utils.BQApi.getDataFromBQ
//import org.json4s.DefaultFormats
//import zio.Task
//
//object ReleaseOrderObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], overall_matrics:Boolean)
//  : Task[List[ReleaseOrder]] = Task {
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//    var deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//    }
//
//    val query = s""" CALL ${getSPName("sp_ro")}('${period.start_date}','${period.end_date}',
//                   |${getArrayOfStringForDates(deviation_period_dates_arr)},
//                   |'${channel.toLowerCase}',
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |'${pt_npt.mkString("_")}',
//                   |$value_for_impact_regular,
//                   |$value_for_advertiser_group,
//                   |$value_for_deviation_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency,
//                   |$overall_matrics
//                   |); """.stripMargin
//
//    var advertiser_group_value:String=""
//    var revenue:Option[Double] = None
//    var deviation_revenue:Option[Double] = None
//    var percentage_deviation:Option[Double] = None
//    var ro: List[ReleaseOrder] = List()
//
//    for (row <- getDataFromBQ(query)) {
//      advertiser_group_value={if (!row.get(0).isNull) row.get(0).getStringValue  else ""}
//      revenue={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      deviation_revenue={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      percentage_deviation={if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      ro = ro:+ReleaseOrder(advertiser_group_value,revenue, percentage_deviation)
//    }
//    ro
//  }
//}
