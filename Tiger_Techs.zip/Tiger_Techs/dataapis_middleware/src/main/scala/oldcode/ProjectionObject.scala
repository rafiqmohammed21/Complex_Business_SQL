//package backends.sales_dashboard.metrics
//
//import java.time.Instant
//import java.time.temporal.ChronoUnit
//
//import backends.sales_dashboard._
//import backends.sales_dashboard.Schema._
//import org.json4s.DefaultFormats
//import org.json4s.native.JsonParser.parse
//import scalaj.http.HttpResponse
//import utils.Configs._
//import utils.HttpClientApi
//import zio.Task
//
//object ProjectionObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String],agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[Projection]] = Task {
//    val requestBody = f"""{
//      projection(${Filter.getFilterStr(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)}){
//        revenues{
//        advertiser_group,
//        revenue,
//        deviation,
//        percentage_deviation
//       },
//       total_revenue,
//       total_percentage_deviation
//      }
//     }"""
//    val url = f"$UAT_DATA_API_URL/api/v1/rev/projection"
//    val start = Instant.now()
//    val response: HttpResponse[String] = HttpClientApi.call(url, requestBody)
//    val end = Instant.now()
//    val time_diff = ChronoUnit.SECONDS.between(start, end)
//    println(s"ProjectionObject Status Code: ${response.code} Thread # ${Thread.currentThread().getId()} Time: $time_diff")
//    val parsed = parse(response.body).extractOpt[ResponseProjectionData]
//    val projections: List[Projection] = createList(parsed.get.data.projection)
//    projections
//  }
//
//  def createList(resp_ro: ResponseProjection): List[Projection] = {
//    var projection: List[Projection] = List()
//    resp_ro.revenues.foreach{input =>
//      projection = projection :+ Projection(input.advertiser_group, input.revenue, input.percentage_deviation)
//    }
//    projection
//  }
//}
