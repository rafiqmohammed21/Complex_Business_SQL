//package backends.sales_dashboard
//
//import java.io.File
//import java.time.LocalDateTime
//import java.time.format.DateTimeFormatter
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics._
//import utils.CsvGenerator.writeToCsv
//import utils.GcsUpload.uploadFile
//import zio.Task
//
//object ProjectionReport {
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  :Task[List[FunnelReportSchema]] = {
//    val release_orders  = ReleaseOrderObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular,true)
//    val projections     = ProjectionObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//    val deals           = DealObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//    val revenues        = RevenueObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//
//    val res = for {
//      ((projections,release_orders),(deals,revenues)) <- projections.zipPar(release_orders).zipPar(deals.zipPar(revenues))
//      final_results <- getFunnelReportList(advertiser_group, projections, release_orders, deals, revenues)
//    } yield (final_results)
//    res
//  }
//
//  def asGcsFile(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]], deviation_advertiser_group: Option[List[String]],impact_regular: Option[List[ImpactRegular]])
//  :Task[String] = {
//
//    val path = for{
//      final_results <- apply(channel, period, deviation_period, regions,agency, sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//      final_path <- getUploadPath(final_results)
//    } yield (final_path)
//
//    path
//  }
//
//  def getUploadPath(results: List[FunnelReportSchema]): Task[String] = Task {
//    // val header :String= classOf[FunnelReportSchema].getDeclaredFields.toList.map( field => field.getName ).mkString(",")
//    val header: String = "Advertisers,Projection,Projection Deviation,Deal,Deal Deviation,Release Order,Release Order Deviation,Revenue"
//
//    var list_of_objects:List[List[String]] = List()
//    results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.projection.getOrElse("").toString
//      ,x.projection_deviation.getOrElse("").toString,x.deal.getOrElse("").toString
//      ,x.deal_deviation.getOrElse("").toString,x.ro.getOrElse("").toString
//      ,x.ro_deviation.getOrElse("").toString,x.revenue.getOrElse("").toString))
//    val file_name = f"Funnel_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
//    val file_path = f"/tmp/$file_name"
//    writeToCsv(file_path,header,list_of_objects)
//    val res:String = uploadFile(file_path, file_name)
//    new File(file_path).delete()
//    res
//  }
//
//  def getFunnelReportList(advertiser_group: Option[List[String]], proj: List[Projection], ro: List[ReleaseOrder], deal: List[Deal], rev: List[Revenue]): Task[List[FunnelReportSchema]] = Task {
//    var mapFR: Map[String, FunnelReportSchema] = Map()
//
//    for (elem <- proj) {
//      if (elem.advertiser_group != null){
//      val fr = mapFR.get(elem.advertiser_group)
//      if (fr == None) {
//        mapFR = mapFR + (elem.advertiser_group -> FunnelReportSchema(
//          advertisers = elem.advertiser_group,
//          projection = elem.revenue,
//          projection_deviation = elem.percentage_deviation
//        ))
//      } else {
//        mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//          projection = elem.revenue,
//          projection_deviation = elem.percentage_deviation
//        ))
//      }
//    }
//    }
//
//    for (elem <- ro) {
//      if (elem.advertiser_group != null) {
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None) {
//          mapFR = mapFR + (elem.advertiser_group -> FunnelReportSchema(
//            advertisers = elem.advertiser_group,
//            ro = elem.revenue,
//            ro_deviation = elem.percentage_deviation
//          ))
//        } else {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            ro = elem.revenue,
//            ro_deviation = elem.percentage_deviation
//          ))
//        }
//      }
//    }
//
//    for (elem <- deal) {
//      if (elem.advertiser_group != null) {
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None) {
//          mapFR = mapFR + (elem.advertiser_group -> FunnelReportSchema(
//            advertisers = elem.advertiser_group,
//            deal = elem.revenue,
//            deal_deviation = elem.percentage_deviation
//          ))
//        } else {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            deal = elem.revenue,
//            deal_deviation = elem.percentage_deviation
//          ))
//        }
//      }
//    }
//
//    for (elem <- rev) {
//      if (elem.advertiser_group != null) {
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None) {
//          mapFR = mapFR + (elem.advertiser_group -> FunnelReportSchema(
//            advertisers = elem.advertiser_group,
//            revenue = elem.revenue
//          ))
//        } else {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            revenue = elem.revenue
//          ))
//        }
//      }
//    }
//
//    mapFR.values.toList.filter(x=> advertiser_group.get.contains(x.advertisers))
//  }
//}