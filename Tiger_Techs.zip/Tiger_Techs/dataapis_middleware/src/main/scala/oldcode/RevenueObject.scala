//package backends.sales_dashboard.metrics
//
//import java.time.Instant
//import java.time.temporal.ChronoUnit
//
//import backends.sales_dashboard._
//import backends.sales_dashboard.Schema._
//import org.json4s.DefaultFormats
//import org.json4s.native.JsonParser.parse
//import scalaj.http.HttpResponse
//import utils.Configs._
//import utils.HttpClientApi
//import zio.Task
//
//object RevenueObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String],agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[Revenue]] = Task {
//    val requestBody = f"""{
//      actualBookedRevenue(${Filter.getFilterStr(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)}){
//      total_revenues{
//        advertiser_group
//        total_revenue
//        total_percentage_deviation
//      },
//      total_actual_revenue
//      total_actual_percentage_deviation
//      total_revenue
//      total_pecentage_deviation
//      number_of_days_actualised
//      number_of_days_month
//      }
//     }"""
//
//    val url = f"$UAT_DATA_API_URL/api/v1/rev/actual_booked"
//    val start = Instant.now()
//    val response: HttpResponse[String] = HttpClientApi.call(url, requestBody)
//    val end = Instant.now()
//    val time_diff = ChronoUnit.SECONDS.between(start, end)
//    println(s"RevenueObject Status Code: ${response.code} Thread # ${Thread.currentThread().getId()} Time: $time_diff")
//    val parsed = parse(response.body).extractOpt[ResponseRevenueData]
//    val revenue: List[Revenue] = createList(parsed.get.data.actualBookedRevenue)
//    revenue
//  }
//
//  def createList(resp_ro: ResponseRevenue): List[Revenue] = {
//    var revenue: List[Revenue] = List()
//    resp_ro.total_revenues.foreach{input =>
//      revenue = revenue :+ Revenue(input.advertiser_group, input.total_revenue, input.total_percentage_deviation)
//    }
//    revenue
//  }
//}
