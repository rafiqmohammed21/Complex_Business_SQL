//package backends.sales_dashboard.metrics.bq
//
//import backends.sales_dashboard.Schema.{ImpactRegular, Period, SPTarget}
//import backends.sales_dashboard.metrics.Utils.{gerArrayOfStringForString, getSPName, getValueForImpactRegular}
//import org.json4s.DefaultFormats
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object TargetObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, regions: List[String], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean)
//  : Task[SPTarget] = Task {
//
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//
//    val query = s""" CALL ${getSPName("sp_target")}('${period.start_date}',
//                   |'${channel.toLowerCase}',
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |$value_for_impact_regular,
//                   |$all_region_selected
//                   |); """.stripMargin
//
//    var target:Option[Double] = None
//    for (row <- getDataFromBQ(query)) {
//      target={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//    }
//    SPTarget(target)
//  }
//}
