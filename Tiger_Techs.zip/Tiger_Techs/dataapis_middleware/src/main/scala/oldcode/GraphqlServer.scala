
// import backends.epm_entertainment_reports.revenue_trends_by_channel.Schema.RevenueByChannelArgs
// import backends.epm_entertainment_reports.{revenue_trends_by_channel, total_revenue}
// import backends.epm_entertainment_reports.total_revenue.Schema.EntTotalRevenueArgs
// import backends.revenue.Schema.{SprDailyArgs, SprDailyResult}
// import backends.revenue.ent.pricing_trend.Schema.PricingTrendResult
// import backends.revenue.generic.revenue_across_channel.Schema.RevenueAcrossChannelResult
// import backends.sales_dashboard.Schema._
// import backends.revenue.ent.pricing_trend.Schema.PricingTrendArgs
// import backends.revenue.generic.revenue_across_channel.Schema.RevenueAcrossChannelArgs
// import backends.south_reports.top_programs
// import backends.south_reports.top_programs.Schema.{Language, TimeBand, TopProgramArgs}
// import caliban.GraphQL._
// import caliban.schema.GenericSchema
// import caliban.{GraphQL, Http4sAdapter, RootResolver}
// import cats.data.Kleisli
// import cats.effect.Blocker
// import org.http4s.dsl.Http4sDsl
// import org.http4s.{HttpRoutes, StaticFile}
// import org.http4s.implicits._
// import org.http4s.server.Router
// import org.http4s.server.blaze.BlazeServerBuilder
// import org.http4s.server.middleware.CORS
// import org.http4s.{HttpRoutes, StaticFile}
// import zio.blocking.Blocking
// import zio.clock.Clock
// import zio.console.{Console, putStrLn}
// import zio.interop.catz._
// import zio.{RIO, _}
// import backends.sales_dashboard.Schema._
// import backends.south_reports.top_programs
// import backends.epm_entertainment_reports.total_revenue
// import backends.epm_entertainment_reports.revenue_trends_by_channel
// import backends.epm_entertainment_reports.total_revenue.Schema.EntTotalRevenueArgs
// import backends.epm_entertainment_reports.revenue_trends_by_channel.Schema.RevenueByChannelArgs
// import backends.revenue.Schema.{SprDailyArgs, SprDailyResult}
// import backends.south_reports.top_programs.Schema.{ Language, TimeBand, TopProgramArgs}
// import org.http4s.dsl.Http4sDsl
// import utils.PostgresApi._
// import backends.revenue.generic.epm_channel_list.Schema.{ EPMChannelListArgs, EPMChannelListResult }
// import backends.south_reports.dominance
// import backends.south_reports.report
// import backends.south_reports.hourly_performance

// import backends.revenue.generic.revenue_target.Schema.{RevenueTargetArgs,RevenueTargetResult}
// import caliban.wrappers.Wrappers.{ maxDepth, maxFields }
// import caliban.wrappers.Wrapper.ExecutionWrapper

// object GraphqlServer extends CatsApp with GenericSchema[Console with Clock] {

//   case class SalesDBQueries(
//                       rev_report: SalesDashBoardReportArgs => RIO[Console, ReportResult]
//                      ,rev_data: SalesDashBoardReportArgs => RIO[Console, DataResult]
//                      ,pricing_to_date_data: SalesDashBoardReportArgs => RIO[Console, PricingToDateDataResult]
//                      ,info_fills_market_share_data: SalesDashBoardReportArgs => RIO[Console, InfoFillsMarketShareResult]
//                      ,total_revenue_to_date : SalesDashBoardReportArgs => RIO[Console, TotalReveueToDateResult]
//                      ,over_all_metrics : SalesDashBoardReportArgs => RIO[Console, DataResult]
//                     )
//   case class RevenueQueries(
//                              spr_daily: SprDailyArgs => RIO[Console, SprDailyResult],
//                              pricing_trend : PricingTrendArgs => RIO[Console, PricingTrendResult],
//                              revenue_across_channel: RevenueAcrossChannelArgs => RIO[Console, RevenueAcrossChannelResult],
//                              epm_channel_list: EPMChannelListArgs => RIO[Console, EPMChannelListResult],
//                              revenue_target: RevenueTargetArgs => RIO[Console, RevenueTargetResult]
//                            )

//   case class SouthQueries(
//                   top_program: TopProgramArgs => RIO[Console, top_programs.Schema.TopProgramResult],
//                   south_dominance: dominance.Schema.DominanceArgs => RIO[Console, dominance.Schema.DominanceResult],
//                   south_report: report.Schema.SouthReportArgs => RIO[Console, report.Schema.SouthReportResult],
//                   hourly_perf: hourly_performance.Schema.HourlyPerformanceArgs => RIO[Console, hourly_performance.Schema.HourlyPerformanceResult]

//                          )

//   case class EPMEntQueries(
//                            total_revenues: EntTotalRevenueArgs => RIO[Console, total_revenue.Schema.TotalRevenueResult],
//                            revenue_trend_by_channel: RevenueByChannelArgs => RIO[Console, revenue_trends_by_channel.Schema.RevenueByChannelResult]
//                          )


//   type GraphqlTask[A] = RIO[Console with Clock, A]

//   implicit val regionSchema: Typeclass[Region]  = gen[Region]
//   implicit val periodSchema: Typeclass[Period]  = gen[Period]
//   implicit val timebandSchema: Typeclass[TimeBand] = gen[TimeBand]
//   implicit val languageSchema: Typeclass[Language] = gen[Language]

//   var list_of_selections:List[String] = List()

//   def getFields(): ExecutionWrapper[Clock] =
//     ExecutionWrapper {
//       case (io, exeRequest) => {
//         list_of_selections = List()
//         exeRequest.field.fields(0).fields.foreach(x => list_of_selections = list_of_selections :+ x.name)
//         io
//       }
//     }

//   def makeSalesDashboardApi(service: GraphqlService): GraphQL[Console with Clock] = {
//     graphQL(
//       RootResolver(
//         SalesDBQueries(
//           rev_report =
//             args => service.getReport(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections),
//           rev_data =
//             args => service.getRevData(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections),
//           pricing_to_date_data =
//             args => service.getPricingToDateData(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections),
//           info_fills_market_share_data =
//             args => service.getInfoFillsMarketShareData(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections),
//           total_revenue_to_date =
//             args => service.getTotalReveueToDate(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections),
//           over_all_metrics =
//             args => service.getOverAllMetrics(args.channel, args.period, args.deviation_period, args.regions, args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular, list_of_selections)
//         )
//       )
//     ) @@
//       maxDepth(30) @@
//       maxFields(200) @@
//       getFields()
//   }


//   def makeSouthApi(service: GraphqlService): GraphQL[Console with Clock] = {
//     graphQL(
//       RootResolver(SouthQueries(
//           args => service.getTopProgramData(args.periods,args.tgmarket,args.timebands, args.genre, args.daysofweek,args.metric,args.language),
//         args => service.getDominance(args.channels,args.periods,args.tgmarket, args.genre, args.daysofweek,args.metric,args.language,args.absolute),
//         args => service.getSouthReport(args.period,args.target,args.region,args.level,args.channel_group_name,args.event_type),
//         args => service.getHourlyPerformance(args.periods,args.language,args.genres,args.tgmarket,args.time_band,args.sd_hd,args.paid_fta,args.tiers,args.days_of_week,args.metric)
//         )
//       )
//     ) @@
//       maxDepth(30) @@
//       maxFields(200) @@
//       getFields()
//   }

//   def makeEPMEntApi(service: GraphqlService): GraphQL[Console with Clock] = {
//     graphQL(
//       RootResolver(
//         EPMEntQueries(
//           args => service.getTotalRevenue(args.period,args.channels,args.businessUnits),
//           args => service.getRevenueByChannel(args.period,args.channels,args.businessUnits,args.layout)
//         )
//       )
//     ) @@
//       maxDepth(30) @@
//       maxFields(200) @@
//       getFields()
//   }

//   def makeRevenueApi(service: GraphqlService): GraphQL[Console with Clock] = {
//     graphQL(
//       RootResolver(
//         RevenueQueries(
//           args => service.getRevenueSprDailyData(args.telecast_date),
//           args => service.getEntPricingTrend(args.period, args.target, args.region, args.layout, args.businessUnits, args.businessUnitGenres, args.channels),
//           args => service.getGenericRevenueAcrossChannel(args.period, args.businessUnits, args.businessUnitGenres, args.channels),
//           args => service.getEPMGenericChannelList(args.period,args.businessUnits,args.category),
//           args => service.getRevenueTarget(args.period, args.businessUnits, args.channels, args.region, args.target)
//         )
//       )
//     ) @@
//       maxDepth(30) @@
//       maxFields(200) @@
//       getFields()
//   }


//   def restRoutes: HttpRoutes[GraphqlTask] = {
//     object ioz extends Http4sDsl[GraphqlTask]
//     import ioz._
//     val otherRoutes:HttpRoutes[GraphqlTask] = HttpRoutes.of[GraphqlTask] {
//       case _@GET -> Root => Ok("Hello, Welcome to Scala HTTP4S")
//     }
//     otherRoutes
//   }

//   override def run(args: List[String]): ZIO[ZEnv, Nothing, Int] = {
//     //getDataFromPostgres()
//     (for {
//       blocker <- ZIO.access[Blocking](_.get.blockingExecutor.asEC).map(Blocker.liftExecutionContext)
//       service <- GraphqlService.make()

//       interpreter1 <- makeSalesDashboardApi(service).interpreter
//       interpreter2 <- makeSouthApi(service).interpreter
//       interpreter3 <- makeEPMEntApi(service).interpreter
//       interpreter4 <- makeRevenueApi(service).interpreter

//       _ <- BlazeServerBuilder[GraphqlTask]
//         .bindHttp(8080, "0.0.0.0")
//         .withHttpApp(
//           Router[GraphqlTask](
//             "/"             -> restRoutes,
//             "/api/graphql"  -> CORS(Http4sAdapter.makeHttpService(interpreter1)),
//             "/api/south"  -> CORS(Http4sAdapter.makeHttpService(interpreter2)),
//             "/api/epm_ent"  -> CORS(Http4sAdapter.makeHttpService(interpreter3)),
//             "/api/revenue" -> CORS(Http4sAdapter.makeHttpService(interpreter4)),
//             "/graphiql"     -> Kleisli.liftF(StaticFile.fromResource("/graphiql.html", blocker, None)),
//             "/south"     -> Kleisli.liftF(StaticFile.fromResource("/south.html", blocker, None)),
//             "/epm_ent"     -> Kleisli.liftF(StaticFile.fromResource("/epm_ent.html", blocker, None)),
//             "/revenue"     -> Kleisli.liftF(StaticFile.fromResource("/revenue.html", blocker, None)),
//           ).orNotFound
//         ).resource
//         .toManaged
//         .useForever
//     } yield 0)
//       .catchAll(err => putStrLn(err.getMessage).as(1))
//   }

// }
