//package backends.sales_dashboard.cards
//
//import zio.Task
//import backends.sales_dashboard.Schema.{DataResult, DayPart, ImpactRegular, Period, SPOverallSchemaJoined}
//import backends.sales_dashboard.metrics.bq.SPOverallObject
//
//object OverAllMetrics {
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[DataResult] = {
//    val overall_data: Task[DataResult] =  SPOverallObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,false, all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//    for{
//      data  <- overall_data
//    } yield data
//  }
//}