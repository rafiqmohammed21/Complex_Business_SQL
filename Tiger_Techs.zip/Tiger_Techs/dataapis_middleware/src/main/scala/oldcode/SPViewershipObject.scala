//package backends.sales_dashboard.metrics
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics.Utils._
//import org.json4s.DefaultFormats
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object SPViewershipObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], overall_matrics:Boolean=false)
//  : Task[List[SPViewershipSchemaJoined]] =  {
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//    var deviation_period_dates_arr :Array[(String,String)]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array((x.start_date,x.end_date))
//    }
//    val period_arr :Array[(String,String)] = Array((period.start_date,period.end_date))
//
//    val query = s""" CALL ${getSPName("sp_viewership")}('${channel.toLowerCase}',
//                   |${getArrayOfStructOfStringForDates(period_arr)},
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//                   |$value_for_impact_regular,
//                   |$value_for_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency
//                   |); """.stripMargin
//
//    val query_dev = s""" CALL ${getSPName("sp_viewership")}('${channel.toLowerCase}',
//                   |${getArrayOfStructOfStringForDates(deviation_period_dates_arr)},
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//                   |$value_for_impact_regular,
//                   |$value_for_deviation_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency
//                   |); """.stripMargin
//
//    val viewership_task = getViewershipList(query)
//    val dev_viewership_task = getViewershipDevList(query_dev)
//
//    val res = for{
//      (a:List[SPViewershipSchema],b:List[SPViewershipDevSchema])  <- viewership_task.zipPar(dev_viewership_task)
//      final_results <- getViewershipJoinedList(advertiser_group,a, b)
//    } yield (final_results)
//    res
//  }
//
//  def getViewershipJoinedList(advertiser_group:Option[List[String]],view:List[SPViewershipSchema],dev_view:List[SPViewershipDevSchema])
//  : Task[List[SPViewershipSchemaJoined]] = Task{
//    var mapViewJoined: Map[String, SPViewershipSchemaJoined] = Map()
//    for (elem <- view) {
//      if (elem.advertiser_group != ""){
//        val view_joined = mapViewJoined.get(elem.advertiser_group)
//        if (view_joined == None ) {
//          mapViewJoined = mapViewJoined + (elem.advertiser_group -> SPViewershipSchemaJoined(
//            advertiser_group = elem.advertiser_group,
//            ad_grp = elem.ad_grp,
//            market_share = elem.market_share
//          ))
//        } else {
//          mapViewJoined = mapViewJoined + (elem.advertiser_group -> view_joined.get.copy(
//            ad_grp = elem.ad_grp,
//            market_share = elem.market_share
//          ))
//        }
//      }
//    }
//
//    for (elem <- dev_view) {
//      if (elem.advertiser_group != ""){
//        val view_joined = mapViewJoined.get(elem.advertiser_group)
//        if (view_joined == None ) {
//          mapViewJoined = mapViewJoined + (elem.advertiser_group -> SPViewershipSchemaJoined(
//            advertiser_group = elem.advertiser_group,
//            dev_ad_grp = elem.dev_ad_grp,
//            dev_market_share = elem.dev_market_share
//          ))
//        } else {
//          mapViewJoined = mapViewJoined + (elem.advertiser_group -> view_joined.get.copy(
//            dev_ad_grp = elem.dev_ad_grp,
//            dev_market_share = elem.dev_market_share
//          ))
//        }
//      }
//    }
//
//    mapViewJoined.values.toList
//  }
//
//  def getViewershipList(query:String):Task[List[SPViewershipSchema]] = Task{
//    var advertiser_group_value:Option[String] = None
//    var ad_grp:Option[Double] = None
//    var market_share:Option[Double] = None
//    var viewership_list: List[SPViewershipSchema] =List()
//
//    for (row <- getDataFromBQ(query)) {
//      advertiser_group_value={if (!row.get(0).isNull) Some(row.get(0).getStringValue)  else None}
//      ad_grp={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      market_share={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      viewership_list = viewership_list:+SPViewershipSchema(advertiser_group_value.getOrElse(""),ad_grp, market_share)
//    }
//    viewership_list
//  }
//
//  def getViewershipDevList(query:String):Task[List[SPViewershipDevSchema]] = Task{
//    var advertiser_group_value:Option[String] = None
//    var dev_ad_grp:Option[Double] = None
//    var dev_market_share:Option[Double] = None
//    var dev_viewership_list: List[SPViewershipDevSchema] =List()
//
//    for (row <- getDataFromBQ(query)) {
//      advertiser_group_value={if (!row.get(0).isNull) Some(row.get(0).getStringValue)  else None}
//      dev_ad_grp={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      dev_market_share={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      dev_viewership_list = dev_viewership_list:+SPViewershipDevSchema(advertiser_group_value.getOrElse(""),dev_ad_grp, dev_market_share)
//    }
//    dev_viewership_list
//  }
//}
