//package oldcode
//
//import backends.sales_dashboard.Schema.{DealCprp, SalesDashBoardReportArgsFlags}
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object DealCprpObject {
//
//  def apply(args: SalesDashBoardReportArgsFlags)
//  : Task[DealCprp] = Task {
//
//    //println(s"=====Deals CPRP object is started ======")
//
//
//    val query = DealCprpSql.queryBuilder(args)
//
//
//    var total_revenue:Option[Double] = None
//    var total_ad_grp:Option[Double] = None
//    var deals_cprp:Option[Double] = None
//    var total_deviation_revenue:Option[Double] = None
//    var total_deviation_ad_grp:Option[Double] = None
//    var deviation_deals_cprp:Option[Double] = None
//    var total_percentage_deviation:Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//      total_revenue={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      total_ad_grp={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      total_deviation_revenue={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      total_deviation_ad_grp={if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      deals_cprp={if (!row.get(4).isNull) Some(row.get(4).getDoubleValue)  else None}
//      deviation_deals_cprp={if (!row.get(5).isNull) Some(row.get(5).getDoubleValue)  else None}
//      total_percentage_deviation={if (!row.get(6).isNull) Some(row.get(6).getDoubleValue)  else None}
//    }
//
//    //println(s"=====Deals CPRP object is ended ======")
//    DealCprp(total_revenue,total_ad_grp,deals_cprp,total_deviation_revenue,total_deviation_ad_grp,deviation_deals_cprp,total_percentage_deviation)
//  }
//}
