//package backends.sales_dashboard.cards
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, InfoFillsMarketShareResult, Period, PricingToDateDataResult}
//import backends.sales_dashboard.metrics._
//import backends.sales_dashboard.metrics.bq.{FairShareObject, FctFillsObject, InfoObject, SPMarketShareObject}
//import org.slf4j.{Logger, LoggerFactory}
//import zio.Task
//
//object InfoFillsMarketShare {
//  val logger: Logger = LoggerFactory.getLogger(getClass.getName)
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  :Task[InfoFillsMarketShareResult]={
//    val t1 = System.nanoTime
//    val info = InfoObject(channel)
//    val fills = FctFillsObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular)
//    val fair_share = FairShareObject(channel, period, pt_npt, impact_regular)
//    val market_share = SPMarketShareObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//
//    val res = for{
//      (((info,fills),market_share),fair_share) <- info.zipPar(fills).zipPar(market_share).zipPar(fair_share)
//      _                                        <- Task{logger.info(s"InfoFillsMarketShare Api fetched data in ${(System.nanoTime - t1) / 1e9d}")}
//      final_res                                <- Task{InfoFillsMarketShareResult(Some(info), Some(fills), Some(market_share), Some(fair_share) )}
//      _                                        <- Task{logger.info(s"InfoFillsMarketShare Api in total took ${(System.nanoTime - t1) / 1e9d}")}
//    } yield final_res
//    res
//  }
//}