//package oldcode
//
//import backends.sales_dashboard.Schema.{RoCprp, SalesDashBoardReportArgsFlags}
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object RoCprpObject {
//
//
//  def apply(args:  SalesDashBoardReportArgsFlags)
//  : Task[RoCprp] = Task {
//    //println(s"=====RO CPRP object is started at ======")
//
//    val query = RoCprpSql.queryBuilder(args)
//
//    var total_revenue:Option[Double] = None
//    var total_ad_grp:Option[Double] = None
//    var ro_cprp:Option[Double] = None
//    var total_deviation_revenue:Option[Double] = None
//    var total_deviation_ad_grp:Option[Double] = None
//    var deviation_ro_cprp:Option[Double] = None
//    var total_percentage_deviation:Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//      total_revenue={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      total_ad_grp={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      total_deviation_revenue={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      total_deviation_ad_grp={if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      ro_cprp={if (!row.get(4).isNull) Some(row.get(4).getDoubleValue)  else None}
//      deviation_ro_cprp={if (!row.get(5).isNull) Some(row.get(5).getDoubleValue)  else None}
//      total_percentage_deviation={if (!row.get(6).isNull) Some(row.get(6).getDoubleValue)  else None}
//    }
//    //println(s"=====RO CPRP object is ended at ======")
//
//    RoCprp(total_revenue= total_revenue, total_ad_grp= total_ad_grp, ro_cprp= ro_cprp, total_deviation_revenue= total_deviation_revenue, total_deviation_ad_grp=total_deviation_ad_grp, deviation_ro_cprp=deviation_ro_cprp, total_percentage_deviation= total_percentage_deviation)
//  }
//}
