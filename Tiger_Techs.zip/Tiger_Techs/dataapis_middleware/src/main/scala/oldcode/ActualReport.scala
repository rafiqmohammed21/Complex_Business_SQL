//package backends.sales_dashboard
//
//import java.io.File
//import java.time.LocalDateTime
//import java.time.format.DateTimeFormatter
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics._
//import utils.CsvGenerator.writeToCsv
//import utils.GcsUpload.uploadFile
//import zio.Task
//
//
//object ActualReport {
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  :Task[List[RevenueReportSchema]] = {
//
//    val revenues_task         = RevenueObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//    val grp_market_share_task = GrpMarketShareObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//    val exit_cprp_task        = ExitCprpObject(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//
//    val res = for{
//      grouped_task  <- revenues_task.zipPar(grp_market_share_task).zipPar(exit_cprp_task)
//      final_results <- getRevenueReportList(advertiser_group,grouped_task._1._1, grouped_task._1._2, grouped_task._2)
//    } yield (final_results)
//
//    res
//  }
//
//  def asGcsFile(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  :Task[String] = {
//
//    val path = for{
//      final_results <- apply(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)
//      final_path <- getUploadPath(final_results)
//    } yield (final_path)
//
//    path
//  }
//
//  def getUploadPath(results: List[RevenueReportSchema]): Task[String] = Task {
//    val header: String = "Advertisers,Revenue,Revenue Deviation,GRP,GRP Deviation,Market Share,Market Share Deviation,Exit CPRP"
//    var list_of_objects:List[List[String]] = List()
//    results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.revenue.getOrElse("").toString
//      ,x.revenue_deviation.getOrElse("").toString,x.grp.getOrElse("").toString
//      ,x.grp_deviation.getOrElse("").toString,x.market_share.getOrElse("").toString
//      ,x.market_share_deviation.getOrElse("").toString,x.exit_cprp.getOrElse("").toString))
//    val file_name = f"Revenue_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
//    val file_path = f"/tmp/$file_name"
//    writeToCsv(file_path,header,list_of_objects)
//    val res:String = uploadFile(file_path, file_name)
//    new File(file_path).delete()
//    res
//  }
//
//  def getRevenueReportList(advertiser_group: Option[List[String]],revs: List[Revenue], grp_market_shares: List[GrpMarketShare], exit_cprps: List[ExitCprp]): Task[List[RevenueReportSchema]] = Task {
//    var mapFR: Map[String, RevenueReportSchema] = Map()
//
//    for (elem <- revs) {
//      if (elem.advertiser_group != null){
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None ) {
//          mapFR = mapFR + (elem.advertiser_group -> RevenueReportSchema(
//            advertisers = elem.advertiser_group,
//            revenue = elem.revenue,
//            revenue_deviation = elem.percentage_deviation
//
//          ))
//        } else {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            revenue = elem.revenue,
//            revenue_deviation = elem.percentage_deviation
//          ))
//        }
//      }
//      }
//
//
//    for (elem <- grp_market_shares) {
//      if (elem.advertiser_group != null) {
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None) {
//          mapFR = mapFR + (elem.advertiser_group -> RevenueReportSchema(
//            advertisers = elem.advertiser_group,
//            grp = elem.grp_revenue,
//            grp_deviation = elem.grp_percentage_deviation,
//            market_share = elem.market_share_revenue,
//            market_share_deviation = elem.market_share_percentage_deviation
//          ))
//        } else  {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            grp = elem.grp_revenue,
//            grp_deviation = elem.grp_percentage_deviation,
//            market_share = elem.market_share_revenue,
//            market_share_deviation = elem.market_share_percentage_deviation
//          ))
//        }
//      }
//    }
//
//    for (elem <- exit_cprps) {
//      if (elem.advertiser_group != null) {
//        val fr = mapFR.get(elem.advertiser_group)
//        if (fr == None) {
//          mapFR = mapFR + (elem.advertiser_group -> RevenueReportSchema(
//            advertisers = elem.advertiser_group,
//            exit_cprp = elem.exit_cprp
//          ))
//        } else {
//          mapFR = mapFR + (elem.advertiser_group -> fr.get.copy(
//            exit_cprp = elem.exit_cprp
//          ))
//        }
//      }
//    }
//
//    mapFR.values.toList.filter(x=> advertiser_group.get.contains(x.advertisers))
//  }
//}