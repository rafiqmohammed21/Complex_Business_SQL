//package backends.sales_dashboard.metrics.bq
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, NewExitCprp, Period}
//import backends.sales_dashboard.metrics.Utils._
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object SPExitCprpObject {
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[NewExitCprp] = Task {
//
//    //println(s"=====Exit object is started at ======")
//
//    var deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//    }
//
//    var lag_deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      val lag_deviation_period = getLagDates(x.start_date,x.end_date)
//      lag_deviation_period_dates_arr = lag_deviation_period_dates_arr ++ Array(lag_deviation_period._1,lag_deviation_period._2)
//    }
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//
//  val query  =
//    s"""CALL ${getSPName("sp_exit_cprp")}('${period.start_date}',
//       |'${period.end_date}',
//       |${getArrayOfStringForDates(deviation_period_dates_arr)},
//       |'${channel.toLowerCase}',
//       |${gerArrayOfStringForString(regions.toArray)},
//       |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//       |${value_for_advertiser_group.map(_.toLower)},
//       |${value_for_deviation_advertiser_group.map(_.toLower)},
//       |${value_for_agency.map(_.toLower)},
//       |${value_for_sub_agency.map(_.toLower)},
//       |$all_region_selected,
//       |$all_advertiser_selected,
//       |$all_agency_selected,
//       |$all_sub_agency_selected
//       |)""".stripMargin
//
//    var total_revenue: Option[Double] = None
//    var total_ad_grp: Option[Double] = None
//    var total_deviation_revenue: Option[Double] = None
//    var total_deviation_ad_grp: Option[Double] = None
//    var exit_cprp: Option[Double] = None
//    var deviation_exit_cprp: Option[Double] = None
//    var percentage_deviation: Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//
//      total_revenue={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      total_ad_grp={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      total_deviation_revenue={if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      total_deviation_ad_grp={if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      exit_cprp={if (!row.get(4).isNull) Some(row.get(4).getDoubleValue)  else None}
//      deviation_exit_cprp={if (!row.get(5).isNull) Some(row.get(5).getDoubleValue)  else None}
//      percentage_deviation={if (!row.get(6).isNull) Some(row.get(6).getDoubleValue)  else None}
//    }
//    //println(s"=====Exit object is ended at ======")
//    NewExitCprp(total_revenue, total_ad_grp, total_deviation_revenue, total_deviation_ad_grp, exit_cprp, deviation_exit_cprp, percentage_deviation)
//  }
//}
