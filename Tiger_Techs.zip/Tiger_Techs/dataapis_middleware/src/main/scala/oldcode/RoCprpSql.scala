//package oldcode
//
//import backends.sales_dashboard.Schema.SalesDashBoardReportArgsFlags
//import backends.sales_dashboard.metrics.Utils._
//
//object RoCprpSql {
//
//
//  def queryBuilder(args:  SalesDashBoardReportArgsFlags)
//  : String =  {
//    //println(s"=====RO CPRP object is started at ======")
//
//    var deviation_period_dates_arr :Array[String]= Array()
//    args.deviation_period.foreach{ x =>
//        deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//      }
//    val lag_period = getLagDates(args.period.start_date,args.period.end_date)
//
//    var lag_deviation_period_dates_arr :Array[String]= Array()
//    args.deviation_period.foreach{ x =>
//      val lag_deviation_period = getLagDates(x.start_date,x.end_date)
//      lag_deviation_period_dates_arr = lag_deviation_period_dates_arr ++ Array(lag_deviation_period._1,lag_deviation_period._2)
//    }
//
//    val value_for_agency = getValueForAgency(args.agency)
//    val value_for_sub_agency = getValueForSubAgency(args.sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(args.advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(args.deviation_advertiser_group)
//    val query =
//      s""" CALL ${getSPName("sp_ro_cprp")}('${args.period.start_date}',
//         |'${args.period.end_date}',
//         |${getArrayOfStringForDates(deviation_period_dates_arr)},
//         |'${lag_period._1}',
//         |'${lag_period._2}',
//         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
//         |'${args.channel}',
//         |${gerArrayOfStringForString(args.regions.toArray)},
//         |'${args.pt_npt.mkString("_")}',
//         |$value_for_advertiser_group,
//         |$value_for_deviation_advertiser_group,
//         |$value_for_agency,
//         |$value_for_sub_agency,
//         |${args.all_region_selected},
//         |${args.all_advertiser_selected},
//         |${args.all_agency_selected},
//         |${args.all_sub_agency_selected}
//         |); """.stripMargin
//    query
//     }
//}
