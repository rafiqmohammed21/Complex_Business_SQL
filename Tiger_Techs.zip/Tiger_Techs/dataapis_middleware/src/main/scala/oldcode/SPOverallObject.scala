//package backends.sales_dashboard.metrics.bq
//
//import java.time.LocalDate
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics.Utils._
//import org.json4s.DefaultFormats
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object SPOverallObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], overall_matrics:Boolean=false,all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[DataResult] =  {
//    //getDataFromPostgres()
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//    var deviation_period_dates_arr :Array[(String,String)]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array((x.start_date,x.end_date))
//    }
//    val period_arr :Array[(String,String)] = Array((period.start_date,period.end_date))
//
//    val query = s""" CALL ${getSPName("sp_overall_metrics")}('${channel.toLowerCase}',
//                   |${getArrayOfStructOfStringForDates(period_arr)},
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//                   |$value_for_impact_regular,
//                   |$value_for_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency,
//                   |$all_region_selected,
//                   |$all_advertiser_selected,
//                   |$all_agency_selected,
//                   |$all_sub_agency_selected
//                   |); """.stripMargin
//
//    val query_dev = s""" CALL ${getSPName("sp_overall_metrics")}('${channel.toLowerCase}',
//                       |${getArrayOfStructOfStringForDates(deviation_period_dates_arr)},
//                       |${gerArrayOfStringForString(regions.toArray)},
//                       |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//                       |$value_for_impact_regular,
//                       |$value_for_deviation_advertiser_group,
//                       |$value_for_agency,
//                       |$value_for_sub_agency,
//                       |$all_region_selected,
//                       |$all_advertiser_selected,
//                       |$all_agency_selected,
//                       |$all_sub_agency_selected
//                       |); """.stripMargin
//
//    val overall_task = getOverallList(query)
//    val dev_overall_task = getOverallDevList(query_dev)
//    var final_results: List[SPOverallSchemaJoined] = List()
//    var rev_results: List[RevenueReportSchema] = List()
//    var funnel_results: List[FunnelReportSchema] = List()
//    val res = for{
//      (a:List[SPOverallSchema],b:List[SPOverallDevSchema])  <- overall_task.zipPar(dev_overall_task)
//      final_results <- getOverallJoinedList(advertiser_group,a, b,period,deviation_period)
//      data <- Task{
//        final_results.foreach{
//          elem =>
//            val rev = RevenueReportSchema(
//              advertisers = elem.advertiser_group,
//              revenue = elem.revenue,
//              revenue_deviation = elem.dev_revenue,
//              grp = elem.grp,
//              grp_deviation = elem.dev_grp,
//              market_share = elem.market_share,
//              market_share_deviation = elem.dev_market_share,
//              exit_cprp = elem.exit_cprp
//            )
//            val funnel = FunnelReportSchema(
//              advertisers = elem.advertiser_group,
//              projection = elem.projection,
//              projection_deviation = elem.dev_projection,
//              deal = elem.deals,
//              deal_deviation = elem.dev_deals,
//              ro = elem.ro,
//              ro_deviation = elem.dev_ro,
//              revenue = elem.revenue
//            )
//            rev_results ++= List(rev)
//            funnel_results  ++= List(funnel)
//        }
//        DataResult(revenue = rev_results, funnel = funnel_results)
//      }
//    } yield data
//    res
//  }
//
//  def getOverallJoinedList(par_advertiser_group:Option[List[String]],overall:List[SPOverallSchema],dev_overall:List[SPOverallDevSchema],period: Period,dev_period: List[Period])
//  : Task[List[SPOverallSchemaJoined]] = Task {
//    var mapOverallJoined: Map[String, SPOverallSchemaJoined] = Map()
//    for (elem <- overall) { //advertiser_group:String,	revenue:Option[Double],grp:Option[Double],	market_share:Option[Double],	exit_cprp:Option[Double], projection:Option[Double], deals:Option[Double],ro:Option[Double]
//      if (elem.advertiser_group != "") {
//        val overall_joined = mapOverallJoined.get(elem.advertiser_group)
//        if (overall_joined == None) {
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> SPOverallSchemaJoined(
//            advertiser_group = elem.advertiser_group,
//            revenue = elem.revenue,
//            grp = elem.grp,
//            market_share = elem.market_share,
//            exit_cprp = elem.exit_cprp,
//            projection = elem.projection,
//            deals = elem.deals,
//            ro = elem.ro,
//            actual_revenue = elem.actual_revenue,
//            booked_revenue = elem.booked_revenue
//          ))
//        } else {
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> overall_joined.get.copy(
//            revenue = Some(math rint (elem.revenue.get * 100)/100),
//            grp = elem.grp,
//            market_share = elem.market_share,
//            exit_cprp = elem.exit_cprp,
//            projection = elem.projection,
//            deals = elem.deals,
//            ro = elem.ro
//          ))
//        }
//      }
//    }
//
//    for (elem <- dev_overall) {
//      if (elem.advertiser_group != "") {
//        val overall_joined = mapOverallJoined.get(elem.advertiser_group)
//        if (overall_joined != None) {
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> overall_joined.get.copy(
//            dev_revenue = elem.dev_revenue,
//            dev_grp = elem.dev_grp,
//            dev_market_share = elem.dev_market_share,
//            dev_exit_cprp = elem.dev_exit_cprp,
//            dev_projection = elem.dev_projection,
//            dev_deals = elem.dev_deals,
//            dev_ro = elem.dev_ro
//          ))
//        }
//      }
//    }
//
//    //mapOverallJoined.values.toList
//    var finalList: List[SPOverallSchemaJoined] = mapOverallJoined.values.toList
//    for (element <- finalList) {
//      val period_days = getDateArray(period.start_date, period.end_date).length
//      var dev_period_arr :Array[String]= Array()
//      dev_period.foreach{ x =>
//        dev_period_arr = dev_period_arr ++ getDateArray(x.start_date,x.end_date)}
//      val dev_period_days = dev_period_arr.length
//
//      element.dev_revenue = element.revenue match {
//        case None => None
//        case Some(_) => element.dev_revenue match {
//          case None => None
//          case Some(_) => {
//            val today_date = LocalDate.now()
//            if(stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
//              val (actual_period, booked_period) = getActualPeriod(period)
//              val actual_length = getDateArray(actual_period.start_date, actual_period.end_date).length
//
//              val booked_length = getDateArray(booked_period.start_date, booked_period.end_date).length
//
//              val actual_revenue = element.actual_revenue match {
//                case None => 0
//                case Some(_) => element.actual_revenue.get
//              }
//
//              val booked_revenue = element.booked_revenue match {
//                case None => 0
//                case Some(_) => element.booked_revenue.get
//              }
//
//              val dev_revenue = element.dev_revenue match {
//                case None => 0
//                case Some(_) => element.dev_revenue.get
//              }
//
//              val numerator = Some(((actual_revenue/actual_length) + (booked_revenue/booked_length)) - (dev_revenue / dev_period_days))
//
//              val denominator = Some(dev_revenue / dev_period_days)
//
//              Some((math rint (numerator.get/denominator.get) * 10000)/100)
//
//            } else {
//              Some((math rint (((element.revenue.get / period_days) - (element.dev_revenue.get / dev_period_days)) / (element.dev_revenue.get / dev_period_days)) * 10000)/100)
//            }
//          }
//        }
//      }
//
//      element.dev_deals = element.deals match {
//        case None => None
//        case Some(_) => element.dev_deals match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.deals.get / period_days) - (element.dev_deals.get / dev_period_days)) / (element.dev_deals.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_exit_cprp = element.exit_cprp match {
//        case None => None
//        case Some(_) => element.dev_exit_cprp match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.exit_cprp.get / period_days) - (element.dev_exit_cprp.get / dev_period_days)) / (element.dev_exit_cprp.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_projection = element.projection match {
//        case None => None
//        case Some(_) => element.dev_projection match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.projection.get / period_days) - (element.dev_projection.get / dev_period_days)) / (element.dev_projection.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_ro = element.ro match {
//        case None => None
//        case Some(_) => element.dev_ro match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.ro.get / period_days) - (element.dev_ro.get / dev_period_days)) / (element.dev_ro.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_grp = element.grp match {
//        case None => None
//        case Some(_) => element.dev_grp match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.grp.get / period_days) - (element.dev_grp.get / dev_period_days)) / (element.dev_grp.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_market_share = element.market_share match {
//        case None => None
//        case Some(_) => element.dev_market_share match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.market_share.get ) - (element.dev_market_share.get )) / (element.dev_market_share.get)) * 10000)/100))
//        }
//      }
//
//      element.revenue = element.revenue match {
//        case None => None
//        case Some(_) => Some(math.rint(element.revenue.get * 100)/100)
//      }
//
//      element.grp = element.grp match {
//        case None => None
//        case Some(_) => Some(math.rint(element.grp.get * 100)/100)
//      }
//
//      element.market_share = element.market_share match {
//        case None => None
//        case Some(_) => Some(math.rint(element.market_share.get * 100)/100)
//      }
//
//      element.exit_cprp = element.exit_cprp match {
//        case None => None
//        case Some(_) => Some(math.rint(element.exit_cprp.get * 100)/100)
//      }
//
//      element.projection = element.projection match {
//        case None => None
//        case Some(_) => Some(math.rint(element.projection.get * 100)/100)
//      }
//
//      element.deals = element.deals match {
//        case None => None
//        case Some(_) => Some(math.rint(element.deals.get * 100)/100)
//      }
//
//      element.ro = element.ro match {
//        case None => None
//        case Some(_) => Some(math.rint(element.ro.get * 100)/100)
//      }
//    }
//
//    finalList
//  }
//  def getOverallList(query:String):Task[List[SPOverallSchema]] = Task{
//    var advertiser_group_value:Option[String] = None
//    var revenue:Option[Double] = None
//    var grp:Option[Double] = None
//    var market_share:Option[Double] = None
//    var exit_cprp:Option[Double] = None
//    var projection:Option[Double] = None
//    var deals:Option[Double] = None
//    var ro:Option[Double] = None
//    var actual_revenue:Option[Double] = None
//    var booked_revenue:Option[Double] = None
//    var overall_list: List[SPOverallSchema] =List()
//
//    for (row <- getDataFromBQ(query)) {
//      advertiser_group_value={if (!row.get("advertiser_group").isNull) Some(row.get("advertiser_group").getStringValue)  else None}
//      revenue={if (!row.get("revenue").isNull) Some(row.get("revenue").getDoubleValue)  else None}
//      grp={if (!row.get("grp").isNull) Some(row.get("grp").getDoubleValue)  else None}
//      market_share={if (!row.get("market_share").isNull) Some(row.get("market_share").getDoubleValue)  else None}
//      exit_cprp={if (!row.get("exit_cprp").isNull) Some(row.get("exit_cprp").getDoubleValue)  else None}
//      projection={if (!row.get("projection").isNull) Some(row.get("projection").getDoubleValue)  else None}
//      deals={if (!row.get("deals").isNull) Some(row.get("deals").getDoubleValue)  else None}
//      ro={if (!row.get("ro").isNull) Some(row.get("ro").getDoubleValue)  else None}
//      actual_revenue={if (!row.get("actual_revenue").isNull) Some(row.get("actual_revenue").getDoubleValue)  else None}
//      booked_revenue={if (!row.get("booked_revenue").isNull) Some(row.get("booked_revenue").getDoubleValue)  else None}
//      overall_list = overall_list:+SPOverallSchema(advertiser_group_value.getOrElse(""),revenue,grp,market_share,	exit_cprp, projection, deals,ro, actual_revenue, booked_revenue	)
//    }
//    overall_list
//  }
//
//  def getOverallDevList(query_dev:String):Task[List[SPOverallDevSchema]] = Task{
//    var dev_advertiser_group_value:Option[String] = None
//    var dev_revenue:Option[Double] = None
//    var dev_grp:Option[Double] = None
//    var dev_market_share:Option[Double] = None
//    var dev_exit_cprp:Option[Double] = None
//    var dev_projection:Option[Double] = None
//    var dev_deals:Option[Double] = None
//    var dev_ro:Option[Double] = None
//    var dev_overall_list: List[SPOverallDevSchema] =List()
//
//    for (row <- getDataFromBQ(query_dev)) {
//      dev_advertiser_group_value={if (!row.get("advertiser_group").isNull) Some(row.get("advertiser_group").getStringValue)  else None}
//      dev_revenue = {if (!row.get("revenue").isNull) Some(row.get("revenue").getDoubleValue)  else None}
//      dev_grp={if (!row.get("grp").isNull) Some(row.get("grp").getDoubleValue)  else None}
//      dev_market_share={if (!row.get("market_share").isNull) Some(row.get("market_share").getDoubleValue)  else None}
//      dev_exit_cprp={if (!row.get("exit_cprp").isNull) Some(row.get("exit_cprp").getDoubleValue)  else None}
//      dev_projection={if (!row.get("projection").isNull) Some(row.get("projection").getDoubleValue)  else None}
//      dev_deals={if (!row.get("deals").isNull) Some(row.get("deals").getDoubleValue)  else None}
//      dev_ro={if (!row.get("ro").isNull) Some(row.get("ro").getDoubleValue)  else None}
//      dev_overall_list = dev_overall_list:+SPOverallDevSchema(dev_advertiser_group_value.getOrElse(""),dev_revenue,dev_grp,dev_market_share,	dev_exit_cprp, dev_projection, dev_deals,dev_ro	)
//    }
//    dev_overall_list
//  }
//
//}
