//package backends.sales_dashboard.cards
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period, PricingToDateDataResult, SalesDashBoardReportArgsFlags}
//import zio.Task
//import backends.sales_dashboard.metrics.bq.{DealCprpObject, ExecutedCprpObject, RoCprpObject}
//
//object PricingToDate {
//  def apply(args: SalesDashBoardReportArgsFlags)
//  :Task[PricingToDateDataResult]={
//
//    val deals_cprp = DealCprpObject( args)
//    val ro_cprp = RoCprpObject(args)
//    val executed_cprp = ExecutedCprpObject(args)
//
//    val res = for{
//      ((deals_cprp,ro_cprp),executed_cprp)  <- deals_cprp.zipPar(ro_cprp).zipPar(executed_cprp)
//      final_res <- Task{PricingToDateDataResult( Some(deals_cprp), Some(ro_cprp),Some(executed_cprp) )}
//    } yield final_res
//    res
//  }
//}