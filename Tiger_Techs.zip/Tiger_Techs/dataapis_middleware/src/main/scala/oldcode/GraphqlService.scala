//import backends.epm_entertainment_reports.total_revenue
//import backends.epm_entertainment_reports.revenue_trends_by_channel
//import zio.Task
//
//
//class GraphqlService() {
//
//
//  def getTotalRevenue(period: total_revenue.Schema.Period, channels: List[String], businessUnits: List[String])
//  : Task[total_revenue.Schema.TotalRevenueResult] = {
//    for {
//      a <- total_revenue.Result.getDimensions(period, channels, businessUnits)
//      //      b <- total_revenue.Result.getMetrics(period,channels,businessUnits)
//    } yield total_revenue.Schema.TotalRevenueResult(a)
//  }
//
//
//  def getRevenueByChannel(period: revenue_trends_by_channel.Schema.Period, channels: List[String], businessUnits: List[String], layout: String)
//  : Task[revenue_trends_by_channel.Schema.RevenueByChannelResult] = {
//    for {
//      a <- revenue_trends_by_channel.Result.getDimensions(period, channels, businessUnits, layout)
//      //      b <- total_revenue.Result.getMetrics(period,channels,businessUnits)
//    } yield revenue_trends_by_channel.Schema.RevenueByChannelResult(a)
//  }
//
//}
//
//object GraphqlService {
//  def make(): Task[GraphqlService] =  Task(new GraphqlService())
//}