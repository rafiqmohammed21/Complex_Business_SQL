//package backends.sales_dashboard.cards
//
//import java.time.LocalDate
//
//import backends.sales_dashboard.Schema._
//import backends.sales_dashboard.metrics.Utils._
//import cats.effect.{IO, Resource}
//import doobie.Fragment
//import doobie.hikari.HikariTransactor
//import zio.Task
//import doobie.implicits._
//import java.text.SimpleDateFormat
//import zio.interop.catz._
//
//import scala.util.Try
//
//object OverAllMetricsPG {
//
//  def apply(transactor: HikariTransactor[Task], channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[DataResultWithTotal] =  {
//    val (actual_date,booked_date) = getActualPeriod(period)
//    val period_arr :Array[(String,String)] = Array((period.start_date,period.end_date))
//    val value_for_impact_regular = getValueForImpactRegularPG(impact_regular)
//    val value_for_advertiser_group = getValueForAdvertiserGroupPG(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroupPG(deviation_advertiser_group)
//    val value_for_agency = getValueForAgencyPG(agency)
//    val value_for_sub_agency = getValueForSubAgencyPG(sub_agency)
//    var deviation_period_dates_arr :Array[(String,String)]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array((x.start_date,x.end_date))
//    }
//
//    val number_of_days_actualised = getDateDiffOfStringDates(actual_date.start_date,actual_date.end_date)+1
//    val number_of_days_month = if (getDateDiffOfStringDates(booked_date.end_date, actual_date.start_date)>0) {
//      getDateDiffOfStringDates(actual_date.start_date, actual_date.end_date)+1
//    }
//    else {
//      getDateDiffOfStringDates(actual_date.start_date, booked_date.end_date)+1
//    }
//    val query_filter_fr  =
//      s""" ('${channel.toLowerCase}',
//         |${getArrayOfStructOfStringForDatesPG(period_arr)},
//         |${gerArrayOfStringForStringPG(regions.toArray)},
//         |${gerArrayOfStringForStringPG(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//         |$value_for_impact_regular,
//         |$value_for_advertiser_group,
//         |$value_for_agency,
//         |$value_for_sub_agency,
//         |$all_region_selected,
//         |$all_advertiser_selected,
//         |$all_agency_selected,
//         |$all_sub_agency_selected) """.stripMargin
//
//    val query_filter_fr_dev  =
//      s""" ('${channel.toLowerCase}',
//         |${getArrayOfStructOfStringForDatesPG(deviation_period_dates_arr)},
//         |${gerArrayOfStringForStringPG(regions.toArray)},
//         |${gerArrayOfStringForStringPG(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//         |$value_for_impact_regular,
//         |$value_for_deviation_advertiser_group,
//         |$value_for_agency,
//         |$value_for_sub_agency,
//         |$all_region_selected,
//         |$all_advertiser_selected,
//         |$all_agency_selected,
//         |$all_sub_agency_selected) """.stripMargin
//
//    val func_str = fr""" select out_advertiser_group, out_revenue, out_grp, out_market_share, out_exit_cprp, out_projection, out_deals, out_ro, out_actual_revenue, out_booked_revenue
//                             from "func_overall_metrics" """.stripMargin
//
//    val func_str_dev = fr""" select out_advertiser_group, out_revenue, out_grp, out_market_share, out_exit_cprp, out_projection, out_deals, out_ro, out_actual_revenue
//                              from "func_overall_metrics" """.stripMargin
//
//    def getOverallFromPostgres(transector :  HikariTransactor[Task], query_sql:Fragment):Task[List[SPOverallSchema]]=
//      query_sql.query[SPOverallSchema].to[List].transact(transector)
//
//
//    def getOverallDevFromPostgres(transector :  HikariTransactor[Task], query_sql:Fragment):Task[List[SPOverallDevSchemaWithActual]]=
//      query_sql.query[SPOverallDevSchemaWithActual].to[List].transact(transector)
//
//
//    val overall_task = getOverallFromPostgres(transactor, func_str++Fragment.const(query_filter_fr))
//    val dev_overall_task = getOverallDevFromPostgres(transactor,func_str_dev++Fragment.const(query_filter_fr_dev))
//    var rev_results: List[RevenueReportSchema] = List()
//    var funnel_results: List[FunnelReportSchema] = List()
//    var deal_total : Option[Double]  = None
//    var projection_total : Option[Double]  = None
//    var ro_total : Option[Double]  = None
//    var actual_total : Option[Double]  = None
//    var dev_actual_total : Option[Double]  = None
//    var booked_total : Option[Double]  = None
//
//    def getDevDateDiff():Int = {
//      var total_no_days = 0
//      deviation_period.foreach{ period=>
//        total_no_days+=getDateDiffOfStringDates(period.start_date,period.end_date)+1
//      }
//      total_no_days
//    }
//
//    def getDeviationPercent(value:Option[Double], dev_value:Option[Double]):Option[Double]={
//      val date_diff_int = getDateDiffOfStringDates(period.start_date, period.end_date)+1
//      val date_diff_int_dev = getDevDateDiff()
//      val value_per_day = Try(value.get/date_diff_int).toOption
//      val dev_value_per_day = Try(dev_value.get/date_diff_int_dev).toOption
//      val result = Try((value_per_day.get - dev_value_per_day.get)*100/dev_value_per_day.get).toOption
//      val result_rounded = Try(math.rint(result.get*100)/100).toOption
//      result_rounded
//    }
//
//    val res = for{
//      (a:List[SPOverallSchema],b:List[SPOverallDevSchemaWithActual])  <- overall_task.zipPar(dev_overall_task)
//      (final_results,internal_actual, internal_booked,  internal_total, deal_sum, ro_sum ,projection_sum ,actual_sum , booked_sum, dev_deal_sum, dev_ro_sum, dev_projection_sum ,dev_actual_sum)<- getOverallJoinedList(advertiser_group,a, b,period,deviation_period)
//      data <- Task{
//        final_results.foreach{
//          elem =>
//            val rev = RevenueReportSchema(
//              advertisers = elem.advertiser_group,
//              revenue = elem.revenue,
//              revenue_deviation = elem.dev_revenue,
//              grp = elem.grp,
//              grp_deviation = elem.dev_grp,
//              market_share = elem.market_share,
//              market_share_deviation = elem.dev_market_share,
//              exit_cprp = elem.exit_cprp
//            )
//            val funnel = FunnelReportSchema(
//              advertisers = elem.advertiser_group,
//              projection = elem.projection,
//              projection_deviation = elem.dev_projection,
//              deal = elem.deals,
//              deal_deviation = elem.dev_deals,
//              ro = elem.ro,
//              ro_deviation = elem.dev_ro,
//              revenue = elem.revenue
//            )
//
//            rev_results ++= List(rev)
//            funnel_results  ++= List(funnel)
//
//            deal_total =  (deal_total ++ elem.deals).reduceOption(_ + _)
//            projection_total = (projection_total ++ elem.projection).reduceOption(_ + _)
//            ro_total = (ro_total ++ elem.ro).reduceOption(_ + _)
//            actual_total = (actual_total ++ elem.actual_revenue).reduceOption(_ + _)
//            booked_total = (booked_total ++ elem.booked_revenue).reduceOption(_ + _)
//        }
//
//        //deal_sum, ro_sum ,projection_sum ,actual_sum , booked_sum,
//        val final_deals = Try(math.rint(deal_sum.get * 100) / 100).toOption
//        val final_projection = Try(math.rint(projection_sum.get * 100) / 100).toOption
//        val final_ro = Try(math.rint(ro_sum.get * 100) / 100).toOption
//        val final_actual_total = Try(math.rint(actual_sum.get * 100) / 100).toOption
//        val (per_dev_actual_revenue,per_dev_revenue) = getActualBookedPercentageDifference(actual_sum,booked_sum,dev_actual_sum,period,deviation_period)
//        val sum_actual_dev_per = Try(math.rint(per_dev_actual_revenue.get * 100) / 100).toOption
//        val sum_deals_dev_per = getDeviationPercent(deal_sum,dev_deal_sum)
//        val sum_projection_dev_per =  getDeviationPercent(projection_sum,dev_projection_sum)
//        val sum_ro_dev_per = getDeviationPercent(ro_sum,dev_ro_sum)
//        val final_revenue_total = Try(math.rint((actual_sum ++ booked_sum).reduceOption(_ + _).get *100)/100).toOption
//        println(
//          s""" deal_total is $deal_total and deal_sum is $deal_sum dev_deal_sum is $dev_deal_sum  sum_deals_dev_per is $sum_deals_dev_per
//             | projection_total is $projection_total  projection_sum is $projection_sum  dev_projection_sum is $dev_projection_sum  sum_projection_dev_per is $sum_projection_dev_per
//             | ro_total is $ro_total  ro_sum is $ro_sum dev_ro_sum is $dev_ro_sum  sum_ro_dev_per is $sum_ro_dev_per
//             | actual_total is $actual_total  actual_sum is $actual_sum  dev_actual_sum is $dev_actual_sum  sum_actual_dev_per is $sum_actual_dev_per
//             | booked_total is $booked_total booked_sum is $booked_sum final_revenue_total is $final_revenue_total""".stripMargin)
//
//        DataResultWithTotal(
//          revenue = rev_results,
//          funnel = funnel_results,
//
//          total = TotalRevenueMetrics(
//            deals = Some(PGDeals(final_deals,None,sum_deals_dev_per)),
//            projection = Some(PGProjection(final_projection,None, sum_projection_dev_per ) ),
//            ro = Some(PGRo(final_ro,None, sum_ro_dev_per )),
//            actual_booked = Some(PGActualBooked( final_actual_total,None, sum_actual_dev_per, final_revenue_total,None,None, Some(number_of_days_actualised), Some(number_of_days_month ),Try(math.rint(internal_actual.get*100)/100).toOption, Try(math.rint(internal_total.get*100)/100 ).toOption))
//          )
//        )
//      }
//    } yield data
//    res
//  }
//
//  def getOverallJoinedList(par_advertiser_group:Option[List[String]],overall:List[SPOverallSchema],dev_overall:List[SPOverallDevSchemaWithActual],period: Period,dev_period: List[Period])
//  : Task[(List[SPOverallSchemaJoinedWithActual], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double], Option[Double])] = Task {
//    //    println("overall is "+ overall)
//    //    println("dev overall is "+dev_overall)
//    var internal_actual : Option[Double]  = None
//    var internal_booked : Option[Double]  = None
//    var internal_total : Option[Double]  = None
//    var dev_deal_sum : Option[Double]  = None
//    var dev_ro_sum : Option[Double]  = None
//    var dev_projection_sum : Option[Double]  = None
//    var dev_actual_sum : Option[Double]  = None
//    var deal_sum : Option[Double]  = None
//    var ro_sum : Option[Double]  = None
//    var projection_sum : Option[Double]  = None
//    var actual_sum : Option[Double]  = None
//    var booked_sum : Option[Double]  = None
//
//    var mapOverallJoined: Map[String, SPOverallSchemaJoinedWithActual] = Map()
//    for (elem <- overall) {
//      if (elem.advertiser_group != "") {
//        val overall_joined = mapOverallJoined.get(elem.advertiser_group)
//        if (overall_joined == None) {
//          deal_sum = (deal_sum ++ elem.deals).reduceOption(_ + _)
//          ro_sum = (ro_sum ++ elem.ro).reduceOption(_ + _)
//          projection_sum = (projection_sum ++ elem.projection).reduceOption(_ + _)
//          actual_sum = (actual_sum ++ elem.actual_revenue).reduceOption(_ + _)
//          booked_sum = (booked_sum ++ elem.booked_revenue).reduceOption(_ + _)
//          if (elem.advertiser_group.toLowerCase == "star tv network") {
//            internal_actual = (internal_actual ++ elem.actual_revenue).reduceOption(_ + _)
//            internal_booked = (internal_booked ++ elem.booked_revenue).reduceOption(_ + _)
//            internal_total = (elem.booked_revenue ++ elem.actual_revenue).reduceOption(_ + _)
//          }
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> SPOverallSchemaJoinedWithActual(
//            advertiser_group = elem.advertiser_group,
//            revenue = elem.revenue,
//            grp = elem.grp,
//            market_share = elem.market_share,
//            exit_cprp = elem.exit_cprp,
//            projection = elem.projection,
//            deals = elem.deals,
//            ro = elem.ro,
//            actual_revenue = elem.actual_revenue,
//            booked_revenue = elem.booked_revenue
//          ))
//        } else {
//          deal_sum = (deal_sum ++ elem.deals).reduceOption(_ + _)
//          ro_sum = (ro_sum ++ elem.ro).reduceOption(_ + _)
//          projection_sum = (projection_sum ++ elem.projection).reduceOption(_ + _)
//          actual_sum = (actual_sum ++ elem.actual_revenue).reduceOption(_ + _)
//          booked_sum = (booked_sum ++ elem.booked_revenue).reduceOption(_ + _)
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> overall_joined.get.copy(
//            revenue = Try(math.rint(elem.revenue.get * 100) / 100).toOption,
//            grp = elem.grp,
//            market_share = elem.market_share,
//            exit_cprp = elem.exit_cprp,
//            projection = elem.projection,
//            deals = elem.deals,
//            ro = elem.ro,
//            actual_revenue = elem.actual_revenue,
//            booked_revenue = elem.booked_revenue
//          ))
//        }
//      }
//    }
//
//    for (elem <- dev_overall) {
//      if (elem.advertiser_group != "") {
//        val overall_joined = mapOverallJoined.get(elem.advertiser_group)
//        if (overall_joined != None) {
//          dev_deal_sum = (dev_deal_sum ++ elem.dev_deals).reduceOption(_ + _)
//          dev_ro_sum = (dev_ro_sum ++ elem.dev_ro).reduceOption(_ + _)
//          dev_projection_sum = (dev_projection_sum ++ elem.dev_projection).reduceOption(_ + _)
//          dev_actual_sum = (dev_actual_sum ++ elem.dev_actual).reduceOption(_ + _)
//          mapOverallJoined = mapOverallJoined + (elem.advertiser_group -> overall_joined.get.copy(
//            dev_revenue = elem.dev_revenue,
//            dev_grp = elem.dev_grp,
//            dev_market_share = elem.dev_market_share,
//            dev_exit_cprp = elem.dev_exit_cprp,
//            dev_projection = elem.dev_projection,
//            dev_deals = elem.dev_deals,
//            dev_ro = elem.dev_ro,
//            dev_actual_revenue = elem.dev_actual
//          ))
//        }
//        else {
//          dev_deal_sum = (dev_deal_sum ++ elem.dev_deals).reduceOption(_ + _)
//          dev_ro_sum = (dev_ro_sum ++ elem.dev_ro).reduceOption(_ + _)
//          dev_projection_sum = (dev_projection_sum ++ elem.dev_projection).reduceOption(_ + _)
//          dev_actual_sum = (dev_actual_sum ++ elem.dev_actual).reduceOption(_ + _)
//        }
//      }
//    }
//
//    //mapOverallJoined.values.toList
//    var finalList: List[SPOverallSchemaJoinedWithActual] = mapOverallJoined.values.toList
//    //println(finalList)
//    for (element <- finalList) {
//      val period_days = getDateArray(period.start_date, period.end_date).length
//      var dev_period_arr :Array[String]= Array()
//      dev_period.foreach{ x =>
//        dev_period_arr = dev_period_arr ++ getDateArray(x.start_date,x.end_date)}
//      val dev_period_days = dev_period_arr.length
//
//      element.dev_revenue = element.revenue match {
//        case None => None
//        case Some(_) => element.dev_revenue match {
//          case None => None
//          case Some(_) => {
//            val today_date = LocalDate.now()
//            if(stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
//              val (actual_period, booked_period) = getActualPeriod(period)
//              val actual_length = getDateArray(actual_period.start_date, actual_period.end_date).length
//
//              val booked_length = getDateArray(booked_period.start_date, booked_period.end_date).length
//
//              val actual_revenue = element.actual_revenue match {
//                case None => 0
//                case Some(_) => element.actual_revenue.get
//              }
//
//              val booked_revenue = element.booked_revenue match {
//                case None => 0
//                case Some(_) => element.booked_revenue.get
//              }
//
//              val dev_revenue = element.dev_revenue match {
//                case None => 0
//                case Some(_) => element.dev_revenue.get
//              }
//
//              val numerator = Some(((actual_revenue/actual_length) + (booked_revenue/booked_length)) - (dev_revenue / dev_period_days))
//
//              val denominator = Some(dev_revenue / dev_period_days)
//
//              Some((math rint (numerator.get/denominator.get) * 10000)/100)
//
//            } else {
//              Some((math rint (((element.revenue.get / period_days) - (element.dev_revenue.get / dev_period_days)) / (element.dev_revenue.get / dev_period_days)) * 10000)/100)
//            }
//          }
//        }
//      }
//
//      element.dev_deals = element.deals match {
//        case None => None
//        case Some(_) => element.dev_deals match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.deals.get / period_days) - (element.dev_deals.get / dev_period_days)) / (element.dev_deals.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_exit_cprp = element.exit_cprp match {
//        case None => None
//        case Some(_) => element.dev_exit_cprp match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.exit_cprp.get / period_days) - (element.dev_exit_cprp.get / dev_period_days)) / (element.dev_exit_cprp.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_projection = element.projection match {
//        case None => None
//        case Some(_) => element.dev_projection match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.projection.get / period_days) - (element.dev_projection.get / dev_period_days)) / (element.dev_projection.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_ro = element.ro match {
//        case None => None
//        case Some(_) => element.dev_ro match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.ro.get / period_days) - (element.dev_ro.get / dev_period_days)) / (element.dev_ro.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_grp = element.grp match {
//        case None => None
//        case Some(_) => element.dev_grp match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.grp.get / period_days) - (element.dev_grp.get / dev_period_days)) / (element.dev_grp.get / dev_period_days)) * 10000)/100))
//        }
//      }
//
//      element.dev_market_share = element.market_share match {
//        case None => None
//        case Some(_) => element.dev_market_share match {
//          case None => None
//          case Some(_) => (Some((math rint (((element.market_share.get ) - (element.dev_market_share.get )) / (element.dev_market_share.get)) * 10000)/100))
//        }
//      }
//
//      element.revenue = element.revenue match {
//        case None => None
//        case Some(_) => Some(math.rint(element.revenue.get * 100)/100)
//      }
//
//      element.grp = element.grp match {
//        case None => None
//        case Some(_) => Some(math.rint(element.grp.get * 100)/100)
//      }
//
//      element.market_share = element.market_share match {
//        case None => None
//        case Some(_) => Some(math.rint(element.market_share.get * 100)/100)
//      }
//
//      element.exit_cprp = element.exit_cprp match {
//        case None => None
//        case Some(_) => Some(math.rint(element.exit_cprp.get * 100)/100)
//      }
//
//      element.projection = element.projection match {
//        case None => None
//        case Some(_) => Some(math.rint(element.projection.get * 100)/100)
//      }
//
//      element.deals = element.deals match {
//        case None => None
//        case Some(_) => Some(math.rint(element.deals.get * 100)/100)
//      }
//
//      element.ro = element.ro match {
//        case None => None
//        case Some(_) => Some(math.rint(element.ro.get * 100)/100)
//      }
//    }
//    (finalList, internal_actual, internal_booked, internal_total, deal_sum, ro_sum ,projection_sum ,actual_sum , booked_sum, dev_deal_sum, dev_ro_sum, dev_projection_sum ,dev_actual_sum)
//  }
//
//  def getDateDiffOfStringDates(sd_str:String, ed_str:String):Int = {
//    val format = new SimpleDateFormat("yyyy-MM-dd")
//    val sd = format.parse(sd_str)
//    val ed = format.parse(ed_str)
//    val diffInDays :Int = ((ed.getTime - sd.getTime) / (1000 * 60 * 60 * 24)).asInstanceOf[Int]
//    diffInDays
//  }
//
//  def asGcsFilePath(list_of_selections: List[String], transactor:  HikariTransactor[Task], channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  :Task[ReportResult] = {
//    val task_overall = apply(transactor: HikariTransactor[Task], channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//    for {
//      a: DataResultWithTotal <- task_overall
//      revenue_list_gcs_path <- getUploadPathRevenueReport(a.revenue)
//      funnel_list_gcs_path <- getUploadPathFunnelReport(a.funnel)
//    } yield ReportResult(revenue_list_gcs_path, funnel_list_gcs_path)
//  }
//
//  //  def asGcsFilePath(list_of_selections: List[String], transactor: Resource[IO, HikariTransactor[IO]], channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], overall_matrics:Boolean=false, all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  //  :Task[ReportResult] = {
//  //    val task_overall = apply(transactor: Resource[IO, HikariTransactor[IO]], channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]], overall_matrics:Boolean, all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  //        if (list_of_selections.contains("revenue") && list_of_selections.contains("funnel")) {
//  //    for {
//  //      a: DataResultWithTotal <- task_overall
//  //      revenue_list_gcs_path <- getUploadPathRevenueReport(a.revenue)
//  //      funnel_list_gcs_path <- getUploadPathFunnelReport(a.funnel)
//  //    } yield ReportResult(revenue_list_gcs_path, funnel_list_gcs_path)
//  //  }
//  //      else if (list_of_selections.contains("funnel"))
//  //        for {
//  //          a: DataResultWithTotal <- task_overall
//  //          funnel_list_gcs_path <- getUploadPathFunnelReport(a.funnel)
//  //        } yield ReportResult("", funnel_list_gcs_path)
//  //      else
//  //        for {
//  //          a: DataResultWithTotal <- task_overall
//  //          revenue_list_gcs_path <- getUploadPathRevenueReport(a.revenue)
//  //        } yield ReportResult(revenue_list_gcs_path, "")
//}