//package oldcode
//
//import backends.sales_dashboard.Schema.{NewExitCprp, SalesDashBoardReportArgsFlags}
//import backends.sales_dashboard.metrics.Utils._
//import doobie.hikari.HikariTransactor
//import zio.Task
//
//object PGExitCprpSql {
//
//  def getSqlQuery (args: SalesDashBoardReportArgsFlags) : Query0[NewExitCprp] = {
//
//    var deviation_period_dates_arr: Array[String] = Array()
//    args.deviation_period.foreach { x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date, x.end_date)
//    }
//    val value_for_advertiser_group = getValueForAdvertiserGroupPG(args.advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroupPG(args.deviation_advertiser_group)
//    val value_for_agency = getValueForAgencyPG(args.agency)
//    val value_for_sub_agency = getValueForSubAgencyPG(args.sub_agency)
//
//    val query_filter_fr =
//      s""" ('${args.period.start_date}',
//         |'${args.period.end_date}',
//         |${getArrayOfStringForDatesPG(deviation_period_dates_arr)},
//         |'${args.channel.toLowerCase}',
//         |${gerArrayOfStringForStringPG(args.regions.toArray)},
//         |${gerArrayOfStringForStringPG(args.pt_npt.toArray.map(x => x.toString.toLowerCase))},
//         |$value_for_advertiser_group,
//         |$value_for_deviation_advertiser_group,
//         |$value_for_agency,
//         |$value_for_sub_agency,
//         |${args.all_region_selected},
//         |${args.all_advertiser_selected},
//         |${args.all_agency_selected},
//         |${args.all_sub_agency_selected}
//         |) """.stripMargin
//
//    val func_str = fr""" select * from "func_exit_cprp" """.stripMargin
//
//    (func_str ++ Fragment.const(query_filter_fr)).query[NewExitCprp]
//
//  }
//
//  def apply(transactor: HikariTransactor[Task], salesDashBoardReportArgsFlags: SalesDashBoardReportArgsFlags)
//  : Task[List[NewExitCprp]] = {
//    getSqlQuery(salesDashBoardReportArgsFlags).to[List].transact(transactor)
//  }
//}
