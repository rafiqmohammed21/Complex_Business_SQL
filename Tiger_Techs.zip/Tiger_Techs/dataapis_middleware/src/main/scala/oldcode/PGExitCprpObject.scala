//package oldcode
//
//import backends.sales_dashboard.Schema.{NewExitCprp, SalesDashBoardReportArgsFlags}
//import doobie.hikari.HikariTransactor
//import org.json4s.DefaultFormats
//import zio.Task
//
//object PGExitCprpObject {
//  private implicit val formats = DefaultFormats
//
//  def apply(transactor: HikariTransactor[Task],args:SalesDashBoardReportArgsFlags)
//  : Task[NewExitCprp] = {
//
//    val exit_cprp_task: Task[List[NewExitCprp]] = PGExitCprpSql(transactor,args)
////    (transactor, func_str ++ Fragment.const(query_filter_fr))
//    def getHeadFromList(list : List[NewExitCprp]) :NewExitCprp ={
//      if(list.isEmpty) NewExitCprp(None, None,None, None,None, None,None) else list.head
//    }
//
//    for{
//      list:List[NewExitCprp] <- exit_cprp_task
//      head:NewExitCprp <- Task{getHeadFromList(list)}
//    } yield head
//
//  }
//}
