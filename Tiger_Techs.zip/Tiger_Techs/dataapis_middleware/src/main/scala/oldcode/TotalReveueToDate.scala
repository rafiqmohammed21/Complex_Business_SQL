//package backends.sales_dashboard.cards
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period, SPTarget, TotalReveueToDateResult}
//import backends.sales_dashboard.metrics.{ActualBookedObject, SPDealObject, SPProjectionObject, SpRoObject, TargetObject}
//import zio.Task
//
//object TotalReveueToDate {
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  :Task[TotalReveueToDateResult]={
//
//    val deals = SPDealObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//    val projection = SPProjectionObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//    val ro = SpRoObject(channel, period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,false,all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//    val target = TargetObject(channel,period,regions,impact_regular, all_region_selected)
//    val actualBooked = ActualBookedObject(channel,period, deviation_period, regions, agency, sub_agency, pt_npt, advertiser_group, deviation_advertiser_group, impact_regular,all_region_selected, all_advertiser_selected, all_agency_selected, all_sub_agency_selected)
//
//    val res = for{
//      ((((deals,projection),ro),target),actualBooked)  <- deals.zipPar(projection).zipPar(ro).zipPar(target).zipPar(actualBooked)
//      final_res <- Task{TotalReveueToDateResult(Some(deals),Some(projection),Some(ro), Some(target), Some(actualBooked) )}
//    } yield final_res
//    res
//  }
//}
