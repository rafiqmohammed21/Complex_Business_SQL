//package backends.sales_dashboard.metrics.bq
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period, SPMarketShare}
//import backends.sales_dashboard.metrics.Utils._
//import org.json4s.DefaultFormats
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object SPMarketShareObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[SPMarketShare] = Task {
//    println(s"======MarketShare object is started======")
//    val value_for_agency = getValueForAgency(agency)
//    val value_for_sub_agency = getValueForSubAgency(sub_agency)
//    val value_for_advertiser_group = getValueForAdvertiserGroup(advertiser_group)
//    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(deviation_advertiser_group)
//    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
//    var deviation_period_dates_arr :Array[String]= Array()
//    deviation_period.foreach{ x =>
//      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
//    }
//
//    val query = s""" CALL ${getSPName("sp_market_share")}('${period.start_date}','${period.end_date}',
//                   |${getArrayOfStringForDates(deviation_period_dates_arr)},
//                   |'${channel.toLowerCase}',
//                   |${gerArrayOfStringForString(regions.toArray)},
//                   |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
//                   |$value_for_impact_regular,
//                   |$value_for_advertiser_group,
//                   |$value_for_deviation_advertiser_group,
//                   |$value_for_agency,
//                   |$value_for_sub_agency,
//                   |$all_region_selected,
//                   |$all_advertiser_selected,
//                   |$all_agency_selected,
//                   |$all_sub_agency_selected
//                   |); """.stripMargin
//
//    var current_channel_ad_grp: Option[Double] = None
//    var current_genre_ad_grp: Option[Double] = None
//    var deviation_channel_ad_grp: Option[Double] = None
//    var deviation_genre_ad_grp: Option[Double] = None
//    var market_share: Option[Double] = None
//    var deviation_market_share: Option[Double] = None
//    var percentage_deviation_market_share: Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//      current_channel_ad_grp = {if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//      current_genre_ad_grp = {if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
//      deviation_channel_ad_grp = {if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
//      deviation_genre_ad_grp = {if (!row.get(3).isNull) Some(row.get(3).getDoubleValue)  else None}
//      market_share = {if (!row.get(4).isNull) Some(row.get(4).getDoubleValue)  else None}
//      deviation_market_share = {if (!row.get(5).isNull) Some(row.get(5).getDoubleValue)  else None}
//      percentage_deviation_market_share = {if (!row.get(6).isNull) Some(row.get(6).getDoubleValue)  else None}
//    }
//    println(s"=====MarketShare object ended======")
//    SPMarketShare(current_channel_ad_grp, current_genre_ad_grp, deviation_channel_ad_grp, deviation_genre_ad_grp, market_share, deviation_market_share, percentage_deviation_market_share)
//  }
//}
