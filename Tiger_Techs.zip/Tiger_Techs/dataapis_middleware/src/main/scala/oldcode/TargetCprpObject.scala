//package backends.sales_dashboard.metrics.bq
//
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period, TargetCprp}
//import backends.sales_dashboard.metrics.Utils.{gerArrayOfStringForString, getSPName}
//import utils.BQApi.getDataFromBQ
//import zio.Task
//
//object TargetCprpObject {
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]],all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_sub_agency_selected: Boolean)
//  : Task[TargetCprp] = Task {
//    //println(s"=====Target object is started at ======")
//
//    val query =
//      s""" CALL ${getSPName("sp_target_cprp")}('${period.start_date}',
//         |'$channel',
//         |${gerArrayOfStringForString(pt_npt.map(_.toString).toArray)}
//         |); """.stripMargin
//
//    var target_cprp:Option[Double] = None
//
//    for (row <- getDataFromBQ(query)) {
//      target_cprp={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
//    }
//   // println(s"=====Target object is ended at ======")
//    TargetCprp(target_cprp)
//  }
//}
