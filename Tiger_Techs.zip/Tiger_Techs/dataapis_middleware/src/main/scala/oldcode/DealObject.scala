//package backends.sales_dashboard.metrics
//
//import java.time.Instant
//import java.time.temporal.ChronoUnit
//
//import backends.sales_dashboard._
//import backends.sales_dashboard.Schema._
//import org.json4s.DefaultFormats
//import org.json4s.native.JsonParser.parse
//import scalaj.http.HttpResponse
//import utils.Configs._
//import utils.HttpClientApi
//import zio.Task
//
//object DealObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[Deal]] = Task {
//    val requestBody = f"""{
//      deals(${Filter.getFilterStr(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group, deviation_advertiser_group,impact_regular)}){
//        revenues{
//        advertiser_group,
//        revenue,
//        deviation,
//        percentage_deviation
//      },
//      total_revenue,
//      total_percentage_deviation
//      }
//     }"""
//    val url = f"$UAT_DATA_API_URL/api/v1/rev/deals"
//    val start = Instant.now()
//    val response: HttpResponse[String] = HttpClientApi.call(url, requestBody)
//    val end = Instant.now()
//    val time_diff = ChronoUnit.SECONDS.between(start, end)
//    println(s"DealObject Status Code: ${response.code} Thread # ${Thread.currentThread().getId()} Time: $time_diff")
//    val parsed = parse(response.body).extractOpt[ResponseDealData]
//    val deals: List[Deal] = createList(parsed.get.data.deals)
//    deals
//  }
//
//  def createList(resp_ro: ResponseDeal): List[Deal] = {
//    var deals: List[Deal] = List()
//    resp_ro.revenues.foreach{input =>
//      deals = deals :+ Deal(input.advertiser_group, input.revenue, input.percentage_deviation)
//    }
//    deals
//  }
//}
