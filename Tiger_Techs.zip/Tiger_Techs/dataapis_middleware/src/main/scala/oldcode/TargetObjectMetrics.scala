//package backends.sales_performance_dashboard.cards
//
//import zio.Task
//import backends.sales_performance_dashboard.Schema._
//import backends.sales_performance_dashboard.metrics.SPTargetObject
//
//object TargetObjectMetrics {
//  def apply(args : SPDArgs)
//  : Task[TargetMetricsResult] = {
//    for {
//     target_data: List[SPTarget] <- SPTargetObject(args)
//      data <- Task{TargetMetricsResult(target_data)}
//    } yield data
//  }
//}