//package backends.sales_dashboard.metrics
//
//import java.time.Instant
//import java.time.temporal.ChronoUnit
//
//import backends.sales_dashboard._
//import backends.sales_dashboard.Schema._
//import org.json4s.DefaultFormats
//import org.json4s.native.JsonParser.parse
//import scalaj.http.HttpResponse
//import utils.Configs._
//import utils.HttpClientApi
//import zio.Task
//
//object ExitCprpObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(channel: String, period: Period, deviation_period: List[Period], regions: List[String],agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
//  : Task[List[ExitCprp]] = Task {
//    val requestBody = f"""{
//    exitCprp(${Filter.getFilterStr(channel, period, deviation_period, regions,agency,sub_agency, pt_npt, advertiser_group,deviation_advertiser_group, impact_regular)}){
//     revenues{
//      advertiser_group,
//      revenue,
//      ad_grp,
//      exit_cprp,
//      deviation_revenue,
//      deviation_ad_grp,
//      deviation_cprp,
//      percentage_deviation
//     }
//     total_revenue
//     total_ad_grp
//     total_exit_cprp
//     total_deviation_revenue
//     total_deviation_ad_grp
//     total_deviation_exit_cprp
//     total_percentage_deviation
//    }
//   }"""
//    val url = f"$UAT_DATA_API_URL/api/v1/rev_vwrshp/ent/exit_cprp"
//    val start = Instant.now()
//    val response: HttpResponse[String] = HttpClientApi.call(url, requestBody)
//    val end = Instant.now()
//    val time_diff = ChronoUnit.SECONDS.between(start, end)
//    println(s"ExitCprpObject Status Code: ${response.code} Thread # ${Thread.currentThread().getId()} Time: $time_diff")
//    val parsed = parse(response.body).extractOpt[ResponseExitCprpData]
//    val deals: List[ExitCprp] = createList(parsed.get.data.exitCprp)
//    deals
//  }
//
//  def createList(resp_ro: ResponseExitCprp): List[ExitCprp] = {
//    var exitCprp: List[ExitCprp] = List()
//    resp_ro.revenues.foreach{input =>
//      exitCprp = exitCprp :+ ExitCprp(
//        advertiser_group=input.advertiser_group,
//        exit_cprp=input.exit_cprp)
//    }
//    exitCprp
//  }
//}
