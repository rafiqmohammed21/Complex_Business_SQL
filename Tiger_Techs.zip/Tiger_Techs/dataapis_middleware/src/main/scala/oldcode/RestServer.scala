//// CATS library
//import cats.data.Kleisli
//import cats.effect.ExitCode
//// Https Library
//import org.http4s.dsl.Http4sDsl
//import org.http4s.implicits._
//import org.http4s.server.blaze._
//import org.http4s.{HttpRoutes, Request, Response}
//// ZIO Library
//import zio._
//import zio.interop.catz._
//import zio.interop.catz.implicits._
//// JSON SERDE Library
//import org.json4s.NoTypeHints
//import org.json4s.native.JsonParser.parse
//import org.json4s.native.Serialization
//import org.json4s.native.Serialization.write
//// Project Level Imports
//import backends.sales_dashboard.Schema.{DayPart, ImpactRegular, Period, SalesDashBoardReportArgs}
//
//object RestServer extends CatsApp {
//    object ioz extends Http4sDsl[Task]
//    import ioz._
//    implicit val formats = Serialization.formats(NoTypeHints)
//    val revenueReports: Kleisli[Task, Request[Task], Response[Task]] = HttpRoutes.of[Task] {
//        case _ @ GET -> Root / "actualReport" =>
//            RestService.getActualReport(channel = "Star Plus"
//                ,period = Period("2019-08-01","2019-08-31")
//                ,deviation_period = List(Period("2019-07-01","2019-08-31"))
//                ,regions = List("EAST", "WEST","NORTH","SOUTH")
//                ,agency = Some(List("starcomm"))
//                ,sub_agency = Some(List("starcomm"))
//                ,pt_npt = List(DayPart.NPT,DayPart.PT)
//                ,advertiser_group = Some(List("Adani Wilmar","Aditya Birla Capital", "abbott healthcare", "google india"))
//                ,deviation_advertiser_group = Some(List("Adani Wilmar","Aditya Birla Capital", "abbott healthcare", "google india"))
//                ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
//            ).flatMap(list => Ok(write(list)))
//        case req @ POST -> Root / "projectionReport" =>
//            val args = parse(req.bodyAsText.toString).extractOpt[SalesDashBoardReportArgs].get
//            RestService.getActualReport(args.channel, args.period, args.deviation_period, args.regions,args.agency, args.sub_agency, args.pt_npt, args.advertiser_group,args.deviation_advertiser_group, args.impact_regular)
//              .flatMap(list => Ok(write(list)))
//        case _ @ GET -> Root / "projectionReport" =>
//            RestService.getProjectionReport(channel = "Star Plus"
//                ,period = Period("2019-08-01","2019-08-31")
//                ,deviation_period = List(Period("2019-07-01","2019-08-31"))
//                ,regions = List("EAST", "WEST","NORTH","SOUTH")
//                ,agency = Some(List("starcomm"))
//                ,sub_agency = Some(List("starcomm"))
//                ,pt_npt = List(DayPart.NPT,DayPart.PT)
//                ,advertiser_group = Some(List("Adani Wilmar","Aditya Birla Capital", "abbott healthcare", "google india"))
//                ,deviation_advertiser_group = Some(List("Adani Wilmar","Aditya Birla Capital", "abbott healthcare", "google india"))
//                ,impact_regular = Some(List(ImpactRegular.IMPACT,ImpactRegular.REGULAR))
//            ).flatMap(list => Ok(write(list)))
//    }.orNotFound
//
//    def run(args: List[String]): ZIO[zio.ZEnv, Nothing, Int] = {
//        BlazeServerBuilder[Task]
//          .bindHttp(9000, "0.0.0.0")
//          .withHttpApp(revenueReports)
//          .serve
//          .compile[Task, Task, ExitCode]
//          .drain
//          .fold(_ => 1, _ => 0)
//      }
//
//}
