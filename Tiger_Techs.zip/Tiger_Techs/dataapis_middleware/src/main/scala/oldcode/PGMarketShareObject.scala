//package oldcode
//
//import backends.sales_dashboard.Schema.{SPMarketShare, SalesDashBoardReportArgsFlags}
//import doobie.hikari.HikariTransactor
//import org.json4s.DefaultFormats
//import zio.Task
//
//object PGMarketShareObject {
//
//  private implicit val formats = DefaultFormats
//
//  def apply(transactor: HikariTransactor[Task],args: SalesDashBoardReportArgsFlags)
//  : Task[SPMarketShare] =  {
//
//    val market_share_task: Task[List[SPMarketShare]] = PGMarketShareSql(transactor: HikariTransactor[Task],args: SalesDashBoardReportArgsFlags)
//
//    def getHeadFromList(list : List[SPMarketShare]) :SPMarketShare ={
//      if(list.isEmpty) SPMarketShare(None, None,None, None,None, None,None) else list.head
//    }
//
//     for{
//      list:List[SPMarketShare] <- market_share_task
//      head:SPMarketShare <- Task{getHeadFromList(list)}
//    } yield head
//  }
//}
