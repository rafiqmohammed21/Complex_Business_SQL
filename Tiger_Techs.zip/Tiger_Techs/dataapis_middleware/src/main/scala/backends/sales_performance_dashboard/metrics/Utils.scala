package backends.sales_performance_dashboard.metrics

import java.time.LocalDate
import java.time.temporal.ChronoUnit.DAYS
import backends.sales_performance_dashboard.Schema.{ImpactRegular, Period}
import utils.Configs

import scala.util.Try
object Utils {

  def getSPName(sp:String):String={
    var master = ""
    var revenue = ""
    var viewership = ""
    var rev_vwrshp_reports = ""
    var revenue_reports = ""
    var viewership_reports = ""

    val env  = "dev"
    if (env=="dev"){
      master = "master"
      revenue = "revenue"
      viewership = "viewership"
      revenue_reports = "test_reports"
      viewership_reports = "test_reports"
      rev_vwrshp_reports = "test_reports"
    }
    else if(env=="uat"){
      master = "master"
      revenue = "revenue"
      viewership = "viewership"
      revenue_reports = "test_reports"
      viewership_reports = "test_reports"
      rev_vwrshp_reports = "test_reports"
    }
    else if(env=="prod"){
      master = "master"
      revenue = "revenue"
      viewership = "viewership"
      rev_vwrshp_reports = "rev_vwrshp_reports"
      revenue_reports = "revenue_reports"
      viewership_reports = "viewership_reports"
    }

    val sp_map:Map[String,String] = Map(
            "sp_overall_metrics" -> f"$rev_vwrshp_reports.sp_overall_metrics_spd",
            "sp_deals_cprp" -> f"$rev_vwrshp_reports.sp_deals_cprp_spd",
            "sp_ro_cprp" -> f"$rev_vwrshp_reports.sp_ro_cprp_spd",
            "sp_executed_cprp" -> f"$rev_vwrshp_reports.sp_executed_cprp_spd",
            "sp_target" -> f"$rev_vwrshp_reports.sp_target_spd"
    )
    sp_map(sp)
  }

  def dates(fromDate: LocalDate): Stream[LocalDate] = {
    fromDate #:: dates(fromDate plusDays 1 )
  }

  def stringToDate(date_str:String):LocalDate={
    val dateFormat = "yyyy-MM-dd"
    val dtf = java.time.format.DateTimeFormatter.ofPattern(dateFormat)
    java.time.LocalDate.parse(date_str, dtf)
  }

  def getLagDates(sd_str:String, ed_str:String):(String,String)={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str)
    val diff :Long = DAYS.between(sd, ed)+1
    val no_of_weeks:Long = (diff/7).ceil.toLong
    val lag_sd = sd.minusDays((no_of_weeks+8)*7)
    val lag_ed = ed.minusDays((no_of_weeks+8)*7)
    (lag_sd.toString,lag_ed.toString)
  }
  
  def getNumberOfDays(periods: List[Period]):Long={
    var num_days:Long = 0
    for (period <- periods)
      {
        val sd = stringToDate(period.start_date)
        val ed = stringToDate(period.end_date)
        num_days = num_days + DAYS.between(sd, ed)+1
      }
    num_days
  }
  
  
  def getPercentageDeviation(curr_val:Option[Double],dev_val:Option[Double],curr_num_days:Long=1,dev_num_days:Long=1):Option[Double]={
    Try((math rint (((curr_val.get / curr_num_days) - (dev_val.get / dev_num_days)) / (dev_val.get / dev_num_days)) * 10000)/100).toOption
  }

  def fullOuterJoin[K](xs: List[List[(K, Any)]]): List[(K, List[Option[Any]])] = {
    val maps = xs.map(_.toMap)
    val allKeys = maps.map(_.keySet).reduce(_ ++ _)
    allKeys.toList.map(k => (k, maps.map(m => m.get(k))))
  }

  def getOptionSum(num1:Option[Double],num2:Option[Double]):Option[Double]={
    (num1 ++ num2).reduceOption(_ + _)
  }

  def getOptionDiff(num1:Option[Double],num2:Option[Double]):Option[Double]={
    if(num1==None && num2==None) None
    else Some(num1.getOrElse(0.0)-num2.getOrElse(0.0))
  }
  
  def getActualBookedPercentageDifference(actual_revenue:Option[Double], booked_revenue:Option[Double], dev_actual_revenue:Option[Double], period:Period, dev_period:List[Period]): (Option[Double],Option[Double]) ={
    val (actual_period, booked_period) = getActualPeriod(period)
    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    var per_dev_actual_revenue:Option[Double] = None
    var per_dev_revenue:Option[Double] = None
    val today_date = LocalDate.now()
    
    // case when current month is selected
    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
      val (actual_period, booked_period) = getActualPeriod(period)
      val actual_days = getNumberOfDays(List(actual_period))
      val booked_days = getNumberOfDays(List(booked_period))
      val normalised_revenue = actual_revenue match {
        case None => booked_revenue match {
          case None => None
          case Some(_) => Some(booked_revenue.get/booked_days)
        }
        case Some(_) => booked_revenue match {
          case None => Some(actual_revenue.get/actual_days)
          case Some(_) => Some((actual_revenue.get/actual_days)+(booked_revenue.get/booked_days))
        }
      }
      //curr_num_days=1 because actual and booked days are already considered in normalized revenue
      per_dev_revenue = getPercentageDeviation(normalised_revenue,dev_actual_revenue,curr_num_days=1, dev_num_days = dev_num_days)
      per_dev_actual_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=actual_days,dev_num_days = dev_num_days)
    }

    // case when previous month is selected  
    else {
      per_dev_actual_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=num_days,dev_num_days = dev_num_days)
      per_dev_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=num_days,dev_num_days = dev_num_days)
    }
    
    (per_dev_actual_revenue,per_dev_revenue)
  }
  
  def getRoundValue(rev_val :Option[Double]):Option[Double]={
      Try(math.rint(rev_val.get * 100)/100).toOption
  }

  def getRoundValue(rev_val :Double):Option[Double]={
    Try(math.rint(rev_val* 100)/100).toOption
  }
  
  def getDateArray(sd_str:String, ed_str:String):Array[String]={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str).plusDays(1)
    val date_array = dates(LocalDate.of(sd.getYear,sd.getMonthValue , sd.getDayOfMonth)).takeWhile(_.isBefore(LocalDate.of(ed.getYear,ed.getMonthValue , ed.getDayOfMonth))).toArray
    val string_array = date_array.map(x => x.toString)
    string_array
  }

  def listOfStringToListofDateFormatter(str_list:Array[String]):String = {
    var res_str:String = "DATE '"+str_list.head.toLowerCase+"'"
    for(element<-str_list.tail)
    {
      res_str+=", DATE '"+element.toLowerCase()+"'"
    }
    res_str
  }
  
  def listOfStructOfStringToListofDateFormatter(str_list:Array[(String,String)]):String = {
    var res_str:String = s"(DATE '${str_list.head._1}', DATE '${str_list.head._2}')"
    for(element<-str_list.tail)
    {
      res_str+=s", (DATE '${element._1}', DATE '${element._2}')"
    }
    res_str
  }
  

  def formatList(channel_list:Array[String]):String = {
    var res_str:String = """  """"+channel_list.head.toLowerCase+"""" """
    for(element<-channel_list.tail)
    {
      res_str+="""  ,""""+element.toLowerCase()+"""" """
    }
    res_str
  }
  
  def gerArrayOfStringForString(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${formatList(lst)} ]"
    }
    res
  }
  

  def getArrayOfStringForDates(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${listOfStringToListofDateFormatter(lst)} ]"
    }
    res
  }
  

  def getArrayOfStructOfStringForDates(lst: Array[(String,String)]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${listOfStructOfStringToListofDateFormatter(lst)} ]"
    }
    res
  }
  

  def getActualPeriod(period:Period):(Period,Period)={
    var actual_date = Period(period.start_date, period.end_date)
    var booked_date = Period("1891-01-01", "1891-01-01")
    val today_date = LocalDate.now()

    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
      println("In current month")
      actual_date = Period(
        start_date = actual_date.start_date,
        end_date = today_date.minusDays(1).toString())
      booked_date = Period(start_date = today_date.toString(), end_date = period.end_date)
    }
    (actual_date,booked_date)
  }
  
  def formatListPG(channel_list:Array[String]):String = {
    var res_str:String = """  E'"""+channel_list.head.toLowerCase.replace("'","\\'") +"""' """
    for(element<-channel_list.tail)
    {
      res_str+="""  ,E'"""+element.toLowerCase.replace("'","\\'")+"""' """
    }
    res_str
  }
  
  def getValueForStringList(str_list:Option[List[String]]):String = str_list match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(str_list.get.toArray)
  }
  
  
  def getValueForImpactRegular(impact_regular: Option[List[ImpactRegular]]):String = impact_regular match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(impact_regular.get.map(_.toString).toArray)
  }

  def gerArrayOfStringForStringPG(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${formatListPG(lst)} ]"
    }
    res
  }

  def getValueForImpactRegularPG(impact_regular: Option[List[ImpactRegular]]):String = impact_regular match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(impact_regular.get.map(_.toString).toArray)
  }

  def getStringValueFromList(str_list: Option[List[String]]): String = str_list match{
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(str_list.get.toArray)
  }

  def listOfStructOfStringToListofDateFormatterPG(str_list:Array[(String,String)]):String = {
    var res_str:String = s"row( '${str_list.head._1}', '${str_list.head._2}')"
    for(element<-str_list.tail)
    {
      res_str+=s", row( '${element._1}', '${element._2}')"
    }
    res_str
  }

  def getArrayOfStructOfStringForDatesPG(lst: Array[(String,String)]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${listOfStructOfStringToListofDateFormatterPG(lst)} ]::period_type[]"
    }
    res
  }

}
