package backends.sales_performance_dashboard
import java.io.{PrintWriter, StringWriter}
import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.cards._
import caliban.CalibanError.ExecutionError
import cats.effect.Blocker
import com.rollbar.notifier.Rollbar
import com.zaxxer.hikari.HikariDataSource
import doobie.hikari.HikariTransactor
import org.slf4j.{Logger, LoggerFactory}
import utils.RollBarContext.logCustomErrorInRollbar
import zio._
import scala.concurrent.ExecutionContext

object SalesPerformanceDashboardService {
  def liveAkka(connectEC: ExecutionContext, rollBar: Rollbar, dbUrl: String, dbUser: String, dbPass: String): ZLayer[Any, Throwable, SalesPerformanceDashboardAkka] = ZLayer.fromEffect(Task {
    import zio.interop.catz._
    val dataSource = new HikariDataSource()
    dataSource.setDriverClassName("org.postgresql.Driver")
    dataSource.setJdbcUrl(dbUrl)
    dataSource.setUsername(dbUser)
    dataSource.setPassword(dbPass)
    val pgTransactor: HikariTransactor[Task] = HikariTransactor[Task](dataSource, connectEC, Blocker.liftExecutionContext(connectEC))
    SalesPerformanceDashboardService(rollBar, pgTransactor)
  })

  def liveHttp4s(pgTransactor: HikariTransactor[Task], rollBar: Rollbar): ZLayer[Any, Throwable, SalesPerformanceDashboardAkka] =
    ZLayer.fromEffect(Task(SalesPerformanceDashboardService(rollBar, pgTransactor)))
}

final case class SalesPerformanceDashboardService(rollBarContext:Rollbar, trans : HikariTransactor[Task]) extends SalesPerformanceDB.Service {

  val logger: Logger = LoggerFactory.getLogger(getClass.getName)

  def getOverallCprpMetrics(args: SPDArgs)
  :ZIO[SalesPerformanceDashboardAkka,Throwable,OverallCprpMetricsResult] =  {
    val t1 = System.nanoTime
    try {
      for {
        t <- OverallCprpMetrics(args)
        _ <- Task{logger.info(s"getOverallCprpMetrics Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield t
    }
    catch {
      case e: Throwable =>
        logger.info(s"getOverallCprpMetrics Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getOverallCprpMetrics", args.toString)
        throw e
    }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }

  def getOverallRevenueMetrics(args: SPDArgs)
  :ZIO[SalesPerformanceDashboardAkka,Throwable,DataResultWithTotalSPD] =  {
    val t1 = System.nanoTime
    try {
      for {
        t <- OverallRevenueMetrics(trans, args)
        _ <- Task{logger.info(s"getOverallRevenueMetrics Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield t
    }
    catch {
      case e: Throwable =>
        logger.info(s"getOverallRevenueMetrics Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getOverallRevenueMetrics", args.toString)
        throw e
    }
  }.mapError { e =>
    val sw = new StringWriter
    e.printStackTrace(new PrintWriter(sw))
    println(sw.toString)
    logger.error(e.getMessage)
    logger.error(sw.toString)
     ExecutionError(e.getMessage)
  }
}