package backends

import backends.sales_performance_dashboard.Schema._
import zio.{Has, ZIO}

package object sales_performance_dashboard {

  object SalesPerformanceDB {

    trait Service {

      def getOverallRevenueMetrics(args: SPDArgs)
      :ZIO[SalesPerformanceDashboardAkka,Throwable,DataResultWithTotalSPD]

      def getOverallCprpMetrics(args: SPDArgs)
      :ZIO[SalesPerformanceDashboardAkka,Throwable,OverallCprpMetricsResult]

    }

  }

  type SalesPerformanceDashboardAkka = Has[SalesPerformanceDB.Service]
  
  def getOverallCprpMetrics(args:SPDArgs, list_of_selections: List[String])
  = ZIO.accessM[SalesPerformanceDashboardAkka](_.get.getOverallCprpMetrics(args))

  def getOverallRevenueMetrics(args:SPDArgs, list_of_selections: List[String])
  = ZIO.accessM[SalesPerformanceDashboardAkka](_.get.getOverallRevenueMetrics(args))

}
