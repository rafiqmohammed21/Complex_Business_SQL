package backends.sales_performance_dashboard.cards

import zio.Task
import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.metrics.SPOverallCprpObject

object OverallCprpMetrics {
  def apply(args: SPDArgs)
  : Task[OverallCprpMetricsResult] = {
    val overall_data: Task[OverallCprpMetricsResult] =  SPOverallCprpObject(args)
    for{
      data  <- overall_data
    } yield data
  }
}