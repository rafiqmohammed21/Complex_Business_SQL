package backends.sales_performance_dashboard.metrics
import backends.sales_dashboard.metrics.Utils.gerArrayOfStringForStringPG
import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.metrics.Utils._
import doobie.Fragment
import doobie.implicits._
import doobie.hikari.HikariTransactor
import zio.Task
import zio.interop.catz._

object SPTargetObject {
  def apply(transactor: HikariTransactor[Task], args : SPDArgs)
  : Task[List[SPTargetSPD]] = {
    val query = s"""('${args.selection_group.toLowerCase}',
                   |'${args.period.start_date}',
                   |'${args.period.end_date}',
                   |${gerArrayOfStringForStringPG(args.channel.toArray)},
                   |${gerArrayOfStringForStringPG(args.regions.toArray)},
                   |${gerArrayOfStringForStringPG(args.pt_npt.toArray.map(x=>x.toString.toLowerCase))},
                   |${getValueForImpactRegularPG(args.impact_regular)}
                   |) """.stripMargin

    val func_str = fr""" select out_selection_group, out_target, out_target_cprp  from "func_target_spd" """.stripMargin
    (func_str ++ Fragment.const(query)).query[SPTargetSPD].to[List].transact(transactor)
  }
  }