package backends.sales_performance_dashboard.metrics

import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.metrics.Utils._
import doobie.Fragment
import doobie.hikari.HikariTransactor
import doobie.implicits._
import org.json4s.DefaultFormats
import zio.Task
import zio.interop.catz._

import scala.util.Try
object SPOverallRevenueObject {
  private implicit val formats = DefaultFormats
  def apply(transactor: HikariTransactor[Task], args: SPDArgs):
  Task[DataResultWithTotalSPD] = {
    val period_arr: Array[(String, String)] = Array((args.period.start_date, args.period.end_date))
    val value_for_impact_regular = getValueForImpactRegularPG(args.impact_regular)
    val value_for_channel = getStringValueFromList(Some(args.channel))
    val value_for_advertiser_group = getStringValueFromList(args.advertiser_group)
    val value_for_deviation_advertiser_group = getStringValueFromList(args.deviation_advertiser_group)
    val value_for_agency = getStringValueFromList(args.agency)
    val value_for_sub_agency = getStringValueFromList(args.sub_agency)
    val value_for_advertiser_category = getStringValueFromList(args.advertiser_category)
    val value_for_brands = getStringValueFromList(args.brands)
    var deviation_period_dates_arr: Array[(String, String)] = Array()
    args.deviation_period.foreach { x =>
      deviation_period_dates_arr = deviation_period_dates_arr ++ Array((x.start_date, x.end_date))
    }

     val query_filter_fr =
      s""" ('${args.selection_group.toLowerCase}',
         |$value_for_channel,
         |${getArrayOfStructOfStringForDatesPG(period_arr)},
         |${gerArrayOfStringForStringPG(args.regions.toArray)},
         |${gerArrayOfStringForStringPG(args.pt_npt.toArray.map(x => x.toString.toLowerCase))},
         |$value_for_impact_regular,
         |$value_for_advertiser_group,
         |$value_for_agency,
         |$value_for_sub_agency,
         |$value_for_advertiser_category,
         |$value_for_brands,
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${args.all_sub_agency_selected},
         |${args.all_advertiser_category_selected},
         |${args.all_brand_selected}) """.stripMargin

    val query_filter_fr_dev =
      s""" ('${args.selection_group.toLowerCase}',
         |$value_for_channel,
         |${getArrayOfStructOfStringForDatesPG(deviation_period_dates_arr)},
         |${gerArrayOfStringForStringPG(args.regions.toArray)},
         |${gerArrayOfStringForStringPG(args.pt_npt.toArray.map(x => x.toString.toLowerCase))},
         |$value_for_impact_regular,
         |$value_for_deviation_advertiser_group,
         |$value_for_agency,
         |$value_for_sub_agency,
         |$value_for_advertiser_category,
         |$value_for_brands,
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${args.all_sub_agency_selected},
         |${args.all_advertiser_category_selected},
         |${args.all_brand_selected}) """.stripMargin

    val query_str =
      fr""" select out_selection_group, out_ro, out_deals, out_projection, out_actual_revenue, out_booked_revenue, out_revenue, out_grp, out_genre_grp, out_market_share,out_exit_revenue, out_exit_channel_grp, out_exit_cprp,
          |out_ro_rev_internal_buys, out_deals_rev_internal_buys, out_projection_rev_internal_buys,
          |out_actual_rev_internal_buys, out_booked_rev_internal_buys, out_total_rev_internal_buys,out_fct
          |from "func_overall_metrics_spd" """.stripMargin

    val overall_task = getOverallFromPostgres(transactor, query_str ++ Fragment.const(query_filter_fr))
    val dev_overall_task = getOverallFromPostgres(transactor, query_str ++ Fragment.const(query_filter_fr_dev))
    var rev_results: List[RevenueReportSchemaSPD] = List()
    var funnel_results: List[FunnelReportSchemaSPD] = List()
    val target_data_task : Task[List[SPTargetSPD]] = SPTargetObject(transactor,args)

    val res = for {
        target_data_list <- target_data_task
      (curr_list, dev_list)<- overall_task.zipPar(dev_overall_task)
      (finalRevenueList, totalRevenueMetrics) <- getOverallJoinedDF(curr_list, dev_list, args.period, args.deviation_period, args.advertiser_group.get)
      data <- Task {
        var sum_target:Option[Double] = None
        var sum_target_cprp:Option[Double] = None
        for (elem <- target_data_list) {
          sum_target = getOptionSum(sum_target, elem.target_revenue)
          sum_target_cprp = getOptionSum(sum_target_cprp, elem.target_cprp)
        }
        val target_result = TargetWithTotal(
          target_list = target_data_list,
          total_target = sum_target,
          total_target_cprp = sum_target_cprp
        )
        finalRevenueList.foreach {
          elem =>
            val rev = RevenueReportSchemaSPD(
              selection_group = elem.selection_group,
              revenue = elem.revenue,
              dev_revenue = elem.dev_revenue,
              revenue_deviation = elem.per_dev_revenue,
              actual_revenue = elem.actual_revenue,
              dev_actual_revenue = elem.dev_actual_revenue,
              actual_revenue_deviation = elem.per_dev_actual_revenue,
              booked_revenue = elem.booked_revenue,
              grp = elem.grp,
              dev_grp = elem.dev_grp,
              grp_deviation = elem.per_dev_grp,
              fct = elem.fct,
              dev_fct = elem.dev_fct,
              fct_deviation = elem.per_dev_fct,
              genre_grp = elem.genre_grp,
              dev_genre_grp = elem.dev_genre_grp,
              genre_grp_deviation = elem.per_dev_genre_grp,
              market_share = elem.market_share,
              dev_market_share = elem.dev_market_share,
              market_share_deviation = elem.per_dev_market_share,
              exit_cprp = elem.exit_cprp,
              dev_exit_cprp = elem.dev_exit_cprp,
              exit_cprp_deviation = elem.per_dev_exit_cprp,
              exit_revenue = elem.exit_revenue,
              dev_exit_revenue = elem.dev_exit_revenue,
              exit_grp = elem.exit_grp,
              dev_exit_grp = elem.dev_exit_grp
            )
            val funnel = FunnelReportSchemaSPD(
              selection_group = elem.selection_group,
              projection = elem.projection,
              dev_projection = elem.dev_projection,
              projection_deviation = elem.per_dev_projection,
              deal = elem.deal,
              dev_deal = elem.dev_deal,
              deal_deviation = elem.per_dev_deal,
              ro = elem.ro,
              dev_ro = elem.dev_ro,
              ro_deviation = elem.per_dev_ro,
              revenue = elem.revenue
            )
            rev_results ++= List(rev)
            funnel_results ++= List(funnel)
                    }
        DataResultWithTotalSPD(
          revenue = rev_results,
          funnel = funnel_results,
          total = totalRevenueMetrics,
          target = target_result
        )
      }
    }yield data
    res
  }

  def getOverallFromPostgres(transector :  HikariTransactor[Task], query_sql:Fragment):Task[List[SPRevenueMetricsSPD]]=
      query_sql.query[SPRevenueMetricsSPD].to[List].transact(transector)

  def getOverallJoinedDF(curr_list:List[SPRevenueMetricsSPD],dev_list:List[SPRevenueMetricsSPD],period: Period,dev_period: List[Period], advertiser_list:List[String]):
  Task[(List[SPOverallRevenueSchemaSPD],TotalRevenueMetricsSPD)] = Task{
    val curr_df = getKeyValuePairs(curr_list)
    val dev_df = getKeyValuePairs(dev_list)
    val join_df = fullOuterJoin(List(curr_df,dev_df))
    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    val (actual_period, booked_period) = getActualPeriod(period)
    val actual_num_days = getNumberOfDays(List(actual_period))
    var sum_ro: Option[Double] = None
    var sum_deal: Option[Double] = None
    var sum_projection: Option[Double] = None
    var sum_actual_revenue: Option[Double] = None
    var sum_booked_revenue: Option[Double] = None
    var sum_revenue: Option[Double] = None
    var sum_grp: Option[Double] = None
    var sum_genre_grp: Option[Double] = None
    var sum_exit_revenue: Option[Double] = None
    var sum_exit_grp: Option[Double] = None
    var sum_dev_ro: Option[Double] = None
    var sum_dev_deal: Option[Double] = None
    var sum_dev_projection: Option[Double] = None
    var sum_dev_actual_revenue: Option[Double] = None
    var sum_dev_revenue: Option[Double] = None
    var sum_dev_grp: Option[Double] = None
    var sum_dev_fct: Option[Double] = None
    var sum_dev_genre_grp: Option[Double] = None
    var sum_dev_exit_revenue: Option[Double] = None
    var sum_dev_exit_grp: Option[Double] = None
    var sum_per_dev_ro: Option[Double] = None
    var sum_per_dev_deal: Option[Double] = None
    var sum_per_dev_projection: Option[Double] = None
    var sum_per_dev_grp: Option[Double] = None
    var sum_per_dev_genre_grp: Option[Double] = None
    var sum_per_dev_exit_revenue: Option[Double] = None
    var sum_per_dev_exit_grp: Option[Double] = None
    val empty_df = SPRevenueMetricsSPD(None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None)
    var sum_ro_internal:Option[Double] = None
    var sum_deal_internal:Option[Double] = None
    var sum_projection_internal:Option[Double] = None
    var sum_actual_internal: Option[Double] = None
    var sum_booked_internal: Option[Double] = None
    var sum_revenue_internal:Option[Double] = None
    var sum_fct: Option[Double] = None
    var finalRevenueList: List[SPOverallRevenueSchemaSPD] = List()
    for (elem <- join_df) {
      val selection_group = elem._1
      val curr_revenue = elem._2(0) match {
        case Some(_) => elem._2(0).get.asInstanceOf[SPRevenueMetricsSPD]
        case None => empty_df
      }
      val dev_revenue = elem._2(1) match {
        case Some(_) => elem._2(1).get.asInstanceOf[SPRevenueMetricsSPD]
        case None => empty_df
      }
      sum_ro_internal = getOptionSum(sum_ro_internal,curr_revenue.ro_internal)
      sum_deal_internal = getOptionSum(sum_deal_internal,curr_revenue.deal_internal)
      sum_projection_internal = getOptionSum(sum_projection_internal,curr_revenue.projection_internal)
      sum_actual_internal = getOptionSum(sum_actual_internal,curr_revenue.actual_internal)
      sum_booked_internal = getOptionSum(sum_booked_internal,curr_revenue.booked_internal)
      sum_revenue_internal = getOptionSum(sum_revenue_internal,curr_revenue.revenue_internal)

      sum_ro = getOptionSum(sum_ro, curr_revenue.ro)
      sum_dev_ro = getOptionSum(sum_dev_ro, dev_revenue.ro)

      sum_projection = getOptionSum(sum_projection, curr_revenue.projection)
      sum_dev_projection = getOptionSum(sum_dev_projection, dev_revenue.projection)

      sum_deal = getOptionSum(sum_deal, curr_revenue.deal)
      sum_dev_deal = getOptionSum(sum_dev_deal, dev_revenue.deal)

      sum_actual_revenue = getOptionSum(sum_actual_revenue, curr_revenue.actual_revenue)
      sum_dev_actual_revenue = getOptionSum(sum_dev_actual_revenue, dev_revenue.actual_revenue)

      sum_booked_revenue = getOptionSum(sum_booked_revenue, curr_revenue.booked_revenue)

      sum_revenue = getOptionSum(sum_revenue, curr_revenue.revenue)
      sum_dev_revenue = getOptionSum(sum_dev_revenue, dev_revenue.revenue)

      sum_grp = getOptionSum(sum_grp, curr_revenue.ad_grp)
      sum_dev_grp = getOptionSum(sum_dev_grp, dev_revenue.ad_grp)

      sum_fct = getOptionSum(sum_grp, curr_revenue.fct)
      sum_dev_fct = getOptionSum(sum_dev_fct, dev_revenue.fct)

      sum_genre_grp = getOptionSum(sum_genre_grp, curr_revenue.genre_grp)
      sum_dev_genre_grp = getOptionSum(sum_dev_genre_grp, dev_revenue.genre_grp)

      sum_exit_revenue = getOptionSum(sum_exit_revenue, curr_revenue.exit_revenue)
      sum_dev_exit_revenue = getOptionSum(sum_dev_exit_revenue, dev_revenue.exit_revenue)

      sum_exit_grp = getOptionSum(sum_exit_grp, curr_revenue.exit_grp)
      sum_dev_exit_grp = getOptionSum(sum_dev_exit_grp, dev_revenue.exit_grp)

      val per_dev_ro = getPercentageDeviation(curr_revenue.ro, dev_revenue.ro, num_days, dev_num_days)
      val per_dev_deal = getPercentageDeviation(curr_revenue.deal, dev_revenue.deal, num_days, dev_num_days)
      val per_dev_projection = getPercentageDeviation(curr_revenue.projection, dev_revenue.projection, num_days, dev_num_days)
      val (per_dev_actual_revenue, per_dev_revenue) = getActualBookedPercentageDifference(curr_revenue.actual_revenue, curr_revenue.booked_revenue, dev_revenue.actual_revenue, period, dev_period)
      val per_dev_grp = getPercentageDeviation(curr_revenue.ad_grp, dev_revenue.ad_grp, num_days, dev_num_days)
      val per_dev_genre_grp = getPercentageDeviation(curr_revenue.genre_grp, dev_revenue.genre_grp, num_days, dev_num_days)
      val per_dev_exit_revenue = getPercentageDeviation(curr_revenue.exit_revenue, dev_revenue.exit_revenue, num_days, dev_num_days)
      val per_dev_exit_grp = getPercentageDeviation(curr_revenue.exit_grp, dev_revenue.exit_grp, num_days, dev_num_days)
      val per_dev_fct = getPercentageDeviation(curr_revenue.fct, dev_revenue.fct, num_days, dev_num_days)

      val per_dev_market_share = getPercentageDeviation(curr_revenue.market_share, dev_revenue.market_share)
      val per_dev_exit_cprp = getPercentageDeviation(curr_revenue.exit_cprp, dev_revenue.exit_cprp)
      val resObj = SPOverallRevenueSchemaSPD(
        selection_group = curr_revenue.selection_group,
        ro = getRoundValue(curr_revenue.ro),
        dev_ro = getRoundValue(dev_revenue.ro),
        per_dev_ro = getRoundValue(per_dev_ro),
        deal = getRoundValue(curr_revenue.deal),
        dev_deal = getRoundValue(dev_revenue.deal),
        per_dev_deal = getRoundValue(per_dev_deal),
        projection = getRoundValue(curr_revenue.projection),
        dev_projection = getRoundValue(dev_revenue.projection),
        per_dev_projection = getRoundValue(per_dev_projection),
        actual_revenue = getRoundValue(curr_revenue.actual_revenue),
        dev_actual_revenue = getRoundValue(dev_revenue.actual_revenue),
        per_dev_actual_revenue = getRoundValue(per_dev_actual_revenue),
        booked_revenue = getRoundValue(curr_revenue.booked_revenue),
        revenue = getRoundValue(curr_revenue.revenue),
        dev_revenue = getRoundValue(dev_revenue.revenue),
        per_dev_revenue = getRoundValue(per_dev_revenue),
        grp = getRoundValue(curr_revenue.ad_grp),
        dev_grp = getRoundValue(dev_revenue.ad_grp),
        per_dev_grp = getRoundValue(per_dev_grp),
        fct = getRoundValue(curr_revenue.fct),
        dev_fct = getRoundValue(dev_revenue.fct),
        per_dev_fct = getRoundValue(per_dev_fct),
        genre_grp = getRoundValue(curr_revenue.genre_grp),
        dev_genre_grp = getRoundValue(dev_revenue.genre_grp),
        per_dev_genre_grp = getRoundValue(per_dev_genre_grp),
        market_share = getRoundValue(curr_revenue.market_share),
        dev_market_share = getRoundValue(dev_revenue.market_share),
        per_dev_market_share = getRoundValue(per_dev_market_share),
        exit_revenue = getRoundValue(curr_revenue.exit_revenue),
        dev_exit_revenue = getRoundValue(dev_revenue.exit_revenue),
        per_dev_exit_revenue = getRoundValue(per_dev_exit_revenue),
        exit_grp = getRoundValue(curr_revenue.exit_grp),
        dev_exit_grp = getRoundValue(dev_revenue.exit_grp),
        per_dev_exit_grp = getRoundValue(per_dev_exit_grp),
        exit_cprp = getRoundValue(curr_revenue.exit_cprp),
        dev_exit_cprp = getRoundValue(dev_revenue.exit_cprp),
        per_dev_exit_cprp = getRoundValue(per_dev_exit_cprp)
      )
      if(resObj.selection_group != None){
      finalRevenueList = finalRevenueList :+ resObj
    }}

    sum_per_dev_ro = getPercentageDeviation(sum_ro,sum_dev_ro,num_days,dev_num_days)
    sum_per_dev_deal = getPercentageDeviation(sum_deal,sum_dev_deal,num_days,dev_num_days)
    sum_per_dev_projection = getPercentageDeviation(sum_projection,sum_dev_projection,num_days,dev_num_days)
    val (sum_per_dev_actual_revenue, sum_per_dev_revenue) = getActualBookedPercentageDifference(sum_actual_revenue,sum_booked_revenue,sum_dev_actual_revenue,period,dev_period)
    sum_per_dev_grp = getPercentageDeviation(sum_grp,sum_dev_grp,num_days,dev_num_days)
    sum_per_dev_genre_grp = getPercentageDeviation(sum_genre_grp,sum_dev_genre_grp,num_days,dev_num_days)
    sum_per_dev_exit_revenue = getPercentageDeviation(sum_exit_revenue,sum_dev_exit_revenue,num_days,dev_num_days)
    val sum_exit_cprp = Try(sum_exit_revenue.get*10000000/sum_exit_grp.get).toOption
    val sum_dev_exit_cprp = Try(sum_dev_exit_revenue.get*10000000/sum_dev_exit_grp.get).toOption
    val sum_per_dev_exit_cprp = getPercentageDeviation(sum_exit_cprp,sum_dev_exit_cprp)
    val sum_market_share = Try((sum_grp.get/sum_genre_grp.get)*100).toOption
    val sum_dev_market_share = Try((sum_dev_grp.get/sum_dev_genre_grp.get)*100).toOption
    val sum_per_dev_market_share = getPercentageDeviation(sum_market_share,sum_dev_market_share)
    val sum_ro_without_internal = getOptionDiff(sum_ro,sum_ro_internal)
    val sum_deal_without_internal = getOptionDiff(sum_deal,sum_deal_internal)
    val sum_projection_without_internal = getOptionDiff(sum_projection,sum_projection_internal)
    val sum_actual_without_internal = getOptionDiff(sum_actual_revenue,sum_actual_internal)
    val sum_booked_without_internal = getOptionDiff(sum_booked_revenue,sum_booked_internal)
    val sum_revenue_without_internal = getOptionDiff(sum_revenue,sum_revenue_internal)
    val totalRevenueMetrics = TotalRevenueMetricsSPD(
      deals = Some(PGDeals(getRoundValue(sum_deal),getRoundValue(sum_dev_deal),getRoundValue(sum_per_dev_deal),getRoundValue(sum_deal_without_internal))),
      projection = Some(PGProjection(getRoundValue(sum_projection),getRoundValue(sum_dev_projection),getRoundValue(sum_per_dev_projection),getRoundValue(sum_projection_without_internal))),
      ro = Some(PGRo(getRoundValue(sum_ro),getRoundValue(sum_dev_ro),getRoundValue(sum_per_dev_ro),getRoundValue(sum_ro_without_internal))),
      actual_booked = Some(PGActualBookedSPD(getRoundValue(sum_actual_revenue),getRoundValue(sum_dev_actual_revenue),getRoundValue(sum_per_dev_actual_revenue),getRoundValue(sum_revenue), getRoundValue(sum_dev_revenue), getRoundValue(sum_per_dev_revenue),Some(actual_num_days),Some(num_days),getRoundValue(sum_actual_internal),getRoundValue(sum_booked_revenue),getRoundValue(sum_revenue_internal),getRoundValue(sum_actual_without_internal),getRoundValue(sum_booked_without_internal),getRoundValue(sum_revenue_without_internal))),
      exit_cprp = Some(PGExitCprp(getRoundValue(sum_exit_revenue),getRoundValue(sum_exit_grp),getRoundValue(sum_dev_exit_revenue),getRoundValue(sum_dev_exit_grp),getRoundValue(sum_exit_cprp),getRoundValue(sum_dev_exit_cprp),getRoundValue(sum_per_dev_exit_cprp))),
      market_share = Some(PGMarketShare(getRoundValue(sum_grp),getRoundValue(sum_genre_grp),getRoundValue(sum_dev_grp),getRoundValue(sum_dev_genre_grp),getRoundValue(sum_market_share),getRoundValue(sum_dev_market_share),getRoundValue(sum_per_dev_market_share))),
      )
    (finalRevenueList,totalRevenueMetrics)
  }
  def getKeyValuePairs(rev_metrics: List[SPRevenueMetricsSPD]): List[(Option[String],SPRevenueMetricsSPD)] =
  {
    var obj_list : List[(Option[String],SPRevenueMetricsSPD)] = List()
    for (rev <- rev_metrics){
      obj_list = obj_list:+(rev.selection_group,rev)
    }
    obj_list
  }
}