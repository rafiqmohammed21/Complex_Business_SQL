package backends.sales_performance_dashboard.cards

import zio.Task
import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.metrics.SPOverallRevenueObject
import doobie.hikari.HikariTransactor

object OverallRevenueMetrics {
  def apply(transactor: HikariTransactor[Task],args:SPDArgs)
  : Task[DataResultWithTotalSPD] = {
    val overall_data: Task[DataResultWithTotalSPD] =  SPOverallRevenueObject(transactor, args)
    for{
      data  <- overall_data
    } yield data
  }
}