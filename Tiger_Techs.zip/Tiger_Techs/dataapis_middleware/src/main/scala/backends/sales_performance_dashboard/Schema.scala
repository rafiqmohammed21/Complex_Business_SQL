package backends.sales_performance_dashboard

object Schema {
  case class FunnelReportSchema (advertisers:String,
                                 projection:Option[Double]=None,
                                 dev_projection:Option[Double]=None,
                                 projection_deviation:Option[Double]=None,
                                 deal:Option[Double]=None,
                                 dev_deal:Option[Double]=None,
                                 deal_deviation:Option[Double]=None,
                                 ro:Option[Double]=None,
                                 dev_ro:Option[Double]=None,
                                 ro_deviation:Option[Double]=None,
                                 revenue:Option[Double]=None
                                )

  case class FunnelReportSchemaSPD (selection_group:Option[String],
                                 projection:Option[Double]=None,
                                 dev_projection:Option[Double]=None,
                                 projection_deviation:Option[Double]=None,
                                 deal:Option[Double]=None,
                                 dev_deal:Option[Double]=None,
                                 deal_deviation:Option[Double]=None,
                                 ro:Option[Double]=None,
                                 dev_ro:Option[Double]=None,
                                 ro_deviation:Option[Double]=None,
                                 revenue:Option[Double]=None
                                )

  case class RevenueReportSchema (selection_group:String,
                                  revenue:Option[Double]=None,
                                  dev_revenue:Option[Double]=None,
                                  revenue_deviation:Option[Double]=None,
                                  actual_revenue:Option[Double]=None,
                                  dev_actual_revenue:Option[Double]=None,
                                  actual_revenue_deviation:Option[Double]=None,
                                  booked_revenue:Option[Double]=None,
                                  grp:Option[Double]=None,
                                  dev_grp:Option[Double]=None,
                                  grp_deviation:Option[Double]=None,
                                  genre_grp:Option[Double]=None,
                                  dev_genre_grp:Option[Double]=None,
                                  genre_grp_deviation:Option[Double]=None,
                                  market_share:Option[Double]=None,
                                  dev_market_share:Option[Double]=None,
                                  market_share_deviation:Option[Double]=None,
                                  exit_cprp:Option[Double]=None,
                                  dev_exit_cprp:Option[Double]=None,
                                  exit_cprp_deviation:Option[Double]=None,
                                  exit_revenue:Option[Double]=None,
                                  dev_exit_revenue:Option[Double]=None,
                                  exit_grp:Option[Double]=None,
                                  dev_exit_grp:Option[Double]=None
                                 )

  case class RevenueReportSchemaSPD (selection_group:Option[String],
                                     revenue:Option[Double]=None,
                                     dev_revenue:Option[Double]=None,
                                     revenue_deviation:Option[Double]=None,
                                     actual_revenue:Option[Double]=None,
                                     dev_actual_revenue:Option[Double]=None,
                                     actual_revenue_deviation:Option[Double]=None,
                                     booked_revenue:Option[Double]=None,
                                     grp:Option[Double]=None,
                                     dev_grp:Option[Double]=None,
                                     grp_deviation:Option[Double]=None,
                                     genre_grp:Option[Double]=None,
                                     dev_genre_grp:Option[Double]=None,
                                     genre_grp_deviation:Option[Double]=None,
                                     fct:Option[Double]=None,
                                     dev_fct:Option[Double]=None,
                                     fct_deviation:Option[Double]=None,
                                     market_share:Option[Double]=None,
                                     dev_market_share:Option[Double]=None,
                                     market_share_deviation:Option[Double]=None,
                                     exit_cprp:Option[Double]=None,
                                     dev_exit_cprp:Option[Double]=None,
                                     exit_cprp_deviation:Option[Double]=None,
                                     exit_revenue:Option[Double]=None,
                                     dev_exit_revenue:Option[Double]=None,
                                     exit_grp:Option[Double]=None,
                                     dev_exit_grp:Option[Double]=None
                                    )

  case class TotalRevenueMetrics(
                                  deals: Option[PGDeals] = None,
                                  projection: Option[PGProjection] = None,
                                  ro: Option[PGRo] = None,
                                  actual_booked: Option[PGActualBooked] = None,
                                  exit_cprp : Option[PGExitCprp] = None,
                                  market_share: Option[PGMarketShare]=None,
                                  target : Option[SPTarget] = None
                                  )
  case class TotalRevenueMetricsSPD(
                                  deals: Option[PGDeals] = None,
                                  projection: Option[PGProjection] = None,
                                  ro: Option[PGRo] = None,
                                  actual_booked: Option[PGActualBookedSPD] = None,
                                  exit_cprp : Option[PGExitCprp] = None,
                                  market_share: Option[PGMarketShare]=None
                                )
  case class SPRevenueMetrics(
                               selection_group:String,
                               ro: Option[Double],
                               deal: Option[Double],
                               projection: Option[Double],
                               actual_revenue: Option[Double],
                               booked_revenue: Option[Double],
                               revenue: Option[Double],
                               ad_grp: Option[Double],
                               genre_grp: Option[Double],
                               market_share: Option[Double],
                               exit_revenue: Option[Double],
                               exit_grp: Option[Double],
                               exit_cprp: Option[Double],
                               ro_internal: Option[Double],
                               deal_internal: Option[Double],
                               projection_internal: Option[Double],
                               actual_internal: Option[Double],
                               booked_internal: Option[Double],
                               revenue_internal: Option[Double]
                             )

  case class SPRevenueMetricsSPD(
                                  selection_group:Option[String],
                                  ro: Option[Double],
                                  deal: Option[Double],
                                  projection: Option[Double],
                                  actual_revenue: Option[Double],
                                  booked_revenue: Option[Double],
                                  revenue: Option[Double],
                                  ad_grp: Option[Double],
                                  genre_grp: Option[Double],
                                  market_share: Option[Double],
                                  exit_revenue: Option[Double],
                                  exit_grp: Option[Double],
                                  exit_cprp: Option[Double],
                                  ro_internal: Option[Double],
                                  deal_internal: Option[Double],
                                  projection_internal: Option[Double],
                                  actual_internal: Option[Double],
                                  booked_internal: Option[Double],
                                  revenue_internal: Option[Double],
                                  fct: Option[Double]
                                )
  case class SPOverallRevenueSchema(
                                     var selection_group:String,
                                     var ro: Option[Double],
                                     var dev_ro: Option[Double],
                                     var per_dev_ro:Option[Double],
                                     var deal: Option[Double],
                                     var dev_deal:Option[Double],
                                     var per_dev_deal:Option[Double],
                                     var projection: Option[Double],
                                     var dev_projection:Option[Double],
                                     var per_dev_projection:Option[Double],
                                     var actual_revenue: Option[Double],
                                     var dev_actual_revenue:Option[Double],
                                     var per_dev_actual_revenue:Option[Double],
                                     var booked_revenue: Option[Double],
                                     var revenue: Option[Double],
                                     var dev_revenue:Option[Double],
                                     var per_dev_revenue:Option[Double],
                                     var grp: Option[Double],
                                     var dev_grp:Option[Double],
                                     var per_dev_grp:Option[Double],
                                     var genre_grp: Option[Double],
                                     var dev_genre_grp:Option[Double],
                                     var per_dev_genre_grp:Option[Double],
                                     var market_share: Option[Double],
                                     var dev_market_share:Option[Double],
                                     var per_dev_market_share:Option[Double],
                                     var exit_revenue: Option[Double],
                                     var dev_exit_revenue:Option[Double],
                                     var per_dev_exit_revenue:Option[Double],
                                     var exit_grp: Option[Double],
                                     var dev_exit_grp:Option[Double],
                                     var per_dev_exit_grp:Option[Double],
                                     var exit_cprp: Option[Double],
                                     var dev_exit_cprp:Option[Double],
                                     var per_dev_exit_cprp:Option[Double]
                                   )

  case class SPOverallRevenueSchemaSPD(
                                        var selection_group:Option[String],
                                        var ro: Option[Double],
                                        var dev_ro: Option[Double],
                                        var per_dev_ro:Option[Double],
                                        var deal: Option[Double],
                                        var dev_deal:Option[Double],
                                        var per_dev_deal:Option[Double],
                                        var fct: Option[Double],
                                        var dev_fct:Option[Double],
                                        var per_dev_fct:Option[Double],
                                        var projection: Option[Double],
                                        var dev_projection:Option[Double],
                                        var per_dev_projection:Option[Double],
                                        var actual_revenue: Option[Double],
                                        var dev_actual_revenue:Option[Double],
                                        var per_dev_actual_revenue:Option[Double],
                                        var booked_revenue: Option[Double],
                                        var revenue: Option[Double],
                                        var dev_revenue:Option[Double],
                                        var per_dev_revenue:Option[Double],
                                        var grp: Option[Double],
                                        var dev_grp:Option[Double],
                                        var per_dev_grp:Option[Double],
                                        var genre_grp: Option[Double],
                                        var dev_genre_grp:Option[Double],
                                        var per_dev_genre_grp:Option[Double],
                                        var market_share: Option[Double],
                                        var dev_market_share:Option[Double],
                                        var per_dev_market_share:Option[Double],
                                        var exit_revenue: Option[Double],
                                        var dev_exit_revenue:Option[Double],
                                        var per_dev_exit_revenue:Option[Double],
                                        var exit_grp: Option[Double],
                                        var dev_exit_grp:Option[Double],
                                        var per_dev_exit_grp:Option[Double],
                                        var exit_cprp: Option[Double],
                                        var dev_exit_cprp:Option[Double],
                                        var per_dev_exit_cprp:Option[Double]
                                      )

  case class PGDeals(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double], without_internal: Option[Double])
  case class PGProjection(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double], without_internal: Option[Double])
  case class PGRo(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double], without_internal: Option[Double])
  case class PGActualBooked(actual_revenue: Option[Double],dev_actual_revenue: Option[Double], actual_percentage_deviation: Option[Double], total_revenue: Option[Double] ,dev_total_revenue: Option[Double],total_revenue_percentage_deviation:Option[Double], number_of_days_actualised:Option[Long],number_of_days_month:Option[Long] , actual_revenue_internal:Option[Double],total_revenue_internal:Option[Double], actual_without_internal: Option[Double],booked_without_internal:Option[Double], total_without_internal: Option[Double] )
  case class PGActualBookedSPD(actual_revenue: Option[Double],dev_actual_revenue: Option[Double], actual_percentage_deviation: Option[Double], total_revenue: Option[Double] ,dev_total_revenue: Option[Double],total_revenue_percentage_deviation:Option[Double], number_of_days_actualised:Option[Long],number_of_days_month:Option[Long] , actual_revenue_internal:Option[Double],booked_revenue_internal:Option[Double],total_revenue_internal:Option[Double], actual_without_internal: Option[Double],booked_without_internal:Option[Double], total_without_internal: Option[Double] )
  case class PGExitCprp(total_revenue:Option[Double], total_ad_grp:Option[Double], total_deviation_revenue:Option[Double], total_deviation_ad_grp:Option[Double], total_exit_cprp:Option[Double], total_deviation_exit_cprp: Option[Double], total_percentage_deviation :Option[Double])
  case class PGMarketShare(current_channel_ad_grp: Option[Double], current_genre_ad_grp: Option[Double], deviation_channel_ad_gr: Option[Double], deviation_genre_ad_grp: Option[Double], market_share: Option[Double], deviation_market_share: Option[Double], percentage_deviation_market_share: Option[Double])
  case class PGTargetSPD(target:Option[Double],target_cprp:Option[Double])

  case class DataResultWithTotal(revenue:List[RevenueReportSchema],funnel:List[FunnelReportSchema], total :TotalRevenueMetrics)
  case class DataResultWithTotalSPD(revenue:List[RevenueReportSchemaSPD],funnel:List[FunnelReportSchemaSPD], target:TargetWithTotal, total :TotalRevenueMetricsSPD)

  case class SPRevenue(revenue: Option[Double], deviation_revenue: Option[Double], cprp: Option[Double], per_devitaion: Option[Double])
  case class SPOverallCprpSchema(
                                  selection_group : String,
                                  ro_revenue : Option[Double],
                                  ro_cprp: Option[Double],
                                  per_dev_ro_cprp: Option[Double],
                                  deal_revenue : Option[Double],
                                  deal_cprp: Option[Double],
                                  per_dev_deal_cprp: Option[Double],
                                  executed_revenue : Option[Double],
                                  executed_cprp: Option[Double],
                                  per_dev_executed_cprp: Option[Double]
                                )

  case class OverallCprpMetricsResult(cprp : List[SPOverallCprpSchema])
  case class SPOverallRevenueMetric(ro:Option[Double], deals:Option[Double], projection:Option[Double], actual_revenue:Option[Double], booked_revenue:Option[Double], revenue:Option[Double], actual_fct:Option[Double], grp : Option[Double], market_share: Option[Double], exit_cprp: Option[Double])

  case class OverallRevenueMetricsResult(revenue : List[SPOverallRevenueSchema],agg_revenue: RevenueAggregatedSchema)
  case class RevenueAggregatedSchema(
                                      ro:Option[Double] = None,
                                      dev_ro:Option[Double] = None,
                                      per_dev_ro:Option[Double]=None,
                                      ro_without_internal:Option[Double]=None,
                                      deals:Option[Double] = None,
                                      dev_deals:Option[Double] = None,
                                      per_dev_deals:Option[Double]=None,
                                      deals_without_internal:Option[Double]=None,
                                      projection:Option[Double] = None,
                                      dev_projection:Option[Double] = None,
                                      per_dev_projection:Option[Double]=None,
                                      projection_without_internal:Option[Double]=None,
                                      actual_revenue:Option[Double] = None,
                                      dev_actual_revenue:Option[Double] = None,
                                      per_dev_actual_revenue:Option[Double]=None,
                                      actual_revenue_without_internal:Option[Double]=None,
                                      booked_revenue:Option[Double]=None,
                                      booked_revenue_without_internal:Option[Double]=None,
                                      total_revenue:Option[Double]=None,
                                      dev_total_revenue:Option[Double]=None,
                                      per_dev_total_revenue:Option[Double]=None,
                                      total_revenue_without_internal:Option[Double]=None
                                    )

  case class TargetSchemaSPD (channel_name:String,
                              target:Option[Double]=None,
                              target_cprp:Option[Double]=None
                             )
case class TargetWithTotal(
                            target_list:List[SPTargetSPD],
                            total_target:Option[Double]=None,
                            total_target_cprp:Option[Double]=None,
                          )
  case class SPTarget(target: Option[Double])
  case class SPTargetSPD(selection_group: String, target_revenue:Option[Double],target_cprp:Option[Double])
  case class TargetMetricsResult(target : List[SPTarget])
  case class SPDTargetargs(selection: String, channel: List[String], period: Period, deviation_period: List[Period], regions: List[String], pt_npt: List[DayPart], impact_regular:Option[List[ImpactRegular]], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], agency: Option[List[String]],sub_agency: Option[List[String]], advertiser_category: Option[List[String]], brand: Option[List[String]], all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean, all_advertiser_category_selected: Boolean, all_brand_selected: Boolean)

  sealed trait Region
  object Region {
    case object EAST  extends Region
    case object WEST  extends Region
    case object NORTH extends Region
    case object SOUTH extends Region
  }

  sealed trait DayPart
  object DayPart {
    case object PT  extends DayPart
    case object NPT extends DayPart
  }

  sealed trait ImpactRegular
  object ImpactRegular {
    case object IMPACT  extends ImpactRegular
    case object REGULAR extends ImpactRegular
  }

  case class Period(start_date: String, end_date: String)
  case class SPDArgs(selection_group:String,channel: List[String], period: Period, deviation_period: List[Period], regions: List[String],pt_npt: List[DayPart], impact_regular:Option[List[ImpactRegular]], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], agency: Option[List[String]], sub_agency: Option[List[String]], advertiser_category: Option[List[String]],brands: Option[List[String]], all_region_selected: Boolean, all_advertiser_selected: Boolean, all_agency_selected: Boolean,all_sub_agency_selected: Boolean, all_advertiser_category_selected: Boolean, all_brand_selected: Boolean)
  case class BarcYearWeek(week:Option[Long], year:Option[Long])


}

