package backends.sales_performance_dashboard
import backends.sales_performance_dashboard.Schema._
import caliban.GraphQL.graphQL
import caliban.schema.GenericSchema
import caliban.{GraphQL, RootResolver}
import zio.ZIO
import zio.clock.Clock
import zio.console.Console
import scala.language.postfixOps

object SalesPerformanceDashboardApi extends GenericSchema[SalesPerformanceDashboardAkka] {

  case class Queries(
                      over_all_revenue_metrics : SPDArgs => ZIO[SalesPerformanceDashboardAkka,Throwable, DataResultWithTotalSPD]
                      ,over_all_cprp_metrics : SPDArgs => ZIO[SalesPerformanceDashboardAkka,Throwable,OverallCprpMetricsResult]
                      )
  var list_of_selections:List[String] = List()

  val api: GraphQL[Console with Clock with SalesPerformanceDashboardAkka] =
    graphQL(
      RootResolver(
        Queries(
          args => getOverallRevenueMetrics(args, list_of_selections),
          args => getOverallCprpMetrics(args, list_of_selections)
        )
      )
    )
}

