package backends.sales_performance_dashboard.metrics

import java.time.LocalDate

import backends.sales_performance_dashboard.Schema._
import backends.sales_performance_dashboard.metrics.Utils._
import org.json4s.DefaultFormats
import utils.BQApi.getDataFromBQ
import zio.Task

object SPOverallCprpObject {

  private implicit val formats = DefaultFormats

  def apply(args:SPDArgs)
  : Task[OverallCprpMetricsResult] =  {

    println("---------------------cprp metrics started------------------")
    val sub_agency = "null"
    val sub_agency_selected = false

    val (actual_date,booked_date) = getActualPeriod(args.period)
    var deviation_period_dates_arr :Array[String]= Array()
    args.deviation_period.foreach{ x =>
        deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date,x.end_date)
      }
    val lag_period = getLagDates(args.period.start_date,args.period.end_date)
    var lag_deviation_period_dates_arr :Array[String]= Array()
    args.deviation_period.foreach{ x =>
      val lag_deviation_period = getLagDates(x.start_date,x.end_date)
      lag_deviation_period_dates_arr = lag_deviation_period_dates_arr ++ Array(lag_deviation_period._1,lag_deviation_period._2)
    }
    val period_arr :Array[(String,String)] = Array((args.period.start_date,args.period.end_date))

    val deals_query =
      s""" CALL ${getSPName("sp_deals_cprp")}('${args.selection_group.toLowerCase}',
         |'${args.period.start_date}',
         |'${args.period.end_date}',
         |'${args.deviation_period.head.start_date}',
         |'${args.deviation_period.last.end_date}',
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |${gerArrayOfStringForString(args.channel.toArray)},
         |${gerArrayOfStringForString(args.regions.toArray)},
         |${gerArrayOfStringForString(args.pt_npt.toArray.map(x=>x.toString.toLowerCase))},
         |${getValueForStringList(args.advertiser_group)},
         |${getValueForStringList(args.deviation_advertiser_group)},
         |${getValueForStringList(args.agency)},
         |${sub_agency},
         |${getValueForStringList(args.advertiser_category)},
         |${getValueForStringList(args.brands)},
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${sub_agency_selected},
         |${args.all_advertiser_category_selected},
         |${args.all_brand_selected}
         |); """.stripMargin
    
    val ro_query =
      s""" CALL ${getSPName("sp_ro_cprp")}('${args.selection_group.toLowerCase}',
         |'${args.period.start_date}',
         |'${args.period.end_date}',
         |${getArrayOfStringForDates(deviation_period_dates_arr)},
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |${gerArrayOfStringForString(args.channel.toArray)},
         |${gerArrayOfStringForString(args.regions.toArray)},
         |${gerArrayOfStringForString(args.pt_npt.toArray.map(x=>x.toString.toLowerCase))},
         |${getValueForStringList(args.advertiser_group)},
         |${getValueForStringList(args.deviation_advertiser_group)},
         |${getValueForStringList(args.agency)},
         |${sub_agency},
         |${getValueForStringList(args.advertiser_category)},
         |${getValueForStringList(args.brands)},
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${sub_agency_selected},
         |${args.all_advertiser_category_selected},
         |${args.all_brand_selected}
         |); """.stripMargin
    
    val executed_query =
      s"""CALL ${getSPName("sp_executed_cprp")}('${args.selection_group.toLowerCase}',
         |'${actual_date.start_date}',
         |'${actual_date.end_date}',
         |${getArrayOfStringForDates(deviation_period_dates_arr)},
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |${gerArrayOfStringForString(args.channel.toArray)},
         |${gerArrayOfStringForString(args.regions.toArray)},
         |${gerArrayOfStringForString(args.pt_npt.toArray.map(x=>x.toString.toLowerCase))},
         |${getValueForStringList(args.advertiser_group)},
         |${getValueForStringList(args.deviation_advertiser_group)},
         |${getValueForStringList(args.agency)},
         |${sub_agency},
         |${getValueForStringList(args.advertiser_category)},
         |${getValueForStringList(args.brands)},
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${sub_agency_selected},
         |${args.all_advertiser_category_selected},
         |${args.all_brand_selected}
         |)""".stripMargin
    
    val deal_task = getOverallList(deals_query)
    val ro_task = getOverallList(ro_query)
    val executed_task = getOverallList(executed_query)
    var overall_results: List[SPOverallCprpSchema] = List()

    val res = for{
      ((ro_list:List[(String,SPRevenue)],executed_list:List[(String,SPRevenue)]),deal_list:List[(String,SPRevenue)])  <-  ro_task.zipPar(executed_task).zipPar(deal_task)
      final_results <- getOverallJoinedList(ro_list,executed_list, deal_list,args.period, args.deviation_period)
      data <- Task{
        final_results.foreach{
          elem =>
            val rev = SPOverallCprpSchema(
              selection_group = elem.selection_group,
              ro_revenue = elem.ro_revenue,
              ro_cprp = elem.ro_cprp,
              per_dev_ro_cprp = elem.per_dev_ro_cprp,
              deal_revenue = elem.deal_revenue,
              deal_cprp = elem.deal_cprp,
              per_dev_deal_cprp = elem.per_dev_deal_cprp,
              executed_revenue = elem.executed_revenue,
              executed_cprp = elem.executed_cprp,
              per_dev_executed_cprp = elem.per_dev_executed_cprp
            )
            overall_results ++= List(rev)
        }
        OverallCprpMetricsResult(final_results)
      }
    } yield data
    println("----------------- cprp metrics ended----------------------")
    res
  }




  def getOverallJoinedList(ro_list:List[(String,SPRevenue)], executed_list:List[(String,SPRevenue)], deal_list:List[(String,SPRevenue)], period: Period, dev_period: List[Period])
  : Task[List[SPOverallCprpSchema]] = Task{
    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    var finalList: List[SPOverallCprpSchema]=List()
    val joindf =  fullOuterJoin(List(ro_list,executed_list,deal_list))
    val nullDF = SPRevenue(None, None, None, None)
    for (elem <- joindf){
      val selection = elem._1
      val ro = elem._2(0) match {
        case Some(_) => elem._2(0).get.asInstanceOf[SPRevenue]
        case None => nullDF
      }
      val executed = elem._2(1) match {
        case Some(_) => elem._2(1).get.asInstanceOf[SPRevenue]
        case None => nullDF
      }
      val deals = elem._2(2) match {
        case Some(_) => elem._2(2).get.asInstanceOf[SPRevenue]
        case None => nullDF
      }
      finalList = finalList:+SPOverallCprpSchema(
        selection,
        getRoundValue(ro.revenue),
        getRoundValue(ro.cprp),
        getRoundValue(ro.per_devitaion),
        getRoundValue(deals.revenue),
        getRoundValue(deals.cprp),
        getRoundValue(deals.per_devitaion),
        getRoundValue(executed.revenue),
        getRoundValue(executed.cprp),
        getRoundValue(executed.per_devitaion)
      )
    }
    finalList

  }

  def getOverallList(query:String):Task[List[(String,SPRevenue)]] = Task{
    var selection_group_value:Option[String] = None
    var revenue:Option[Double] = None
    var deviation_revenue:Option[Double] = None
    var cprp:Option[Double] = None
    var per_deviation_revenue:Option[Double] = None

    var overall_list: List[(String,SPRevenue)] =List()
    for (row <- getDataFromBQ(query)) {
      selection_group_value={if (!row.get("selection_group").isNull) Some(row.get("selection_group").getStringValue)  else None}
      revenue={if (!row.get("total_revenue").isNull) Some(row.get("total_revenue").getDoubleValue)  else None}
      deviation_revenue={if (!row.get("total_deviation_revenue").isNull) Some(row.get("total_deviation_revenue").getDoubleValue)  else None}
      cprp={if (!row.get("cprp").isNull) Some(row.get("cprp").getDoubleValue)  else None}
      per_deviation_revenue={if (!row.get("percentage_deviation").isNull) Some(row.get("percentage_deviation").getDoubleValue)  else None}
      val metrics = SPRevenue(revenue,deviation_revenue,cprp,per_deviation_revenue)
      overall_list = overall_list:+(selection_group_value.getOrElse(""),metrics)
    }
    overall_list
  }

}