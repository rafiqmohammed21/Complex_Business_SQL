package backends.sales_dashboard.metrics.bq

import backends.sales_dashboard.Schema.{DayPart, FairShare, ImpactRegular, Period, SalesDashBoardReportArgsFlags}
import backends.sales_dashboard.metrics.Utils.{gerArrayOfStringForString, getSPName, getValueForImpactRegular}
import utils.BQApi.getDataFromBQ
import zio.Task

object FairShareSql {

  def queryBuilder(channel :String,period:Period,impact_regular: Option[List[ImpactRegular]],pt_npt: List[DayPart]): String =  {
    val value_for_impact_regular = getValueForImpactRegular(impact_regular)
    val query  =
      s"""CALL ${getSPName("sp_fair_share")}('${period.start_date}',
         |'${period.end_date}',
         |'${channel.toLowerCase}',
         |${gerArrayOfStringForString(pt_npt.toArray.map(x=>x.toString.toLowerCase))},
         |$value_for_impact_regular
         |)""".stripMargin

    query
  }
}
