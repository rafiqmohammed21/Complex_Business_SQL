package backends.sales_dashboard.metrics.pg

import backends.sales_dashboard.Schema._
import backends.sales_dashboard.metrics.Utils._
import doobie.Fragment
import doobie.hikari.HikariTransactor
import doobie.implicits._
import doobie.util.query.Query0
import zio.Task
import zio.interop.catz._

object PGTargetWithCprpSql {
  
  def getSqlQuery (args: SalesDashBoardReportArgsFlags) : Query0[PGTargetWithCPRP] = {
    val query_filter_fr  =
      s""" ('${args.period.start_date}',
         |'${args.channel.toLowerCase}',
         |${gerArrayOfStringForStringPG(args.regions.toArray)},
         |${getValueForImpactRegularPG(args.impact_regular)},
         |${gerArrayOfStringForStringPG(args.pt_npt.toArray.map(x=>x.toString.toLowerCase))}
         |) """.stripMargin

    val func_str = fr""" select * from "func_target_with_cprp" """.stripMargin

    (func_str++Fragment.const(query_filter_fr)).query[PGTargetWithCPRP]

  }

  def apply(transactor:  HikariTransactor[Task],salesDashBoardReportArgsFlags: SalesDashBoardReportArgsFlags)
  : Task[List[PGTargetWithCPRP]] =  {
    getSqlQuery(salesDashBoardReportArgsFlags).to[List].transact(transactor)
  }
}
