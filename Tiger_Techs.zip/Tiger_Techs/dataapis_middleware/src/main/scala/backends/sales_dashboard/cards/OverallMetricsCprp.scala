package backends.sales_dashboard.cards
import backends.sales_dashboard.Schema._
import backends.sales_dashboard.metrics.Utils._
import doobie.hikari.HikariTransactor
import utils.BQApi.getDataFromBQ
import zio.Task

import scala.util.Try

object OverallMetricsCprp {
  def apply(trans: HikariTransactor[Task], args:SPDReportArgsRegFlagWithCategory)
  : Task[OverallCprpMetricsResult] =  {
    println("---------------------cprp metrics started------------------")

    val query = OverallMetricsCprpSql.queryBuilder(args)

    val deals_query = query._1
    val ro_query = query._2
    val executed_query = query._3

    val deal_task = getOverallList(deals_query)
    val ro_task = getOverallList(ro_query)
    val executed_task = getOverallList(executed_query)

    var overall_results: List[SPOverallCprpSchema] = List()
    println(args.advertiser_group.get)
    val res = for{
      ((ro_list:(List[(String,SPCprpMetrics)],SPCprpMetrics),executed_list:(List[(String,SPCprpMetrics)],SPCprpMetrics)),deal_list:(List[(String,SPCprpMetrics)],SPCprpMetrics))  <-  ro_task.zipPar(executed_task).zipPar(deal_task)
      final_results <- getOverallJoinedList(ro_list._1,executed_list._1, deal_list._1,args.period, args.deviation_period, args.advertiser_group.get)

      total_ro = ro_list._2
      total_deal = deal_list._2
      total_executed = executed_list._2
      data <- Task{
        final_results.foreach{
          elem =>
            val rev = elem
            overall_results ++= List(rev)
        }
         val totalCprpMetrics = PricingToDateDataResult(
          deals_cprp = Some(DealCprp(total_revenue = total_deal.revenue,
            total_ad_grp = total_deal.grp,
            deals_cprp = total_deal.cprp,
            total_deviation_revenue = total_deal.dev_revenue,
            total_deviation_ad_grp = total_deal.dev_grp,
            deviation_deals_cprp = total_deal.dev_cprp,
            total_percentage_deviation = total_deal.per_devitaion)
          ),
          ro_cprp = Some(RoCprp(total_revenue = total_ro.revenue,
            total_ad_grp = total_ro.grp,
            ro_cprp = total_ro.cprp,
            total_deviation_revenue = total_ro.dev_revenue,
            total_deviation_ad_grp = total_ro.dev_grp,
            deviation_ro_cprp = total_ro.dev_cprp,
            total_percentage_deviation = total_ro.per_devitaion)
          ),
          executed_cprp = Some(ExecutedCprp(total_revenue = total_executed.revenue,
            total_ad_grp = total_executed.grp,
            executed_cprp = total_executed.cprp,
            total_deviation_revenue = total_executed.dev_revenue,
            total_deviation_ad_grp = total_executed.dev_grp,
            deviation_executed_cprp = total_executed.dev_cprp,
            total_percentage_deviation = total_executed.per_devitaion)
          )
        )
        OverallCprpMetricsResult(final_results,totalCprpMetrics)
      }
    } yield data
    println("----------------- cprp metrics ended----------------------")
    res
  }

  def getKeyValuePairs(rev_metrics: List[RevenueReportSchema]): Map[String,RevenueReportSchema] =
  {
    var cprp_obj_list : Map[String,RevenueReportSchema] = Map()
    for (rev <- rev_metrics){
      cprp_obj_list = cprp_obj_list ++ Map(rev.advertisers -> rev)
    }
    cprp_obj_list
  }


  def getOverallJoinedList(ro_list:List[(String,SPCprpMetrics)], executed_list:List[(String,SPCprpMetrics)], deal_list:List[(String,SPCprpMetrics)],period: Period, dev_period: List[Period], advertiser_list: List[String])
  : Task[List[SPOverallCprpSchema]] = Task{
    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    var finalList: List[SPOverallCprpSchema]=List()
    val joindf =  fullOuterJoin(List(ro_list,executed_list,deal_list))
    val nullDF = SPCprpMetrics(None, None, None, None, None, None, None)
    for (elem <- joindf){
      val advertiser_group = elem._1
      val ro = elem._2(0) match {
        case Some(_) => elem._2(0).get.asInstanceOf[SPCprpMetrics]
        case None => nullDF
      }
      val executed = elem._2(1) match {
        case Some(_) => elem._2(1).get.asInstanceOf[SPCprpMetrics]
        case None => nullDF
      }
      val deal = elem._2(2) match {
        case Some(_) => elem._2(2).get.asInstanceOf[SPCprpMetrics]
        case None => nullDF
      }

      if(advertiser_list.map(x=>x.toLowerCase).contains(advertiser_group.toLowerCase)) {
        finalList = finalList :+ SPOverallCprpSchema(
          advertiser_group,
          ro_revenue = getRoundValue(ro.revenue),
          ro_grp = getRoundValue(ro.grp),
          ro_cprp = getRoundValue(ro.cprp),
          dev_ro_revenue = getRoundValue(ro.dev_revenue),
          dev_ro_grp = getRoundValue(ro.dev_grp),
          dev_ro_cprp = getRoundValue(ro.dev_cprp),
          per_dev_ro_cprp = getRoundValue(ro.per_devitaion),
          deal_revenue = getRoundValue(deal.revenue),
          deal_grp = getRoundValue(deal.grp),
          deal_cprp = getRoundValue(deal.cprp),
          dev_deal_revenue = getRoundValue(deal.dev_revenue),
          dev_deal_grp = getRoundValue(deal.dev_grp),
          dev_deal_cprp = getRoundValue(deal.dev_cprp),
          per_dev_deal_cprp = getRoundValue(deal.per_devitaion),
          executed_revenue = getRoundValue(executed.revenue),
          executed_grp = getRoundValue(executed.grp),
          executed_cprp = getRoundValue(executed.cprp),
          dev_executed_revenue = getRoundValue(executed.dev_revenue),
          dev_executed_grp = getRoundValue(executed.dev_grp),
          dev_executed_cprp = getRoundValue(executed.dev_cprp),
          per_dev_executed_cprp = getRoundValue(executed.per_devitaion)
        )
      }
    }
    finalList

  }

  def getOverallList(query:String):Task[(List[(String,SPCprpMetrics)],SPCprpMetrics)] = Task{
    var advertiser_group:Option[String] = None
    var revenue:Option[Double] = None
    var grp : Option[Double] = None
    var cprp : Option[Double] = None
    var dev_revenue:Option[Double] = None
    var dev_grp : Option[Double] = None
    var dev_cprp:Option[Double] = None
    var percentage_deviation:Option[Double] = None
    var total_revenue:Option[Double] = None
    var total_grp : Option[Double] = None
    var total_cprp : Option[Double] = None
    var total_dev_revenue:Option[Double] = None
    var total_dev_grp : Option[Double] = None
    var total_dev_cprp:Option[Double] = None
    var total_per_deviation:Option[Double] = None

    var overall_list: List[(String,SPCprpMetrics)] =List()
    for (row <- getDataFromBQ(query)) {
      advertiser_group=Try(row.get("advertiser_group").getStringValue).toOption
      revenue=Try(row.get("revenue").getDoubleValue).toOption
      total_revenue = getOptionSum(total_revenue,revenue)
      grp=Try(row.get("ad_grp").getDoubleValue).toOption
      total_grp = getOptionSum(total_grp,grp)
      cprp=Try(row.get("cprp").getDoubleValue).toOption
      dev_revenue=Try(row.get("deviation_revenue").getDoubleValue).toOption
      total_dev_revenue = getOptionSum(total_dev_revenue,dev_revenue)
      dev_grp=Try(row.get("deviation_ad_grp").getDoubleValue).toOption
      total_dev_grp = getOptionSum(total_dev_grp,dev_grp)
      dev_cprp=Try(row.get("deviation_cprp").getDoubleValue).toOption
      percentage_deviation=Try(row.get("percentage_deviation").getDoubleValue).toOption

      val metrics = SPCprpMetrics(
        revenue,
        grp,
        cprp,
        dev_revenue,
        dev_grp,
        dev_cprp,
        percentage_deviation
      )
      overall_list = overall_list:+(advertiser_group.getOrElse(""),metrics)
    }
    total_cprp = Try((total_revenue.get*10000000)/total_grp.get).toOption
    total_dev_cprp = Try((total_dev_revenue.get*10000000)/total_dev_grp.get).toOption
    total_per_deviation = getPercentageDeviation(total_cprp,total_dev_cprp)
    val total_cprp_metrics=SPCprpMetrics(
      getRoundValue(total_revenue),
      getRoundValue(total_grp),
      getRoundValue(total_cprp),
      getRoundValue(total_dev_revenue),
      getRoundValue(total_dev_grp),
      getRoundValue(total_dev_cprp),
      getRoundValue(total_per_deviation)
    )
    (overall_list,total_cprp_metrics)
  }

  def asGcsFilePath(list_of_selections: List[String], transactor:  HikariTransactor[Task], args: SPDReportArgsRegFlagWithCategory)
  :Task[ReportResultCprp] = {

    val value_for_is_regional = args.is_regional match {
      case None => false
      case Some(true) => true
      case Some(false) => false
      case _ => false
    }

    val task_overall = OverAllMetricsPG(transactor: HikariTransactor[Task], args)
    val cprp_overall = apply(transactor: HikariTransactor[Task],args)
    val impact_length =  args.impact_regular match {
      case None => 0
      case _ => args.impact_regular.get.length
    }
    var only_impact = false
    if (impact_length==1)
    {
      if (!args.impact_regular.get(0).toString.toLowerCase.contains("regular"))
        only_impact = true
    }

    if(value_for_is_regional == false){

      for {
        rev_funnel: DataResultWithTotal <- task_overall
        cprp_obj: OverallCprpMetricsResult <- cprp_overall
        revenue_list_gcs_path <- getUploadPathRevenueReport(rev_funnel.revenue,only_impact)
        funnel_list_gcs_path <- getUploadPathFunnelReport(rev_funnel.funnel)
        cprp_obj_list = getKeyValuePairs(rev_funnel.revenue)
        cprp_list_gcs_path <- getUploadPathCprpReport(cprp_obj.cprp, cprp_obj_list,only_impact)
      } yield ReportResultCprp(revenue_list_gcs_path, funnel_list_gcs_path, cprp_list_gcs_path)

    }

    else {

      for {
        rev_funnel: DataResultWithTotal <- task_overall
        cprp_obj: OverallCprpMetricsResult <- cprp_overall
        revenue_list_gcs_path <- getUploadPathRevenueReportReg(rev_funnel.revenue,only_impact)
        funnel_list_gcs_path <- getUploadPathFunnelReportReg(rev_funnel.funnel)
        cprp_obj_list = getKeyValuePairs(rev_funnel.revenue)
        cprp_list_gcs_path <- getUploadPathCprpReportReg(cprp_obj.cprp, cprp_obj_list,only_impact)
      } yield ReportResultCprp(revenue_list_gcs_path, funnel_list_gcs_path, cprp_list_gcs_path)

    }
  }


}
