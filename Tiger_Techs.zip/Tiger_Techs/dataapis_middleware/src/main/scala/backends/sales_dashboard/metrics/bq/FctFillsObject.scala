package backends.sales_dashboard.metrics.bq

import backends.sales_dashboard.SalesDashboardApi
import backends.sales_dashboard.Schema.{FctFills, InfoSchema, Period}
import backends.sales_dashboard.cards.InfoFillsFairShare
import org.slf4j.{Logger, LoggerFactory}
import scalacache.Cache
import scalacache.redis.RedisCache
import scalacache.serialization.binary._
import utils.BQApi.getDataFromBQ
import scalacache.Mode

import scala.concurrent.duration._
import zio.Task
import zio.interop.catz._
import scalacache.memoization._
import utils.Configs

object FctFillsObject{

  implicit val redisCache: Cache[FctFills] = RedisCache(SalesDashboardApi.jedisPool)
  implicit val mode: Mode[Task] = scalacache.CatsEffect.modes.async


  val logger: Logger = LoggerFactory.getLogger(getClass.getName)
  logger.info("Connected to redis database : " + Configs.REDIS_CONNECTION_URL)

  def apply(channel:String,period: Period)
  : Task[FctFills] =  memoizeF[Task, FctFills](Some(Configs.REDIS_CACHE_RESTORE_TIME)) {
    val query = FctFillsSql.queryBuilder(channel,period)
    var with_hul:Option[Double] = None
    var without_hul:Option[Double] = None

    for (row <- getDataFromBQ(query)) {
      with_hul={if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
      without_hul={if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
    }
    Task(FctFills(with_hul = with_hul, without_hul = without_hul))
  }
}
