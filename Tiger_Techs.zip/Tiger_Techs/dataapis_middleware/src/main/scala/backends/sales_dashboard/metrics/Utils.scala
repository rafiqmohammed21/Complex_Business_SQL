package backends.sales_dashboard.metrics

import java.io.File
import java.time.format.DateTimeFormatter
import java.time.{LocalDate, LocalDateTime}
import java.time.temporal.ChronoUnit.DAYS

import backends.sales_dashboard.Schema.{FunnelReportSchema, ImpactRegular, Period, RevenueReportSchema,SPOverallCprpSchema}
import utils.Configs
import utils.CsvGenerator._
import utils.GcsUpload.uploadFile
import zio.Task

import scala.util.Try
object Utils {

  def getSPName(sp:String):String={
    var dataset = ""

    val env  = Configs.ENV
    if (env=="local"){
      dataset = "test_reports"
    }
    else if(env=="dev"){
      dataset = "dev_reports"
    }
    else if(env=="stg"){
      dataset = "stg_reports"
    }
    else if(env=="uat"){
      dataset = "uat_reports"
    }
    else if(env=="prod"){
      dataset = "prod_reports"
    }

    val sp_map:Map[String,String] = Map(
      "sp_deals_cprp" -> f"$dataset.sp_deals_cprp",
      "sp_executed_cprp" -> f"$dataset.sp_executed_cprp",
      "sp_executed_cprp_new" -> f"$dataset.sp_executed_cprp_new",
      "sp_ro_cprp" -> f"$dataset.sp_ro_cprp",
      "sp_fair_share" -> f"$dataset.sp_fair_share",
      "sp_fct_fills" -> f"$dataset.sp_fct_fills",
      "sp_info" -> f"$dataset.sp_info",
    )
    sp_map(sp)
  }

  def dates(fromDate: LocalDate): Stream[LocalDate] = {
    fromDate #:: dates(fromDate plusDays 1 )
  }

  def stringToDate(date_str:String):LocalDate={
    val dateFormat = "yyyy-MM-dd"
    val dtf = java.time.format.DateTimeFormatter.ofPattern(dateFormat)
    java.time.LocalDate.parse(date_str, dtf)
  }

  def getLagDates(sd_str:String, ed_str:String):(String,String)={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str)
    val diff :Long = DAYS.between(sd, ed)+1
    val no_of_weeks:Long = (diff/7).ceil.toLong
    val lag_sd = sd.minusDays((no_of_weeks+8)*7)
    val lag_ed = ed.minusDays((no_of_weeks+8)*7)
    (lag_sd.toString,lag_ed.toString)
  }

  def getLagDatesReg(sd_str:String, ed_str:String):(String,String)={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str)
    val diff :Long = DAYS.between(sd, ed)+1
    val no_of_weeks = if (diff<=35) 4 else (diff/7).ceil.toLong
    val
    lag_sd = sd.minusDays((no_of_weeks+4)*7)
    val lag_ed = lag_sd.plusDays( (no_of_weeks*7)-1 )
    (lag_sd.toString,lag_ed.toString)
  }
  val query_str = """ select * from "disney_fy_cal" """.stripMargin

  def getLagDatesForCovid(sd_str:String, ed_str:String):(String,String)={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str)
    val diff :Long = DAYS.between(sd, ed)+1

    val no_of_weeks = if (diff<=35) 4 else (diff/7).ceil.toLong

    var lag_sd = sd.minusDays((no_of_weeks+4)*7)
    var lag_ed = lag_sd.plusDays( (no_of_weeks*7)-1 )

    if (sd.compareTo(stringToDate("2020-03-29")) >=0 && sd.compareTo(stringToDate("2020-10-03")) <=0 ){
       lag_sd = sd.minusDays((no_of_weeks+0)*7)
       lag_ed = lag_sd.plusDays( (no_of_weeks*7)-1 )
    }
    (lag_sd.toString,lag_ed.toString)
  }

  def getDateArray(sd_str:String, ed_str:String):Array[String]={
    val sd = stringToDate(sd_str)
    val ed = stringToDate(ed_str).plusDays(1)
    val date_array = dates(LocalDate.of(sd.getYear,sd.getMonthValue , sd.getDayOfMonth)).takeWhile(_.isBefore(LocalDate.of(ed.getYear,ed.getMonthValue , ed.getDayOfMonth))).toArray
    val string_array = date_array.map(x => x.toString)
    string_array
  }

  def listOfStringToListofDateFormatter(str_list:Array[String]):String = {
    var res_str:String = "DATE '"+str_list.head.toLowerCase+"'"
    for(element<-str_list.tail)
    {
      res_str+=", DATE '"+element.toLowerCase()+"'"
    }
    res_str
  }

  def listOfStringToListofDateFormatterPG(str_list:Array[String]):String = {
    var res_str:String = "'"+str_list.head.toLowerCase+"'::date"
    for(element<-str_list.tail)
    {
      res_str+=", '"+element.toLowerCase()+"'::date"
    }
    res_str
  }

  def listOfStructOfStringToListofDateFormatter(str_list:Array[(String,String)]):String = {
    var res_str:String = s"(DATE '${str_list.head._1}', DATE '${str_list.head._2}')"
    for(element<-str_list.tail)
    {
      res_str+=s", (DATE '${element._1}', DATE '${element._2}')"
    }
    res_str
  }

  def listOfStructOfStringToListofDateFormatterPG(str_list:Array[(String,String)]):String = {
    var res_str:String = s"row( '${str_list.head._1}', '${str_list.head._2}')"
    for(element<-str_list.tail)
    {
      res_str+=s", row( '${element._1}', '${element._2}')"
    }
    res_str
  }

  def formatList(channel_list:Array[String]):String = {
    var res_str:String = """  """"+channel_list.head.toLowerCase+"""" """
    for(element<-channel_list.tail)
    {
      res_str+="""  ,""""+element.toLowerCase()+"""" """
    }
    res_str
  }
  def formatListPG(channel_list:Array[String]):String = {
    var res_str:String = """  E'"""+channel_list.head.toLowerCase.replace("'","\\'") +"""' """
    for(element<-channel_list.tail)
    {
      res_str+="""  ,E'"""+element.toLowerCase.replace("'","\\'")+"""' """
    }
    res_str
  }
  def formatListPGCustom(channel_list:Array[String]):String = {
    var res_str:String =
      """
        |E'""".stripMargin+channel_list.head.toLowerCase.replace("'","\\'") +"""' """
    for(element<-channel_list.tail)
    {
      res_str+=
        """
          |,E'""".stripMargin+element.toLowerCase.replace("'","\\'")+"""' """
    }
    res_str
  }
  def gerArrayOfStringForString(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${formatList(lst)} ]"
    }
    res
  }

  def gerArrayOfStringForStringPG(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${formatListPG(lst)} ]"
    }
    res
  }
  def gerArrayOfStringForStringPGCustom(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${formatListPGCustom(lst)} ]"
    }
    res
  }

  def getArrayOfStringForDates(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${listOfStringToListofDateFormatter(lst)} ]"
    }
    res
  }

  def getArrayOfStringForDatesPG(lst: Array[String]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${listOfStringToListofDateFormatterPG(lst)} ]"
    }
    res
  }

  def getArrayOfStructOfStringForDates(lst: Array[(String,String)]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "["
      res += f"${listOfStructOfStringToListofDateFormatter(lst)} ]"
    }
    res
  }

  def getArrayOfStructOfStringForDatesPG(lst: Array[(String,String)]):String={
    var res:String = "null"
    if(!lst.isEmpty) {
      res = "array["
      res += f"${listOfStructOfStringToListofDateFormatterPG(lst)} ]::period_type[]"
    }
    res
  }

  def getActualPeriod(period:Period):(Period,Period)={
    var actual_date = Period(period.start_date, period.end_date)
    var booked_date = Period("1891-01-01", "1891-01-01")
    val today_date = LocalDate.now()

    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {

      actual_date = Period(
        start_date = actual_date.start_date,
        end_date = today_date.minusDays(1).toString())
      booked_date = Period(start_date = today_date.toString(), end_date = period.end_date)
    }
    (actual_date,booked_date)
  }


  def getActualPeriodEnt(period:Period):(Period,Period)={
    var actual_date = Period(period.start_date, period.end_date)
    var booked_date = Period("1891-01-01", "1891-01-01")
    val today_date = LocalDate.now()

    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {

      actual_date = Period(
        start_date = actual_date.start_date,
        end_date = today_date.toString())
      booked_date = Period(start_date = today_date.plusDays(1).toString(), end_date = period.end_date)
    }
    (actual_date,booked_date)
  }
  

  def getValueForAgency(agency:Option[List[String]]):String = agency match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(agency.get.toArray)
  }
  def getValueForAgencyPG(agency:Option[List[String]]):String = agency match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(agency.get.toArray)
  }

  def  getValueForSubAgency(sub_agency:Option[List[String]]):String = sub_agency match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(sub_agency.get.toArray)
  }

  def  getValueForSubAgencyPG(sub_agency:Option[List[String]]):String = sub_agency match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(sub_agency.get.toArray)
  }

  def getValueForAdvertiserGroup(advertiser_group:Option[List[String]]):String = advertiser_group match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(advertiser_group.get.toArray)
  }
  def getValueForAdvertiserGroupPG(advertiser_group:Option[List[String]]):String = advertiser_group match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(advertiser_group.get.toArray)
  }

  def getValueForDeviationAdvertiserGroupPG(deviation_advertiser_group:Option[List[String]]):String = deviation_advertiser_group match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(deviation_advertiser_group.get.toArray)
  }

  def getStringValueFromList(str_list: Option[List[String]]): String = str_list match{
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(str_list.get.toArray)
  }

  def getStringValueFromListCustom(str_list: Option[List[String]]): String = str_list match{
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPGCustom(str_list.get.toArray)
  }

  def getValueForDeviationAdvertiserGroup(deviation_advertiser_group:Option[List[String]]):String = deviation_advertiser_group match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(deviation_advertiser_group.get.toArray)
  }



  def getValueForImpactRegular(impact_regular: Option[List[ImpactRegular]]):String = impact_regular match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForString(impact_regular.get.map(_.toString).toArray)
  }

  def getValueForImpactRegularPG(impact_regular: Option[List[ImpactRegular]]):String = impact_regular match {
    case None => "null"
    case Some(_) =>  gerArrayOfStringForStringPG(impact_regular.get.map(_.toString).toArray)
  }

  def getUploadPathRevenueReport(results: List[RevenueReportSchema],only_impact:Boolean): Task[String] = Task {
    if (only_impact==true){
      val header: String = "Advertisers,Revenue,Revenue Deviation,GRP,GRP Deviation"
      var list_of_objects:List[List[String]] = List()
      results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.revenue.getOrElse("").toString
        ,x.revenue_deviation.getOrElse("").toString,x.grp.getOrElse("").toString
        ,x.grp_deviation.getOrElse("").toString))

      val file_name = f"Revenue_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
      val file_path = f"/tmp/$file_name"
      writeToCsv(file_path,header,list_of_objects)
      val res:String = uploadFile(file_path, file_name)
      new File(file_path).delete()
      res
    }
    else {
      val header: String = "Advertisers,Revenue,Revenue Deviation,GRP,GRP Deviation,Market Share,Market Share Deviation,Exit CPRP"
      var list_of_objects:List[List[String]] = List()
      results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.revenue.getOrElse("").toString
        ,x.revenue_deviation.getOrElse("").toString,x.grp.getOrElse("").toString
        ,x.grp_deviation.getOrElse("").toString,x.market_share.getOrElse("").toString
        ,x.market_share_deviation.getOrElse("").toString,x.exit_cprp.getOrElse("").toString))
      val file_name = f"Revenue_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
      val file_path = f"/tmp/$file_name"
      writeToCsv(file_path,header,list_of_objects)
      val res:String = uploadFile(file_path, file_name)
      new File(file_path).delete()
      res
    }
  }

  def getUploadPathRevenueReportReg(results: List[RevenueReportSchema],only_impact:Boolean): Task[String] = Task {
    if (only_impact==true){
      val header: String = "Advertisers,Revenue,Revenue Deviation,GRP,GRP Deviation"
      var list_of_objects:List[List[String]] = List()
      results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.revenue.getOrElse("").toString
        ,x.revenue_deviation.getOrElse("").toString,x.grp.getOrElse("").toString
        ,x.grp_deviation.getOrElse("").toString))

      val file_name = f"Revenue_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.xlsx"
      val file_path = f"/tmp/$file_name"
      writeToExcel(file_path,"Revenue",header,list_of_objects)
      val res:String = uploadFile(file_path, file_name)
      new File(file_path).delete()
      res
    }
    else {
      val header: String = "Advertisers,Revenue,Revenue Deviation,GRP,GRP Deviation,Market Share,Market Share Deviation,Exit CPRP"
      var list_of_objects:List[List[String]] = List()
      results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.revenue.getOrElse("").toString
        ,x.revenue_deviation.getOrElse("").toString,x.grp.getOrElse("").toString
        ,x.grp_deviation.getOrElse("").toString,x.market_share.getOrElse("").toString
        ,x.market_share_deviation.getOrElse("").toString,x.exit_cprp.getOrElse("").toString))
      val file_name = f"Revenue_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.xlsx"
      val file_path = f"/tmp/$file_name"
      writeToExcel(file_path,"Revenue",header,list_of_objects)
      val res:String = uploadFile(file_path, file_name)
      new File(file_path).delete()
      res
    }
  }

  def getUploadPathFunnelReport(results: List[FunnelReportSchema]): Task[String] = Task {
    // val header :String= classOf[FunnelReportSchema].getDeclaredFields.toList.map( field => field.getName ).mkString(",")
    val header: String = "Advertisers,Projection,Projection Deviation,Deal,Deal Deviation,Release Order,Release Order Deviation,Revenue"

    var list_of_objects:List[List[String]] = List()
    results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.projection.getOrElse("").toString
      ,x.projection_deviation.getOrElse("").toString,x.deal.getOrElse("").toString
      ,x.deal_deviation.getOrElse("").toString,x.ro.getOrElse("").toString
      ,x.ro_deviation.getOrElse("").toString,x.revenue.getOrElse("").toString))
    val file_name = f"Funnel_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
    val file_path = f"/tmp/$file_name"
    writeToCsv(file_path,header,list_of_objects)
    val res:String = uploadFile(file_path, file_name)
    new File(file_path).delete()
    res
  }

  def getUploadPathFunnelReportReg(results: List[FunnelReportSchema]): Task[String] = Task {
    // val header :String= classOf[FunnelReportSchema].getDeclaredFields.toList.map( field => field.getName ).mkString(",")
    val header: String = "Advertisers,Projection,Projection Deviation,Revenue"
    var list_of_objects:List[List[String]] = List()
    results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertisers,x.projection.getOrElse("").toString
      ,x.projection_deviation.getOrElse("").toString,x.revenue.getOrElse("").toString))
    val file_name = f"Funnel_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.xlsx"
    val file_path = f"/tmp/$file_name"
    writeToExcel(file_path,"Funnel",header,list_of_objects)
    val res:String = uploadFile(file_path, file_name)
    new File(file_path).delete()
    res
  }

  def getUploadPathCprpReport(results: List[SPOverallCprpSchema], rev_result: Map [String, RevenueReportSchema], only_impact:Boolean): Task[String] = Task {
    // val header :String= classOf[FunnelReportSchema].getDeclaredFields.toList.map( field => field.getName ).mkString(",")
    val header: String = "Advertisers,Deal CPRP,Deal CPRP Deviation,Release Order CPRP,Release Order CPRP Deviation,Executed CPRP,Executed CPRP Deviation,Exit CPRP, Exit CPRP Deviation, Revenue, Revenue Deviation"

    var list_of_objects:List[List[String]] = List()
    results.foreach(x=>list_of_objects=list_of_objects:+List(x.advertiser_group,x.deal_cprp.getOrElse("").toString
      ,x.per_dev_deal_cprp.getOrElse("").toString,x.ro_cprp.getOrElse("").toString
      ,x.per_dev_ro_cprp.getOrElse("").toString,x.executed_cprp.getOrElse("").toString
      ,x.per_dev_executed_cprp.getOrElse("").toString,
      rev_result.get(x.advertiser_group) match {
        case None => ""
        case Some(_) => if(only_impact) "N/A" else rev_result.get(x.advertiser_group).get.exit_cprp.getOrElse("").toString},
      rev_result.get(x.advertiser_group) match {
        case None => ""
        case Some(_) => rev_result.get(x.advertiser_group).get.exit_cprp_deviation.getOrElse("").toString},
      rev_result.get(x.advertiser_group) match {
        case None => ""
        case Some(_) => rev_result.get(x.advertiser_group).get.revenue.getOrElse("").toString},
      rev_result.get(x.advertiser_group) match {
        case None => ""
        case Some(_) => rev_result.get(x.advertiser_group).get.revenue_deviation.getOrElse("").toString}))

    val file_name = f"Cprp_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.csv"
    val file_path = f"/tmp/$file_name"
    writeToCsv(file_path,header,list_of_objects)
    val res:String = uploadFile(file_path, file_name)
    new File(file_path).delete()
    res
  }

  def getUploadPathCprpReportReg(results: List[SPOverallCprpSchema], rev_result: Map [String, RevenueReportSchema], only_impact:Boolean): Task[String] = Task {
    // val header :String= classOf[FunnelReportSchema].getDeclaredFields.toList.map( field => field.getName ).mkString(",")
    val header: String = "Advertisers,Executed CPRP,Executed CPRP Deviation,Exit CPRP, Exit CPRP Deviation, Revenue, Revenue Deviation"

    var list_of_objects:List[List[String]] = List()
    results.foreach( x =>

      list_of_objects=list_of_objects:+List(

        x.advertiser_group,
        x.executed_cprp.getOrElse("").toString,
        x.per_dev_executed_cprp.getOrElse("").toString,
        rev_result.get(x.advertiser_group) match {
          case None => ""
          case Some(_) => if(only_impact) "N/A" else rev_result.get(x.advertiser_group).get.exit_cprp.getOrElse("").toString},
        rev_result.get(x.advertiser_group) match {
          case None => ""
          case Some(_) => rev_result.get(x.advertiser_group).get.exit_cprp_deviation.getOrElse("").toString},
        rev_result.get(x.advertiser_group) match {
          case None => ""
          case Some(_) => rev_result.get(x.advertiser_group).get.revenue.getOrElse("").toString},
        rev_result.get(x.advertiser_group) match {
          case None => ""
          case Some(_) => rev_result.get(x.advertiser_group).get.revenue_deviation.getOrElse("").toString}

      )
    )

    val file_name = f"Cprp_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmssSSS"))}.xlsx"
    val file_path = f"/tmp/$file_name"
    writeToExcel(file_path,"CPRP",header,list_of_objects)
    val res:String = uploadFile(file_path, file_name)
    new File(file_path).delete()
    res
  }

  def getNumberOfDays(periods: List[Period]):Long={
    var num_days:Long = 0
    for (period <- periods)
    {
      val sd = stringToDate(period.start_date)
      val ed = stringToDate(period.end_date)
      num_days = num_days + DAYS.between(sd, ed)+1
    }
    num_days
  }

  def getPercentageDeviation(curr_val:Option[Double],dev_val:Option[Double],curr_num_days:Long=1,dev_num_days:Long=1):Option[Double]={
    Try((math rint (((curr_val.get / curr_num_days) - (dev_val.get / dev_num_days)) / (dev_val.get / dev_num_days)) * 10000)/100).toOption
  }

  def getAdGrpDifference(grp:Option[Double], dev_grp:Option[Double], period:Period, dev_period:List[Period]): Option[Double] ={
    val (actual_period, booked_period) = getActualPeriod(period)
    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    var per_dev_grp:Option[Double] = None
    val today_date = LocalDate.now()
    // case when current month is selected
    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
      val (actual_period, booked_period) = getActualPeriod(period)
      val actual_days = getNumberOfDays(List(actual_period))
      val normalised_grp = grp match {
        case None => None
        case Some(_) => Some(grp.get/actual_days)
      }
      //curr_num_days=1 because actual and booked days are already considered in normalized revenue
      per_dev_grp = getPercentageDeviation(normalised_grp,dev_grp,curr_num_days=1, dev_num_days = dev_num_days)
    }
    // case when previous month is selected
    else {
      per_dev_grp = getPercentageDeviation(grp,dev_grp,curr_num_days=num_days,dev_num_days = dev_num_days)
    }
    per_dev_grp
  }

  def getActualBookedPercentageDifference(actual_revenue:Option[Double], booked_revenue:Option[Double], dev_actual_revenue:Option[Double], period:Period, dev_period:List[Period], value_for_is_regional:Boolean): (Option[Double],Option[Double]) ={

    val num_days = getNumberOfDays(List(period))
    val dev_num_days = getNumberOfDays(dev_period)
    var per_dev_actual_revenue:Option[Double] = None
    var per_dev_revenue:Option[Double] = None
    val today_date = LocalDate.now()
    // case when current month is selected
    if (stringToDate(period.start_date).compareTo(today_date) <= 0 && stringToDate(period.end_date).compareTo(today_date) >= 0) {
      val (actual_period, booked_period) = if(value_for_is_regional==false) getActualPeriodEnt(period) else getActualPeriod(period)
      val actual_days = getNumberOfDays(List(actual_period))
      val booked_days = getNumberOfDays(List(booked_period))
      val normalised_revenue = actual_revenue match {
        case None => booked_revenue match {
          case None => None
          case Some(_) => Some(booked_revenue.get/booked_days)
        }
        case Some(_) => booked_revenue match {
          case None => Some(actual_revenue.get/actual_days)
          case Some(_) => Some((actual_revenue.get/actual_days)+(booked_revenue.get/booked_days))
        }
      }
      //curr_num_days=1 because actual and booked days are already considered in normalized revenue
      per_dev_revenue = getPercentageDeviation(normalised_revenue,dev_actual_revenue,curr_num_days=1, dev_num_days = dev_num_days)
      per_dev_actual_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=actual_days,dev_num_days = dev_num_days)
    }
    // case when previous month is selected
    else {
      per_dev_actual_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=num_days,dev_num_days = dev_num_days)
      per_dev_revenue = getPercentageDeviation(actual_revenue,dev_actual_revenue,curr_num_days=num_days,dev_num_days = dev_num_days)
    }
    (per_dev_actual_revenue,per_dev_revenue)
  }

  def fullOuterJoin[K](xs: List[List[(K, Any)]]): List[(K, List[Option[Any]])] = {
    val maps = xs.map(_.toMap)
    val allKeys = maps.map(_.keySet).reduce(_ ++ _)
    allKeys.toList.map(k => (k, maps.map(m => m.get(k))))
  }

  def getOptionSum(num1:Option[Double],num2:Option[Double]):Option[Double]={
    (num1 ++ num2).reduceOption(_ + _)
  }

  def getOptionDivision(num1:Option[Double],num2:Option[Double]):Option[Double]={
    if (num1==None || num2==None) return None
    else Some(num1.get/num2.get)
  }

  def getOptionDiff(num1:Option[Double],num2:Option[Double]):Option[Double]={
    if(num1==None && num2==None) None
    else Some(num1.getOrElse(0.0)-num2.getOrElse(0.0))
  }

  def getRoundValue(rev_val :Option[Double]):Option[Double]={
    Try(math.rint(rev_val.get * 100)/100).toOption
  }

  def getRoundValue(rev_val : Double): Double={
    math.rint(rev_val * 100)/100
  }
}