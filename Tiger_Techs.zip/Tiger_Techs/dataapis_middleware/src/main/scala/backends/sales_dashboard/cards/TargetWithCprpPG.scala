package backends.sales_dashboard.cards

import backends.sales_dashboard.Schema.{ PGTargetWithCPRP,SalesDashBoardReportArgsFlags, TargetWithCprp}
import backends.sales_dashboard.metrics.pg.{ PGTargetWithCprpObject}
import doobie.hikari.HikariTransactor
import zio.Task

object TargetWithCprpPG {
  def apply(transactor: HikariTransactor[Task],args: SalesDashBoardReportArgsFlags)
  : Task[TargetWithCprp] = {
    val tgt_with_cprp_data: Task[PGTargetWithCPRP] =  PGTargetWithCprpObject(transactor: HikariTransactor[Task],args)
    for{
      (a:PGTargetWithCPRP)  <- tgt_with_cprp_data
      data <- Task{TargetWithCprp(target_with_cprp = a)}
    } yield data
  }
}