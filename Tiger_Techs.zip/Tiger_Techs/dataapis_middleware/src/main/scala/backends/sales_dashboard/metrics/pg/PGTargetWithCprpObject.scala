package backends.sales_dashboard.metrics.pg

import backends.sales_dashboard.Schema._
import backends.sales_dashboard.metrics.Utils._
import doobie.Fragment
import doobie.hikari.HikariTransactor
import zio.Task
import doobie.implicits._
import org.json4s.DefaultFormats
import zio.interop.catz._

object PGTargetWithCprpObject {

  private implicit val formats = DefaultFormats

  def apply(transactor:  HikariTransactor[Task],args: SalesDashBoardReportArgsFlags)
  : Task[PGTargetWithCPRP] =  {


    val target_with_cprp: Task[List[PGTargetWithCPRP]] = PGTargetWithCprpSql(transactor, args)

    def getHeadFromList(list : List[PGTargetWithCPRP]) :PGTargetWithCPRP ={
      if(list.isEmpty) PGTargetWithCPRP(None, None) else list.head
    }

     for{
      list:List[PGTargetWithCPRP] <- target_with_cprp
      head:PGTargetWithCPRP <- Task{getHeadFromList(list)}
    } yield head
  }
}
