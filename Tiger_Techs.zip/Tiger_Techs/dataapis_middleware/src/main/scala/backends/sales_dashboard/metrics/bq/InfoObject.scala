package backends.sales_dashboard.metrics.bq
import backends.sales_dashboard.SalesDashboardApi
import backends.sales_dashboard.Schema.{BarcYearWeek, InfoSchema}
import backends.sales_dashboard.cards.InfoFillsFairShare
import scalacache.{Mode, _}
import scalacache.memoization._
import scalacache.redis.RedisCache
import scalacache.serialization.binary._
import utils.BQApi.getDataFromBQ
import utils.Configs
import zio.Task
import zio.interop.catz._

import scala.concurrent.duration._
object InfoObject {

  implicit val redisCache: Cache[InfoSchema] = RedisCache(SalesDashboardApi.jedisPool)
  implicit val mode: Mode[Task] = scalacache.CatsEffect.modes.async

  def apply(channel_name: String)
  : Task[InfoSchema]  =  memoizeF[Task, InfoSchema](Some(Configs.REDIS_CACHE_RESTORE_TIME))  {


    val query = InfoSql.queryBuilder(channel_name)
    var a_1:Option[Long] = None
    var a_2:Option[Long] = None
    var spr_to_date:Option[String] = None
    var channel_primary_tg:Option[String] = None
    var projection:Option[String] = None
    var ro:Option[String] = None
    var deals:Option[String] = None
    var actual_booked:Option[String] = None
    var target:Option[String] = None
    var productivity:Option[String] = None
    var data_source:Option[String] = None

    for (row <- getDataFromBQ(query)) {
      a_1={if (!row.get("barc_year_week").isNull) Some(row.get("barc_year_week").getRecordValue.get(0).getLongValue)  else None}
      a_2={if (!row.get("barc_year_week").isNull) Some(row.get("barc_year_week").getRecordValue.get(1).getLongValue)  else None}
      spr_to_date={if (!row.get("spr_to_date").isNull) Some(row.get("spr_to_date").getStringValue)  else None}
      channel_primary_tg={if (!row.get("channel_primary_tg").isNull) Some(row.get("channel_primary_tg").getStringValue)  else None}
      projection={if (!row.get("projection").isNull) Some(row.get("projection").getStringValue)  else None}
      ro={if (!row.get("ro").isNull) Some(row.get("ro").getStringValue)  else None}
      deals={if (!row.get("deals").isNull) Some(row.get("deals").getStringValue)  else None}
      actual_booked={if (!row.get("actual_booked").isNull) Some(row.get("actual_booked").getStringValue)  else None}
      target={if (!row.get("target").isNull) Some(row.get("target").getStringValue)  else None}
      productivity={if (!row.get("productivity").isNull) Some(row.get("productivity").getStringValue)  else None}
      data_source={if (!row.get("data_source").isNull) Some(row.get("data_source").getStringValue)  else None}
    }
    val barc_year_week = BarcYearWeek(a_1,a_2)
    Task(InfoSchema(barc_year_week,spr_to_date,channel_primary_tg,projection,ro,deals,actual_booked,target,productivity,data_source))
  }
}
