package backends.sales_dashboard

import backends.sales_dashboard.Schema._

object Filter {
  def getFilterStr(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]],pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group:Option[List[String]], impact_regular: Option[List[ImpactRegular]]):String = {
    val regionsStr = """[""""+regions.mkString("""","""")+""""]"""
    val dayPartStr = "["+pt_npt.mkString(",")+"]"
    var filterStr = f"""channel: "$channel",
    period:{start_date:"${period.start_date}", end_date:"${period.end_date}"},
    deviation_period:${getDeviationString(deviation_period)},
    regions: $regionsStr,
    pt_npt:$dayPartStr"""
    if (agency != None) {
      if (agency.get.toString() != "List()"){
        val agencyStr = """["""" + agency.get.mkString("""","""") + """"]"""
        filterStr = filterStr + f",agency: $agencyStr"
      }
    }
    if (sub_agency!=None){
      if (sub_agency.get.toString() != "List()") {
        val subAgencyStr = """["""" + sub_agency.get.mkString("""","""") + """"]"""
        filterStr = filterStr + f",sub_agency: $subAgencyStr"
      }
    }
    if (advertiser_group != None) {
      if (advertiser_group.get.toString() != "List()") {
        val advertiserGroupStr = """["""" + advertiser_group.get.mkString("""","""") + """"]"""
        filterStr = filterStr + f",advertiser_group: $advertiserGroupStr"
      }
    }
    if (deviation_advertiser_group != None) {
      if (deviation_advertiser_group.get.toString() != "List()") {
        val deviation_advertiser_group_str = """["""" + deviation_advertiser_group.get.mkString("""","""") + """"]"""
        filterStr = filterStr + f",deviation_advertiser_group: $deviation_advertiser_group_str"
      }
    }
    if (impact_regular != None) {
      if (impact_regular.get.toString() != "List()") {
        val impactRegularStr = "[" + impact_regular.get.mkString(",") + "]"
        filterStr = filterStr + f",impact_regular: $impactRegularStr"
      }
    }
    filterStr
  }

  def getDeviationString(periods:List[Period])
  : String = {
    var res = "["
    periods.foreach(period=> res+=f"""{start_date:\"${period.start_date}\",end_date:\"${period.end_date}\"},""")
    res.dropRight(1)+"]"
  }
}