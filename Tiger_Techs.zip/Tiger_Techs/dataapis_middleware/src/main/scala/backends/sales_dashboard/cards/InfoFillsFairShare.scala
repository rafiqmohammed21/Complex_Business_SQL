package backends.sales_dashboard.cards

import backends.sales_dashboard.Schema.{InfoFillsFairShareResult, SalesDashBoardReportArgsFlags}
import backends.sales_dashboard.metrics.bq.{FairShareObject, FctFillsObject, InfoObject}
import org.slf4j.{Logger, LoggerFactory}
import zio.Task

object InfoFillsFairShare {
  val logger: Logger = LoggerFactory.getLogger(getClass.getName)

  def apply(args: SalesDashBoardReportArgsFlags)
  :Task[InfoFillsFairShareResult]={
    val info = InfoObject(args.channel)
    val fills = FctFillsObject(args.channel,args.period)
    val fair_share = FairShareObject(args.channel,args.period,args.impact_regular,args.pt_npt)

    val res = for{
      ((info,fills),fair_share) <- info.zipPar(fills).zipPar(fair_share)
      final_res <- Task{InfoFillsFairShareResult(Some(info), Some(fills), Some(fair_share) )}
    } yield final_res
    res
  }
}