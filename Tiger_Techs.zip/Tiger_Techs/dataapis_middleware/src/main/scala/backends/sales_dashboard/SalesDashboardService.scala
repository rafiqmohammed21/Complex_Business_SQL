package backends.sales_dashboard

import backends.sales_dashboard.Schema._
import backends.sales_dashboard.cards._
import caliban.CalibanError.ExecutionError
import cats.effect.Blocker
import com.rollbar.notifier.Rollbar
import com.zaxxer.hikari.HikariDataSource
import doobie.hikari.HikariTransactor
import org.slf4j.{Logger, LoggerFactory}
import utils.RollBarContext.logCustomErrorInRollbar
import zio._
import scala.concurrent.ExecutionContext

object SalesDashboardService {

  def liveAkka(connectEC: ExecutionContext, rollBar: Rollbar, dbUrl: String, dbUser: String, dbPass: String): ZLayer[Any, Throwable, SalesDashboardAkka] = ZLayer.fromEffect(Task {
    import zio.interop.catz._
    val dataSource = new HikariDataSource()
    dataSource.setDriverClassName("org.postgresql.Driver")
    dataSource.setJdbcUrl(dbUrl)
    dataSource.setUsername(dbUser)
    dataSource.setPassword(dbPass)
    val pgTransactor: HikariTransactor[Task] = HikariTransactor[Task](dataSource, connectEC, Blocker.liftExecutionContext(connectEC))
    SalesDashboardService(rollBar, pgTransactor)
  })

  def liveHttp4s(pgTransactor: HikariTransactor[Task], rollBar: Rollbar): ZLayer[Any, Throwable, SalesDashboardAkka] =
    ZLayer.fromEffect(Task(SalesDashboardService(rollBar, pgTransactor)))
}

final case class SalesDashboardService(rollBarContext:Rollbar, trans : HikariTransactor[Task]) extends SalesDB.Service {

  val logger: Logger = LoggerFactory.getLogger(getClass.getName)

  def getInfoFillsFairShareData(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
  :ZIO[SalesDashboardAkka,Throwable,InfoFillsFairShareResult] =   {
      val t1 = System.nanoTime
      try {
        for {
          t <- InfoFillsFairShare(args)
          _ <- Task{logger.info(s"getInfoFillsFairShareData Api took ${(System.nanoTime - t1) / 1e9d}")}
        } yield t
      }
      catch {
        case e: Throwable =>
          logger.info(s"getInfoFillsFairShareData Api took ${(System.nanoTime - t1) / 1e9d}")
          logCustomErrorInRollbar(rollBarContext, e, "getInfoFillsFairShareData", args.toString)
          throw e
      }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }

  def getTargetWithCprpPG(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
  :ZIO[SalesDashboardAkka,Throwable,TargetWithCprp] =  {
    val t1 = System.nanoTime
    try {
      for {
        t <- TargetWithCprpPG(trans,args)
        _ <- Task{logger.info(s"getTargetWithCprpPG Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield t
    }
    catch {
      case e: Throwable =>
        logger.info(s"getTargetWithCprpPG Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getTargetWithCprpPG", args.toString)
        throw e
    }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }

  def getOverAllMetricsCprp(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  :ZIO[SalesDashboardAkka,Throwable,OverallCprpMetricsResult] =  {
    val t1 = System.nanoTime
    try {
      for {
        t <- OverallMetricsCprp(trans, args)
        _ <- Task{logger.info(s"getOverAllMetricsCprp Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield t
    }
    catch {
      case e: Throwable =>
        logger.info(s"getOverAllMetricsCprp Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getOverAllMetricsCprp", args.toString)
        throw e
    }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }

  def getOverAllMetricsPG(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  :ZIO[SalesDashboardAkka,Throwable,DataResultWithTotal] =  {
    val t1 = System.nanoTime
    try {
      for {
        t <- OverAllMetricsPG(trans, args)
        _ <- Task{logger.info(s"getOverAllMetricsPG Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield t
    }
    catch {
      case e: Throwable =>
        logger.info(s"getOverAllMetricsPG Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getOverAllMetricsPG", args.toString)
        throw e
    }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }

  def getReport( args: SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  :ZIO[SalesDashboardAkka,Throwable,ReportResultCprp] =     {
    val t1 = System.nanoTime
    try {
      for {
        a <- OverallMetricsCprp.asGcsFilePath(list_of_selections: List[String], trans: HikariTransactor[Task],args: SPDReportArgsRegFlagWithCategory)
        _ <- Task{logger.info(s"getPricingToDateData Api took ${(System.nanoTime - t1) / 1e9d}")}
      } yield a
    }
    catch {
      case e: Throwable =>
        logger.info(s"getPricingToDateData Api took ${(System.nanoTime - t1) / 1e9d}")
        logCustomErrorInRollbar(rollBarContext, e, "getReport", args.toString)
        throw e
    }
  }.mapError { e =>
    logger.error(e.getMessage)
    ExecutionError(e.getMessage)
  }
}