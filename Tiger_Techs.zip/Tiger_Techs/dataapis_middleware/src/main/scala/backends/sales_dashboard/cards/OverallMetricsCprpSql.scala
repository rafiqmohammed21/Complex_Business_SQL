package backends.sales_dashboard.cards

import backends.sales_dashboard.Schema._
import backends.sales_dashboard.metrics.Utils._

object OverallMetricsCprpSql {
  def queryBuilder(args: SPDReportArgsRegFlagWithCategory)
  : (String, String, String) = {
    println("---------------------cprp metrics started------------------")


    var deviation_period_dates_arr: Array[String] = Array()
    args.deviation_period.foreach { x =>
      deviation_period_dates_arr = deviation_period_dates_arr ++ Array(x.start_date, x.end_date)
    }
    val value_for_is_regional = args.is_regional match {
      case None => false
      case Some(true) => true
      case Some(false) => false
      case _ => false
    }

    val (actual_date, booked_date) = if(value_for_is_regional==false) getActualPeriodEnt(args.period) else getActualPeriod(args.period)

    val lag_period = if(value_for_is_regional==false) getLagDatesForCovid(args.period.start_date, args.period.end_date)
                      else getLagDatesReg(args.period.start_date, args.period.end_date)
    var lag_deviation_period_dates_arr: Array[String] = Array()
    args.deviation_period.foreach { x =>
      val lag_deviation_period = if(value_for_is_regional==false) getLagDatesForCovid(x.start_date, x.end_date)
      else getLagDatesReg(x.start_date, x.end_date)
      lag_deviation_period_dates_arr = lag_deviation_period_dates_arr ++ Array(lag_deviation_period._1, lag_deviation_period._2)
    }
    val period_arr: Array[(String, String)] = Array((args.period.start_date, args.period.end_date))
    val value_for_agency = getValueForAgency(args.agency)
    val value_for_sub_agency = getValueForSubAgency(args.sub_agency)
    val value_for_advertiser_group = getValueForAdvertiserGroup(args.advertiser_group)
    val value_for_deviation_advertiser_group = getValueForDeviationAdvertiserGroup(args.deviation_advertiser_group)
    val value_for_advertiser_category = getValueForSubAgency(args.advertiser_category)
    val value_for_all_advertiser_category_selected = args.all_advertiser_category_selected match {
      case None => true
      case Some(true) => true
      case Some(false) => false
      case _ => true
    }
    val deals_query =
      s""" CALL stg_reports.sp_deals_cprp_ctgr('${args.period.start_date}',
         |'${args.period.end_date}',
         |'${args.deviation_period.head.start_date}',
         |'${args.deviation_period.last.end_date}',
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |'${args.channel.toLowerCase}',
         |${gerArrayOfStringForString(args.regions.toArray)},
         |'${args.pt_npt.mkString("_")}',
         |$value_for_advertiser_group,
         |$value_for_deviation_advertiser_group,
         |$value_for_agency,
         |$value_for_sub_agency,
         |$value_for_advertiser_category,
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${args.all_sub_agency_selected},
         |$value_for_all_advertiser_category_selected
         |); """.stripMargin

    val ro_query =
      s""" CALL stg_reports.sp_ro_cprp_ctgr('${args.period.start_date}',
         |'${args.period.end_date}',
         |${getArrayOfStringForDates(deviation_period_dates_arr)},
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |'${args.channel}',
         |${gerArrayOfStringForString(args.regions.toArray)},
         |'${args.pt_npt.mkString("_")}',
         |$value_for_advertiser_group,
         |$value_for_deviation_advertiser_group,
         |$value_for_agency,
         |$value_for_sub_agency,
         |$value_for_advertiser_category,
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${args.all_sub_agency_selected},
         |$value_for_all_advertiser_category_selected
         |); """.stripMargin

    val executed_query =
      s"""CALL stg_reports.sp_executed_cprp_ctgr('${actual_date.start_date}',
         |'${actual_date.end_date}',
         |${getArrayOfStringForDates(deviation_period_dates_arr)},
         |'${lag_period._1}',
         |'${lag_period._2}',
         |${getArrayOfStringForDates(lag_deviation_period_dates_arr)},
         |'${args.channel.toLowerCase}',
         |${gerArrayOfStringForString(args.regions.toArray)},
         |${gerArrayOfStringForString(args.pt_npt.toArray.map(x => x.toString.toLowerCase))},
         |${value_for_advertiser_group.map(_.toLower)},
         |${value_for_deviation_advertiser_group.map(_.toLower)},
         |${value_for_agency.map(_.toLower)},
         |${value_for_sub_agency.map(_.toLower)},
         |$value_for_advertiser_category,
         |${args.all_region_selected},
         |${args.all_advertiser_selected},
         |${args.all_agency_selected},
         |${args.all_sub_agency_selected},
         |$value_for_all_advertiser_category_selected
         |)""".stripMargin

    (deals_query,ro_query,executed_query)
  }
}