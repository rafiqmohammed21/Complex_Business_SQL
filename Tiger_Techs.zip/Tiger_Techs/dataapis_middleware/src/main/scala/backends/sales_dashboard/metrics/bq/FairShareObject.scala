package backends.sales_dashboard.metrics.bq

import backends.sales_dashboard.SalesDashboardApi
import backends.sales_dashboard.Schema.{DayPart, FairShare, ImpactRegular, Period}
import scalacache.{Cache, Mode}
import scalacache.memoization._
import scalacache.redis.RedisCache
import scalacache.serialization.binary._
import utils.BQApi.getDataFromBQ
import zio.Task
import zio.interop.catz._
import utils.Configs

import scala.concurrent.duration._

object FairShareObject {

  implicit val redisCache: Cache[FairShare] = RedisCache(SalesDashboardApi.jedisPool)
  implicit val mode: Mode[Task] = scalacache.CatsEffect.modes.async

  def apply(channel :String,period:Period,impact_regular: Option[List[ImpactRegular]],pt_npt: List[DayPart])
  : Task[FairShare] = memoizeF[Task, FairShare](Some(Configs.REDIS_CACHE_RESTORE_TIME)) {
    val query = FairShareSql.queryBuilder(channel,period,impact_regular,pt_npt)
    var channel_grp : Option[Double] = None
    var genre_grp : Option[Double] = None
    var fair_share : Option[Double] = None

    for (row <- getDataFromBQ(query)) {

      channel_grp = {if (!row.get(0).isNull) Some(row.get(0).getDoubleValue)  else None}
      genre_grp = {if (!row.get(1).isNull) Some(row.get(1).getDoubleValue)  else None}
      fair_share = {if (!row.get(2).isNull) Some(row.get(2).getDoubleValue)  else None}
    }
    Task(FairShare(channel_grp,	genre_grp,	fair_share))
  }
}
