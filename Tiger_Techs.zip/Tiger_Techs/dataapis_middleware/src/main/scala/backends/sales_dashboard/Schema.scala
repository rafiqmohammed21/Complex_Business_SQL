package backends.sales_dashboard

object Schema {

  case class FunnelReportSchema (advertisers:String,
                           projection:Option[Double]=None, 
                           dev_projection:Option[Double]=None,
                           projection_deviation:Option[Double]=None,
                           deal:Option[Double]=None, 
                           dev_deal:Option[Double]=None,
                           deal_deviation:Option[Double]=None,
                           ro:Option[Double]=None,
                           dev_ro:Option[Double]=None,     
                           ro_deviation:Option[Double]=None,
                           revenue:Option[Double]=None
                          )

  case class RevenueReportSchema (advertisers:String,
                                  revenue:Option[Double]=None,
                                  dev_revenue:Option[Double]=None,
                                  revenue_deviation:Option[Double]=None,
                                  actual_revenue:Option[Double]=None,
                                  dev_actual_revenue:Option[Double]=None,
                                  actual_revenue_deviation:Option[Double]=None,
                                  booked_revenue:Option[Double]=None,
                                  grp:Option[Double]=None,
                                  dev_grp:Option[Double]=None,
                                  grp_deviation:Option[Double]=None,
                                  genre_grp:Option[Double]=None,
                                  dev_genre_grp:Option[Double]=None,
                                  genre_grp_deviation:Option[Double]=None,
                                  market_share:Option[Double]=None,
                                  dev_market_share:Option[Double]=None,
                                  market_share_deviation:Option[Double]=None,
                                  exit_cprp:Option[Double]=None,
                                  dev_exit_cprp:Option[Double]=None,
                                  exit_cprp_deviation:Option[Double]=None,
                                  exit_revenue:Option[Double]=None,
                                  dev_exit_revenue:Option[Double]=None,
                                  exit_grp:Option[Double]=None,
                                  dev_exit_grp:Option[Double]=None
                           )
  case class SPViewershipSchema(advertiser_group:String,	ad_grp:Option[Double],	market_share:Option[Double])
  case class SPViewershipDevSchema(advertiser_group:String,	dev_ad_grp:Option[Double],	dev_market_share:Option[Double])
  case class SPViewershipSchemaJoined(advertiser_group:String,	ad_grp:Option[Double]=None,dev_ad_grp:Option[Double]=None, market_share:Option[Double]=None, dev_market_share:Option[Double]=None)

  case class SPOverallSchema(advertiser_group:String,	revenue:Option[Double],grp:Option[Double],	market_share:Option[Double],	exit_cprp:Option[Double], projection:Option[Double], deals:Option[Double],ro:Option[Double], actual_revenue:Option[Double], booked_revenue:Option[Double])
  //out_advertiser_group |  out_ro  | out_actual_revenue | out_booked_revenue | out_revenue |    out_deals     |  out_projection  |     out_grp      | out_genre_grp | out_market_share |  out_exit_cprp
  case class PGOverallSchema(advertiser_group:String, ro:Double, actual_revenue:Double, booked_revenue:Double, revenue:Double, deal:Double, projection:Double,grp:Double, genre_grp:Double, market_share:Double, exit_cprp:Double)
  case class SPOverallDevSchema(advertiser_group:String,	dev_revenue:Option[Double],dev_grp:Option[Double],	dev_market_share:Option[Double],	dev_exit_cprp:Option[Double], dev_projection:Option[Double], dev_deals:Option[Double],dev_ro:Option[Double])
  case class SPOverallDevSchemaWithActual(advertiser_group:String,	dev_revenue:Option[Double],dev_grp:Option[Double],	dev_market_share:Option[Double],	dev_exit_cprp:Option[Double], dev_projection:Option[Double], dev_deals:Option[Double],dev_ro:Option[Double], dev_actual:Option[Double])

  case class SPOverallSchemaJoined(
    advertiser_group:String,
    var revenue:Option[Double]=None,
    var dev_revenue:Option[Double]=None,
    var grp:Option[Double]=None,
    var	dev_grp:Option[Double]=None,
    var market_share:Option[Double]=None,
    var dev_market_share:Option[Double]=None,
    var	exit_cprp:Option[Double]=None,
    var dev_exit_cprp:Option[Double]=None,
    var projection:Option[Double]=None,
    var dev_projection:Option[Double]=None,
    var deals:Option[Double]=None,
    var dev_deals:Option[Double]=None,
    var ro:Option[Double]=None,
    var dev_ro:Option[Double]=None,
    var actual_revenue:Option[Double]=None,
    var booked_revenue:Option[Double]=None
                                  )
  case class SPOverallSchemaJoinedWithActual(
                                    advertiser_group:String,
                                    var revenue:Option[Double]=None,
                                    var dev_revenue:Option[Double]=None,
                                    var grp:Option[Double]=None,
                                    var	dev_grp:Option[Double]=None,
                                    var market_share:Option[Double]=None,
                                    var dev_market_share:Option[Double]=None,
                                    var	exit_cprp:Option[Double]=None,
                                    var dev_exit_cprp:Option[Double]=None,
                                    var projection:Option[Double]=None,
                                    var dev_projection:Option[Double]=None,
                                    var deals:Option[Double]=None,
                                    var dev_deals:Option[Double]=None,
                                    var ro:Option[Double]=None,
                                    var dev_ro:Option[Double]=None,
                                    var actual_revenue:Option[Double]=None,
                                    var dev_actual_revenue:Option[Double]=None,
                                    var booked_revenue:Option[Double]=None
                                  )

  case class ReleaseOrderOutput(advertiser_group: String, revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])
  case class ResponseReleaseOrder(revenues: List[ReleaseOrderOutput],total_revenue: Option[Double],total_percentage_deviation: Option[Double] )
  case class ResponseReleaseOrders(releaseOrder: ResponseReleaseOrder)
  case class ResponseReleaseOrderData (data: ResponseReleaseOrders)
  case class ReleaseOrder(advertiser_group: String, revenue: Option[Double], percentage_deviation: Option[Double])
  case class SpRo(revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])

  case class ProjectionOutput(advertiser_group: String, revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])
  case class ResponseProjection(revenues: List[ProjectionOutput], total_revenue: Option[Double], total_percentage_deviation: Option[Double])
  case class ResponseProjections(projection: ResponseProjection)
  case class ResponseProjectionData (data: ResponseProjections)
  case class Projection(advertiser_group: String, revenue: Option[Double], percentage_deviation: Option[Double])
  case class SPProjection(revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])

  case class DealOutput(advertiser_group: String, revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])
  case class ResponseDeal(revenues: List[DealOutput], total_revenue: Option[Double],total_percentage_deviation: Option[Double])
  case class ResponseDeals(deals: ResponseDeal)
  case class ResponseDealData (data: ResponseDeals)
  case class Deal(advertiser_group: String, revenue: Option[Double], percentage_deviation: Option[Double])
  case class SPDeal(revenue: Option[Double], deviation: Option[Double], percentage_deviation: Option[Double])
  case class SPTarget(target: Option[Double])
  case class PGTargetWithCPRP(target: Option[Double], target_cprp: Option[Double])

  case class SPActualBooked(actual_revenue: Option[Double], actual_deviation: Option[Double], actual_percentage_deviation: Option[Double], total_revenue: Option[Double],total_deviation: Option[Double], total_percentage_deviation: Option[Double],number_of_days_actualised:Option[Long]=None,number_of_days_month:Option[Long]=None ,actual_revenue_internal:Option[Double]=None,total_revenue_internal:Option[Double]=None )
  case class FairShare(channel_grp: Option[Double],	genre_grp: Option[Double],	fair_share: Option[Double])

  case class RevenueOutput(advertiser_group: String, total_revenue: Option[Double], total_percentage_deviation: Option[Double])
  case class ResponseRevenue(total_revenues: List[RevenueOutput], total_actual_revenue: Option[Double],
    total_actual_percentage_deviation: Option[Double], total_revenue: Option[Double],
    total_pecentage_deviation: Option[Double], number_of_days_actualised: Option[Int], number_of_days_month: Option[Int])
  case class ResponseRevenues(actualBookedRevenue: ResponseRevenue)
  case class ResponseRevenueData (data: ResponseRevenues)
  case class Revenue(advertiser_group: String, revenue: Option[Double], percentage_deviation: Option[Double])

  case class GrpMarketShareOutput(advertiser_group: String, channel_ad_grp: Option[Double], genre_ad_grp:Option[Double], deviation_channel_ad_grp:Option[Double], deviation_genre_ad_grp:Option[Double], percentage_deviation_channel_ad_grp: Option[Double], market_share: Option[Double], percentage_deviation_market_share: Option[Double])
  case class ResponseGrpMarketShare(marketShares: List[GrpMarketShareOutput], total_market_share:Option[Double], total_percentage_deviation:Option[Double])
  case class ResponseGrpMarketShares(marketShare: ResponseGrpMarketShare)
  case class ResponseGrpMarketShareData (data: ResponseGrpMarketShares)
  case class GrpMarketShare(advertiser_group: String, grp_revenue: Option[Double], grp_percentage_deviation: Option[Double], market_share_revenue: Option[Double], market_share_percentage_deviation: Option[Double])
  case class SPMarketShare(current_channel_ad_grp: Option[Double],	current_genre_ad_grp: Option[Double],	deviation_channel_ad_gr: Option[Double],deviation_genre_ad_grp: Option[Double],	market_share: Option[Double],	deviation_market_share: Option[Double],	percentage_deviation_market_share: Option[Double])

  case class TargetMarketExit(target_with_cprp: PGTargetWithCPRP, market_share: SPMarketShare, exit_cprp: NewExitCprp)
  case class TargetWithCprp(target_with_cprp: PGTargetWithCPRP)

  case class ExitCprpOutput(advertiser_group: String, revenue:Option[Double], ad_grp:Option[Double],exit_cprp:Option[Double], deviation_revenue:Option[Double], deviation_ad_grp:Option[Double], deviation_cprp:Option[Double], percentage_deviation:Option[Double])
  case class ResponseExitCprp(revenues: List[ExitCprpOutput], total_revenue:Option[Double], total_ad_grp:Option[Double],  total_exit_cprp:Option[Double], total_deviation_revenue:Option[Double], total_deviation_ad_grp:Option[Double], total_deviation_exit_cprp: Option[Double], total_percentage_deviation :Option[Double])
  case class ResponseExitCprps(exitCprp: ResponseExitCprp)
  case class ResponseExitCprpData (data: ResponseExitCprps)
  case class ExitCprp(advertiser_group: String, exit_cprp: Option[Double])
  case class DealCprp(total_revenue: Option[Double], total_ad_grp: Option[Double], deals_cprp: Option[Double],
    total_deviation_revenue: Option[Double], total_deviation_ad_grp: Option[Double],
    deviation_deals_cprp: Option[Double], total_percentage_deviation: Option[Double]
   )
  case class SPCprpMetrics(revenue: Option[Double], grp: Option[Double], cprp:Option[Double], dev_revenue: Option[Double], dev_grp:Option[Double], dev_cprp: Option[Double], per_devitaion: Option[Double])
  case class SPOverallCprpSchema(
                                  advertiser_group : String,
                                  ro_revenue : Option[Double],
                                  ro_grp:Option[Double],
                                  ro_cprp: Option[Double],
                                  dev_ro_revenue : Option[Double],
                                  dev_ro_grp : Option[Double],
                                  dev_ro_cprp : Option[Double],
                                  per_dev_ro_cprp: Option[Double],
                                  deal_revenue : Option[Double],
                                  deal_grp : Option[Double],
                                  deal_cprp: Option[Double],
                                  dev_deal_revenue : Option[Double],
                                  dev_deal_grp : Option[Double],
                                  dev_deal_cprp: Option[Double],
                                  per_dev_deal_cprp: Option[Double],
                                  executed_revenue : Option[Double],
                                  executed_grp:Option[Double],
                                  executed_cprp: Option[Double],
                                  dev_executed_revenue : Option[Double],
                                  dev_executed_grp:Option[Double],
                                  dev_executed_cprp: Option[Double],
                                  per_dev_executed_cprp: Option[Double]
                                 )
  case class TotalCprpMetrics(
                               ro_revenue : Option[Double],
                               ro_grp:Option[Double],
                               ro_cprp: Option[Double],
                               dev_ro_revenue : Option[Double],
                               dev_ro_grp : Option[Double],
                               dev_ro_cprp : Option[Double],
                               per_dev_ro_cprp: Option[Double],
                               deal_revenue : Option[Double],
                               deal_grp : Option[Double],
                               deal_cprp: Option[Double],
                               dev_deal_revenue : Option[Double],
                               dev_deal_grp : Option[Double],
                               dev_deal_cprp: Option[Double],
                               per_dev_deal_cprp: Option[Double],
                               executed_revenue : Option[Double],
                               executed_grp:Option[Double],
                               executed_cprp: Option[Double],
                               dev_executed_revenue : Option[Double],
                               dev_executed_grp:Option[Double],
                               dev_executed_cprp: Option[Double],
                               per_dev_executed_cprp: Option[Double]
                             )
  case class OverallCprpMetricsResult(cprp : List[SPOverallCprpSchema],total_cprp : PricingToDateDataResult)
  
  
  case class SPRevenueMetrics(
                             advertiser_group:String,
                              ro: Option[Double],
                              deal: Option[Double],
                              projection: Option[Double],
                              actual_revenue: Option[Double],
                              booked_revenue: Option[Double],
                              revenue: Option[Double],
                              ad_grp: Option[Double],
                              genre_grp: Option[Double],
                              market_share: Option[Double],
                              exit_revenue: Option[Double],
                              exit_grp: Option[Double],
                              exit_cprp: Option[Double])
  case class SPOverallRevenueSchema(
                               var advertiser_group:String,
                               var ro: Option[Double],
                               var dev_ro: Option[Double],
                               var per_dev_ro:Option[Double],
                               var deal: Option[Double],
                               var dev_deal:Option[Double],
                               var per_dev_deal:Option[Double],
                               var projection: Option[Double],
                               var dev_projection:Option[Double],
                               var per_dev_projection:Option[Double],
                               var actual_revenue: Option[Double],
                               var dev_actual_revenue:Option[Double],
                               var per_dev_actual_revenue:Option[Double],
                               var booked_revenue: Option[Double],
                               var revenue: Option[Double],
                               var dev_revenue:Option[Double],
                               var per_dev_revenue:Option[Double],
                               var grp: Option[Double],
                               var dev_grp:Option[Double],
                               var per_dev_grp:Option[Double],
                               var genre_grp: Option[Double],
                               var dev_genre_grp:Option[Double],
                               var per_dev_genre_grp:Option[Double],
                               var market_share: Option[Double],
                               var dev_market_share:Option[Double],
                               var per_dev_market_share:Option[Double],
                               var exit_revenue: Option[Double],
                               var dev_exit_revenue:Option[Double],
                               var per_dev_exit_revenue:Option[Double],

                               var exit_grp: Option[Double],
                               var dev_exit_grp:Option[Double],
                               var per_dev_exit_grp:Option[Double],

                               var exit_cprp: Option[Double],
                               var dev_exit_cprp:Option[Double],
                               var per_dev_exit_cprp:Option[Double]

                                   )
  case class TotalRevenueMetrics(
                                 deals: Option[PGDeals] = None, 
                                 projection: Option[PGProjection] = None,
                                 ro: Option[PGRo] = None, 
                                 actual_booked: Option[PGActualBooked] = None,
                                 exit_cprp : Option[NewExitCprp] = None,
                                 market_share: Option[SPMarketShare]=None
                                )
  case class TargetCprp(target_cprp:Option[Double] )
  case class FctFills(with_hul: Option[Double], without_hul: Option[Double])

  case class RoCprp(total_revenue: Option[Double], total_ad_grp: Option[Double], ro_cprp: Option[Double], total_deviation_revenue: Option[Double], total_deviation_ad_grp: Option[Double], deviation_ro_cprp: Option[Double], total_percentage_deviation: Option[Double])
  case class ExecutedCprp(total_revenue: Option[Double], total_ad_grp: Option[Double],  total_deviation_revenue: Option[Double], total_deviation_ad_grp: Option[Double], executed_cprp: Option[Double],deviation_executed_cprp: Option[Double], total_percentage_deviation: Option[Double])

  case class NewExitCprp(total_revenue:Option[Double], total_ad_grp:Option[Double],total_deviation_revenue:Option[Double], total_deviation_ad_grp:Option[Double], total_exit_cprp:Option[Double], total_deviation_exit_cprp: Option[Double], total_percentage_deviation :Option[Double])

  sealed trait Region
  object Region {
    case object EAST  extends Region
    case object WEST  extends Region
    case object NORTH extends Region
    case object SOUTH extends Region
  }

  sealed trait DayPart
  object DayPart {
    case object PT  extends DayPart
    case object NPT extends DayPart
  }

  sealed trait ImpactRegular
  object ImpactRegular {
    case object IMPACT  extends ImpactRegular
    case object REGULAR extends ImpactRegular
  }

  case class Period(start_date: String, end_date: String)
  case class SalesDashBoardReportArgs(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]])
  case class SalesDashBoardReportArgsFlags(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean,all_advertiser_selected: Boolean, all_agency_selected:Boolean, all_sub_agency_selected: Boolean)
  case class SPDReportArgsWithCategory(channel: String,
                                       period: Period,
                                       deviation_period: List[Period],
                                       regions: List[String],
                                       agency: Option[List[String]],
                                       sub_agency: Option[List[String]],
                                       advertiser_category: Option[List[String]],
                                       pt_npt: List[DayPart],
                                       advertiser_group: Option[List[String]],
                                       deviation_advertiser_group: Option[List[String]],
                                       impact_regular: Option[List[ImpactRegular]],
                                       all_region_selected: Boolean,
                                       all_advertiser_selected: Boolean,
                                       all_agency_selected:Boolean,
                                       all_sub_agency_selected: Boolean,
                                       all_advertiser_category_selected: Option[Boolean])
  case class SalesDashBoardReportArgsRegFlag(channel: String, period: Period, deviation_period: List[Period], regions: List[String], agency: Option[List[String]],sub_agency: Option[List[String]], pt_npt: List[DayPart], advertiser_group: Option[List[String]],deviation_advertiser_group: Option[List[String]], impact_regular: Option[List[ImpactRegular]], all_region_selected: Boolean,all_advertiser_selected: Boolean, all_agency_selected:Boolean, all_sub_agency_selected: Boolean, is_regional: Boolean)
  case class SPDReportArgsRegFlagWithCategory(channel: String,
                                              period: Period,
                                              deviation_period: List[Period],
                                              regions: List[String],
                                              agency: Option[List[String]],
                                              sub_agency: Option[List[String]],
                                              advertiser_category: Option[List[String]],
                                              pt_npt: List[DayPart],
                                              advertiser_group: Option[List[String]],
                                              deviation_advertiser_group: Option[List[String]],
                                              impact_regular: Option[List[ImpactRegular]],
                                              all_region_selected: Boolean,
                                              all_advertiser_selected: Boolean,
                                              all_agency_selected:Boolean,
                                              all_sub_agency_selected: Boolean,
                                              all_advertiser_category_selected: Option[Boolean],
                                              is_regional: Option[Boolean])
  case class BarcYearWeek(week:Option[Long], year:Option[Long])
  case class InfoSchema(barc_year_week:BarcYearWeek,
                        spr_to_date:Option[String],
                        channel_primary_tg:Option[String],
                        projection:Option[String],
                        ro:Option[String],
                        deals:Option[String],
                        actual_booked:Option[String],
                        target:Option[String],
                        productivity:Option[String],
                        data_source:Option[String])
  case class Info(channel: String)
  case class Fills(channel: String)
  case class ReportResult(revenue: String, funnel: String)
  case class ReportResultCprp(revenue: String, funnel: String, cprp: String)
  case class DataResultWithTotal(revenue:List[RevenueReportSchema],funnel:List[FunnelReportSchema], total :TotalRevenueMetrics)
  case class DataResult(revenue:List[RevenueReportSchema],funnel:List[FunnelReportSchema])
  case class PGDeals(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double])
  case class PGProjection(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double])
  case class PGRo(revenue: Option[Double],dev_revenue: Option[Double], percentage_deviation: Option[Double])
  case class PGActualBooked(actual_revenue: Option[Double],dev_actual_revenue: Option[Double], actual_percentage_deviation: Option[Double], total_revenue: Option[Double] ,dev_total_revenue: Option[Double],total_revenue_percentage_deviation:Option[Double], number_of_days_actualised:Option[Long],number_of_days_month:Option[Long] , actual_revenue_internal:Option[Double],total_revenue_internal:Option[Double] )
  case class TotalRevenuePG(deals: Option[PGDeals], projection: Option[PGProjection], ro: Option[PGRo], actual_booked: Option[PGActualBooked])
  case class TotalRevenue(deals:Double, deals_dev_per:Double, projection:Double, projection_dev_per:Double, ro:Double, ro_dev_per:Double , actual:Double, actual_dev_per:Double, actual_booked:Double, actual_revenue_internal:Double,total_revenue_internal:Double)
  //case class PricingToDateDataResult(deals_cprp: Option[DealCprp] = None, ro_cprp: Option[RoCprp] = None, target_cprp: Option[TargetCprp] = None, executed_cprp: Option[ExecutedCprp] = None, exit_cprp: Option[NewExitCprp] = None)
  case class PricingToDateDataResult(deals_cprp: Option[DealCprp] = None, ro_cprp: Option[RoCprp] = None, executed_cprp: Option[ExecutedCprp] = None)
  //case class InfoFillsMarketShareResult(info: Option[InfoSchema]=None, fills: Option[FctFills]=None, market_share: Option[SPMarketShare], fair_share: Option[FairShare])
  case class InfoFillsMarketShareResult(info: Option[InfoSchema]=None, fills: Option[FctFills]=None, fair_share: Option[FairShare])
  case class InfoFillsFairShareResult(info: Option[InfoSchema]=None, fills: Option[FctFills]=None, fair_share: Option[FairShare])
  case class TotalReveueToDateResult(deals: Option[SPDeal], projection: Option[SPProjection], ro: Option[SpRo], target: Option[SPTarget],actual_booked: Option[SPActualBooked])
}