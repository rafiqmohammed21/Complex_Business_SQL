package backends.sales_dashboard.metrics.bq

import backends.sales_dashboard.Schema.{BarcYearWeek, InfoSchema}
import backends.sales_dashboard.metrics.Utils.getSPName
import utils.BQApi.getDataFromBQ
import zio.Task

object InfoSql {

  def queryBuilder(channel_name: String)
  : String =  {
    s"""CALL ${getSPName("sp_info")}('$channel_name')""".stripMargin
  }
}
