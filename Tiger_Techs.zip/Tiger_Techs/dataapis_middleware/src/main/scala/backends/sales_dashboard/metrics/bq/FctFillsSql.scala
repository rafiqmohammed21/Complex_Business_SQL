package backends.sales_dashboard.metrics.bq

import backends.sales_dashboard.Schema.{FctFills, Period, SalesDashBoardReportArgsFlags}
import backends.sales_dashboard.metrics.Utils.{getActualPeriod, getSPName}
import utils.BQApi.getDataFromBQ
import zio.Task

object FctFillsSql{
  def queryBuilder(channel_name:String,period: Period)
  : String = {
    val (actual_date,booked_date) = getActualPeriod(period)
    val query = s""" CALL ${getSPName("sp_fct_fills")}('${channel_name}','${actual_date.start_date}', '${actual_date.end_date}')"""
    query

  }
}
