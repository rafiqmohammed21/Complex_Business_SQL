package backends

import backends.sales_dashboard.Schema._
import zio.{Has, ZIO}

package object sales_dashboard {

  object SalesDB {

    trait Service {

      def getInfoFillsFairShareData(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
      :ZIO[SalesDashboardAkka,Throwable,InfoFillsFairShareResult]

      def getReport(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
      : ZIO[SalesDashboardAkka,Throwable,ReportResultCprp]

      def getOverAllMetricsPG(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
      :ZIO[SalesDashboardAkka,Throwable,DataResultWithTotal]

      def getOverAllMetricsCprp(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
      :ZIO[SalesDashboardAkka,Throwable,OverallCprpMetricsResult]

      def getTargetWithCprpPG(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
      :ZIO[SalesDashboardAkka,Throwable,TargetWithCprp]


    }

  }

  type SalesDashboardAkka = Has[SalesDB.Service]

  def getInfoFillsFairShareData(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
  =
    ZIO.accessM[SalesDashboardAkka](_.get.getInfoFillsFairShareData(args, list_of_selections))

  def getTargetWithCprpPG(args:SalesDashBoardReportArgsFlags, list_of_selections: List[String])
  =
    ZIO.accessM[SalesDashboardAkka](_.get.getTargetWithCprpPG(args, list_of_selections))

  def getReport(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  = ZIO.accessM[SalesDashboardAkka](_.get.getReport(args, list_of_selections))

  def getOverAllMetricsCprp(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  = ZIO.accessM[SalesDashboardAkka](_.get.getOverAllMetricsCprp(args, list_of_selections))

  def getOverAllMetricsPG(args:SPDReportArgsRegFlagWithCategory, list_of_selections: List[String])
  = ZIO.accessM[SalesDashboardAkka](_.get.getOverAllMetricsPG(args, list_of_selections))

}
