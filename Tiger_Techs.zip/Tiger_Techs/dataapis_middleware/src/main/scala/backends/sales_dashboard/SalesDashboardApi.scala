package backends.sales_dashboard

import backends.sales_dashboard.Schema._
import caliban.GraphQL.graphQL
import caliban.schema.GenericSchema
import caliban.{GraphQL, RootResolver}
import redis.clients.jedis.{JedisPool, JedisPoolConfig}
import utils.Configs
import zio.ZIO
import zio.clock.Clock
import zio.console.Console

import scala.language.postfixOps

object SalesDashboardApi extends GenericSchema[SalesDashboardAkka] {

  val jedisPool = new JedisPool(new JedisPoolConfig(),Configs.REDIS_CONNECTION_URL, 6379,20000,"o4lsmzA5BC")

  case class Queries(
                      rev_report: SPDReportArgsRegFlagWithCategory => ZIO[SalesDashboardAkka,Throwable, ReportResultCprp]
                      ,info_fills_market_share_data: SalesDashBoardReportArgsFlags => ZIO[SalesDashboardAkka,Throwable, InfoFillsFairShareResult]
                      ,over_all_metrics_pg : SPDReportArgsRegFlagWithCategory => ZIO[SalesDashboardAkka,Throwable, DataResultWithTotal]
                      ,target_market_exit_pg : SalesDashBoardReportArgsFlags => ZIO[SalesDashboardAkka,Throwable, TargetWithCprp]
                      ,over_all_metrics_cprp : SPDReportArgsRegFlagWithCategory => ZIO[SalesDashboardAkka,Throwable,OverallCprpMetricsResult]
                    )
  var list_of_selections:List[String] = List()
  val api: GraphQL[Console with Clock with SalesDashboardAkka] =
    graphQL(
      RootResolver(
        Queries(
          args => getReport(args, list_of_selections),
          args => getInfoFillsFairShareData(args, list_of_selections),
          args => getOverAllMetricsPG(args, list_of_selections),
          args => getTargetWithCprpPG(args, list_of_selections),
          args => getOverAllMetricsCprp(args, list_of_selections)
        )
      )
    )
}

