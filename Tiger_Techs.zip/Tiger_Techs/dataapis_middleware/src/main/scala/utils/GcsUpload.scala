package utils

import java.io.FileInputStream
import java.net.URL
import java.nio.file.{Files, Paths}
import java.util.concurrent.TimeUnit

import com.google.auth.oauth2.{GoogleCredentials, ServiceAccountCredentials}
import com.google.cloud.storage.{BlobId, BlobInfo, Storage, StorageOptions}

object GcsUpload {

  def getGcsStorage(gcsCredFile:String):Storage={
    val credentials: GoogleCredentials  = ServiceAccountCredentials.fromStream(new FileInputStream(gcsCredFile))
    StorageOptions.newBuilder().setCredentials(credentials).build().getService()
  }

  def uploadFile(sourceFile:String,destinationFile:String):String={
    val byteArray = Files.readAllBytes(Paths.get(sourceFile))
    val storage:Storage = getGcsStorage(Configs.GCS_BQ_CRED)
    val blobId :BlobId = BlobId.of("star-dl-temp-mint", "csvUpload/"+destinationFile)
    val  blobInfo:BlobInfo = BlobInfo.newBuilder(blobId).setContentType("text/csv").build()
    storage.create(blobInfo,byteArray)
    val url: URL  =  storage.signUrl(blobInfo, 15, TimeUnit.MINUTES, Storage.SignUrlOption.withV4Signature())
    url.toString()
  }

}
