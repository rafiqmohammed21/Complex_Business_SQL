package utils

import java.io.FileInputStream
import java.util.UUID

import BQApi.bigQuery

import scala.collection.JavaConverters._
import com.google.auth.oauth2.ServiceAccountCredentials
import com.google.cloud.bigquery.{BigQueryOptions, FieldValueList, JobId, JobInfo, QueryJobConfiguration}
import org.slf4j.{Logger, LoggerFactory}
import utils.DbMigration.getClass

object BQApi {
  val logger: Logger = LoggerFactory.getLogger(getClass.getName)
  lazy val credentials = {
    logger.info("Initiating Credentials")
    ServiceAccountCredentials.fromStream(new FileInputStream(Configs.GCS_BQ_CRED))
  }
  lazy val bigQuery = {
    logger.info("Initiating Big Query Connection")
    BigQueryOptions.newBuilder.setCredentials(credentials).build.getService
  }

  def validateBqQuery(query:String): Boolean = {
    val queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).setDryRun(true).build
    var isValidated = false
    try {
      bigQuery.create(JobInfo.newBuilder(queryConfig).build)
      isValidated = true
    }catch{
      case e => e.printStackTrace()
    }
    isValidated
  }

  def getDataFromBQ(query:String):Iterable[FieldValueList]= {
      val queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).build
      val jobId = JobId.of(UUID.randomUUID.toString)
      var queryJob = bigQuery.create(JobInfo.newBuilder(queryConfig).setJobId(jobId).build)
      // Wait for the query to complete.
      try queryJob = queryJob.waitFor()
      catch {
        case e: InterruptedException =>
          e.printStackTrace()
      }
      // Check for errors
      if (queryJob == null) throw new RuntimeException("Job no longer exists")
      else if (queryJob.getStatus.getError != null) { // You can also look at queryJob.getStatus().getExecutionErrors() for all
        // errors, not just the latest one.
        throw new RuntimeException(queryJob.getStatus.getError.toString)
      }
      try {
        val result = queryJob.getQueryResults()
        result.iterateAll().asScala
      }
  }
}
