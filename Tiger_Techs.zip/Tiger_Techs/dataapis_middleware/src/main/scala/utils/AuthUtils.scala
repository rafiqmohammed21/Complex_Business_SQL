package utils

import org.http4s.{HttpRoutes, Request}
import zio.{RIO, ZEnv}
import cats.data.OptionT
import org.http4s.dsl.Http4sDsl
import zio.interop.catz._
import cats.data.Kleisli
import org.http4s.util.CaseInsensitiveString
import org.slf4j.{Logger, LoggerFactory}

object AuthUtils {

  type ExampleTask[A] = RIO[ZEnv, A]
  val logger: Logger = LoggerFactory.getLogger(getClass.getName)
  object ioz extends Http4sDsl[ExampleTask]
  import ioz._

  def validateUserAuthInfo(token: String):Boolean = {
    if (token == "Barer "+ Configs.token.get(Configs.ENV).head) true
    else false
  }

  def AuthMiddleware(service: HttpRoutes[ExampleTask],authEnabled:Boolean): HttpRoutes[ExampleTask] =
    Kleisli {
      (req: Request[ExampleTask]) =>
        if(authEnabled) {
          req.headers.get(CaseInsensitiveString("Authorization")) match {
            case Some(value) => {
              logger.info("Token from middleware app : " + value)
              val token = value.value
              val isTokenValid = validateUserAuthInfo(token)
              logger.info("Is Token Valid => " + isTokenValid)
              if (isTokenValid) {
                //Return response as it it in case of success
                service(req)
              } else {
                //Return forbidden error as request is invalid
                OptionT.liftF(Forbidden())
              }
            }
            case None => {
              logger.info("Header not present. Invalid Requests !! ")
              OptionT.liftF(Forbidden())
            }
          }
        } else{
          //Return response as it it in case of authentication is disabled
          service(req)
        }
    }
}
