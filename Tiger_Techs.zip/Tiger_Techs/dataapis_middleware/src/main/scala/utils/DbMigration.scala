package utils

import org.flywaydb.core.Flyway
import org.slf4j.{Logger, LoggerFactory}

object DbMigration {
  val logger: Logger = LoggerFactory.getLogger(getClass.getName)
  def apply() =
     {
      Flyway
        .configure(this.getClass.getClassLoader)
        .dataSource(Configs.DB_URL, Configs.DB_USER, Configs.DB_PASS)
        .locations("db/migration")
        .connectRetries(Int.MaxValue)
        .load()
        .migrate()
    }
}