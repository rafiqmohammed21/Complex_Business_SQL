//package utils

//object PubSubAPI {

  //import com.google.pubsub.v1.ProjectTopicName
  //import com.google.cloud.pubsub.v1.Publisher
  //import com.google.protobuf.ByteString
  //import com.google.pubsub.v1.PubsubMessage
  //import java.util.concurrent.TimeUnit
  //
  //import com.google.api.core.ApiFutureCallback
  //import com.google.api.core.ApiFutures
  //import com.google.common.util.concurrent.MoreExecutors
  //import com.google.cloud.pubsub.v1.TopicAdminClient
  //import com.google.pubsub.v1.ProjectTopicName //libraryDependencies += "com.google.api.grpc" % "grpc-google-cloud-pubsub-v1" % "1.87.0"

  //  def pushMessage(csv_msg:String, topic_name: String):Unit={
  //
  //    val topic :ProjectTopicName = ProjectTopicName.of("mint-bi-reporting", topic_name)
  //    try {
  //      val topicAdminClient = TopicAdminClient.create
  //      try topicAdminClient.createTopic(topic)
  //      finally if (topicAdminClient != null) topicAdminClient.close()
  //    }
  //
  //    var publisher:Publisher = null
  //    try{
  //      publisher = Publisher.newBuilder(topic).build
  //      val data = ByteString.copyFromUtf8(csv_msg)
  //      val pubsubMessage = PubsubMessage.newBuilder.setData(data).build
  //      val messageIdFuture = publisher.publish(pubsubMessage)
  //
  //      ApiFutures.addCallback(
  //        messageIdFuture,
  //
  //        new ApiFutureCallback[String]() {
  //          override def onSuccess(messageId: String): Unit = {
  //            System.out.println("published with message id: " + messageId)
  //          }
  //          override def onFailure(t: Throwable): Unit = {
  //            System.out.println("failed to publish: " + t)
  //          }
  //        },
  //
  //        MoreExecutors.directExecutor
  //      )
  //    }
  //    finally{
  //      if (publisher != null) {
  //        publisher.shutdown
  //        publisher.awaitTermination(1, TimeUnit.MINUTES)
  //      }
  //    }
  //  }

//}
