package utils

import scala.io.Source
import scala.concurrent.duration._

object Configs {
    lazy val ENV: String = Source.fromResource("ENV.txt").getLines.toList.head
    println(s"inside utils.Configs: environment is set to $ENV")
    val GCS_BQ_CRED = "/opt/docker/tmp/gcsCred_m-b-r.json"
    val token: Map[String, String] = Map(
        "dev" -> "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkVQTS1zY2FsYS1hcGktZGV2IiwiaWF0IjoxNTE2MjM5MDIyfQ.TBC1gcOcPjkxfMq0gdzgpIub6V4eKPnZpY4A-2-lHe8",
        "stg" -> "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkVQTS1zY2FsYS1hcGktZGV2IiwiaWF0IjoxNTE2MjM5MDIyfQ.TBC1gcOcPjkxfMq0gdzgpIub6V4eKPnZpY4A-2-lHe8",
        "uat" -> "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkVQTS1zY2FsYS1hcGktdWF0IiwiaWF0IjoxNTE2MjM5MDIyfQ.MJINPVlt5YS5thdDASrxSioiBZwMOqGRKhrOxqkFuB8",
        "prod" -> "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkVQTS1zY2FsYS1hcGktcHJvZCIsImlhdCI6MTUxNjIzOTAyMn0.BC-l6W5BoGhDOkhsiU4MrEqhlMKi14wx9z24-YuITIs",
        "local" -> "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkVQTS1zY2FsYS1hcGktZGV2IiwiaWF0IjoxNTE2MjM5MDIyfQ.TBC1gcOcPjkxfMq0gdzgpIub6V4eKPnZpY4A-2-lHe8",
    )
    val DB_URL: String = ENV match{
        case "dev" => s"jdbc:postgresql://10.40.32.44:5432/sales_dashboard"
        case "stg" => s"jdbc:postgresql://10.40.32.44:5432/sales_dashboard"
        case "uat" => s"jdbc:postgresql://10.40.32.22:5432/sales_dashboard"
        case "prod" => s"jdbc:postgresql://10.40.32.20:5432/sales_dashboard"
        case "local" => "jdbc:postgresql://localhost:5432/sales_dashboard"
    }
    val DB_USER: String = ENV match {
        case "dev" => "mintrw"
        case "stg" => "mintrw"
        case "uat" => "mintrw"
        case "prod" => "mintrw"
        case "local" => "postgres"
    }
    val DB_PASS: String = ENV match {
        case "dev" => "$tar@MintRW2o2o"
        case "stg" => "$tar@MintRW2o2o"
        case "uat" => "$tar@MintRW2o2o"
        case "prod" => "$tar@MintRW2o2o"
        case "local" => "postgres"
    }
    val AUTHENTICATION_ENABLED: Boolean = ENV match {
        case "dev" => false
        case "stg" => false
        case "uat" => true
        case "prod" => true
        case "local" => false
    }

    val REDIS_CONNECTION_URL: String = ENV match {
        case "dev" => s"172.22.154.93"
        case "stg" => s"172.22.154.93"
        case "uat" => s"172.22.154.98"
        case "prod" => s"172.22.154.94"
        case "local" => s"localhost"
    }

    val REDIS_CACHE_RESTORE_TIME: FiniteDuration = ENV match {
        case "dev" => 3600.seconds
        case "stg" => 3600.seconds
        case "uat" => 3600.seconds
        case "prod" => 3600.seconds
        case "local" => 3600.seconds
    }
        
}
