package utils

import org.http4s.headers.Authorization
import org.http4s.{EntityEncoder, Request, Response, Status}
import zio.blocking.effectBlocking
import zio.clock.Clock
import zio.{Has, RIO, ZEnv, ZIO}
import scala.io.Source
import caliban.{Http4sAdapter,GraphQLInterpreter, CalibanError}
import caliban.schema.GenericSchema
import utils.Configs


//object LoginModule {
//
//  import LoginSupport.{Ev, SimpleService, currentUser}
//
//  def provideEnv(request: Request[RIO[ZEnv, *]]): ZEnv => Ev =
//    (env: ZEnv) => {
//    var b: zio.RIO[LoginSupport.Auth,LoginSupport.User] = ZIO.fromEither(request.headers.get(Authorization).map(_.value).toRight("No `Authorization` header"))
//    .flatMap(currentUser)
//    .mapError(e => new Throwable("EEE"))
//    env ++ Has(SimpleService(b))
//  }
//
//  def staticResource(path: String): RIO[ZEnv, Response[RIO[ZEnv, *]]] = {
//    var x = Source.fromResource(path).getLines.mkString("\n")
//    effectBlocking(x).map(
//      content =>
//        Response[RIO[ZEnv, *]](Status.Ok, body = EntityEncoder[RIO[ZEnv, *], String](EntityEncoder.stringEncoder).toEntity(content).body)
//    )
//  }
//
//}
//
//object LoginSupport {
//
//  type Auth = Has[AuthService[Any]]
//  type Ev = Auth with Clock
//
//  trait AuthService[R] {
//    def currentUser: RIO[Auth, User]
//  }
//
//  case class User(name: String)
//
//  def currentUser(token: String): ZIO[Auth, Throwable, User] = {
//    //ZIO.fail(new Throwable("No no!"))
//    println("In Current User: Token => " + token)
//    var usr:User = User("fail")
//    if (token == "Barer "+ Configs.token.get(Configs.ENV).head)
//      usr = User("abcd")
//    ZIO.succeed(usr)
//  }
//  case class SimpleService(currentUser: RIO[Auth, User]) extends AuthService[Any]
//}