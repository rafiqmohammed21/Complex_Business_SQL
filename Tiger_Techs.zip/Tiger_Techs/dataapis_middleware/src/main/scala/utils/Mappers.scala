package utils

object Mappers {
  def dayMap: Map[String, String] ={
    val days = Map("sun" -> "1", "mon" -> "2", "tue" -> "3", "wed" -> "4", "thu" -> "5", "fri" -> "6", "sat" -> "7")
    days
  }

  def mapDay(day:String): String ={
    val dMap = dayMap
    val dNum = dMap(day)
    dNum
  }

  def mapDayInt(day:String): Int = {
    val dMap = dayMap
    val dNum = dMap(day).toInt
    dNum
  }
}
