package utils
import java.io.{BufferedWriter, File, FileOutputStream, FileWriter}
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.{XSSFSheet, XSSFWorkbook}
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.IndexedColors

object CsvGenerator {

  def writeToCsv(file:String,header:String,list_of_objects:List[List[String]]):Unit={
    val writer = new BufferedWriter(new FileWriter(file))
    writer.write(header+"\n")
    writer.write(list_of_objects.map(_.mkString(",")).mkString("\n"))
    writer.close()
    println("=========Csv file has been created successfully!=========")
  }

  def writeToExcel(file:String,sheetName:String, header:String,list_of_objects:List[List[String]]):Unit={

    val workbook:XSSFWorkbook = new XSSFWorkbook()
    val sheet:XSSFSheet = workbook.createSheet(sheetName)
    val header_list:List[String] = header.split(",").toList
    val header_row:Row = sheet.createRow(0)

    val headerFont = workbook.createFont
    headerFont.setColor(IndexedColors.WHITE.index)
    headerFont.setBold(true)
    val headerCellStyle:CellStyle = sheet.getWorkbook.createCellStyle
    headerCellStyle.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index)
    headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)
    headerCellStyle.setFont(headerFont)

    for(i<-header_list.indices) {
      val cell  = header_row.createCell(i)
      cell.setCellStyle(headerCellStyle)
      cell.setCellValue(header_list(i))
    }

    for(i<-list_of_objects.indices) {
      val next_row:Row = sheet.createRow(i+1)
      for(j<-list_of_objects(i).indices) {
        val cell  = next_row.createCell(j)
        if(j==0 || list_of_objects(i)(j) == "") cell.setCellValue(list_of_objects(i)(j))
        else cell.setCellValue(list_of_objects(i)(j).toDouble)
      }
    }

    val out_file :FileOutputStream = new FileOutputStream(new File(file))
    workbook.write(out_file)
    out_file.close()
    println("=========Excel file has been created successfully!=========")
  }

}