package utils
import scalaj.http._
import org.json4s.DefaultFormats
object HttpClientApi   {

  private implicit val formats = DefaultFormats
  def call(url: String, requestBody: String): HttpResponse[String] = {
    val response = Http(url).timeout(connTimeoutMs = 10000, readTimeoutMs = 50000).postForm(Seq("query" -> requestBody)).asString
    response
  }
}