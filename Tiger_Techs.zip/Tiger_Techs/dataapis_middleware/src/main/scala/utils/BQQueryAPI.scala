package utils

import java.io.FileInputStream

import com.google.auth.oauth2.ServiceAccountCredentials
import com.google.cloud.bigquery._
import utils.BQApi.{bigQuery, logger, validateBqQuery}

import scala.collection.JavaConverters._

object BQQueryAPI {
  lazy val credentials = {
    println("Initiating Credentials")
    ServiceAccountCredentials.fromStream(new FileInputStream(Configs.GCS_BQ_CRED))
  }
  lazy val bigQuery = {
    println("Initiating Big Query Connection")
    BigQueryOptions.newBuilder.setCredentials(credentials).build.getService
  }

  def validateBqQuery(query:String): Boolean = {
    val queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).setDryRun(true).build
    var isValidated = false
    try {
      bigQuery.create(JobInfo.newBuilder(queryConfig).build)
      isValidated = true
    }catch{
      case e => e.printStackTrace()
    }
    isValidated
  }

  def getDataFromBQ(query:String):Iterable[FieldValueList]= {
      val queryConfig = QueryJobConfiguration.newBuilder(query).setUseLegacySql(false).build
      try {
        bigQuery.query(queryConfig).iterateAll().asScala
      }
  }
}


