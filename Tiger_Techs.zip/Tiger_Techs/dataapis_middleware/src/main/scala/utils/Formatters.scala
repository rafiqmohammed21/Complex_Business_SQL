package utils

import utils.Mappers.mapDay

object Formatters {
  def formatList(channel_list:List[String]):String = {
    var res_str:String = "'"+channel_list.head.toLowerCase+"'"
    for(element<-channel_list.tail)
    {
      res_str+=",'"+element.toLowerCase()+"'"
    }
    res_str
  }


  def formatTGMarket(tgmarket:String):Array[String] = {
    val tgm:Array[String] = tgmarket.split('|')
    tgm
  }



  def formatDaysOfWeek(daysOfWeek:List[String]):String = {
    var res_str:String = mapDay(daysOfWeek.head)
    for(element<-daysOfWeek.tail)
    {
      res_str+=","+mapDay(element)
    }
    res_str
  }


  def formatTGMarketList(tgmarket:List[String]):String = {
    var res_str:String = s" (LOWER(Target) = '${tgmarket.head.split('|')(0).toLowerCase().trim()}'AND LOWER(Region) = '${tgmarket.head.split('|')(1).toLowerCase().trim()}')"
    for(element<-tgmarket.tail)
    {
      res_str+=s" OR (LOWER(Target) = '${element.split('|')(0).toLowerCase().trim()}'AND LOWER(Region) = '${element.split('|')(1).toLowerCase().trim()}')"
    }
    res_str
  }

  def formatOptionList(channel_list: Option[List[String]]): String = {
    var res_str:String = null
    if (!channel_list.isEmpty) {
      res_str = "'"+channel_list.head.head.toLowerCase()+"'"
      for (element <- channel_list.head.tail) {
        res_str += ", '" + element.toLowerCase() + "'"
      }
    }
    res_str
  }

  def getOptionList(value: Option[List[String]]): String={
    var res:String = null
    if(!value.isEmpty) {
      res = "["
      res += f"${formatOptionList(value)} ]"
    }
    res
  }

  def getFormattedArray(inputArray: List[String]):String={
    var res:String = null
    if(!inputArray.isEmpty) {
      res = "["

      res += f"${formatList(inputArray)} ]"
    }
    res
  }

  def getFormattedString(inStr:String):String={
    var res:String = null
    if(!inStr.trim.isEmpty) {
      res = "'" + inStr + "'"
    }
    res
  }

  def formatDate(date:String):String = {
    "date('" + date + "')"
  }


  def formatOptionalBoolean(inputString: Option[Boolean]): Boolean = {
    inputString match {
      case Some(value) => value
      case None => false
      case null => false
    }
  }

  def formatOptionalString(inputString: Option[String]): String = {
    inputString match {
      case Some(value) => "'" + value + "'"
      case None => "null"
      case null => "null"
    }
  }

  def roundOffOptionalDouble(value: Double, roundBy: Int) : Double = {
    BigDecimal(value).setScale(roundBy, BigDecimal.RoundingMode.HALF_UP).toDouble
  }

  def formatOptionalInt(inputString: Option[Int]): String = {
    inputString match {
      case Some(value) =>  value.toString
      case None => "null"
      case null => "null"
    }
  }


}
