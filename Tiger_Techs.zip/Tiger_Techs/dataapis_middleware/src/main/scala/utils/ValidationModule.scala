package utils

import caliban.CalibanError.ValidationError
import caliban.execution.ExecutionRequest
import caliban.wrappers.Wrapper.{ExecutionWrapper, ValidationWrapper}
import zio.{IO, ZIO}
import caliban.parsing.adt.Document

object ValidationModule {

//  def validate(): ValidationWrapper[Ev] =
//    ValidationWrapper {process => (doc: Document) =>
//      for {
//        req   <- process(doc)
//        usr <- ZIO.accessM[Ev](_.get.currentUser).mapError(er => ValidationError("No `Authorization` header", ""))
//        _ <- IO.when(usr.name != "abcd")(
//          IO.fail(ValidationError("Invalid User", ""))
//        )
//      } yield req
//    }

  var list_of_selections:List[String] = List()

  //  def getFields(): ExecutionWrapper[Ev] =
  //    ExecutionWrapper {
  //      case (io, exeRequest) => {
  //        list_of_selections = List()
  //        exeRequest.field.fields(0).fields.foreach(x => list_of_selections = list_of_selections :+ x.name)
  //        io
  //      }
  //    }

}
