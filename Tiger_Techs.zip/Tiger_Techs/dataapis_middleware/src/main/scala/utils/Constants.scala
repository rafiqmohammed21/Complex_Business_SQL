package utils

object Constants {

  val dashboardMinYearList : Map[String, Int] = Map(
    "ONEVIEW" -> 2017,
    "SPORTS" -> 2017,
    "ENTERTAINMENT" -> 2011,
    "REGIONAL" -> 2011,
    "LIKE" -> 2011,
    "DISTRIBUTION" -> 2017
  )

  val dataAvailabilityList : Map[String, String] = Map(
    "DataSource" -> "Star Data Lake",
    "Excludes" -> "Hotstar revenue data"
  )

  val totalRevenueOneviewList : Map[String, String] = Map(
    "tv" -> "television",
    "ht" -> "hotstar",
    "total" -> "total"
  )
}
