import backends.sales_dashboard.{SalesDashboardApi, SalesDashboardService}
import backends.sales_performance_dashboard.{SalesPerformanceDashboardApi, SalesPerformanceDashboardService}
import caliban.{CalibanError, GraphQLInterpreter}
import cats.effect.{Blocker, Resource}
import com.rollbar.notifier.Rollbar
import doobie.hikari.HikariTransactor
import doobie.util.ExecutionContexts
import utils.{Configs, RollBarContext}
import zio.interop.catz._
import zio.{Task, ZIO, ZEnv}
import scala.concurrent.ExecutionContext

object CalibanHelpers {
  private val rollBar: Rollbar = RollBarContext()

  def dbResource: Resource[Task, HikariTransactor[Task]] = {
    for {
      connectEC <- ExecutionContexts.fixedThreadPool[Task](20)
      xa        <- HikariTransactor.newHikariTransactor[Task](
        "org.postgresql.Driver", // driver classname
        Configs.DB_URL, // connect URL
        Configs.DB_USER, // username
        Configs.DB_PASS, // password
        connectEC,                              // await connection here
        Blocker.liftExecutionContext(connectEC) // transactEC // execute JDBC operations here
      )
      } yield xa
    }

  def salesDashboardAkkaInterpreter(executionContext: ExecutionContext): ZIO[Any, CalibanError, GraphQLInterpreter[ZEnv, Throwable]] =
    SalesDashboardService.liveAkka(executionContext,rollBar,Configs.DB_URL,Configs.DB_USER,Configs.DB_PASS)
      .memoize
      .use {
        layer => SalesDashboardApi.api.interpreter.map(_.provideCustomLayer(layer))
      }

  def salesDashboardHttp4sInterpreter(transactor: HikariTransactor[Task]): ZIO[Any, CalibanError, GraphQLInterpreter[ZEnv, Throwable]] =
    SalesDashboardService.liveHttp4s(transactor,rollBar)
      .memoize
      .use {
        layer => SalesDashboardApi.api.interpreter.map(_.provideCustomLayer(layer))
      }

  def salesPerformanceDashboardAkkaInterpreter(executionContext: ExecutionContext): ZIO[Any, CalibanError, GraphQLInterpreter[ZEnv, Throwable]] =
    SalesPerformanceDashboardService.liveAkka(executionContext,rollBar,Configs.DB_URL,Configs.DB_USER,Configs.DB_PASS)
      .memoize
      .use {
        layer => SalesPerformanceDashboardApi.api.interpreter.map(_.provideCustomLayer(layer))
      }

  def salesPerformanceDashboardHttp4sInterpreter(transactor: HikariTransactor[Task]): ZIO[Any, CalibanError, GraphQLInterpreter[ZEnv, Throwable]] =
    SalesPerformanceDashboardService.liveHttp4s(transactor,rollBar)
      .memoize
      .use {
        layer => SalesPerformanceDashboardApi.api.interpreter.map(_.provideCustomLayer(layer))
      }
}
