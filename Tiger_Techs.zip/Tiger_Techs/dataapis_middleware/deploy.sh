#!/usr/bin/env bash
sbt docker:publishLocal
#docker tag  dataapis-middleware:0.1.0 asia.gcr.io/mint-bi-reporting/staging/dataapis-middleware
#docker push asia.gcr.io/mint-bi-reporting/staging/dataapis-middleware

#!/usr/bin/env bash
# sbt docker:publishLocal
# docker run -it --rm -p 8080:8080 asia.gcr.io/mint-bi-reporting/uat/dataapis-middleware:0.1.0
# gcloud app deploy app_dev.yaml -v v1 --image-url=asia.gcr.io/mint-bi-reporting/dev/dataapis-middleware:0.1.0
# gcloud app logs tail -s devmid
