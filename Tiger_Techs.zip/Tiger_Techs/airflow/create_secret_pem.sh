#!/usr/bin/env bash

kubectl create secret generic hdptiger \
--from-file=pem/hdptiger.pem
