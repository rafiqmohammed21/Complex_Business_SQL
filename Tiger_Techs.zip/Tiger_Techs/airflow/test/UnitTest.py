import unittest
from airflow.models import DagBag

dag_id = 'data_download'
dagbag = DagBag()


class TestDagIntegrity(unittest.TestCase):

    def setUp(self):
        self.dagbag = dagbag

    # Test for Import Errors
    def test_import_dags(self):
        self.assertTrue(
            len(self.dagbag.import_errors)==0,
            'DAG import failures. Errors: {}'.format(self.dagbag.import_errors)
            )

    # Test for Email Availability
    def test_alert_email_present(self):
        emails = self.dagbag.get_dag(dag_id).default_args.get('email', [])
        msg = 'Alert email not set for DAG {id}'.format(id=dag_id)
        self.assertIn('z6f6k5x3f5o3y8e4@startv.slack.com', emails, msg)

    # Test for Tasks Availability
    def test_contain_tasks(self):
        dag = self.dagbag.get_dag(dag_id)
        tasks = dag.tasks
        task_ids = list(map(lambda task: task.task_id, tasks))
        self.assertListEqual(task_ids, ['run_spark_job_livy'])

    # Test for Failure Call BACK Notification
    def test_callback_onfailure(self):
        dag = dagbag.get_dag(dag_id)
        task = dag.get_task('run_spark_job_livy')
        call_back = task.on_failure_callback
        self.assertNotEqual(call_back.__name__,None,'Notification on task failure is mandatory')

    # Test for Success Call BACK Notification
    def test_callback_onsuccess(self):
        dag = dagbag.get_dag(dag_id)
        task = dag.get_task('run_spark_job_livy')
        call_back = task.on_success_callback
        self.assertNotEqual(call_back.__name__,None,'Notification on task success is mandatory')


suite = unittest.TestLoader().loadTestsFromTestCase(TestDagIntegrity)
unittest.TextTestRunner(verbosity=2).run(suite)