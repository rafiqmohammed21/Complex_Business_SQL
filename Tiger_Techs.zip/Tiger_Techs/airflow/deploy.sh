#!/usr/bin/env bash

set -e

$(aws ecr get-login --region ap-south-1 --no-include-email)

docker build -t 831083831535.dkr.ecr.ap-south-1.amazonaws.com/mint/prod/airflow:v12 .

docker push 831083831535.dkr.ecr.ap-south-1.amazonaws.com/mint/prod/airflow:v12

scp -i /Users/tharwanin/Desktop/pem/PRD-MINT-EKS-Workstation.pem airflow-deployment.yaml ubuntu@13.234.49.9:/home/ubuntu/airflow/prod/airflow-deployment.yaml

ssh -i /Users/tharwanin/Desktop/pem/PRD-MINT-EKS-Workstation.pem ubuntu@13.234.49.9 <<'ENDSSH'
kubectl apply -f /home/ubuntu/airflow/prod/airflow-deployment.yaml --record=true
ENDSSH