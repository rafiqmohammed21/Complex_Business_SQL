from datetime import datetime

from utils.data_ingestion import push_notification, date_formats
from utils.livy_api import LivyApi
from airflow import DAG, AirflowException
from airflow.operators.python_operator import PythonOperator
from utils.global_variables import *
from utils.send_notification import dag_failure_callback, dag_success_callback, dag_send_notification, remove_temp_file
import logging

from utils.spot_ratings import get_current_month_week_year

DAG_ID = 'GCP_spr_ingestion'

default_args = {
    'owner': 'Swapnil',
    'depends_on_past': False,
    'start_date': datetime(2019, 9, 26),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None)


def spr_ingestion_to_bq(**context):
    if context['dag_run'].conf:
        current_date = context['dag_run'].conf["start_date"]
        logging.info('Running through rest trigger => start_date: ' + current_date)
    else:
        current_date = date_formats()['Y-m-d']
        logging.info('Running through scheduled trigger => year: ' + str(current_date))

    yarn_app_name = "MINT_SPR_INGESTION_TO_BQ"
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB,JAR_GCS_CON,JAR_GCS_CRED,JAR_SLACK,JAR_STTP]
    logging.info("SPR Ingestion Process to BigQuery  started for the day : " + current_date)
    push_notification(context, "process_type", "spark_spr_bigquery_ingestion")
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    jar_args = [
        "job_name==EtlJobOnAirSPR",
        "job_input_path==" +  SPR_CURRENCY_INPUT_DATA_PATH,
        "job_output_path==" + SPR_JOB_OUTPUT_PATH,
        "currency_input_data_path==" + SPR_CURRENCY_INPUT_DATA_PATH,
        "spr_history_load_input_path==" + SPR_ONAIR_HISTORY_LOAD_INPUT_PATH,
        "champ_history_load_input_path==" + SPR_CHAMP_HISTORY_LOAD_INPUT_PATH,
        "spr_output_dataset==" + SPR_OUTPUT_DATASET,
        "spr_output_table_name==" + SPR_OUTPUT_TABLE_NAME,
        "current_date==" + current_date,
        "test==false", "debug==false", "aggregate_error==false"
        ]
    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                       jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify", current_date)
    except:
        push_notification(context, "notify", "SPR Ingestion to BigQuery  Process Failed - " + current_date)
        raise AirflowException('{} SPR Ingestion to BQ  Process Failed'.format("daily"))


def currency_ingestion_to_spr(**context):
    if context['dag_run'].conf:
        current_date = context['dag_run'].conf["start_date"]
        year = context['dag_run'].conf["year"]
        logging.info('Running through rest trigger => start_date: ' + current_date)
    else:
        current_date = date_formats()['Y-m-d']
        year = get_current_month_week_year()[0]
        logging.info('Running through scheduled trigger => start_date: ' + str(current_date))
        logging.info('Running through scheduled trigger => year: ' + str(year))

    yarn_app_name = "MINT_SPR_INGESTION_TO_BQ"
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB,JAR_GCS_CON,JAR_GCS_CRED,JAR_SLACK,JAR_STTP]
    push_notification(context, "process_type", "spark_currency_ingestion")
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    jar_args = [
        "job_name==EtlJobOnAirCurrency",
        "job_input_path==" + CURRENCY_JOB_INPUT_PATH + "/date=" + current_date + "/master/currency/*",
        "job_output_path==" + CURRENCY_JOB_OUTPUT_PATH + "/year=" + str(year),
        "currency_output_filename==currency_" + current_date + ".orc",
        "test==false", "debug==false", "aggregate_error==false"
        ]
    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                       jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify",  current_date)
    except:
        push_notification(context, "notify", " Currency raw to  orc conversion Failed - " + current_date)
        raise AirflowException('Raw to  orc conversion Failed for currency')


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
            "dag_id": DAG_ID,
            "dag_object": dag,
            "task_name": "spr to big-query daily ingestion",
            "event": "GCP SPR Ingestion - "+"DAILY"+" - "+MERIDIAN,
            "ingestion": 'SPR'
            },
    dag=dag
)


mint_spr_ingestion_to_bq = PythonOperator(
    task_id='SPARK_mint_spr_ingestion_to_bq',
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    python_callable=spr_ingestion_to_bq,
    params={'file_mode': 'a'},
    dag=dag,
)

mint_currency_ingestion = PythonOperator(
    task_id='SPARK_mint_currency_ingestion',
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    python_callable=currency_ingestion_to_spr,
    params={'file_mode': 'w'},
    dag=dag,
)

mint_currency_ingestion >> mint_spr_ingestion_to_bq >> notification_task
