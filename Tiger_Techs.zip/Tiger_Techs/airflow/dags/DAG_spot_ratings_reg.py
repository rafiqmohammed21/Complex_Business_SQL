from datetime import datetime
from airflow import DAG
from airflow.operators.python_operator import PythonOperator

from utils.data_ingestion import dag_run_schedule_interval
from utils.send_notification import dag_success_callback, dag_failure_callback, dag_send_notification, remove_temp_file
from utils.spot_ratings import run_job_spot_ratings
import logging
from utils.spot_ratings_qc import run_job_spot_ratings_qc
from utils.spot_ratings import get_current_month_week_year

DAG_ID = 'GCP_spot_ratings_reg'

default_args = {
    'owner': 'Danveer',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}
dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=dag_run_schedule_interval('barc'))


def spot_ratings_reg_gcs_to_bq(**context):
    if context['dag_run'].conf:
        year = context['dag_run'].conf["year"]
        week = context['dag_run'].conf["week"]
        logging.info('Running through rest trigger => year: ' + year)
        logging.info('Running through rest trigger => week: ' + week)
    else:
        year = get_current_month_week_year()[0]
        week = get_current_month_week_year()[2]
        logging.info('Running through manual trigger => year: ' + str(year))
        logging.info('Running through manual trigger => week: ' + str(week))
    run_job_spot_ratings(context,'regional', year, week)


def spot_ratings_reg_qc(**context):
    if context['dag_run'].conf:
        year = context['dag_run'].conf["year"]
        week = context['dag_run'].conf["week"]
        logging.info('Running through rest trigger => year: ' + year)
        logging.info('Running through rest trigger => week: ' + week)
    else:
        year = get_current_month_week_year()[0]
        week = get_current_month_week_year()[2]
        logging.info('Running through manual trigger => year: ' + str(year))
        logging.info('Running through manual trigger => week: ' + str(week))
    run_job_spot_ratings_qc(context, 'regional', year, week)

mint_spot_ratings_reg_qc = PythonOperator(
    task_id="SPARK_mint_spot_ratings_reg_qc",
    provide_context=True,
    python_callable=spot_ratings_reg_qc,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag,
)

mint_spot_ratings_reg_to_bq = PythonOperator(
    task_id="SPARK_mint_spot_ratings_reg_to_bq",
    provide_context=True,
    python_callable=spot_ratings_reg_gcs_to_bq,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag,
)
notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "spot ratings reg ingestion",
        "event": "SPOT RATINGS REG Ingestion - WEEKLY",
        "ingestion": 'SPOT RATINGS REG'
    },
    dag=dag
)

mint_spot_ratings_reg_qc >> mint_spot_ratings_reg_to_bq >> notification_task
