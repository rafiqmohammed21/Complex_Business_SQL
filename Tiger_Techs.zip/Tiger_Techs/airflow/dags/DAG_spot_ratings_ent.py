from datetime import datetime
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from utils.spot_ratings_qc import run_job_spot_ratings_qc
from utils.data_ingestion import dag_run_schedule_interval
from utils.spot_ratings import run_job_spot_ratings
import logging
from utils.spot_ratings import get_current_month_week_year
from utils.send_notification import dag_send_notification, remove_temp_file, dag_success_callback, dag_failure_callback

DAG_ID = 'GCP_spot_ratings_ent'

default_args = {
    'owner': 'Danveer',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}
dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1,
          schedule_interval=dag_run_schedule_interval('barc'))


def spot_ratings_ent_qc(**context):
    if context['dag_run'].conf:
        year = context['dag_run'].conf["year"]
        week = context['dag_run'].conf["week"]
        logging.info('Running through rest trigger => year: ' + year)
        logging.info('Running through rest trigger => week: ' + week)
    else:
        year = get_current_month_week_year()[0]
        week = get_current_month_week_year()[2]
        logging.info('Running through manual trigger => year: ' + str(year))
        logging.info('Running through manual trigger => week: ' + str(week))
    run_job_spot_ratings_qc(context, 'entertainment', year, week)


def spot_ratings_ent_gcs_to_bq(**context):
    if context['dag_run'].conf:
        year = context['dag_run'].conf["year"]
        week = context['dag_run'].conf["week"]
        logging.info('Running through rest trigger => year: ' + year)
        logging.info('Running through rest trigger => week: ' + week)
    else:
        year = get_current_month_week_year()[0]
        week = get_current_month_week_year()[2]
        logging.info('Running through manual trigger => year: ' + str(year))
        logging.info('Running through manual trigger => week: ' + str(week))
    run_job_spot_ratings(context, 'entertainment', year, week)


mint_spot_ratings_ent_qc = PythonOperator(
    task_id="SPARK_mint_spot_ratings_ent_qc",
    provide_context=True,
    python_callable=spot_ratings_ent_qc,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag,
)

mint_spot_ratings_ent_to_bq = PythonOperator(
    task_id="SPARK_mint_spot_ratings_ent_to_bq",
    provide_context=True,
    python_callable=spot_ratings_ent_gcs_to_bq,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag,
)
notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "spot ratings ent ingestion",
        "event": "SPOT RATINGS ENT Ingestion - WEEKLY",
        "ingestion": 'SPOT RATINGS ENT'
    },
    dag=dag
 )

mint_spot_ratings_ent_qc >> mint_spot_ratings_ent_to_bq >> notification_task
