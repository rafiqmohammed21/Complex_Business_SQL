from airflow import AirflowException

from utils.data_ingestion import push_notification
from utils.livy_api import LivyApi
from utils.global_variables import *
from datetime import datetime


def run_job_spot_ratings(context, job_type: str, year: str, week: str):
    if job_type == 'entertainment':
        job_input_path = f"gs://dl-spot-ratings/entertainment/year={year}/week={week}/raw"
        job_output_path = f"gs://dl-spot-ratings/transformed/entertainment/year={year}/week={week}"
        output_table_name = "entertainment_spot_ratings"
        job_name = "EtlJobEntSpotRatings"
    elif job_type == 'regional':
        job_input_path = f"gs://dl-spot-ratings/regional/year={year}/week={week}/raw"
        job_output_path = f"gs://dl-spot-ratings/transformed/regional/year={year}/week={week}"
        output_table_name = "reg_spot_ratings"
        job_name = "EtlJobRegSpotRatings"
    yarn_app_name = 'DI_' + "MINT_SPOT_RATINGS_TO_BQ"
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB, JAR_GCS_CON, JAR_GCS_CRED, JAR_SLACK, JAR_STTP]
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    push_notification(context, "process_type", "spark_spot_ratings_bigquery_ingestion")
    jar_args = [
        f"job_name=={job_name}", f"job_input_path=={job_input_path}",
        f"job_output_path=={job_output_path}",
        "output_dataset==viewership", f"output_table_name=={output_table_name}",
        "test==false", "debug==false", "aggregate_error==false"
    ]
    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                              jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify", f"week {week} {year}")
    except:
        push_notification(context, "notify",
                          "spot ratings ingestion to bq task failed for " + f"week {week} {year}")
        raise AirflowException('{} Spot ratings ingestion to BQ Process Failed'.format("Weekly"))


def get_current_month_week_year():
    year = datetime.today().year
    month = datetime.today().month
    week = datetime.today().isocalendar()[1]
    return year, month, week
