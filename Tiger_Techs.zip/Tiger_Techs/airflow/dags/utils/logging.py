import logging
from datetime import datetime

from utils.data_download import memory_footprint
from utils.global_variables import tz


def print_log(DAG_ID, RUN_ENV, EMR_HOST, JOB, CALLBACK_URL=None):
 logging.info('Memory before DAG-{} is started: {} MB'.format(DAG_ID,memory_footprint()))
 logging.info('RUN_ENV: ' + RUN_ENV)
 logging.info('EMR_HOST: ' + EMR_HOST)
 logging.info('DAG_ID: ' + DAG_ID)
 logging.info('JOB: ' + JOB)
 logging.info('MINT CALLBACK_URL: ' + CALLBACK_URL)
 logging.info("Current Time Now (UTC): " + str(datetime.now()))
 logging.info("Current Time Now (IST): " + str(datetime.now(tz)))