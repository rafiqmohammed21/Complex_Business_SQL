import logging
from datetime import date, datetime

import boto3
import requests
from airflow import AirflowException
from pytz import timezone

from utils.file_operation import getS3ListOfFiles


def dag_run_schedule_interval(ingestionType):
    if ingestionType.lower() == "barc":
        return "00 10 * * THU"
    elif ingestionType.lower() == "spr":
        if getMeridianOfDay() == 'MORNING':
            return "00 00 * * *"
        else:
            return "00 15 * * *"
    elif ingestionType.lower() == "barc_1min":
        return "00 17 * * *"


def last_week_for_year(year):
    last_week = date(year, 12, 28)
    return last_week.isocalendar()[1]


def getMeridianOfDay():
    IST = timezone('Asia/Kolkata')
    current_time = datetime.now(IST).strftime('%Y-%m-%d %H-%M-%S %p')
    if 'AM' in current_time:
        return 'MORNING'
    elif 'PM' in current_time:
        return 'EVENING'


def get_year_week_date(orc_path):
    IST = timezone('Asia/Kolkata')
    today = datetime.now(IST)
    dt = today.strftime("%Y-%m-%d")
    year = getMaxPartitionValue(orc_path, 'year')
    week = getMaxPartitionValue(orc_path + '/' + 'year={}'.format(year), 'week')
    if week == 1:
        year = year - 1
        week = last_week_for_year(year)
    return year, week, dt


def call_back(CALLBACK_URL,BUSINESS):
    cb_url = url_finder(CALLBACK_URL,BUSINESS)
    logging.info('CALLBACK_URLs: ' + str(cb_url))
    headers = {'x-user-auth-token': 'g7uGXPQ_ZraGG2f2B8sgHWarTNW_axjvh-krn3QgsPjz_azqWg', "Content-Type": "application/json"}
    entertainment_response = requests.get(cb_url.get('entertainment'), headers=headers, verify=False)
    regional_response = requests.get(cb_url.get('regional'), headers=headers, verify=False)
    if entertainment_response.status_code in [204, 200] and regional_response.status_code in [204, 200]:
        logging.info("entertainment call back is success with response {}".format(entertainment_response.status_code))
        logging.info("regional call back is success with response {}".format(entertainment_response.status_code))
    else:
        raise AirflowException('Rest api call back is not success')


def getWeekList(base_path, year):
    list_of_files = getS3ListOfFiles(base_path+"year="+str(year)+"/")
    week_list = []
    for week_path in list_of_files:
        if 'week' in week_path:
            week_string = week_path.split('/')[-1]
            week = int(week_string.split('=')[1])
            week_list.append(week)
    return week_list


def getYearWeekList(base_path):
    list_of_files = getS3ListOfFiles(base_path)
    year_week_list = []
    for year_path in list_of_files:
        if 'year' in year_path:
            year_string = year_path.split('/')[-1]
            year = int(year_string.split('=')[1])
            week_list = getWeekList(base_path, year)
            for week in week_list:
                year_week_list.append((year, week))
    year_week_list.sort(key=lambda year_week: (year_week[0], year_week[1]))
    return year_week_list


def getDateList(base_path):
    list_of_files = getS3ListOfFiles(base_path)
    date_list = []
    for day_path in list_of_files:
        if 'date' in day_path:
            date_string = day_path.split('/')[-1]
            formatted_date = date_string.split("=")[1]
            date_list.append(formatted_date)
    date_list.sort()
    return date_list


def getMaxPartitionValue(base_path, partition_type):
    list_of_files = getS3ListOfFiles(base_path)
    z = []
    for i in list_of_files:
        partition_index = len(i.split('/')) - 1
        z.append(i.split('/')[partition_index])
    partitions = filter(lambda x: x.startswith(partition_type), z)
    partition_value = map(lambda x: int(x.split('=')[1]), set(partitions))
    return max(partition_value)


def push_notification(context, key, value):
    context['ti'].xcom_push(key=key, value=value)


def url_finder(callback_url, business):
    url_list = {}
    for business in business:
        url_list.update({business: callback_url + 'business=' + business})
    return url_list


def date_formats(): return {
    "Ymd": datetime.now().strftime("%Y%m%d"),
    "Y-m-d": datetime.now().strftime("%Y-%m-%d")
}


def read_html_content(bucket, path, date, module, run_type):
    print('logs/' + module + '/' + run_type + '/' + 'date={}'.format(date) + '/' + path + '/' + 'part-00000')
    print(bucket)
    obj = boto3.resource('s3').Object(bucket,
                                      'logs/' + module + '/' + run_type + '/' + 'date={}'.format(date) + '/' + path + '/' + 'part-00000')
    return obj.get()['Body'].read()

