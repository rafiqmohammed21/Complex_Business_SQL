from airflow.contrib.operators.slack_webhook_operator import SlackWebhookOperator
from airflow.utils.email import send_email
from datetime import timedelta, datetime
import logging
import re
import pendulum
import os
from utils.file_operation import writeToFile, readFromFile, remove_file
from utils.global_variables import RUN_ENV, FAILURE_EMAIL_LIST, ELB_NAME, SLACK_WEBHOOK_TOKEN
from utils.message_templates import *

utc = pendulum.timezone('UTC')


def operator_success_callback(context):
    tmp_file_path = context.get('task_instance').dag_id
    start_date = context.get('task_instance').start_date
    end_date = datetime.utcnow().replace(tzinfo=utc)
    duration = round(((end_date-start_date).total_seconds()/60), 2)
    process = context['params']['process_type']
    notification = context['params']['notify']
    file_mode = context['params']['file_mode']
    message = "\n\t\t\t\t   :small_blue_diamond:"+"*"+process+"*" + " - (" + str(duration) + " min) - (" + notification+")"
    writeToFile(tmp_file_path, file_mode, message)


def operator_failure_callback(context):
    tmp_file_path = context.get('task_instance').dag_id
    start_date = context.get('task_instance').start_date
    end_date = datetime.utcnow().replace(tzinfo=utc)
    duration = round(((end_date-start_date).total_seconds()/60), 2)
    process = context['params']['process_type']
    notification = context['params']['notify']
    file_mode = context['params']['file_mode']
    message = "\n\t\t\t\t   :small_orange_diamond:"+"*"+process+"*" + " - (" + str(duration) + " min) - (" + notification+")"
    writeToFile(tmp_file_path, file_mode, message)


def dag_success_callback(context):
    task_id = context.get('task_instance').task_id
    start_date = context.get('task_instance').start_date
    end_date = datetime.utcnow().replace(tzinfo=utc)
    duration = round(((end_date-start_date).total_seconds()/60), 2)
    process = context['ti'].xcom_pull(task_ids=task_id, key='process_type')
    notification = context['ti'].xcom_pull(task_ids=task_id, key='notify')
    tmp_file_path = context.get('task_instance').dag_id
    file_mode = context["params"]["file_mode"]
    message = "\n\t\t\t\t   :small_blue_diamond:"+"*"+process+"*" + " - (" + str(duration) + " min) - (" + notification+")"
    writeToFile(tmp_file_path, file_mode, message)


def dag_failure_callback(context):
    task_id = context.get('task_instance').task_id
    start_date = context.get('task_instance').start_date
    end_date = datetime.utcnow().replace(tzinfo=utc)
    duration = round(((end_date-start_date).total_seconds()/60), 2)
    process = context['ti'].xcom_pull(task_ids=task_id, key='process_type')
    notification = context['ti'].xcom_pull(task_ids=task_id, key='notify')
    tmp_file_path = context.get('task_instance').dag_id
    file_mode = context["params"]["file_mode"]
    message = "\n\t\t\t\t   :small_orange_diamond:"+"*"+process+"*" + " - (" + str(duration) + " min) - (" + notification+")"
    writeToFile(tmp_file_path, file_mode, message)


def remove_temp_file(context):
    tmp_file_path = context.get('task_instance').dag_id
    remove_file(tmp_file_path)


def dag_send_notification(**context):
    DAG_ID = context['params']['dag_id']
    tmp_file_path = context.get('task_instance').dag_id
    dag = context['params']['dag_object']
    message = readFromFile(tmp_file_path)
    logging.info(message)
    os.remove(tmp_file_path)
    task_id = context['params']['task_name']
    event = context['params']['event']
    execution_date = (context.get('execution_date') + timedelta(hours=5, minutes=30)).strftime('%Y-%m-%d %H:%M:%S')
    task_log_url = context.get('task_instance').log_url
    if "orange" in message.lower():
        status = "Failed"
        email_message = re.sub(':[^:]+:', '', message).replace('*', '')
        email_msg = MessageTemplate.ingestion_email_message(event, status, execution_date,email_message,task_log_url)
        email_subject = RUN_ENV + ' - DAG: ' + DAG_ID + ' - {}'.format(status)
        send_email(to=FAILURE_EMAIL_LIST, subject=email_subject, html_content=email_msg)

        slack_msg = MessageTemplate.ingestion_slack_failure_message(RUN_ENV, event, DAG_ID,task_id, execution_date,
                                                                    message, task_log_url)
        slack_msg = slack_msg.replace("localhost", ELB_NAME)
        logging.info(slack_msg)
        failed_alert = SlackWebhookOperator(
            task_id='slack_webhook',
            http_conn_id='slack',
            webhook_token=SLACK_WEBHOOK_TOKEN,
            message=slack_msg,
            username='airflow',
            dag=dag)
        return failed_alert.execute(context=context)

    else:
        slack_msg = MessageTemplate.ingestion_slack_success_message(RUN_ENV, event, DAG_ID, task_id, execution_date,
                                                                    message, task_log_url)
        logging.info(slack_msg)
        slack_msg = slack_msg.replace("localhost", ELB_NAME)
        success_alert = SlackWebhookOperator(
            task_id='slack_webhook',
            http_conn_id='slack',
            webhook_token=SLACK_WEBHOOK_TOKEN,
            message=slack_msg,
            username='Mint-DataLake-WebHook',
            dag=dag)
        return success_alert.execute(context=context)



