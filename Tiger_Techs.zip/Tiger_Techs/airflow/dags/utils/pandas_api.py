import io
import pandas as pd
import boto3
import xlsxwriter
from datetime import datetime
from pandas.io.common import EmptyDataError


class PandasApi():
    """
    Contains Function to convert csv to excel
    """
    def csv_to_excel_conversion(bucket, csv_path, excel_path):
        startTime = datetime.now()
        output = io.BytesIO()
        try:
         df = pd.read_csv(csv_path)
        except EmptyDataError:
         df = pd.DataFrame()
        writer = pd.ExcelWriter(output, engine='xlsxwriter')
        df.to_excel(writer, index=False, sheet_name='data')
        writer.save()
        data = output.getvalue()
        s3 = boto3.resource('s3')
        s3.Bucket(bucket).put_object(Key=excel_path,Body=data)
        return datetime.now() - startTime

