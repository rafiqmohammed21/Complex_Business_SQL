import logging
import json
import requests
import time


class LivyApi():
    """
    Contains Livy Api calls for batch spark submit
    """
    @staticmethod
    def run_livy_batch(emr_host, app_jar, class_name, yarn_app_name
                       , driver_memory, executor_memory
                       , jar_args, app_deps, app_files, max_executors, package_deps
                       , num_executors=1):

        if package_deps is not None and app_deps is not None:
            data = {
                "file": app_jar
                , "className": class_name
                , "name": yarn_app_name
                , "driverMemory": driver_memory
                , "executorMemory": executor_memory
                , "executorCores": 2
                , "numExecutors": int(num_executors)
                , "args": jar_args
                , "jars": app_deps
                , "files": app_files
                , "conf": {
                    "spark.dynamicAllocation.maxExecutors": max_executors
                    , "spark.jars.packages": package_deps
                    , "spark.yarn.maxAppAttempts": 1
                }
            }
        elif app_deps is not None:
            data = {
                "file": app_jar
                , "className": class_name
                , "name": yarn_app_name
                , "driverMemory": driver_memory
                , "executorMemory": executor_memory
                , "executorCores": 2
                , "numExecutors": int(num_executors)
                , "args": jar_args
                , "jars": app_deps
                , "files": app_files
                , "conf": {
                    "spark.dynamicAllocation.maxExecutors": max_executors
                    , "spark.yarn.maxAppAttempts": 1
                }
            }
        elif package_deps is not None:
            data = {
                "file": app_jar
                , "className": class_name
                , "name": yarn_app_name
                , "driverMemory": driver_memory
                , "executorMemory": executor_memory
                , "executorCores": 2
                , "numExecutors": int(num_executors)
                , "args": jar_args
                , "files": app_files
                , "conf": {
                    "spark.dynamicAllocation.maxExecutors": max_executors
                    , "spark.jars.packages": package_deps
                    , "spark.yarn.maxAppAttempts": 1
                }
            }
        else:
            data = {
                "file": app_jar
                , "className": class_name
                , "name": yarn_app_name
                , "driverMemory": driver_memory
                , "executorMemory": executor_memory
                , "executorCores": 2
                , "numExecutors": int(num_executors)
                , "args": jar_args
                , "files": app_files
                , "conf": {
                    "spark.dynamicAllocation.maxExecutors": max_executors
                    , "spark.yarn.maxAppAttempts": 1
                }
            }

        logging.info('LIVY REQUEST: ' + str(data))
        logging.info('LIVY REQUEST JSON: ' + str(json.dumps(data)))
        headers = {'Content-Type': 'application/json'}
        response = requests.post(emr_host + '/batches', data=json.dumps(data), headers=headers)

        logging.info('LIVY RESPONSE: ' + str(response.json()))
        response_headers = response.headers

        session_url = emr_host + response_headers['location'].split('/statements', 1)[0]
        logging.info('SESSION URL: ' + session_url)

        statement_status = ''
        while statement_status != 'success':
            statement_url = emr_host + response_headers['location']
            statement_response = requests.get(statement_url, headers={'Content-Type': 'application/json'})
            statement_status = statement_response.json()['state']
            logging.info('BATCH STATUS: ' + statement_status)

            if statement_status == 'dead':
                lines = requests.get(session_url + '/log', headers={'Content-Type': 'application/json'}).json()['log']
                for line in lines:
                    logging.info(line)
                raise ValueError('Exception in the app caused it to be dead: ' + statement_status)

            time.sleep(10)
