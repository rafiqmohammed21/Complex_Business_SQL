class MessageTemplate():
    """
    Contains Slack and Email Message Templates for success and failure notifications
    """
    @staticmethod
    def slack_success_message(dag_id):
        slack_msg = """
                    :large_blue_circle: Success 
                    *DAG*: {dag} 
                    *Message*: All the tasks of {dag} executed successfully
                    """.format(dag=dag_id)
        return slack_msg

    @staticmethod
    def slack_failure_message(event, module, token, business, exec_date, log_url, run_env):
        slack_msg = """
                    :red_circle: {run_env} - Data Download Task Failure!
                    *Business*: {business}
                    *Event*: {event}
                    *Module*: {module}
                    *Token*: {token}
                    *Time of Execution*: {exec_date}
                    *Error at*: {log_url}
                    """.format(event=event, module=module, business=business, token=token, exec_date=exec_date, log_url=log_url, run_env=run_env)
        return slack_msg

    @staticmethod
    def ingestion_slack_success_message(run_env, event, dag_id, task_id, exec_date, message, log_url):
        slack_msg = """
                      :large_blue_circle: {run_env} - {event} Process *Success!*
                      *DAG*: {dag_id}
                      *Task*: {task_id}
                      *Time of Execution*: {exec_date}
                      *Steps (Task - Duration - Period)*: {message}
                      *Log*: {log_url}
                      """.format(run_env=run_env,
                                 event=event,
                                 dag_id=dag_id,
                                 task_id=task_id,
                                 exec_date=exec_date,
                                 message=message,
                                 log_url=log_url)
        return slack_msg

    @staticmethod
    def ingestion_slack_failure_message(run_env, event, dag_id, task_id, exec_date, message, log_url):
        slack_msg = """
                      :red_circle: {run_env} - {event} Process *Failure!*
                      *DAG*: {dag_id}
                      *Task*: {task_id}
                      *Time of Execution*: {exec_date}
                      *Steps (Task - Duration - Period)* : {message}
                      *Error at*: {log_url}
                      """.format(run_env=run_env,
                                 event=event,
                                 exec_date=exec_date,
                                 dag_id = dag_id,
                                 task_id = task_id,
                                 message = message,
                                 log_url=log_url)
        return slack_msg

    @staticmethod
    def ingestion_email_message(event, status, execution_date,message,log_url):
        email_msg = """
                      <h1>Please do not reply to this mail.</h1>
                      '{event}' is '{status}' with '{message}' at '{exec_date}' <br />
                      Log: {log_url} <br />
                      """.format(event=event,
                                 status=status,
                                 exec_date=execution_date,
                                 message=message,
                                 log_url=log_url)
        return email_msg

    @staticmethod
    def email_message(dag_id, module, token, business, exec_date, log_url, event, status, csv_path,excel_exec_time):
        email_msg = """
                    <h1>Please do not reply to this mail.</h1>
                    '{event}' for business '{business}' of module '{module}' token '{token}' is '{status}' <br />
                    Time of Execution: {exec_date} <br />
                    Log is at: {log_url} <br />
                    S3 Data Download Location: {csv_path} <br />
                    Time Taken for Excel Conversion: {excel_exec_time} <br />
                    """.format(dag=dag_id, module=module, token=token, business=business, exec_date=exec_date, log_url=log_url, event=event, status=status, csv_path=csv_path,excel_exec_time=excel_exec_time)
        return email_msg
