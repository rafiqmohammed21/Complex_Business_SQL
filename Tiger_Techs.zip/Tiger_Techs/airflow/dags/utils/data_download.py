import logging
from airflow import AirflowException
import psutil, os


def memory_footprint():
    # Returns memory (in MB) being used by Python process
    mem = psutil.Process(os.getpid()).memory_info().rss
    return (mem / 1024 ** 2)


def url_finder(callback_url, module, token, business):
    if module == 'grp':
        return callback_url + '/spr_download?type=posteval_grp&token=' + token + '&business=' + business
    elif module == 'revenue':
        return callback_url + '/spr_download?type=posteval_revenue&token=' + token + '&business=' + business
    elif module == 'clientview':
        return callback_url + '/spr_download?type=posteval_client_view&token=' + token + '&business=' + business
    elif module == 'spr':
        return callback_url + '/spr_download?token=' + token + '&business=' + business
    elif module == 'barc':
        return callback_url + '/barc_download?token=' + token + '&business=' + business
    else:
        logging.info('Invalid MODULE specified in REST api call')
        raise AirflowException('Invalid MODULE specified in REST api call')


def path_finder(run_env, module, token, business):
    if module == 'grp':
        return 'download/'  + business + '/' + run_env.lower() + '/posteval/' + module + '/data/' + token.split('_')[1]
    elif module == 'revenue':
        return 'download/' + business + '/' + run_env.lower() + '/posteval/' + module + '/data/' + token.split('_')[1]
    elif module == 'clientview':
        return 'download/' + business + '/' + run_env.lower() + '/posteval/' + module + '/data/' + token + '/raw'
    elif module == 'spr':
        return 'download/' + business + '/' + run_env.lower() + '/' + module + '/data/' + token
    elif module == 'barc':
        return 'download/' + business + '/' + run_env.lower() + '/' + module + '/data/' + token
    else:
        logging.info('Invalid MODULE specified for download path')
        raise AirflowException('Invalid MODULE specified for download path')