import ast

from airflow.hooks.base_hook import BaseHook
from airflow.models import Variable
from pytz import timezone

from config.CONFIG_mint import *
from utils.data_ingestion import getMeridianOfDay

#Common Variables
tz = timezone('Asia/Kolkata')
SLACK_CONN_ID = 'slack'
SLACK_WEBHOOK_TOKEN = BaseHook.get_connection(SLACK_CONN_ID).password
ELB_NAME = common_variables["aws_elb_name"]
RUN_ENV = common_variables["environment"]
EMR_HOST = common_variables["emr_master"]
APP_JAR = common_variables["application_jar"]
APP_FILES = ast.literal_eval(common_variables["application_properties_file"])
APP_DEPS = ast.literal_eval(common_variables["application_jar_dependency"])
BUSINESS = ast.literal_eval(common_variables["business"])
PRE_INGESTION_LANDING_BUCKET = common_variables["spr_bucket"]
LANDING_BUCKET = common_variables["landing_bucket"]
TRANSFORMED_BUCKET = common_variables["transformed_bucket"]
SUCCESS_EMAIL_LIST = ast.literal_eval(common_variables["success_mail_list"])
FAILURE_EMAIL_LIST = ast.literal_eval(common_variables["failure_mail_list"])
BUSINESS_TYPE_REGIONAL = BUSINESS[1]
BUSINESS_TYPE_ENTERTAINMENT = BUSINESS[0]
MERIDIAN = getMeridianOfDay()

#DD Variables
dd_vars = Variable.get("dd_variables", deserialize_json=True)

DD_CLASS_NAME = dd_vars["data_download_class"]
DD_DRIVER_MEMORY = dd_vars["data_download_driver_memory"]
DD_EXECUTOR_MEMORY = dd_vars["data_download_executor_memory"]
DD_MAX_EXECUTORS = dd_vars["data_download_max_executors"]
DD_CALLBACK_URL = data_download_variables["data_download_cb_url"]

#DI Variables
di_vars = Variable.get("di_variables", deserialize_json=True)

DI_CLASS_NAME = di_vars["data_ingestion_class"]
DI_PRE_CLASS_NAME = di_vars["data_pre_ingestion_class"]
DI_DRIVER_MEMORY = di_vars["data_ingestion_driver_memory"]
DI_EXECUTOR_MEMORY = di_vars["data_ingestion_executor_memory"]
DI_NUM_EXECUTORS = di_vars["data_ingestion_num_executors"]
DI_MAX_EXECUTORS = di_vars["data_ingestion_max_executors"]
DI_BARC_CALLBACK_URL = data_ingestion_variables["data_ingestion_cb_url_barc"]
DI_SPR_CALLBACK_URL = data_ingestion_variables["data_ingestion_cb_url_spr"]
DI_SPR_REPORTS_CALLBACK_URL = data_ingestion_variables["data_ingestion_cb_url_spr_reports"]
BARC_RAW_PATH = data_ingestion_variables["barc_pricing_raw_path"]
BARC_QC_PATH = data_ingestion_variables["barc_pricing_qc_path"]
BARC_ORC_PATH = data_ingestion_variables["barc_pricing_orc_path"]
SPR_RAW_PATH = data_ingestion_variables["onair_spr_raw_path"]
SPR_ORC_PATH = data_ingestion_variables["onair_spr_orc_path"]
POSTEVAL_RAW_PATH = data_ingestion_variables["post_eval_raw_path"]
POSTEVAL_QC_PATH = data_ingestion_variables["post_eval_qc_path"]
POSTEVAL_ORC_PATH = data_ingestion_variables["post_eval_orc_path"]
BARC_HISTORICAL_SRC_RAW_PATH = data_ingestion_variables["barc_pricing_raw_historical_path"]
BARC_HISTORICAL_SRC_QC_PATH = data_ingestion_variables["barc_pricing_qc_historical_path"]
POSTEVAL_RAW_HISTORICAL_PATH = data_ingestion_variables["post_eval_raw_historical_path"]
POSTEVAL_QC_HISTORICAL_PATH = data_ingestion_variables["post_eval_qc_historical_path"]

#Pre DI Variables
CHAMP_PRE_INGESTION_FILE_NAME = file_names['pre_ingestion_champ']
ONAIR_PRE_INGESTION_FILE_NAME  =  file_names['pre_ingestion_onair']
ONAIR_PRE_INGESTION_RAW_PATH = data_ingestion_variables["pre_ingestion_onair_raw_path"]
CHAMP_PRE_INGESTION_RAW_PATH = data_ingestion_variables["pre_ingestion_champ_raw_path"]



#KYLIN Variables
BARC_REPAIR_TABLE_PATH = kylin_variables["barc_repair_table_path"]
SPR_REPAIR_TABLE_PATH = kylin_variables["spr_repair_table_path"]


#Adhoc Variables
BARC_RUN_YEAR = Variable.get("barc_run_year")
BARC_RUN_WEEK = Variable.get("barc_run_week")
BARC_RUN_TYPE = Variable.get("barc_run_type")
BARC_1MIN_RUN_TYPE = Variable.get("barc_1min_run_type")
BARC_1MIN_RUN_YEAR = Variable.get("barc_1min_run_year")
BARC_1MIN_RUN_WEEK = Variable.get("barc_1min_run_week")
SPR_RUN_TYPE = Variable.get("spr_run_type")
SPR_RUN_DATE = Variable.get("spr_run_date")
SPR_CUBE_REFRESH = Variable.get("spr_cube_refresh")



# Master job Variables
JAR_POSTGRE = master_data_var["jar_postgre"]
JAR_BQ = master_data_var["jar_bq"]
JAR_SPARKLIB = master_data_var["jar_sparklib"]
JAR_GCS_CON = master_data_var["jar_gcs_con"]
JAR_GCS_CRED = master_data_var["jar_gcs_cred"]
JAR_SLACK = master_data_var["jar_slack"]
FILE_LOADDATA = master_data_var["file_loaddata"]
FILE_GCS_CRED = master_data_var["file_gcs_cred"]
MAIN_CLASS = master_data_var["main_class"]

#Distribution job Variable
JAR_STTP = distribution_packs_var["jar_sttp"]

#Spr Ingestion job variables
SPR_JOB_OUTPUT_PATH = spr_ingestion_var["spr_job_output_path"]
SPR_CURRENCY_INPUT_DATA_PATH = spr_ingestion_var["spr_currency_input_data_path"]
SPR_ONAIR_HISTORY_LOAD_INPUT_PATH = spr_ingestion_var["spr_onair_history_load_input_path"]
SPR_CHAMP_HISTORY_LOAD_INPUT_PATH = spr_ingestion_var["spr_champ_history_load_input_path"]
SPR_OUTPUT_DATASET = spr_ingestion_var["spr_output_dataset"]
SPR_OUTPUT_TABLE_NAME = spr_ingestion_var["spr_output_table_name"]

#currency ingestion variables
CURRENCY_JOB_INPUT_PATH = spr_ingestion_var["currency_job_input_path"]
CURRENCY_JOB_OUTPUT_PATH = spr_ingestion_var["currency_job_output_path"]

#revenue funnel variables
FUNNEL_JOB_INPUT_POSTGRE_TABLE_NAME = funnel_ingestion_var["funnel_input_postgre_table_name"]
FUNNEL_OUTPUT_PATH = funnel_ingestion_var["funnel_output_path"]
FUNNEL_OUTPUT_PATH_GCS = funnel_ingestion_var["funnel_output_path_gcs"]
FUNNEL_OUTPUT_DATASET_NAME = funnel_ingestion_var["funnel_output_dataset"]
FUNNEL_OUTPUT_TABLE_NAME = funnel_ingestion_var["funnel_output_table_name"]




#ro variables
RO_JOB_INPUT_POSTGRE_TABLE_NAME = ro_ingestion_var["ro_postgre_table_name"]
RO_OUTPUT_PATH = ro_ingestion_var["ro_output_path"]
RO_OUTPUT_PATH_GCS = ro_ingestion_var["ro_output_path_gcs"]
RO_OUTPUT_DATASET_NAME = ro_ingestion_var["ro_dataset"]
RO_OUTPUT_TABLE_NAME = ro_ingestion_var["ro_output_table_name"]

#revenue sales_unit variables
SALES_UNIT_JOB_INPUT_POSTGRE_TABLE_NAME = sale_unit_ingestion_var["sales_unit_postgre_table_name"]
SALES_UNIT_OUTPUT_PATH = sale_unit_ingestion_var["sales_unit_output_path"]
SALES_UNIT_OUTPUT_PATH_GCS = sale_unit_ingestion_var["sales_unit_output_path_gcs"]
SALES_UNIT_OUTPUT_DATASET_NAME = sale_unit_ingestion_var["sales_unit_output_dataset"]
SALES_UNIT_OUTPUT_TABLE_NAME = sale_unit_ingestion_var["sales_unit_output_table_name"]
