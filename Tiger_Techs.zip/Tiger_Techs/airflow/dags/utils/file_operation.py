import os
from s3fs.core import S3FileSystem

def writeToFile(filePath, mode, message):
    tmp_file = open(filePath, mode)
    tmp_file.write(message)
    tmp_file.close()


def readFromFile(filePath):
    tmp_file = open(filePath, "r")
    message = tmp_file.read()
    tmp_file.close()
    return message


def remove_file(filePath):
    if os.path.isfile(filePath):
        os.remove(filePath)


def getS3ListOfFiles(basePath):
    try:
        s3_file = S3FileSystem(anon=False)
        list_of_files = s3_file.ls(basePath)
        return list_of_files
    except:
        raise Exception("S3 file not found")




