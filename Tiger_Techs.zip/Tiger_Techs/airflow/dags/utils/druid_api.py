import logging
import json
import requests
import time


class DruidApi():
    """
    Contains Druid Api calls for druid ingestion
    """
    @staticmethod
    def run_ingestion_job(druid_host, data_source, segment_granularity, dimension_lists, metric_lists):
        logging.info('DATA_SOURCE: ' + data_source)
        logging.info('DRUID HOST: ' + druid_host)

        ingestion_json = {
            "type": "index",
            "spec": {
                "dataSchema": {
                    "dataSource": data_source,
                    "parser": {
                        "type": "string",
                        "parseSpec": {
                            "format": "json",
                            "dimensionsSpec": dimension_lists,
                            "timestampSpec": {
                                "format": "auto",
                                "column": "date"
                            }
                        }
                    },
                    "metricsSpec": metric_lists,
                    "granularitySpec": {
                        "type": "uniform",
                        "segmentGranularity": segment_granularity,
                        "queryGranularity": "day",
                        # "intervals": ["2018-01-20/2018-01-21"],
                        "rollup": False
                    }
                },
                "ioConfig": {
                    "type": "index",
                    "firehose": {
                        "type": "static-s3",
                        "prefixes": ["s3://star-dl-eks/druid/input-data/" + data_source + "/"]
                    }
                },
                "tuningconfig": {
                    "type": "index_parallel",
                    "maxNumSubTasks": 1
                }
            }
        }
        logging.info('DRUID INGESTION DICT: ' + str(ingestion_json))
        logging.info('DRUID INGESTION JSON: ' + str(json.dumps(ingestion_json)))

        headers = {'Content-Type': 'application/json'}
        response = requests.post(druid_host, data=json.dumps(ingestion_json), headers=headers)
        task_id = response.json()["task"]
        logging.info('DRUID RESPONSE TASK ID: ' + task_id)

        while True:
            time.sleep(10)
            url = druid_host + '/{0}/status'.format(task_id)
            response = requests.get(url)
            response_status_code = response.json()["status"]["statusCode"]
            if response_status_code in ['SUCCESS', 'FAILED']:
                logging.info('DRUID INGESTION COMPLETED: ' + str(response.json()))
                return
            elif response_status_code in ['RUNNING']:
                logging.info('DRUID INGESTION RUNNING: ' + str(response.json()))
            else:
                raise Exception("Task {0} did not finish!".format(task_id))

