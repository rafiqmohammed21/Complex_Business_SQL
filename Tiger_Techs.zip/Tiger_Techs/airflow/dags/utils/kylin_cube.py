import calendar
import json
import logging
import sys
import time
from datetime import timedelta, datetime, date

import requests

from utils.global_variables import *
from config.CONFIG_mint import kylin_variables

date_list = []


# get the start date and end date of the month
def get_month_day_range(date):
    start_date = date.replace(day=1)
    end_date = date.replace(day=calendar.monthrange(date.year, date.month)[1])
    new_end_date = end_date + timedelta(days=1)
    return start_date, new_end_date


# get the start date and end date of the week
def get_week_day_range(date):
    current_start_date = date - timedelta(days=date.weekday()+2)
    barc_start_date = current_start_date+timedelta(days=-7)
    barc_end_date = barc_start_date + timedelta(days=7)
    return barc_start_date, barc_end_date


# convert date to milliseconds
def convert_date_to_millisecs(start_date, end_date):
    start_time = start_date.strftime('%s') + '000'
    end_time = end_date.strftime('%s') + '000'
    return start_time, end_time


def append_date_list(start_date, end_date):
    date_list.append((start_date, end_date))
    return date_list


## build the cube
def build_kylin_cube(url, data, headers):
    try:
        logging.info(url)
        response = requests.put(url, data=json.dumps(data), headers=headers, verify=False)
        logging.info(response.text)
        logging.info(response.raise_for_status())
        return response
    except requests.exceptions.HTTPError as err:
        logging.info(err)
        sys.exit(1)


def check_build_progress(progress, job_status, job_id, headers, get_url):
    while progress != '100.0':
        counter = 0
        while job_status == "ERROR" and counter < 4:
            time.sleep(60)
            requests.put(kylin_variables["kylin_url"] +'/jobs/'+ job_id + '/resume', headers=headers, verify=False)
            get_response = requests.get(get_url, headers=headers,verify=False)
            job_status = str(get_response.json()["job_status"])
            logging.info(job_status)
            counter = counter + 1
            logging.info(counter)
        if counter == 4:
            logging.info('build failed')
            sys.exit(500)
        time.sleep(60)
        get_response = requests.get(get_url, headers=headers, verify=False)
        job_status = str(get_response.json()["job_status"])
        logging.info(job_status)
        progress = str(get_response.json()["progress"])
        logging.info(progress)


def getKylinCubeName(moduleName, business_type):
    if business_type == BUSINESS_TYPE_REGIONAL:
        switcher={
            'barc_daily': kylin_variables["regional_barc_daily"],
            'posteval_barc': kylin_variables["regional_posteval_barc"],
            'spr_daily': kylin_variables["regional_spr_daily"],
            'posteval_spr': kylin_variables["regional_posteval_spr"]
        }
        return switcher.get(moduleName, "Invalid module name")
    elif business_type == BUSINESS_TYPE_ENTERTAINMENT:
        switcher={
            'barc_daily': kylin_variables["entertainment_barc_daily"],
            'posteval_barc': kylin_variables["entertainment_posteval_barc"],
            'spr_daily': kylin_variables["entertainment_spr_daily"],
            'posteval_spr': kylin_variables["entertainment_posteval_spr"]
        }
        return switcher.get(moduleName, "Invalid module name")


def build_cube(cubeName, headers, start_time, end_time, buildType):
    data = {"startTime": start_time, "endTime": end_time, "buildType": buildType}
    logging.info(data)
    url = kylin_variables["kylin_url"]+'/cubes/'+cubeName+'/build'
    response = build_kylin_cube(url, data, headers)
    time.sleep(3)
    logging.info(response.json()["uuid"])
    job_id = str(response.json()["uuid"])
    get_url = kylin_variables["kylin_url"]+'/jobs/'+job_id
    get_response = requests.get(get_url, headers=headers, verify=False)
    job_status = str(get_response.json()["job_status"])
    progress = str(get_response.json()["progress"])
    logging.info('started the job progress')
    logging.info(progress)
    time.sleep(5)
    check_build_progress(progress, job_status, job_id, headers, get_url)


def check_month(day, month, year):
    if (month == 1):
        previous_dateinput = date(year - 1, 12, day)
    else:
        previous_dateinput = date(year, month - 1, day)
    return previous_dateinput


def getSegementsBuilt():
    date_list_str = []
    for dates in date_list:
        start_date = dates[0]
        end_date = dates[1]
        date_list_str.append(str(start_date).replace("-", "/") + " - " + str(end_date).replace("-", "/"))
    return date_list_str


# returns cube segments in descending order
def getSegments(cubeName):
    segment_list = []
    data = {"projectName": kylin_variables["kylin_project_name"], "cubeName": cubeName, "offset": 0, "limit": 0}
    url = kylin_variables["kylin_url"]+'/cubes/'
    headers = {'Authorization': "Basic QURNSU46S1lMSU4=", "Content-Type": "application/json"}
    response = requests.get(url, data=json.dumps(data), headers=headers, verify=False)
    cubes = response.json()
    for cube in cubes:
        if cube["name"] == cubeName:
            for segment in cube["segments"]:
                segment_name = segment["name"]
                segment_start_date = segment_name.split("_")[0]
                segment_end_date = segment_name.split("_")[1]
                start_date = segment_start_date[0:4]+"-"+segment_start_date[4:6]+"-"+segment_start_date[6:8]
                end_date = segment_end_date[0:4]+"-"+segment_end_date[4:6]+"-"+segment_end_date[6:8]
                segment_list.append(start_date + "," + end_date)
    segment_list.sort()
    return segment_list


def getSegmentIndexForDate (cubeName, inputDate):
    segment_list = getSegments(cubeName)
    segment_index = len(segment_list)
    for index in range(0, len(segment_list), 1):
        start_date_str = segment_list[index].split(",")[0].strip()
        end_date_str = segment_list[index].split(",")[1].strip()
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
        for_date = datetime.strptime(inputDate, "%Y-%m-%d").date()
        if for_date < end_date:
            segment_index = index
            break
    return segment_index


def getSegmentsBetweenDate(cubeName, startDate, endDate):
    segment_list = getSegments(cubeName)
    start_index = getSegmentIndexForDate(cubeName, startDate)
    end_index = getSegmentIndexForDate(cubeName, endDate)
    return segment_list[start_index:end_index+1]


def spr_cube_segement_calculation(moduleName, business_type, run_date):
    dateinput = datetime.strptime(run_date, "%Y-%m-%d").date()
    day = dateinput.day
    month = dateinput.month
    year = dateinput.year
    if day > 7:
        # get the start_date and end_date
        start_date, end_date = get_month_day_range(dateinput)
        append_date_list(start_date, end_date)
    elif day == 1:
        # PREVIOUS MONTH
        previous_dateinput = check_month(day, month, year)
        previous_start_date, previous_end_date = get_month_day_range(previous_dateinput)
        append_date_list(previous_start_date, previous_end_date)
        # CURRENT MONTH
        current_st_date, current_ed_date = get_month_day_range(dateinput)
        append_date_list(current_st_date, current_ed_date)
    else:
        # refresh cube for current month and previous month
        current_start_date, current_end_date = get_month_day_range(dateinput)
        append_date_list(current_start_date, current_end_date)
        previous_dateinput = check_month(day, month, year)
        previous_start_date, previous_end_date = get_month_day_range(previous_dateinput)
        append_date_list(previous_start_date, previous_end_date)
    cube_segments_build(moduleName, business_type)


def cube_segments_refresh(moduleName, business_type, from_date, to_date):
    cubeName = getKylinCubeName(moduleName, business_type)
    segments = getSegmentsBetweenDate(cubeName, from_date, to_date)
    segments.sort(reverse=True)#build latest segments first
    if len(segments) > 0:
        for segment in segments:
            segment_start_date = segment.split(",")[0]
            segment_end_date = segment.split(",")[1]
            start_date = datetime.strptime(segment_start_date, "%Y-%m-%d").date()
            end_date = datetime.strptime(segment_end_date, "%Y-%m-%d").date()
            append_date_list(start_date, end_date)
    else:
        start_date = datetime.strptime(from_date, "%Y-%m-%d").date()
        end_date = datetime.strptime(to_date, "%Y-%m-%d").date() + timedelta(days=1)
        append_date_list(start_date, end_date)
    cube_segments_build(moduleName, business_type)


def cube_segments_build(moduleName, business_type):
    headers = {'Authorization': kylin_variables["Authorization"], "Content-Type": kylin_variables["Content-Type"]}
    cubeName = getKylinCubeName(moduleName, business_type)
    for dates in date_list:
        start_date = dates[0]
        end_date = dates[1]
        start_time, end_time = convert_date_to_millisecs(start_date, end_date)
        logging.info(start_date)
        logging.info(end_date)
        build_cube(cubeName, headers, start_time, end_time, 'BUILD')
