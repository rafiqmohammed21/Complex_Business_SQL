from datetime import datetime

from airflow import AirflowException
from airflow import DAG
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.operators.python_operator import PythonOperator
from airflow.utils.trigger_rule import TriggerRule

from utils.data_ingestion import push_notification, getYearWeekList, getDateList
from utils.global_variables import *
from utils.kylin_cube import getSegementsBuilt, cube_segments_refresh
from utils.livy_api import LivyApi
from utils.send_notification import dag_send_notification, remove_temp_file, dag_success_callback, dag_failure_callback, \
    operator_success_callback, operator_failure_callback

DAG_ID = 'cubes_barc'

default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': 'z6f6k5x3f5o3y8e4@startv.slack.com',
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None, catchup=False)


kylin_task_details = lambda : [{'task_id': 'KYLIN_regional_barc_daily_cube', 'cubeName': 'barc_daily', 'businessType': BUSINESS_TYPE_REGIONAL},
                               {'task_id': 'KYLIN_regional_barc_posteval_cube', 'cubeName': 'posteval_barc', 'businessType': BUSINESS_TYPE_REGIONAL},
                               {'task_id': 'KYLIN_entertainment_barc_daily_cube', 'cubeName': 'barc_daily', 'businessType': BUSINESS_TYPE_ENTERTAINMENT},
                               {'task_id': 'KYLIN_entertainment_barc_posteval_cube', 'cubeName': 'posteval_barc', 'businessType': BUSINESS_TYPE_ENTERTAINMENT}]
kylin_task_list = []
kylin_msck_command = lambda: ' sh {} '.format(BARC_REPAIR_TABLE_PATH)


def barc_cube_build_func(**kwargs):
    cubeName = kwargs['params']['cubeName']
    businessType = kwargs['params']['business_type']
    push_notification(kwargs, "process_type", "kylin_"+businessType+"_"+cubeName)
    try:
        if BARC_RUN_TYPE.lower() == "weekly":
            barc_path = "s3://"+BARC_ORC_PATH+"/year={}/week={}/".format(str(BARC_RUN_YEAR), str(BARC_RUN_WEEK).zfill(2))
            print(barc_path)
            run_date_list = getDateList(barc_path)
            start_date = run_date_list[0]
            end_date = run_date_list[-1]
            cube_segments_refresh(cubeName, businessType, start_date, end_date)
        elif BARC_RUN_TYPE.lower() == "historical":
            year_week_list = getYearWeekList(BARC_HISTORICAL_SRC_RAW_PATH)
            min_year_week = year_week_list[0]
            max_year_week = year_week_list[-1]
            min_base_path = "s3://"+BARC_ORC_PATH+"/year={}/week={}/".format(str(min_year_week[0]), str(min_year_week[1]).zfill(2))
            max_base_path = "s3://"+BARC_ORC_PATH+"/year={}/week={}/".format(str(max_year_week[0]), str(max_year_week[1]).zfill(2))
            start_date = getDateList(min_base_path)[0]
            end_date = getDateList(max_base_path)[-1]
            cube_segments_refresh(cubeName, businessType, start_date, end_date)
        date_list = getSegementsBuilt()
        notify_message = ' , '.join(date_list)
        push_notification(kwargs, "notify", notify_message)
    except:
        date_list = getSegementsBuilt()
        notify_message = ' , '.join(date_list)
        push_notification(kwargs, "notify", notify_message)
        raise AirflowException("Cube building Failed")
    return


def aws_sync_postgre(**context):
    push_notification(context, "process_type", "spark_aws_master_table_sync")
    push_notification(context, "notify", "copy postgre master tables to s3")
    yarn_app_name = 'DI_' + "KYLIN"
    jar_args = ["KYLIN"]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None)
    except:
        raise AirflowException('aws sync operation Failed')
    return


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "barc cube build",
        "event": "BARC Cube Build - "+BARC_RUN_TYPE.upper()
    },
    trigger_rule=TriggerRule.ALL_DONE,
    on_failure_callback=remove_temp_file,
    dag=dag
)

sync_task = PythonOperator(
    task_id='SPARK_postgre_to_s3_mint_master_tables',
    python_callable=aws_sync_postgre,
    provide_context=True,
    trigger_rule=TriggerRule.NONE_FAILED,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={"file_mode": "w"},
    dag=dag)

msck_task = SSHOperator(
    ssh_conn_id='msck_ssh',
    task_id='KYLIN_ssh_msck_to_orc_table',
    command=kylin_msck_command(),
    params={
        "process_type": "hive_add_partition",
        "notify": "add hive partitions",
        "file_mode": "a"
    },
    on_success_callback=operator_success_callback,
    on_failure_callback=operator_failure_callback,
    dag=dag)

for task in kylin_task_details():
    kylin_task_list.append(PythonOperator(
        task_id=task['task_id'],
        python_callable=barc_cube_build_func,
        provide_context=True,
        trigger_rule=TriggerRule.NONE_FAILED,
        params={
            "cubeName": task['cubeName'],
            "business_type": task['businessType'],
            "file_mode": "a"
        },
        on_success_callback=dag_success_callback,
        on_failure_callback=dag_failure_callback,
        dag=dag)
    )


sync_task          >> msck_task
msck_task          >> kylin_task_list
kylin_task_list    >> notification_task



