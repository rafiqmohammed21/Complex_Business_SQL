from datetime import datetime

from utils.data_ingestion import push_notification, date_formats
from utils.livy_api import LivyApi
from airflow import DAG, AirflowException
from airflow.operators.python_operator import PythonOperator
from utils.global_variables import *
import logging

from utils.send_notification import dag_send_notification, remove_temp_file, dag_success_callback, dag_failure_callback
from utils.spot_ratings import get_current_month_week_year

DAG_ID = 'GCP_distribution_packs'

default_args = {
    'owner': 'Danveer',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}
dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None)


def distribution_packs_gcs_to_bq(**context):
    if context['dag_run'].conf:
        year = context['dag_run'].conf["year"]
        month = context['dag_run'].conf["month"]
        logging.info('Running through rest trigger => year: ' + year)
        logging.info('Running through rest trigger => month: ' + month)
    else:
        year = get_current_month_week_year()[0]
        month = get_current_month_week_year()[1]
        logging.info('Running through manual trigger => year: ' + str(year))
        logging.info('Running through manual trigger => month: ' + str(month))

    yarn_app_name = 'DI_' + "MINT_DISTRIBUTION_PACKS_TO_BQ"
    current_date = date_formats()['Y-m-d']
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB, JAR_GCS_CON, JAR_GCS_CRED, JAR_SLACK, JAR_STTP]
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    push_notification(context, "process_type", "spark_dist_packs_bigquery_ingestion")
    jar_args = [
        "job_name==EtlJobDistributionData",
        f"job_input_path==gs://dl-distribution/distribution_data/monthly/year={year}/month={month}",
        f"job_output_path==gs://dl-temp-mint/output/distribution_data/monthly/year={year}/month={month}",
        "job_channel_state_output_path==gs://dl-temp-mint/output/distribution_channel_state_master",
        "channel_master_input_path==gs://dl-distribution/distribution_master/current/ditribution_channel_master.csv",
        "distribution_state_master_input_path==gs://dl-distribution/distribution_master/current/ditribution_state_master.csv",
        "distribution_channel_state_master_input_path==gs://dl-distribution/distribution_master/current/channel_to_state_master.csv",
        "distribution_output_dataset==viewership", "distribution_output_table_name==dist_data",
        "distribution_output_channel_state_master_table_name==dist_channel_state_master",
        "test==false", "debug==false", "aggregate_error==false"
    ]
    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                               jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify", current_date)
    except:
        push_notification(context, "notify", "distribution packs ingestion to bq task failed - date - " + current_date)
        raise AirflowException('{} Distribution packs Ingestion to BQ Process Failed'.format("Monthly"))


mint_distribution_packs_to_bq = PythonOperator(
    task_id='SPARK_mint_distribution_packs_to_bq',
    provide_context=True,
    python_callable=distribution_packs_gcs_to_bq,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag,
)
notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "dist packs ingestion",
        "event": "DIST PACKS Ingestion - MONTHLY",
        "ingestion": 'DIST PACKS'
    },
    dag=dag
)

mint_distribution_packs_to_bq >> notification_task
