import logging
from datetime import datetime
import os

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.sensors import S3KeySensor
from airflow.utils.trigger_rule import TriggerRule

from utils.data_ingestion import dag_run_schedule_interval, push_notification, getYearWeekList
from utils.global_variables import *
from utils.livy_api import LivyApi
from utils.logging import print_log
from utils.send_notification import remove_temp_file, dag_failure_callback, dag_success_callback, dag_send_notification, \
    operator_failure_callback

DAG_ID = 'ingestion_barc_1min'


default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=1, max_active_runs=1, schedule_interval=dag_run_schedule_interval('barc_1min'), catchup=False)
ingestion_task_list = []
rawsuccessCheckPath = lambda :"s3://"+POSTEVAL_RAW_PATH+'/year={}/week={}/SUCCESS.txt'


def check_run_type(**context):
    try:
        run_type = context['dag_run'].conf["run_type"]
        logging.info(run_type)
        Variable.set("barc_1min_run_type", run_type)
        if run_type.lower() == "weekly":
            Variable.set("barc_1min_run_year", context['dag_run'].conf["run_year"])
            Variable.set("barc_1min_run_week", context['dag_run'].conf["run_week"])
            return 'weekly_run'
        elif run_type.lower() == "historical":
            return 'historical_run'
    except:
        Variable.set("barc_1min_run_type", "daily")
        return 'daily_run'


def getRunWeekList():
    if BARC_1MIN_RUN_TYPE == "weekly":
        return [(BARC_1MIN_RUN_YEAR, BARC_1MIN_RUN_WEEK)]
    elif BARC_1MIN_RUN_TYPE == "daily":
        raw_path = "s3://" + BARC_ORC_PATH + "/"
        return getYearWeekList(raw_path)[-4:]
    elif BARC_1MIN_RUN_TYPE == "historical":
        raw_path = "s3://" + POSTEVAL_RAW_HISTORICAL_PATH + "/"
        return getYearWeekList(raw_path)
    else:
        logging.info("Wrong arguments")


def aws_sources_sync(**context):
    push_notification(context, "process_type", "s3_aws_source_tables_sync")
    push_notification(context, "notify", "copy "+BARC_RUN_TYPE.lower() + " data to raw folder")
    os.system("aws s3 sync " + POSTEVAL_RAW_HISTORICAL_PATH + "/" + " " + POSTEVAL_RAW_PATH + '/')
    os.system("aws s3 sync " + POSTEVAL_QC_HISTORICAL_PATH + "/" + " " + POSTEVAL_QC_PATH + '/')


def posteval_ingestion(**context):
    BARCYear = context["params"]["run_year"]
    BARCWeek = context["params"]["run_week"]
    print_log(DAG_ID, RUN_ENV, EMR_HOST, "INGESTION", "None")
    push_notification(context, "process_type", "spark_ingestion_"+BARC_1MIN_RUN_TYPE)
    push_notification(context, "notify", "week {} {}".format(BARCWeek, BARCYear))
    yarn_app_name = 'DI_' + "BARC_1MIN" + "_" + BARC_1MIN_RUN_TYPE
    jar_args = ["POSTEVAL", BARCYear, BARCWeek, BARC_1MIN_RUN_TYPE]
    print(BARCYear, BARCWeek, BARC_1MIN_RUN_TYPE)
    LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name, DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY,
                           jar_args, APP_DEPS, APP_FILES, DI_MAX_EXECUTORS, None)


def ingestion_task(year, week):
    return PythonOperator(
        task_id='barc_1min_{}_{}'.format(year, week),
        provide_context=True,
        python_callable=posteval_ingestion,
        on_failure_callback=dag_failure_callback,
        on_success_callback=dag_success_callback,
        trigger_rule=TriggerRule.NONE_FAILED,
        params={
            "file_mode": "a",
            "run_year": year,
            "run_week": week
        },
        dag=dag,
    )


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "barc 1 min ingestion",
        "event": "BARC 1 MIN Ingestion - " + BARC_1MIN_RUN_TYPE.upper()
    },
    trigger_rule=TriggerRule.ALL_DONE,
    on_failure_callback=remove_temp_file,
    dag=dag
)

weekly_task = DummyOperator(task_id='weekly_run', dag=dag)
historical_task = DummyOperator(task_id='historical_run', dag=dag)
daily_task = DummyOperator(task_id='daily_run', dag=dag)


check_type_task = BranchPythonOperator(
    task_id='check_run_type',
    provide_context=True,
    python_callable=check_run_type,
    params={
        "file_mode": "w"
    },
    dag=dag,
)

raw_success_file_check = S3KeySensor(
    task_id='raw_success_file_check',
    poke_interval=60 * 30,
    timeout=60 * 60 * 8,
    bucket_key=rawsuccessCheckPath().format(BARC_1MIN_RUN_YEAR, BARC_1MIN_RUN_WEEK),
    bucket_name=None,
    wildcard_match=False,
    on_failure_callback=operator_failure_callback,
    params={
        "process_type": "check_success_file",
        "notify": "raw success file is not uploaded for year-{} week-{} !!".format(BARC_1MIN_RUN_YEAR, BARC_1MIN_RUN_WEEK),
        "file_mode": "w"
    },
    dag=dag
)

sync_sources_task = PythonOperator(
    task_id='S3_sources_sync',
    python_callable=aws_sources_sync,
    provide_context=True,
    params={"file_mode": "w"},
    trigger_rule=TriggerRule.NONE_FAILED,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    dag=dag
)


check_type_task >> [weekly_task, daily_task, historical_task]
historical_task >> sync_sources_task
weekly_task >> raw_success_file_check

for yearWeek in getRunWeekList():
    [raw_success_file_check, daily_task, sync_sources_task] >> ingestion_task(str(yearWeek[0]), str(yearWeek[1]).zfill(2)) >> notification_task

