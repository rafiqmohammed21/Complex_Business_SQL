from datetime import datetime

from utils.data_ingestion import push_notification
from utils.livy_api import LivyApi
from airflow import DAG, AirflowException
from airflow.operators.python_operator import PythonOperator
from utils.global_variables import *

import logging

from utils.send_notification import dag_failure_callback, dag_success_callback, dag_send_notification, remove_temp_file

DAG_ID = 'GCP_ro'

default_args = {
    'owner': 'Danveer',
    'depends_on_past': False,
    'start_date': datetime(2019, 9, 26),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None)


def converttostr(input_seq):
    seperator="\',\'"
    final_str = seperator.join(input_seq)
    return final_str


def ro_postgre_to_bq(**context):
    if context['dag_run'].conf:
        current_date = context['dag_run'].conf["month"]
        logging.info('Running through scheduled trigger => year: ' + converttostr(current_date))

    refresh_dates = "\'" + converttostr(current_date) + "\'"
    yarn_app_name = "MINT_RELEASE_ORDER_INGESTION_TO_BQ"
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB, JAR_GCS_CON, JAR_GCS_CRED, JAR_SLACK, JAR_STTP]
    logging.info("Release Order Ingestion Process to BigQuery  started")
    push_notification(context, "process_type", "spark_ro_bigquery_ingestion")
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    jar_args = [
        "job_name==EtlJobRO",
        "job_input_path==" + RO_JOB_INPUT_POSTGRE_TABLE_NAME,
        "job_output_path==" + RO_OUTPUT_PATH,
        "job_output_path_gcs==" + RO_OUTPUT_PATH_GCS,
        "refresh_dates==" + refresh_dates,
        "ro_output_dataset==" + RO_OUTPUT_DATASET_NAME,
        "ro_output_table_name==" + RO_OUTPUT_TABLE_NAME,
        "test==false", "debug==false", "aggregate_error==false"
    ]

    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                               jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify", refresh_dates)
    except:
        push_notification(context, "notify", "Release Order Ingestion to BigQuery  Process Failed for dates - " + refresh_dates)
        raise AirflowException('{} Release Order Ingestion to BQ  Process Failed'.format("daily"))


mint_ro_to_bq = PythonOperator(
    task_id='SPARK_mint_ro_to_bq',
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    python_callable=ro_postgre_to_bq,
    params={'file_mode': 'w'},
    dag=dag
)


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
            "dag_id": DAG_ID,
            "dag_object": dag,
            "task_name": "release order to big-query daily ingestion",
            "event": "GCP RO Ingestion - "+"DAILY"+" - "+MERIDIAN,
            "ingestion": 'RELEASE ORDER'
            },
    dag=dag
)

mint_ro_to_bq >> notification_task

