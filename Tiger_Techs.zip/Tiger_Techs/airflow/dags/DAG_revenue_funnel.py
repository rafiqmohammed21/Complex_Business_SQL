from datetime import datetime

from utils.data_ingestion import push_notification, date_formats
from utils.livy_api import LivyApi
from airflow import DAG, AirflowException
from airflow.operators.python_operator import PythonOperator
from utils.global_variables import *
from utils.send_notification import dag_failure_callback, dag_success_callback, dag_send_notification, remove_temp_file
import logging

from utils.spot_ratings import get_current_month_week_year

DAG_ID = 'GCP_funnel_ingestion'

default_args = {
    'owner': 'Swapnil',
    'depends_on_past': False,
    'start_date': datetime(2019, 9, 26),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None)


def converttostr(input_seq):
    seperator="\',\'"
    final_str = seperator.join(input_seq)
    return final_str

def revenue_funnel_ingestion_to_bq(**context):
    if context['dag_run'].conf:
        current_date = context['dag_run'].conf["month"]
        logging.info('Running through scheduled trigger => year: ' + converttostr(current_date))

    yarn_app_name = "MINT_REVENUE_FUNNEL_INGESTION_TO_BQ"
    refresh_dates = "\'" + converttostr(current_date) + "\'"
    app_dep_jars = [JAR_POSTGRE, JAR_BQ, JAR_SPARKLIB,JAR_GCS_CON,JAR_GCS_CRED,JAR_SLACK,JAR_STTP]
    logging.info(" Revenue Funnel Ingestion Process to BigQuery  started for year_month : " + refresh_dates)
    push_notification(context, "process_type", "spark revenue funnel")
    app_prop_files = [FILE_LOADDATA, FILE_GCS_CRED]
    jar_args = [
        "job_name==EtlJobFunnel",
        "job_input_path==" + FUNNEL_JOB_INPUT_POSTGRE_TABLE_NAME,
        "job_output_path==" + FUNNEL_OUTPUT_PATH,
        "job_output_path_gcs==" + FUNNEL_OUTPUT_PATH_GCS,
        "refresh_dates==" + refresh_dates,
        "funnel_output_dataset==" + FUNNEL_OUTPUT_DATASET_NAME,
        "funnel_output_table_name==" + FUNNEL_OUTPUT_TABLE_NAME,
        "test==false", "debug==false", "aggregate_error==false"
        ]
    try:
        LivyApi.run_livy_batch(EMR_HOST, JAR_SPARKLIB, MAIN_CLASS, yarn_app_name, DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY,
                       jar_args, app_dep_jars, app_prop_files, DD_MAX_EXECUTORS, None)
        push_notification(context, "notify", refresh_dates)
    except:
        push_notification(context, "notify", "Revenue Funnel Ingestion to BigQuery  Process Failed - " + refresh_dates)
        raise AirflowException('{} Revenue Funnel Ingestion to BQ  Process Failed'.format("daily"))


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
            "dag_id": DAG_ID,
            "dag_object": dag,
            "task_name": "Revenue Funnel to big-query daily ingestion",
            "event": "GCP Revenue Funnel Ingestion - "+"DAILY"+" - "+MERIDIAN,
            "ingestion": 'Funnel'
            },
    dag=dag
)


mint_revenue_funnel_ingestion = PythonOperator(
    task_id='SPARK_mint_revenue_funnel_ingestion',
    provide_context=True,
    python_callable=revenue_funnel_ingestion_to_bq,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag
)

mint_revenue_funnel_ingestion >> notification_task
