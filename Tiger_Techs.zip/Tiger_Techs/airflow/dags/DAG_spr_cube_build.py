import logging
from datetime import timedelta, datetime

from airflow import AirflowException
from airflow import DAG
from airflow.contrib.operators.ssh_operator import SSHOperator
from airflow.operators.python_operator import PythonOperator

from utils.data_ingestion import push_notification
from utils.global_variables import *
from utils.kylin_cube import spr_cube_segement_calculation, getSegementsBuilt, cube_segments_refresh
from utils.livy_api import LivyApi
from utils.logging import print_log
from utils.send_notification import dag_send_notification, remove_temp_file, dag_success_callback, dag_failure_callback, \
    operator_success_callback, operator_failure_callback

DAG_ID = 'cubes_spr'

default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date': datetime(2019, 11, 13),
    'email': 'z6f6k5x3f5o3y8e4@startv.slack.com',
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=None, catchup=False)


kylin_task_details = lambda: [{'task_id': 'KYLIN_regional_spr_daily_channel_level_cube', 'cubeName': 'spr_daily', 'businessType': BUSINESS_TYPE_REGIONAL},
                              {'task_id': 'KYLIN_regional_spr_daily_deal_level_cube', 'cubeName': 'posteval_spr', 'businessType': BUSINESS_TYPE_REGIONAL},
                              {'task_id': 'KYLIN_entertainment_spr_daily_channel_level_cube', 'cubeName': 'spr_daily', 'businessType': BUSINESS_TYPE_ENTERTAINMENT},
                              {'task_id': 'KYLIN_entertainment_spr_daily_deal_level_cube', 'cubeName': 'posteval_spr', 'businessType': BUSINESS_TYPE_ENTERTAINMENT}]
kylin_task_list = []
kylin_msck_command = lambda: ' sh {} '.format(SPR_REPAIR_TABLE_PATH)


def spr_cube_build_func(**kwargs):
    cubeName = kwargs['params']['cubeName']
    businessType = kwargs['params']['business_type']
    push_notification(kwargs, "process_type", "kylin_" + businessType + "_" + cubeName)
    try:
        if SPR_RUN_TYPE.lower() == "historical" and SPR_CUBE_REFRESH.lower() == "yes":
            till_date = datetime.now()
            from_date = (till_date + timedelta(days=-(26*7))).strftime("%Y-%m-%d")
            cube_segments_refresh(cubeName, businessType, from_date, till_date.strftime("%Y-%m-%d"))
        elif SPR_RUN_TYPE.lower() == "daily":
            spr_cube_segement_calculation(cubeName, businessType, SPR_RUN_DATE)
        date_list = getSegementsBuilt()
        notify_message = ' , '.join(date_list)
        push_notification(kwargs, "notify", notify_message)
    except:
        date_list = getSegementsBuilt()
        notify_message = ' , '.join(date_list)
        push_notification(kwargs, "notify", notify_message)
        raise AirflowException("Cube building Failed")
    return


def aws_sync_postgre(**context):
    print_log(DAG_ID, RUN_ENV, EMR_HOST, "CUBE BUILD", "None")
    push_notification(context, "process_type", "spark_aws_master_table_sync")
    push_notification(context, "notify", "copy postgre master tables to s3")
    yarn_app_name = 'DI_' + "KYLIN"
    jar_args = ["KYLIN"]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None, DI_NUM_EXECUTORS)
    except:
        raise AirflowException('aws sync operation failed')
    return


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    op_kwargs={'file_mode': 'r'},
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "spr daily cube build",
        "event": "SPR Cube Build - "+SPR_RUN_TYPE.upper()+" - "+MERIDIAN
    },
    trigger_rule='all_done',
    dag=dag
)

for task in kylin_task_details():
    logging.info(task['task_id']+":"+task['cubeName']+":"+task['businessType'])
    kylin_task_list.append(PythonOperator(
        task_id=task['task_id'],
        python_callable=spr_cube_build_func,
        provide_context=True,
        params={'cubeName': task['cubeName'], 'business_type': task['businessType'], 'file_mode': 'a'},
        on_success_callback=dag_success_callback,
        on_failure_callback=dag_failure_callback,
        dag=dag)
    )

msck_task = SSHOperator(
    ssh_conn_id='msck_ssh',
    task_id='KYLIN_ssh_msck_to_orc_table',
    command=kylin_msck_command(),
    on_success_callback=operator_success_callback,
    on_failure_callback=operator_failure_callback,
    params={
        "process_type": "hive_add_partition",
        "notify": "add hive partitions",
        "file_mode": "a"
    },
    dag=dag)


sync_task = PythonOperator(
    task_id='SPARK_postgre_to_s3_mint_master_tables',
    python_callable=aws_sync_postgre,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'w'},
    dag=dag)


sync_task          >> msck_task
msck_task          >> kylin_task_list
kylin_task_list    >> notification_task



