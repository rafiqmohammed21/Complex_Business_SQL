import json
from datetime import datetime

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2019, 3, 17),
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG('INIT_create_variables', default_args=default_args, schedule_interval='@once')


def create_variables():

    #DD Variables
    dd_variables_json = {
            "data_download_class": "Download",
            "data_download_driver_memory": "1g",
            "data_download_executor_memory": "2g",
            "data_download_max_executors": 3
    }
    dd_variables_str = json.dumps(dd_variables_json)
    Variable.set("dd_variables", dd_variables_str)

    #DI Variables
    di_variables_json = {
        "data_pre_ingestion_class":"PreIngestion",
        "data_ingestion_class": "Ingestion",
        "data_ingestion_driver_memory": "4g",
        "data_ingestion_executor_memory": "8g",
        "data_ingestion_num_executors": 4,
        "data_ingestion_max_executors": 6
    }

    di_variables_str = json.dumps(di_variables_json)
    Variable.set("di_variables", di_variables_str)

    #Adhoc Variables
    Variable.set("barc_run_type", "weekly")
    Variable.set("barc_run_year", "2019")
    Variable.set("barc_run_week", "01")
    Variable.set("barc_1min_run_type", "weekly")
    Variable.set("barc_1min_run_year", "2019")
    Variable.set("barc_1min_run_week", "01")
    Variable.set("spr_run_type", "daily")
    Variable.set("spr_run_date", "2019-01-01")
    Variable.set("spr_cube_refresh", "no")

t3 = PythonOperator(task_id='create_variables', python_callable=create_variables, dag=dag)
