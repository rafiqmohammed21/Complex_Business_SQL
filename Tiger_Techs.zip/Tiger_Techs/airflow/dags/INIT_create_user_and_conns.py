from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow import settings
from airflow.models import Connection, User
from datetime import datetime, timedelta
from airflow.contrib.auth.backends.password_auth import PasswordUser

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2019, 3, 17),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 10,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG('INIT_create_user_and_conns', default_args=default_args, schedule_interval='@once')


def create_connection():
    session = settings.Session()
    conn1 = Connection(
        conn_id='emr_ssh',
        conn_type='ssh',
        host='172.22.69.239',
        login='hadoop',
        extra='{"key_file": "/usr/local/airflow/Prod-Mint-Cluster.pem","allow_host_key_change":"true"}'
    )
    conn2 = Connection(
        conn_id='slack',
        conn_type='http',
        host='https://hooks.slack.com/services'
    )
    conn2.set_password('/T454TCPBL/BHA12LF7E/HCkX8CKv20cQrgZt7vL7Mkve')
    conn3 = Connection(
        conn_id='msck_ssh',
        conn_type='ssh',
        host='10.0.0.120',
        login='ec2-user',
        extra='{"key_file": "/usr/local/airflow/pem/hdptiger.pem","allow_host_key_change":"true"}'
    )
    session.add(conn1)
    session.commit()
    session.add(conn2)
    session.commit()
    session.add(conn3)
    session.commit()
    session.close()


def create_user():
    session = settings.Session()
    user = PasswordUser(User())
    user.username = 'mint_admin'
    user.email = 'mint_admin@mint_admin.com'
    user.password = 'MinTUser'
    user.superuser = True
    session.add(user)
    session.commit()
    session.close()


t1 = PythonOperator(task_id='create_connection', python_callable=create_connection, dag=dag)
t2 = PythonOperator(task_id='create_user', python_callable=create_user, dag=dag)
