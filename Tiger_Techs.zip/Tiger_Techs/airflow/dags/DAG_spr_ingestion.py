import logging
from datetime import datetime

from airflow import AirflowException
from airflow import DAG
from airflow.operators import TriggerDagRunOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.sensors import S3KeySensor
from airflow.utils.email import send_email

from utils.data_ingestion import dag_run_schedule_interval, push_notification, date_formats, call_back, \
    read_html_content
from utils.global_variables import *
from utils.livy_api import LivyApi
from utils.logging import print_log
from utils.send_notification import operator_failure_callback, dag_success_callback, dag_failure_callback, \
    remove_temp_file, dag_send_notification

DAG_ID = 'ingestion_spr'

default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date':  datetime(2019, 11, 13),
    'email': 'z6f6k5x3f5o3y8e4@startv.slack.com',
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, max_active_runs=1, schedule_interval=dag_run_schedule_interval('spr'), catchup=False)


getSPRLatestRunDetails = {
    "pre_ingestion_onair_path": lambda : "s3://" + ONAIR_PRE_INGESTION_RAW_PATH  + '/' + 'date=' + SPR_RUN_DATE + '/' + 'SUCCESS.txt',
    "pre_ingestion_champ_path": lambda : "s3://" + CHAMP_PRE_INGESTION_RAW_PATH + '/' + 'date=' + SPR_RUN_DATE + '/' + CHAMP_PRE_INGESTION_FILE_NAME + '_' + datetime.strptime(SPR_RUN_DATE, "%Y-%m-%d").strftime("%Y%m%d")+'.txt'
}


def reports_generation(**context):
    push_notification(context, "process_type", "spark_spr_reports_generation")
    yarn_app_name = 'DI_' + "SPR_" + 'REPORTS_' + date_formats()['Ymd'] + '_' + MERIDIAN
    ingestion_type = context["params"]["ingestion"]
    jar_args = ["SPRREPORTS", SPR_RUN_DATE]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None, DI_NUM_EXECUTORS)
        push_notification(context, "notify", str(SPR_RUN_DATE.replace("-", "/")))
        call_back(DI_SPR_CALLBACK_URL, BUSINESS)
        call_back(DI_SPR_REPORTS_CALLBACK_URL, BUSINESS)
        push_notification(context, "whether_report_generation_success", True)
    except:
        push_notification(context, "notify", "reports generation task failed - date - "+str(SPR_RUN_DATE.replace("-", "/")))
        raise AirflowException('{} Reports Generation Process Failed'.format(ingestion_type))


def spr_ingestion(**context):
    ingestion_type = context["params"]["ingestion"]
    print_log(DAG_ID, RUN_ENV, EMR_HOST, "INGESTION", DI_SPR_CALLBACK_URL)
    push_notification(context, "process_type", "spark_{}_ingestion".format(ingestion_type.lower()))
    yarn_app_name = "DI_{}_{}_INGESTION_{}_{}".format(ingestion_type, SPR_RUN_TYPE, SPR_RUN_DATE, MERIDIAN)
    jar_args = [ingestion_type, SPR_RUN_DATE, SPR_RUN_TYPE]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None, DI_NUM_EXECUTORS)
        push_notification(context, "notify", str(SPR_RUN_DATE.replace("-", "/")))
    except:
        push_notification(context, "notify", "raw to orc conversion task failed - date - "+str(SPR_RUN_DATE.replace("-", "/")))
        raise AirflowException('{} Ingestion Process Failed'.format(ingestion_type))


def spr_pre_ingestion(**context):
    ingestion_type = context["params"]["ingestion"]
    print_log(DAG_ID,RUN_ENV,EMR_HOST,"PRE INGESTION",DI_SPR_CALLBACK_URL)
    logging.info("SPR Process started for the day : " + str(SPR_RUN_DATE))
    logging.info("processing pre-ingestion for : {}".format(ingestion_type))
    push_notification(context, "process_type", "spark_{}_pre_ingestion".format(ingestion_type.lower()))
    yarn_app_name = "DI_{}_{}_PREINGESTION_{}_{}".format(ingestion_type, SPR_RUN_TYPE, SPR_RUN_DATE, MERIDIAN)
    jar_args = [ingestion_type, SPR_RUN_DATE, SPR_RUN_TYPE]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_PRE_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None, DI_NUM_EXECUTORS)
        push_notification(context, "notify", str(SPR_RUN_DATE).replace("-", "/"))
        email_msg = read_html_content(PRE_INGESTION_LANDING_BUCKET,'html', SPR_RUN_DATE,ingestion_type.lower(), SPR_RUN_TYPE.lower())
        email_subject = RUN_ENV + '-' + ' {} '.format(ingestion_type) + 'data uploaded into data lake'
        send_email(to=SUCCESS_EMAIL_LIST, subject=email_subject, html_content=email_msg)
    except:
        push_notification(context, "notify", "pre ingestion process task failed - date "+str(SPR_RUN_DATE.replace("-", "/")))
        raise AirflowException('{} Pre-Ingestion Process Failed'.format(ingestion_type))


def check_run_type(**context):
    try:
        run_type = context['dag_run'].conf["run_type"]
        run_date = context['dag_run'].conf["run_date"]
        Variable.set("spr_run_type", run_type)
        Variable.set("spr_run_date", run_date)
        if run_type.lower() == "historical":
            cube_refresh = context['dag_run'].conf["cube_refresh"]
            Variable.set("spr_cube_refresh", cube_refresh)
            return 'historical_run'
        elif run_type.lower() == "daily":
            cube_refresh = "yes"
            Variable.set("spr_cube_refresh", cube_refresh)
            return 'daily_run'

    except:
        run_type = "daily"
        cube_refresh = "yes"
        Variable.set("spr_run_type", run_type)
        Variable.set("spr_cube_refresh", cube_refresh)
        Variable.set("spr_run_date", datetime.now().strftime("%Y-%m-%d"))
        return 'daily_run'


cubes_trigger_task = TriggerDagRunOperator(
    task_id='cubes_trigger',
    trigger_dag_id="cubes_spr",
    trigger_rule="none_failed",
    dag=dag,
    provide_context=True
)

spr_gcp_ingestion_trigger_task = TriggerDagRunOperator(
    task_id='spr_gcp_ingestion_trigger',
    trigger_dag_id="GCP_spr_ingestion",
    trigger_rule="none_failed",
    dag=dag
)

notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    on_failure_callback=remove_temp_file,
    trigger_rule="all_done",
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "spr daily ingestion",
        "event": "SPR Ingestion - "+SPR_RUN_TYPE.upper()+" - "+MERIDIAN,
        "ingestion": 'SPR'
    },
    dag=dag
)

report_generation_task = PythonOperator(
    task_id='SPARK_report_generation',
    python_callable=reports_generation,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    params={'file_mode': 'a', 'ingestion': 'SPR'},
    dag=dag
)


onair_ingestion_task = PythonOperator(
    task_id='SPARK_onair_ingestion',
    python_callable=spr_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a','ingestion': 'ONAIR'},
    dag=dag
)

champ_ingestion_task = PythonOperator(
    task_id='SPARK_champ_ingestion',
    python_callable=spr_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a', 'ingestion': 'CHAMP'},
    dag=dag
)

onair_pre_ingestion_task = PythonOperator(
    task_id='SPARK_onair_pre_ingestion',
    python_callable=spr_pre_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a', 'ingestion':'ONAIR'},
    dag=dag
)

champ_pre_ingestion_task = PythonOperator(
    task_id='SPARK_champ_pre_ingestion',
    python_callable=spr_pre_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a', 'ingestion':'CHAMP'},
    dag=dag
)

onair_data_sensor = S3KeySensor(
    task_id='onair_data_sensor',
    poke_interval=60 * 30,
    timeout=60 * 60 * 2,
    bucket_key=getSPRLatestRunDetails['pre_ingestion_onair_path'](),
    bucket_name=None,
    wildcard_match=False,
    trigger_rule="none_failed",
    params={
        "process_type": "check_onair_success_file",
        "notify": "raw success file is not uploaded for date : {} ".format(SPR_RUN_DATE),
        "ingestion": 'SPR',
        "file_mode": "a"
    },
    on_failure_callback=operator_failure_callback,
    dag=dag
)

champ_data_sensor = S3KeySensor(
    task_id='champ_data_sensor',
    poke_interval=60 * 30,
    timeout=60 * 60 * 2,
    bucket_key=getSPRLatestRunDetails['pre_ingestion_champ_path'](),
    bucket_name=None,
    wildcard_match=False,
    trigger_rule="none_failed",
    params={
        "process_type": "check_champ_success_file",
        "notify": "raw success file is not uploaded for date : {} ".format(SPR_RUN_DATE),
        "ingestion": 'SPR',
        "file_mode": "a"
    },
    on_failure_callback=operator_failure_callback,
    dag=dag
)


onair_ingestion_historical_task = PythonOperator(
    task_id='SPARK_onair_ingestion_historical',
    python_callable=spr_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a','ingestion': 'ONAIR'},
    dag=dag
)


onair_pre_ingestion_historical_task = PythonOperator(
    task_id='SPARK_onair_pre_ingestion_historical',
    python_callable=spr_pre_ingestion,
    provide_context=True,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    trigger_rule="none_failed",
    params={'file_mode': 'a', 'ingestion':'ONAIR'},
    dag=dag
)

daily_task = DummyOperator(task_id='daily_run', dag=dag)
historical_task = DummyOperator(task_id='historical_run', dag=dag)

check_type_task = BranchPythonOperator(
    task_id='check_run_type',
    python_callable=check_run_type,
    provide_context=True,
    on_success_callback=remove_temp_file,
    dag=dag
)

check_type_task >> [daily_task, historical_task]
daily_task >> [champ_data_sensor, onair_data_sensor]
champ_data_sensor  >> champ_pre_ingestion_task
onair_data_sensor    >> onair_pre_ingestion_task
champ_pre_ingestion_task >> champ_ingestion_task
onair_pre_ingestion_task >> onair_ingestion_task
champ_ingestion_task >> report_generation_task
onair_ingestion_task >> report_generation_task
report_generation_task >> cubes_trigger_task

historical_task >> onair_pre_ingestion_historical_task >> onair_ingestion_historical_task >> cubes_trigger_task

cubes_trigger_task >> notification_task
notification_task >> spr_gcp_ingestion_trigger_task
