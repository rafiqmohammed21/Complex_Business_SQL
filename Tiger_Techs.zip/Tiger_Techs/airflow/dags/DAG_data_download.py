from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.contrib.operators.slack_webhook_operator import SlackWebhookOperator
from airflow import AirflowException
from datetime import datetime,timedelta
from airflow.utils.email import send_email
import requests
import logging
from utils.data_download import *
from utils.global_variables import *
from utils.livy_api import *
from utils.message_templates import *
from utils.pandas_api import *


DAG_ID = 'data_download'

logging.info('Memory before DAG-{} is started: {} MB'.format(DAG_ID,memory_footprint()))
logging.info('RUN_ENV: ' + RUN_ENV)
logging.info('EMR_HOST: ' + EMR_HOST)
logging.info('DAG_ID: ' + DAG_ID)
logging.info('MINT CALLBACK_URL: ' + DD_CALLBACK_URL)

default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date': datetime(2019, 8, 17),
    'retries': 2,
    'retry_delay': timedelta(minutes=2),
    'email': 'z6f6k5x3f5o3y8e4@startv.slack.com',
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, schedule_interval=None)


def dag_failure(context, event='Data Download'):
    business = context['dag_run'].conf["business"]
    token = context['dag_run'].conf["token"]
    module = context['dag_run'].conf["type_of"]
    execution_date = context.get('execution_date')
    task_log_url = context.get('task_instance').log_url
    path = path_finder(RUN_ENV, module, token, business)
    csv_path = 'https://s3.console.aws.amazon.com/s3/buckets/' + TRANSFORMED_BUCKET + '/' + path + '/'

    # Send An Email
    send_mail(module, token, business, execution_date, task_log_url, event, "Failure", csv_path,"Not Applicable")

    # Send Slack Notification
    slack_msg = MessageTemplate.slack_failure_message(event, module, token, business, execution_date, task_log_url,RUN_ENV)
    slack_msg = slack_msg.replace("localhost", ELB_NAME)
    failed_alert = SlackWebhookOperator(
        task_id='slack_webhook',
        http_conn_id='slack',
        webhook_token=SLACK_WEBHOOK_TOKEN,
        message=slack_msg,
        username='Mint-DataLake-WebHook',
        dag=dag)
    return failed_alert.execute(context=context)


def dag_success(context):
    business = context['dag_run'].conf["business"]
    token = context['dag_run'].conf["token"]
    module = context['dag_run'].conf["type_of"]
    execution_date = context.get('execution_date')
    task_log_url = context.get('task_instance').log_url
    cb_url = url_finder(DD_CALLBACK_URL, module, token, business)
    path = path_finder(RUN_ENV, module, token, business)
    csv_path = 'https://s3.console.aws.amazon.com/s3/buckets/' + TRANSFORMED_BUCKET + '/' + path + '/'

    logging.info('S3 DOWNLOAD LOCATION: ' + csv_path)
    logging.info('MINT CALLBACK_URL: ' + cb_url)

    headers = {'x-user-auth-token': 'g7uGXPQ_ZraGG2f2B8sgHWarTNW_axjvh-krn3QgsPjz_azqWg', "Content-Type": "application/json"}
    response = requests.get(cb_url, headers=headers, verify=False)

    ExcelExecTime = context['ti'].xcom_pull(task_ids='convert_csv_to_excel')

    if response.status_code in [204, 200]:
        logging.info("MINTAPI Callback Response code: " + str(response))
        send_mail(module, token, business, execution_date, task_log_url, 'Data Download', "Success", csv_path, ExcelExecTime)
    else:
        logging.info("MINTAPI Callback Response code: " + str(response.status_code))
        dag_failure(context, 'Callback Failed')
        raise AirflowException('Rest api call back is not success')


def send_mail(module, token, business, execution_date, task_log_url, event, status, csv_path,excel_exec_time):
    email_msg = MessageTemplate.email_message(DAG_ID, module, token, business, execution_date, task_log_url, event, status, csv_path, excel_exec_time)
    email_msg = email_msg.replace("localhost", ELB_NAME)
    email_subject = RUN_ENV + ' - DAG: ' + DAG_ID + ' - {}'.format(status)
    if status.upper() == 'SUCCESS':
        send_email(to=SUCCESS_EMAIL_LIST, subject=email_subject, html_content=email_msg)
    elif status.upper() == 'FAILURE':
        send_email(to=FAILURE_EMAIL_LIST, subject=email_subject, html_content=email_msg)


def run_spark_job(**context):
    business = context['dag_run'].conf["business"]
    token = context['dag_run'].conf["token"]
    module = context['dag_run'].conf["type_of"]
    yarn_app_name = 'DD_' + business + '_' + token + '_' + module
    jar_args = [business, token, module]

    logging.info('TASK CONTEXT: ' + str(context))
    logging.info('BUSINESS: ' + business)
    logging.info('MODULE: ' + module)
    logging.info('TOKEN: ' + token)

    LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DD_CLASS_NAME, yarn_app_name
                           , DD_DRIVER_MEMORY, DD_EXECUTOR_MEMORY, jar_args, APP_DEPS
                           , APP_FILES, DD_MAX_EXECUTORS, None)


download_task = PythonOperator(
    task_id='run_spark_job_livy',
    python_callable=run_spark_job,
    provide_context=True,
    on_failure_callback=dag_failure,
    on_success_callback=dag_success,
    dag=dag,
)

download_task
