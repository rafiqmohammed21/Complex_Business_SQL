import logging
import os
from datetime import datetime

from airflow import AirflowException
from airflow import DAG
from airflow.operators import TriggerDagRunOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator, BranchPythonOperator
from airflow.operators.sensors import S3KeySensor
from airflow.utils.trigger_rule import TriggerRule

from utils.data_ingestion import dag_run_schedule_interval, get_year_week_date, push_notification, date_formats, \
    call_back
from utils.global_variables import *
from utils.livy_api import LivyApi
from utils.logging import print_log
from utils.send_notification import operator_failure_callback, dag_success_callback, dag_failure_callback, \
    remove_temp_file, dag_send_notification

DAG_ID = 'ingestion_barc'

default_args = {
    'owner': 'mint',
    'depends_on_past': False,
    'start_date':  datetime(2019, 11, 13),
    'email': ['z6f6k5x3f5o3y8e4@startv.slack.com'],
    'email_on_failure': False,
    'email_on_retry': False
}

dag = DAG(DAG_ID, default_args=default_args, concurrency=2, schedule_interval=dag_run_schedule_interval('barc'), catchup = False)
rawsuccessCheckPath = lambda: "s3://"+BARC_RAW_PATH+'/year={}/week={}/SUCCESS.txt'
qcsuccessCheckPath = lambda: "s3://"+BARC_QC_PATH+'/year={}/week={}/SUCCESS.txt'


def check_run_type(**context):
    try:
        run_type = context['dag_run'].conf["run_type"]
        if run_type.lower() == "historical":
            Variable.set("barc_run_type", run_type)
            return 'historical_run'
        elif run_type.lower() == "weekly":
            run_year = context['dag_run'].conf["run_year"]
            run_week = context['dag_run'].conf["run_week"]
            Variable.set("barc_run_type", run_type)
            Variable.set("barc_run_year", run_year)
            Variable.set("barc_run_week", run_week)
            return 'weekly_run'
    except:
        run_type = "weekly"
        Variable.set("barc_run_type", run_type)
        Variable.set("barc_run_year", get_year_week_date(BARC_ORC_PATH)[0])
        Variable.set("barc_run_week", get_year_week_date(BARC_ORC_PATH)[1]+1)
        return 'weekly_run'


def barc_ingestion(**context):
    print_log(DAG_ID, RUN_ENV, EMR_HOST, "INGESTION", DI_BARC_CALLBACK_URL)
    logging.info("Existing BARC YEAR,WEEK: " + str(BARC_RUN_YEAR)+","+str(BARC_RUN_WEEK))
    logging.info("Processing BARC data for : " + str(BARC_RUN_WEEK))
    logging.info("Success path: " + rawsuccessCheckPath().format(BARC_RUN_YEAR, BARC_RUN_WEEK))
    push_notification(context, "process_type", "spark_barc_ingestion")
    yarn_app_name = 'DI_' + "Barc" + BARC_RUN_TYPE + " - " + date_formats()['Y-m-d']
    jar_args = ["BARC", BARC_RUN_YEAR, BARC_RUN_WEEK, BARC_RUN_TYPE]
    try:
        LivyApi.run_livy_batch(EMR_HOST, APP_JAR, DI_CLASS_NAME, yarn_app_name
                               , DI_DRIVER_MEMORY, DI_EXECUTOR_MEMORY, jar_args, APP_DEPS
                               , APP_FILES, DI_MAX_EXECUTORS, None, DI_NUM_EXECUTORS)
        push_notification(context, "notify", "week "+str(BARC_RUN_WEEK)+" "+str(BARC_RUN_YEAR))
        push_notification(context, "whether_barcjob_success", True)
        call_back(DI_BARC_CALLBACK_URL,BUSINESS)
    except:
        push_notification(context, "notify", "raw to orc conversion task failed week "+str(BARC_RUN_WEEK)+" "+str(BARC_RUN_YEAR))
        raise AirflowException('BARC Ingestion Process Failed')


def posteval_ingestion_trigger(context, dag_run_obj):
    dag_run_obj.payload = {'run_type': BARC_RUN_TYPE, 'run_week': BARC_RUN_WEEK, 'run_year': BARC_RUN_YEAR}
    return dag_run_obj


def aws_sources_sync(**context):
    push_notification(context, "process_type", "s3_aws_source_tables_sync")
    push_notification(context, "notify", "copy "+BARC_RUN_TYPE.lower() + " data to raw folder")
    os.system("aws s3 sync " + BARC_HISTORICAL_SRC_RAW_PATH + " " + BARC_RAW_PATH + '/')
    os.system("aws s3 sync " + BARC_HISTORICAL_SRC_QC_PATH + " " + BARC_QC_PATH + '/')


check_type_task = BranchPythonOperator(
    task_id='check_run_type',
    python_callable=check_run_type,
    provide_context=True,
    on_success_callback=remove_temp_file,
    dag=dag
)

weekly_task = DummyOperator(task_id='weekly_run', dag=dag)
historical_task = DummyOperator(task_id='historical_run', dag=dag)

raw_success_file_check = S3KeySensor(
    task_id='raw_success_file_check',
    poke_interval=60 * 30,
    timeout=60 * 60 * 8,
    bucket_key=rawsuccessCheckPath().format(BARC_RUN_YEAR, BARC_RUN_WEEK),
    bucket_name=None,
    wildcard_match=False,
    on_failure_callback=operator_failure_callback,
    params={
        "process_type": "check_success_file",
        "notify": "raw success file is not uploaded for year-{} week-{} !!".format(BARC_RUN_YEAR, BARC_RUN_WEEK),
        "file_mode": "w"
    },
    dag=dag
)

qc_success_file_check = S3KeySensor(
    task_id='qc_success_file_check',
    poke_interval=60 * 30,
    timeout=60 * 60 * 8,
    bucket_key=qcsuccessCheckPath().format(BARC_RUN_YEAR, BARC_RUN_WEEK),
    bucket_name=None,
    wildcard_match=False,
    on_failure_callback=operator_failure_callback,
    params={
        "process_type": "check_success_file",
        "notify": "qc success file is not uploaded for year-{} week-{} !!".format(BARC_RUN_YEAR, BARC_RUN_WEEK),
        "file_mode": "w"
    },
    dag=dag
)

sync_sources_task = PythonOperator(
    task_id='S3_sources_sync',
    python_callable=aws_sources_sync,
    provide_context=True,
    params={"file_mode": "w"},
    trigger_rule=TriggerRule.NONE_FAILED,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    dag=dag
)

ingestion_task = PythonOperator(
    task_id='SPARK_barc_ingestion',
    python_callable=barc_ingestion,
    provide_context=True,
    params={"file_mode": "a"},
    trigger_rule=TriggerRule.NONE_FAILED,
    on_success_callback=dag_success_callback,
    on_failure_callback=dag_failure_callback,
    dag=dag
)


notification_task = PythonOperator(
    task_id='Send_Notification',
    provide_context=True,
    python_callable=dag_send_notification,
    params={
        "dag_id": DAG_ID,
        "dag_object": dag,
        "task_name": "barc ingestion",
        "event": "BARC Ingestion - "+BARC_RUN_TYPE.upper()
    },
    trigger_rule=TriggerRule.ALL_DONE,
    on_failure_callback=remove_temp_file,
    dag=dag
)


cubes_trigger_task = TriggerDagRunOperator(
    task_id='cubes_trigger',
    trigger_dag_id="cubes_barc",
    provide_context=True,
    trigger_rule=TriggerRule.NONE_FAILED,
    dag=dag
)

check_type_task >> [weekly_task, historical_task]
weekly_task >> [raw_success_file_check, qc_success_file_check] >> ingestion_task
historical_task >> sync_sources_task
sync_sources_task >> ingestion_task
ingestion_task >> cubes_trigger_task
cubes_trigger_task >> notification_task

if BARC_RUN_TYPE.lower() == "weekly":
    barc_1min_weekly_trigger = TriggerDagRunOperator(
        task_id='barc_1min_trigger',
        trigger_dag_id="ingestion_barc_1min",
        provide_context=True,
        python_callable=posteval_ingestion_trigger,
        trigger_rule=TriggerRule.NONE_FAILED,
        dag=dag
    )

    ingestion_task >> barc_1min_weekly_trigger
