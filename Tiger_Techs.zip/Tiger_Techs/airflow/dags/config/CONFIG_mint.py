DRUID_CONFIG = {
    'DRUID_HOST': 'http://druid-master-svc:8090/druid/indexer/v1/task'
}

common_variables = {
    "environment": "PRODUCTION",
    "aws_elb_name": "prod-mint-566680849.ap-south-1.elb.amazonaws.com",
    "emr_master": "http://172.22.69.207:8998",
    "success_mail_list": "['nitin.tharwani@startv.com', 'gopi.kannedhara.vc@startv.com', "
                         "'ramya.venkatesh.vc@startv.com' , 'danveer.sharma@startv.com', "
                         "'swapnil.sonawane@startv.com' ]",
    "failure_mail_list": "['nitin.tharwani@startv.com','gopi.kannedhara.vc@startv.com',"
                         "'ramya.venkatesh.vc@startv.com', 'girish.parashar@startv.com', "
                         "'ramanathan.r.vc@startv.com', 'danveer.sharma@startv.com', "
                         "'swapnil.sonawane@startv.com', 'support-mint@startv.com' ]",
    "application_jar": "s3://star-dl-eks/emr/jars/prod/mint-master_2.11-0.1.jar",
    "application_properties_file": "['s3://star-dl-eks/emr/jars/prod/mint.properties']",
    "application_package_deps": "com.crealytics:spark-excel_2.11:0.11.1",
    "application_jar_dependency":
        "['s3://star-dl-eks/emr/jars/lib/org.postgresql_postgresql-42.1.4.jar',"
        "'s3://star-dl-eks/emr/jars/lib/hive-contrib.jar']",
    "landing_bucket": "star-dl-barc-ad",
    "transformed_bucket": "star-dl-barc-ad",
    "spr_bucket": "star-dl-spr",
    "business": "['entertainment','regional']"
}

data_download_variables = {
    "data_download_cb_url": "https://mintapi.startv.com/api/v1/files"
}

data_ingestion_variables = {
    "data_ingestion_cb_url_barc": "https://mintapi.startv.com/api/v1/files/import_barc_data?",
    "data_ingestion_cb_url_spr": "https://mintapi.startv.com/api/v1/files/import_spr_data?type=spr&",
    "data_ingestion_cb_url_spr_reports": "https://mintapi.startv.com/api/v1/files/import_spr_data?type=modified_spr&",
    "barc_pricing_raw_path": common_variables["landing_bucket"]+ '/' + 'landingzone' + '/' + 'pricing'"",
    "barc_pricing_qc_path": common_variables["landing_bucket"]+ '/' + 'landingzone' + '/' + 'pricing_qc'"",
    "barc_pricing_orc_path": common_variables["transformed_bucket"] + '/' + 'transformed' + '/' + 'pricing_orc'"",
    "onair_spr_raw_path": common_variables["landing_bucket"] + '/' + 'staging' + '/' + 'onair'"",
    "onair_spr_orc_path": common_variables["spr_bucket"] + '/' + 'transformed' + '/' + 'onair'"",
    "post_eval_raw_path": common_variables["landing_bucket"] + '/' + 'landingzone' + '/' + 'posteval' + '/' + 'raw_files'"",
    "post_eval_qc_path": common_variables["landing_bucket"] + '/' + 'landingzone' + '/' + 'posteval' + '/' + 'qc_files'"",
    "post_eval_orc_path": common_variables["transformed_bucket"] + '/' + 'transformed' + '/' + 'post_eval_onair_spr_grp_orc'"",
    "pre_ingestion_onair_raw_path": common_variables["spr_bucket"] + '/raw/onair/daily',
    "pre_ingestion_champ_raw_path": common_variables["spr_bucket"] + '/raw/champ/daily',
    "barc_pricing_raw_historical_path": "s3://star-dl-barc-ad/landingzone/pricing_newtg/RAW/",
    "barc_pricing_qc_historical_path": "s3://star-dl-barc-ad/landingzone/pricing_newtg/QC/",
    "post_eval_raw_historical_path": "s3://star-dl-barc-ad/landingzone/posteval_newtg/raw_files",
    "post_eval_qc_historical_path": "s3://star-dl-barc-ad/landingzone/posteval_newtg/qc_files"
}

kylin_variables = {
    "kylin_url": "https://10.0.0.120:7443/kylin/api",
    "kylin_project_name": "MINT_PROD",
    "Authorization": "Basic QURNSU46S1lMSU4=",
    "Content-Type": "application/json",
    "regional_barc_daily": "prod_regional_barc_daily",
    "regional_posteval_barc": "prod_regional_posteval_barc",
    "regional_spr_daily": "prod_regional_spr_daily",
    "regional_posteval_spr": "prod_regional_posteval_spr",
    "entertainment_barc_daily": "prod_entertainment_barc_daily",
    "entertainment_posteval_barc": "prod_entertainment_posteval_barc",
    "entertainment_spr_daily": "prod_entertainment_spr_daily",
    "entertainment_posteval_spr": "prod_entertainment_posteval_spr",
    "barc_repair_table_path":  "/home/ec2-user/jobs/mint/production/ingestion/barc/scripts/msck_table.sh",
    "spr_repair_table_path": "/home/ec2-user/jobs/mint/production/ingestion/spr/scripts/msck_table.sh"
}

file_names = {
    "pre_ingestion_champ" : "ChampData",
    "pre_ingestion_onair" : "ONAIR_SPR"
}

master_data_var = {
   "jar_postgre": 's3://star-dl-eks/emr/jars/lib/gcp/org.postgresql_postgresql-42.1.4.jar',
   "jar_bq": 's3://star-dl-eks/emr/jars/lib/gcp/bigquerylib.jar',
   "jar_sparklib": 's3://star-dl-eks/emr/jars/prod/sparklib.jar',
   "jar_gcs_con":'s3://star-dl-eks/emr/jars/lib/gcp/gcs-connector-hadoop3-latest.jar',
   "jar_gcs_cred" :'s3://star-dl-eks/emr/jars/lib/gcp/google-auth-library-credentials-0.17.1.jar',
   "jar_slack" :'s3://star-dl-eks/emr/jars/lib/gcp/slack-webhook-1.2.1.jar',
   "file_loaddata": 's3://star-dl-eks/emr/jars/prod/loaddata.properties',
   "file_gcs_cred":'s3://star-dl-eks/emr/jars/prod/gcsCred.json',
   "main_class":'LoadData'
   }
distribution_packs_var = {
    "jar_sttp":'s3://star-dl-eks/emr/jars/lib/gcp/core_2.11-1.0.5.jar'
}

spr_ingestion_var = {
    "spr_job_output_path": 'gs://dl-revenue/spr',
    "spr_currency_input_data_path": 's3://star-dl-spr/transformed/master/currency_historical/year=*',
    "spr_onair_history_load_input_path": 's3://star-dl-spr/transformed/onair',
    "spr_champ_history_load_input_path": 's3://star-dl-spr/transformed/champ',
    "spr_output_dataset": 'revenue',
    "spr_output_table_name": 'spr',
    "currency_job_input_path": 's3://star-dl-spr/raw/onair/daily',
    "currency_job_output_path": 's3://star-dl-spr/transformed/master/currency_historical'
}

funnel_ingestion_var = {
    "funnel_input_postgre_table_name": 'postgre_table_funnel_info',
    "funnel_output_path": 's3://star-dl-dev/advt_chnl_master',
    "funnel_output_path_gcs": 'gs://dl-revenue/funnel',
    "funnel_output_dataset": 'revenue',
    "funnel_output_table_name": 'funnel',
}


sale_unit_ingestion_var = {
    "sales_unit_postgre_table_name": 'postgre_table_sales_unit_product_info',
    "sales_unit_output_path": 's3://star-dl-dev/advt_chnl_master',
    "sales_unit_output_path_gcs": 'gs://dl-revenue/sales_unit',
    "sales_unit_output_dataset": 'revenue',
    "sales_unit_output_table_name": 'sales_unit',
}

ro_ingestion_var = {
    "ro_postgre_table_name": 'postgreTableRO',
    "ro_output_path": 's3://star-dl-dev/advt_chnl_master',
    "ro_output_path_gcs": 'gs://dl-revenue/ro',
    "ro_dataset": 'revenue',
    "ro_output_table_name": 'ro_data',
}
