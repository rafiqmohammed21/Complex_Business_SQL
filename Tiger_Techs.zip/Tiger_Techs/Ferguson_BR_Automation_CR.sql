
USE [ODS_Mode]
GO

DROP TABLE IF EXISTS [dbo].[Ferguson_vwFreightAudit_tmp]

/****** Object:  Table [dbo].[Ferguson_vwFreightAudit_tmp]    Script Date: 2/21/2020 11:31:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Ferguson_vwFreightAudit_tmp](
	[Account] [nvarchar](510) NULL,
	[Whse] [varchar](255) NULL,
	[WhseName] [nvarchar](510) NULL,
	[Assoc Whse] [varchar](255) NULL,
	[Carrier] [nvarchar](510) NULL,
	[Carrier Name] [nvarchar](510) NULL,
	[Supplier ID] [nvarchar](255) NULL,
	[Pro#] [varchar](255) NULL,
	[RptWeek] [datetime] NULL,
	[Ship Date] [varchar](255) NULL,
	[Lading] [varchar](255) NULL,
	[OrigCity] [varchar](255) NULL,
	[OrigSt] [varchar](255) NULL,
	[OrigZip] [varchar](255) NULL,
	[OrigCntry] [varchar](255) NULL,
	[DestCity] [varchar](255) NULL,
	[DestSt] [varchar](255) NULL,
	[DestZip] [varchar](255) NULL,
	[DestCntry] [varchar](255) NULL,
	[I/O/TP/B/C] [varchar](255) NULL,
	[GL#] [varchar](255) NOT NULL,
	[Shipper] [varchar](255) NULL,
	[ProcBy] [varchar](255) NULL,
	[class1] [float] NULL,
	[class2] [float] NULL,
	[class3] [float] NULL,
	[class4] [float] NULL,
	[class5] [float] NULL,
	[class6] [float] NULL,
	[class7] [float] NULL,
	[class8] [float] NULL,
	[class9] [float] NULL,
	[class10] [float] NULL,
	[class11] [float] NULL,
	[Weight1] [float] NULL,
	[Weight2] [float] NULL,
	[Weight3] [float] NULL,
	[Weight4] [float] NULL,
	[Weight5] [float] NULL,
	[Weight6] [float] NULL,
	[Weight7] [float] NULL,
	[Weight8] [float] NULL,
	[Weight9] [float] NULL,
	[Weight10] [float] NULL,
	[Weight11] [float] NULL,
	[P?] [varchar](50) NULL,
	[Amount] [decimal](19, 4) NULL,
	[Fee] [int] NULL,
	[TotalAmount] [decimal](19, 4) NULL,
	[Consign Name] [varchar](255) NULL,
	[InvoiceDate] [varchar](255) NULL,
	[Carrier Payment Approved Date] [date] NULL,
	[Carrier Payment Corrected Date] [date] NULL,
	[Orig_LocType] [nvarchar](1022) NULL,
	[Orig_LocNum] [varchar](255) NULL,
	[Dest_LocType] [nvarchar](1022) NULL,
	[Dest_LocNum] [varchar](255) NULL,
	[PaymentMethod] [varchar](255) NULL,
	[ShipperType] [varchar](255) NULL,
	[ConsigneeType] [varchar](255) NULL,
	[shipmentprimaryreference] [varchar](255) NULL,
	[loadprimaryreference] [varchar](255) NULL,
	[Billable Warehouse] [varchar](255) NULL,
	[Billable Warehouse Name] [nvarchar](510) NULL,
	[Billable Account] [nvarchar](510) NULL,
	[Movement Type] [varchar](255) NULL,
	[Pending GL] [varchar](255) NULL,
	[Source of Order] [varchar](255) NULL,
	[Ferguson Internal Customer #] [varchar](255) NULL,
	[FEI GL Coded] [varchar](255) NULL,
	[OrigAccount] [nvarchar](510) NULL,
	[OrigWhse] [varchar](255) NULL,
	[OrigWhseName] [nvarchar](510) NULL,
	[OrigMovementType] [varchar](255) NULL,
	[Mode] [nvarchar](255) NULL,
	[Shipment ID] [varchar](500) NULL,
	[Load ID] [varchar](255) NULL,
	[ExtractDate] [datetime] NULL,
	[Created_Timestamp] [datetime] NULL,
	[xmlid] [int] NULL
) ON [PRIMARY]
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Ferguson_vwFreightAudit_tmp')
BEGIN 
	Print 'Ferguson Temp table created successfully - Ferguson_vwFreightAudit_tmp'
END
GO

Use ODS_Mode
GO

BEGIN
---------------------------Avoid Duplicate insert adding ID Column to Primary Key Constraint ------------------------------------

DECLARE @SQL NVARCHAR(255)
DECLARE @Database varchar(30) = 'ODS_Mode';
DECLARE @Tablename Varchar(255) = 'Fact_Ferguson_BR_Ref_Upd';
DECLARE @Schema Varchar(5) = 'dbo';
DECLARE @Constraint_Type Varchar(100) = 'PRIMARY KEY'

WHILE EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_CATALOG = @Database

AND TABLE_NAME = @Tablename AND CONSTRAINT_SCHEMA = @Schema)	

BEGIN

SELECT @SQL = 'ALTER TABLE ' + @Tablename + ' DROP CONSTRAINT ' + CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
WHERE CONSTRAINT_CATALOG = @Database AND TABLE_NAME = @Tablename 
AND CONSTRAINT_SCHEMA = @Schema AND CONSTRAINT_TYPE =@Constraint_Type

EXEC sp_executesql @sql;

END

ALTER TABLE Fact_Ferguson_BR_Ref_Upd
ADD CONSTRAINT PK_BR_Ref_Upd PRIMARY KEY (ID, ShipmentPrimaryReference, LoadPrimaryreference, Date_Added);

END
GO 

IF NOT EXISTS (
		SELECT 1 from 
			INFORMATION_SCHEMA.TABLE_CONSTRAINTS Tab, 
			INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE Col 
		WHERE 
			Col.Constraint_Name = Tab.Constraint_Name
			AND Col.Table_Name = Tab.Table_Name
			AND Constraint_Type = 'PRIMARY KEY'
			AND Col.Table_Name = 'Fact_Ferguson_BR_Ref_Upd'
			AND col.COLUMN_NAME = 'ID')
	BEGIN
		PRINT 'Failure in script - rollback is completed'
		
		BEGIN
		---------------------------Remove ID Column from Primary Key Constraint ------------------------------------
		
		DECLARE @SQL NVARCHAR(255)
		DECLARE @Database varchar(30) = 'ODS_Mode';
		DECLARE @Tablename Varchar(255) = 'Fact_Ferguson_BR_Ref_Upd';
		DECLARE @Schema Varchar(5) = 'dbo';
		DECLARE @Constraint_Type Varchar(100) = 'PRIMARY KEY'

		WHILE EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_CATALOG = @Database

		AND TABLE_NAME = @Tablename AND CONSTRAINT_SCHEMA = @Schema)	

		BEGIN

		SELECT @SQL = 'ALTER TABLE ' + @Tablename + ' DROP CONSTRAINT ' + CONSTRAINT_NAME
		FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
		WHERE CONSTRAINT_CATALOG = @Database AND TABLE_NAME = @Tablename 
		AND CONSTRAINT_SCHEMA = @Schema AND CONSTRAINT_TYPE =@Constraint_Type

		EXEC sp_executesql @sql;

		END

		ALTER TABLE Fact_Ferguson_BR_Ref_Upd
		ADD CONSTRAINT PK_BR_Ref_Upd PRIMARY KEY (ShipmentPrimaryReference, LoadPrimaryreference, [Pro#], Date_Added);

		END

	END
ELSE 
	BEGIN
	PRINT 'Ferguson BR Automation - Primary Key Created Successfully'
	END
GO	


USE [ODS_Mode]
GO

/****** Object:  StoredProcedure [dbo].[SP_Ferguson_BR_Automation]    Script Date: 11/1/2019 1:16:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER  PROCEDURE [dbo].[SP_Ferguson_BR_Automation]
AS
BEGIN

-------------------------------Audit table insertion with variables------------------------------------------------------
DECLARE @Src_RwCnt INT;
DECLARE @Src_DelCnt INT;
DECLARE @Tgt_Inscnt INT;
DECLARE @Tgt_Delcnt INT;
DECLARE @Tgt_Updcnt INT;
DECLARE @LoadDate_Daily Date;
	
--------------------------------Two weeks of data loading into temp table based on created timestamp in view----------------------------------------------------
	
			TRUNCATE TABLE Ferguson_vwFreightAudit_tmp;
			INSERT INTO [dbo].Ferguson_vwFreightAudit_tmp(
				     [Account]
					,[Whse]
					,[WhseName]
					,[Assoc Whse]
					,[Carrier]
					,[Carrier Name]
					,[Supplier ID]
					,[Pro#]
					,[RptWeek]
					,[Ship Date]
					,[Lading]
					,[OrigCity]
					,[OrigSt]
					,[OrigZip]
					,[OrigCntry]
					,[DestCity]
					,[DestSt]
					,[DestZip]
					,[DestCntry]
					,[I/O/TP/B/C]
					,[GL#]
					,[Shipper]
					,[ProcBy]
					,[class1]
					,[class2]
					,[class3]
					,[class4]
					,[class5]
					,[class6]
					,[class7]
					,[class8]
					,[class9]
					,[class10]
					,[class11]
					,[Weight1]
					,[Weight2]
					,[Weight3]
					,[Weight4]
					,[Weight5]
					,[Weight6]
					,[Weight7]
					,[Weight8]
					,[Weight9]
					,[Weight10]
					,[Weight11]
					,[P?]
					,[Amount]
					,[Fee]
					,[TotalAmount]
					,[Consign Name]
					,[InvoiceDate]
					,[Carrier Payment Approved Date]
					,[Carrier Payment Corrected Date]
					,[Orig_LocType]
					,[Orig_LocNum]
					,[Dest_LocType]
					,[Dest_LocNum]
					,[PaymentMethod]
					,[ShipperType]
					,[ConsigneeType]
					,[shipmentprimaryreference]
					,[loadprimaryreference]
					,[Billable Warehouse]
					,[Billable Warehouse Name]
					,[Billable Account]
					,[Movement Type]
					,[Pending GL]
					,[Source of Order]
					,[Ferguson Internal Customer #]
					,[FEI GL Coded]
					,[OrigAccount]
					,[OrigWhse]
					,[OrigWhseName]
					,[OrigMovementType]
					,[Mode]
					,[Shipment ID]
					,[Load ID]
					,[ExtractDate]
					,[Created_Timestamp]
					,[xmlid])
			Select [Account]
				,[Whse]
				,[WhseName]
				,[Assoc Whse]
				,[Carrier]
				,[Carrier Name]
				,[Supplier ID]
				,[Pro#]
				,[RptWeek]
				,[Ship Date]
				,[Lading]
				,[OrigCity]
				,[OrigSt]
				,[OrigZip]
				,[OrigCntry]
				,[DestCity]
				,[DestSt]
				,[DestZip]
				,[DestCntry]
				,[I/O/TP/B/C]
				,[GL#]
				,[Shipper]
				,[ProcBy]
				,[class1]
				,[class2]
				,[class3]
				,[class4]
				,[class5]
				,[class6]
				,[class7]
				,[class8]
				,[class9]
				,[class10]
				,[class11]
				,[Weight1]
				,[Weight2]
				,[Weight3]
				,[Weight4]
				,[Weight5]
				,[Weight6]
				,[Weight7]
				,[Weight8]
				,[Weight9]
				,[Weight10]
				,[Weight11]
				,[P?]
				,[Amount]
				,[Fee]
				,[TotalAmount]
				,[Consign Name]
				,[InvoiceDate]
				,[Carrier Payment Approved Date]
				,[Carrier Payment Corrected Date]
				,[Orig_LocType]
				,[Orig_LocNum]
				,[Dest_LocType]
				,[Dest_LocNum]
				,[PaymentMethod]
				,[ShipperType]
				,[ConsigneeType]
				,[shipmentprimaryreference]
				,[loadprimaryreference]
				,[Billable Warehouse]
				,[Billable Warehouse Name]
				,[Billable Account]
				,[Movement Type]
				,[Pending GL]
				,[Source of Order]
				,[Ferguson Internal Customer #]
				,[FEI GL Coded]
				,[OrigAccount]
				,[OrigWhse]
				,[OrigWhseName]
				,[OrigMovementType]
				,[Mode]
				,[Shipment ID]
				,[Load ID]
				,[ExtractDate]
				,[Created_Timestamp]
				,[xmlid]
			from [dbo].[Ferguson_vwFreightAudit_3]
			WHERE  CAST(Created_Timestamp AS DATE) 
					Between Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) 
					and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101);

---------------------------------------------------Pro# with Null values email to User-------------------------------------------------------------------------------------------
BEGIN
DECLARE @RWCNT INT = 0;
----------------------change the profile available in production --------------------------------------------------------
DECLARE @PROFILE VARCHAR(MAX) = (Select top 1 Name from msdb..sysmail_profile Order by 1 Desc);
-------------------------email recipients --------------------------------------------------------------------------------
DECLARE @RECP VARCHAR(MAX) =  'Juliet.Tuapen@modetransportation.com;Maya.Petkova@modetransportation.com';

IF @RWCNT < (SELECT Count(1) AS cNT
from Ferguson_vwFreightAudit_tmp 
Where 
(shipmentprimaryreference Is Null OR loadprimaryreference IS Null OR [Pro#] IS Null)
AND    (
			CAST([Carrier Payment Approved Date] as date)  is not Null
			OR
			CAST([Carrier Payment Corrected Date] as date) is not Null
		  )
)
BEGIN
DECLARE @xml NVARCHAR(MAX)
DECLARE @query NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)

SET @xml = CAST(( SELECT ISNULL(shipmentprimaryreference,'NA') AS 'td','',ISNULL(loadprimaryreference,'NA') AS 'td','',
ISNULL([Pro#],'NA') AS 'td','',Created_Timestamp AS 'td','', ExtractDate AS 'td'
From Ferguson_vwFreightAudit_tmp 
Where 
(shipmentprimaryreference Is Null OR loadprimaryreference IS Null OR [Pro#] IS Null)
AND    (
			CAST([Carrier Payment Approved Date] as date)  is not Null
			OR
			CAST([Carrier Payment Corrected Date] as date) is not Null
		  )
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))



SET @body ='<html><body><H3>These loads are missing Pro#. Please fix and retransmit</H3>
<table border = 1> 
<tr>
<th> shipmentprimaryreference </th> <th> loadprimaryreference </th> <th> [Pro#] </th>
<th> Created_Timestamp </th><th> ExtractDate </th></tr>'    
 
SET @body = @body + @xml +'</table></body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = @PROFILE, 
@body = @body,
@body_format ='HTML',
@query = @query,
@recipients = @RECP,
@subject = 'BR Report – Missing Pro# on loads';
END
END


-------------------------------------BR Ref Update table condition for daily data load ---------------------------------------------------------
Select @LoadDate_Daily = Cast(CreatedDate As Date) From dbo.ODS_Control Where TableName = 'Fact_Ferguson_BR_ref_upd';

----------------------------------Current date data if already available removing from BR Ref Update------------------------------------------

Delete from Fact_Ferguson_BR_Ref_upd WHERE CAST([Created_Timestamp] AS DATE) = @LoadDate_Daily;

------------------------------------del count insertion in Audit table--------------------------------------------------------------------------
SET @Tgt_Delcnt = ROWCOUNT_BIG();

-------------------------------------------Fact_Ferguson_BR_Ref_upd table insert one day incremental based control table created date from temp table data--------------------------------------
	BEGIN TRY
	
	INSERT INTO Fact_Ferguson_BR_Ref_upd
	(								
	 XmlID
	,LoadPrimaryreference				
	,ShipmentPrimaryReference	
	,[Pro#]	
	,[Load ID]							
	,[Shipment ID]						
	,BillableWarehouse					
	,BillableWarehouseAccessorial		
	,MovementType						
	,TMS_BillableWarehouse				
	,TMS_BillableWarehouseAccessorial	
	,TMS_MovementType					
	,[Pending GL]							
	,Carrier							
	,ExtractDate						
	,Created_Timestamp					
	,Status								
	,Date_Added							
	,Date_Sent
	)							
	SELECT 
		   XmlID,
		   loadprimaryreference AS 'LoadPrimaryreference',
		   shipmentprimaryreference AS 'ShipmentPrimaryReference',
		   [Pro#] AS 'Pro#',
		   LTRIM(RTRIM(REPLACE([Load ID], '(T)', ''))) AS 'Load ID',
		   LTRIM(RTRIM(REPLACE([Shipment ID], '(T)', ''))) AS 'Shipment ID',
		   CASE
			   WHEN [Billable Warehouse] IS NULL THEN
				   [Whse]
			   ELSE
				   ''
		   END AS 'BillableWarehouse',
		   '' AS BillableWarehouseAccessorial,
		   CASE
			   WHEN [Movement Type] IS NULL THEN
				   [I/O/TP/B/C]
			   ELSE
				   ''
		   END AS 'MovementType',
		   [Billable Warehouse] AS TMS_BillableWarehouse,
		   '' AS TMS_BillableWarehouseAccessorial,
		   [Movement Type] AS TMS_MovementType,
		   [Pending GL],
		    Carrier,
		   [ExtractDate],
		   [Created_Timestamp],
		   'New' AS Status,
		   Getdate() AS Date_Added,
		   Null AS Date_Sent
			FROM [dbo].[Ferguson_vwFreightAudit_tmp]
			WHERE CAST([Created_Timestamp] AS DATE) >= @LoadDate_Daily 
				AND CAST([Created_Timestamp] AS DATE) < CAST(GETDATE() AS DATE)
				  AND 
					  [Mode] = N'LTL'
				  AND
				  (
						  ([Billable Warehouse] is null and [Whse] is not null)
				 OR
						  ([Movement Type] is null and ([I/O/TP/B/C] is not null and [I/O/TP/B/C] != 'FEI REVIEW'  and [I/O/TP/B/C] != 'FEI REVIEW - 39'))
					  )
					  AND [Pending GL] IS NULL;
---------------------------------------Audit table insertion for BR ref update details ----------------------------------------------------------------					  
				SET @Tgt_Inscnt = ROWCOUNT_BIG();		
--------------------------------------------------------Src rowcount Insertion in Audit Table----------------------------------------------------------------------
				SELECT @Src_RwCnt = COUNT(*) FROM Ferguson_vwFreightAudit_tmp WHERE CAST([Created_Timestamp] AS DATE) > @LoadDate_Daily 
					AND CAST([Created_Timestamp] AS DATE) < CAST(GETDATE() AS DATE)
					AND [Mode] = N'LTL' AND
				  (
						  ([Billable Warehouse] is null and [Whse] is not null)
				 OR
						  ([Movement Type] is null and ([I/O/TP/B/C] is not null and [I/O/TP/B/C] != 'FEI REVIEW'  and [I/O/TP/B/C] != 'FEI REVIEW - 39'))
					  )
					  AND [Pending GL] IS NULL;
				SET @Src_DelCnt = NULL;
				SET @Tgt_Inscnt = NULL;
				SET @Tgt_Updcnt = NULL;

			INSERT INTO dbo.ODS_Audit(DataBaseName,SchemaName,TableName,Src_RwCnt,Src_DelCnt,Tgt_Inscnt,Tgt_Delcnt,Tgt_Updcnt,CreatedDate,UpdatedDate)
			SELECT 'ODS_Mode','dbo','Fact_Ferguson_BR_ref_upd',@Src_RwCnt,@Src_DelCnt,@Tgt_Inscnt,@Tgt_Delcnt,@Tgt_Updcnt,GETDATE(),NULL;
						
--------------------------------------Control table update with current date in Fact_Ferguson_BR_ref_upd table---------------------------------------------------------		
		UPDATE dbo.ODS_Control	
		SET Status = 'Success', CreatedDate = Convert(Date,Getdate(),101)
		Where TableName = 'Fact_Ferguson_BR_ref_upd'; 
---------------------------------------------------------------------------------------------------------------------------------------------------------------		
		END TRY
---------------------------------------Error table insertion -------------------------------------------------------------------
		BEGIN CATCH
		
				INSERT INTO dbo.ODS_Error(DataBaseName,SchemaName,TableName,ErrorID,ErrorDesc,ErrorProc,ErrorLine,ErrorDate)
				SELECT   'ODS_Mode'
						,'dbo'
						,'Fact_Ferguson_BR_ref_upd'
						,Error_Number()
						,Error_Message()
						,Error_Procedure() 
						,Error_Line()
						,Getdate()
				
		END CATCH
		
---------------------------------------------------------Removing Null values of Primary key from Temp table--------------------------------------------

Delete from Ferguson_vwFreightAudit_tmp 
Where (shipmentprimaryreference Is Null OR loadprimaryreference IS Null OR [Pro#] IS Null)
AND    (
			CAST([Carrier Payment Approved Date] as date)  is not Null
			OR
			CAST([Carrier Payment Corrected Date] as date) is not Null
		  )

--------------------------------------------Fact_Ferguson_BR_Weekly table insert with one week of data from Temp table -----------------------------------------------
		BEGIN TRY
		
		INSERT INTO Fact_Ferguson_BR_Weekly
		(
				 XmlID 
				,Account
				,Whse			
				,WhseName							
				,[Assoc Whse]							
				,Carrier							
				,[Carrier Name]						
				,[Supplier ID]					
				,[Pro#]							    
				,RptWeek							
				,[Ship Date]						
				,Lading								
				,OrigCity							
				,OrigSt								
				,OrigZip							
				,OrigCntry							
				,DestCity							
				,DestSt								
				,DestZip							
				,DestCntry							
				,[I/O/TP/B/C]						
				,[GL#]								
				,Shipper							
				,ProcBy								
				,class1								
				,class2								
				,class3								
				,class4								
				,class5								
				,class6								
				,class7								
				,class8								
				,class9								
				,class10							
				,class11							
				,Weight1							
				,Weight2							
				,Weight3							
				,Weight4							
				,Weight5							
				,Weight6							
				,Weight7							
				,Weight8							
				,Weight9							
				,Weight10							
				,Weight11							
				,[P?]								
				,Amount								
				,Fee								
				,TotalAmount						
				,[Consign Name]						
				,Orig_LocType						
				,Orig_LocNum						
				,Dest_LocType						
				,Dest_LocNum						
				,PaymentMethod						
				,shipmentprimaryreference			
				,loadprimaryreference				
				,[Billable Warehouse]				
				,[Movement Type]					
				,[Source of Order]					
				,[Ferguson Internal Customer#]		
				,[FEI GL Coded]						
				,ExtractDate						
				,InvoiceDate						
				,[Carrier Payment Approved Date]	
				,[Carrier Payment Corrected Date]		
				,[Load ID]						
				,[Shipment ID]						
				,Mode								
				,Status								
				,Date_Added	
				,Date_Updated						
				,Date_Sent_Daily					
				,Date_Sent_Weekly
				)
		SELECT 
			   TF.XmlID 
			  ,TF.[Account]
			  ,TF.[Whse]
			  ,TF.[WhseName]
			  ,TF.[Assoc Whse]
			  ,TF.[Carrier]
			  ,TF.[Carrier Name]
			  ,TF.[Supplier ID]
			  ,TF.[Pro#]
			  ,TF.[RptWeek]
			  ,TF.[Ship Date]
			  ,TF.[Lading]
			  ,TF.[OrigCity]
			  ,TF.[OrigSt]
			  ,TF.[OrigZip]
			  ,TF.[OrigCntry]
			  ,TF.[DestCity]
			  ,TF.[DestSt]
			  ,TF.[DestZip]
			  ,TF.[DestCntry]
			  ,TF.[I/O/TP/B/C]
			  ,TF.[GL#]
			  ,TF.[Shipper]
			  ,TF.[ProcBy]
			  ,TF.[class1]
			  ,TF.[class2]
			  ,TF.[class3]
			  ,TF.[class4]
			  ,TF.[class5]
			  ,TF.[class6]
			  ,TF.[class7]
			  ,TF.[class8]
			  ,TF.[class9]
			  ,TF.[class10]
			  ,TF.[class11]
			  ,TF.[Weight1]
			  ,TF.[Weight2]
			  ,TF.[Weight3]
			  ,TF.[Weight4]
			  ,TF.[Weight5]
			  ,TF.[Weight6]
			  ,TF.[Weight7]
			  ,TF.[Weight8]
			  ,TF.[Weight9]
			  ,TF.[Weight10]
			  ,TF.[Weight11]
			  ,TF.[P?]
			  ,TF.[Amount]
			  ,TF.[Fee]
			  ,TF.[TotalAmount]
			  ,TF.[Consign Name]
			  ,TF.[Orig_LocType]
			  ,TF.[Orig_LocNum]
			  ,TF.[Dest_LocType]
			  ,TF.[Dest_LocNum]
			  ,TF.[PaymentMethod]
			  ,TF.[shipmentprimaryreference]
			  ,TF.[loadprimaryreference]
			  ,TF.[Billable Warehouse]
			  ,TF.[Movement Type]
			  ,TF.[Source of Order]
			  ,TF.[Ferguson Internal Customer #]
			  ,TF.[FEI GL Coded]
			  ,TF.[ExtractDate]
			  ,TF.[InvoiceDate]
			  ,TF.[Carrier Payment Approved Date]
			  ,TF.[Carrier Payment Corrected Date]
			  ,LTrim(RTrim(Replace(TF.[Load ID],'(T)',''))) as 'Load ID'
			  ,LTrim(RTrim(Replace(TF.[Shipment ID],'(T)',''))) as 'Shipment ID'
			  ,TF.[Mode]
			  ,'New' AS Status								
			  ,Getdate() AS Date_Added	
			  ,Null AS Date_Updated						
			  ,Null AS Date_Sent_Daily					
			  ,Null AS Date_Sent_Weekly
		  FROM [dbo].[Ferguson_vwFreightAudit_tmp] TF
		  LEFT OUTER JOIN Fact_Ferguson_BR_Weekly FW
		  ON TF.shipmentprimaryreference = FW.shipmentprimaryreference
		  AND TF.loadprimaryreference = FW.loadprimaryreference
		  AND TF.[Pro#]	= FW.[Pro#]
		  WHERE (FW.shipmentprimaryreference IS NULL
			 AND FW.loadprimaryreference IS NULL
			 AND FW.[Pro#] IS NULL)
		  AND    
		  (
			CAST(TF.[Carrier Payment Approved Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
			OR
			CAST(TF.[Carrier Payment Corrected Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
		  )
			and (Case when TF.[TotalAmount] = 0 and TF.[Carrier]='RLCA' and Left(TF.[Pro#],1) = 'D' then 'Y' else 'N' end ) = 'N'
			and (Case when TF.[TotalAmount] = 0 and TF.[Mode] = 'Truckload' then 'Y' else 'N' end ) = 'N'
			
---------------------------------------Audit table insert for BR weekly table details-------------------------------------------------------------						
			SET @Tgt_Inscnt = ROWCOUNT_BIG();
			SELECT @Src_RwCnt = COUNT(*) FROM Ferguson_vwFreightAudit_tmp TF WHERE     
												  (
													CAST(TF.[Carrier Payment Approved Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
													OR
													CAST(TF.[Carrier Payment Corrected Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
												  )
			and (Case when TF.[TotalAmount] = 0 and TF.[Carrier]='RLCA' and Left(TF.[Pro#],1) = 'D' then 'Y' else 'N' end ) = 'N'
			and (Case when TF.[TotalAmount] = 0 and TF.[Mode] = 'Truckload' then 'Y' else 'N' end ) = 'N';
			SET @Src_DelCnt = NULL;
			SET @Tgt_Delcnt = NULL;
			SET @Tgt_Updcnt = NULL;

			INSERT INTO dbo.ODS_Audit(DataBaseName,SchemaName,TableName,Src_RwCnt,Src_DelCnt,Tgt_Inscnt,Tgt_Delcnt,Tgt_Updcnt,CreatedDate,UpdatedDate)
			SELECT 'ODS_Mode','dbo','Fact_Ferguson_BR_Weekly',@Src_RwCnt,@Src_DelCnt,@Tgt_Inscnt,@Tgt_Delcnt,@Tgt_Updcnt,GETDATE(),NULL;

		END TRY
----------------------------------------Error tabel insert ------------------------------------------------------------------------------------		
		BEGIN CATCH
		
				INSERT INTO dbo.ODS_Error(DataBaseName,SchemaName,TableName,ErrorID,ErrorDesc,ErrorProc,ErrorLine,ErrorDate)
				SELECT   'ODS_Mode'
						,'dbo'
						,'Fact_Ferguson_BR_Weekly'
						,Error_Number()
						,Error_Message()
						,Error_Procedure() 
						,Error_Line()
						,Getdate()
				
		END CATCH

-------------------------------------------Fact_Ferguson_BR_Weekly Update based on any column data changes from temp table -------		
		BEGIN TRY
		UPDATE FW
			SET 
				 FW.XmlID 							=   TF.XmlID 
				,FW.Account 						= 	TF.[Account]
				,FW.Whse 							= 	TF.[Whse]
				,FW.WhseName 						= 	TF.[WhseName]
				,FW.[Assoc Whse]					= 	TF.[Assoc Whse]
				,FW.Carrier 						= 	TF.[Carrier]
				,FW.[Carrier Name]					= 	TF.[Carrier Name]
				,FW.[Supplier ID]					= 	TF.[Supplier ID]
				,FW.[Pro#] 							= 	TF.[Pro#]
				,FW.RptWeek 						= 	TF.[RptWeek]
				,FW.[Ship Date] 					= 	TF.[Ship Date]
				,FW.Lading 							= 	TF.[Lading]
				,FW.OrigCity 						= 	TF.[OrigCity]
				,FW.OrigSt 							= 	TF.[OrigSt]
				,FW.OrigZip 						= 	TF.[OrigZip]
				,FW.OrigCntry 						= 	TF.[OrigCntry]
				,FW.DestCity 						= 	TF.[DestCity]
				,FW.DestSt 							= 	TF.[DestSt]
				,FW.DestZip 						= 	TF.[DestZip]
				,FW.DestCntry 						= 	TF.[DestCntry]
				,FW.[I/O/TP/B/C] 					= 	TF.[I/O/TP/B/C]
				,FW.[GL#]	 						= 	TF.[GL#]
				,FW.Shipper 						= 	TF.[Shipper]
				,FW.ProcBy 							= 	TF.[ProcBy]
				,FW.class1 							= 	TF.[class1]
				,FW.class2 							= 	TF.[class2]
				,FW.class3 							= 	TF.[class3]
				,FW.class4 							= 	TF.[class4]
				,FW.class5 							= 	TF.[class5]
				,FW.class6 							= 	TF.[class6]
				,FW.class7 							= 	TF.[class7]
				,FW.class8 							= 	TF.[class8]
				,FW.class9 							= 	TF.[class9]
				,FW.class10 						= 	TF.[class10]
				,FW.class11 						= 	TF.[class11]
				,FW.Weight1 						= 	TF.[Weight1]
				,FW.Weight2 						= 	TF.[Weight2]
				,FW.Weight3 						= 	TF.[Weight3]
				,FW.Weight4 						= 	TF.[Weight4]
				,FW.Weight5 						= 	TF.[Weight5]
				,FW.Weight6 						= 	TF.[Weight6]
				,FW.Weight7 						= 	TF.[Weight7]
				,FW.Weight8 						= 	TF.[Weight8]
				,FW.Weight9 						= 	TF.[Weight9]
				,FW.Weight10 						= 	TF.[Weight10]
				,FW.Weight11 						= 	TF.[Weight11]
				,FW.[P?] 							= 	TF.[P?]
				,FW.Amount 							= 	TF.[Amount]
				,FW.Fee 							= 	TF.[Fee]
				,FW.TotalAmount 					= 	TF.[TotalAmount]
				,FW.[Consign Name] 					= 	TF.[Consign Name]
				,FW.Orig_LocType 					= 	TF.[Orig_LocType]
				,FW.Orig_LocNum 					= 	TF.[Orig_LocNum]
				,FW.Dest_LocType 					= 	TF.[Dest_LocType]
				,FW.Dest_LocNum 					= 	TF.[Dest_LocNum]
				,FW.PaymentMethod 					= 	TF.[PaymentMethod]
				,FW.shipmentprimaryreference      	= 	TF.[shipmentprimaryreference]
				,FW.loadprimaryreference 	     	= 	TF.[loadprimaryreference]
				,FW.[Billable Warehouse] 		    = 	TF.[Billable Warehouse]
				,FW.[Movement Type]				 	= 	TF.[Movement Type]
				,FW.[Source of Order] 				= 	TF.[Source of Order]
				,FW.[Ferguson Internal Customer#] 	= 	TF.[Ferguson Internal Customer #]
				,FW.[FEI GL Coded]			 		= 	TF.[FEI GL Coded]
				,FW.ExtractDate 					= 	Cast(TF.[ExtractDate] AS Date)
				,FW.InvoiceDate 					= 	TF.[InvoiceDate]
				,FW.[Carrier Payment Approved Date] = 	TF.[Carrier Payment Approved Date]
				,FW.[Carrier Payment Corrected Date] = 	TF.[Carrier Payment Corrected Date]
				,FW.[Load ID] 						= 	LTrim(RTrim(Replace(TF.[Load ID],'(T)','')))
				,FW.[Shipment ID]					= 	LTrim(RTrim(Replace(TF.[Shipment ID],'(T)','')))
				,FW.Mode 							= 	TF.[Mode]
				,FW.Status 							= 	'New'
				,FW.Date_Updated 					= 	Getdate()
			FROM Fact_Ferguson_BR_Weekly FW
			JOIN Ferguson_vwFreightAudit_tmp TF
			ON  TF.shipmentprimaryreference = FW.shipmentprimaryreference
			AND TF.loadprimaryreference 	= FW.loadprimaryreference 
			AND TF.[Pro#]					= FW.[Pro#]
			WHERE 
				   FW.XmlID								!=  TF.XmlID
				OR FW.Account 							!= 	TF.[Account]
				OR FW.Whse 								!= 	TF.[Whse]
				OR FW.WhseName 							!= 	TF.[WhseName]
				OR FW.[Assoc Whse] 						!= 	TF.[Assoc Whse]
				OR FW.Carrier 							!= 	TF.[Carrier]
				OR FW.[Carrier Name] 					!= 	TF.[Carrier Name]
				OR FW.[Supplier ID] 					!= 	TF.[Supplier ID]
				OR FW.RptWeek 							!= 	TF.[RptWeek]
				OR FW.[Ship Date] 						!= 	TF.[Ship Date]
				OR FW.Lading 							!= 	TF.[Lading]
				OR FW.OrigCity 							!= 	TF.[OrigCity]
				OR FW.OrigSt 							!= 	TF.[OrigSt]
				OR FW.OrigZip 							!= 	TF.[OrigZip]
				OR FW.OrigCntry 						!= 	TF.[OrigCntry]
				OR FW.DestCity 							!= 	TF.[DestCity]
				OR FW.DestSt 							!= 	TF.[DestSt]
				OR FW.DestZip 							!= 	TF.[DestZip]
				OR FW.DestCntry 						!= 	TF.[DestCntry]
				OR FW.[I/O/TP/B/C] 						!= 	TF.[I/O/TP/B/C]
				OR FW.[GL#]	 							!= 	TF.[GL#]
				OR FW.Shipper 							!= 	TF.[Shipper]
				OR FW.ProcBy 							!= 	TF.[ProcBy]
				OR FW.class1 							!= 	TF.[class1]
				OR FW.class2 							!= 	TF.[class2]
				OR FW.class3 							!= 	TF.[class3]
				OR FW.class4 							!= 	TF.[class4]
				OR FW.class5 							!= 	TF.[class5]
				OR FW.class6 							!= 	TF.[class6]
				OR FW.class7 							!= 	TF.[class7]
				OR FW.class8 							!= 	TF.[class8]
				OR FW.class9 							!= 	TF.[class9]
				OR FW.class10 							!= 	TF.[class10]
				OR FW.class11 							!= 	TF.[class11]
				OR FW.Weight1 							!= 	TF.[Weight1]
				OR FW.Weight2 							!= 	TF.[Weight2]
				OR FW.Weight3 							!= 	TF.[Weight3]
				OR FW.Weight4 							!= 	TF.[Weight4]
				OR FW.Weight5 							!= 	TF.[Weight5]
				OR FW.Weight6 							!= 	TF.[Weight6]
				OR FW.Weight7 							!= 	TF.[Weight7]
				OR FW.Weight8 							!= 	TF.[Weight8]
				OR FW.Weight9 							!= 	TF.[Weight9]
				OR FW.Weight10 							!= 	TF.[Weight10]
				OR FW.Weight11 							!= 	TF.[Weight11]
				OR FW.[P?] 								!= 	TF.[P?]
				OR FW.Amount 							!= 	TF.[Amount]
				OR FW.Fee 								!= 	TF.[Fee]
				OR FW.TotalAmount 						!= 	TF.[TotalAmount]
				OR FW.[Consign Name]					!= 	TF.[Consign Name]
				OR FW.Orig_LocType 						!= 	TF.[Orig_LocType]
				OR FW.Orig_LocNum 						!= 	TF.[Orig_LocNum]
				OR FW.Dest_LocType 						!= 	TF.[Dest_LocType]
				OR FW.Dest_LocNum 						!= 	TF.[Dest_LocNum]
				OR FW.PaymentMethod 					!= 	TF.[PaymentMethod]
				OR FW.shipmentprimaryreference      	!= 	TF.[shipmentprimaryreference]
				OR FW.loadprimaryreference 	     		!= 	TF.[loadprimaryreference]
				OR FW.[Billable Warehouse] 		    	!= 	TF.[Billable Warehouse]
				OR FW.[Movement Type] 					!= 	TF.[Movement Type]
				OR FW.[Source of Order] 				!= 	TF.[Source of Order]
				OR FW.[Ferguson Internal Customer#] 	!= 	TF.[Ferguson Internal Customer #]
				OR FW.[FEI GL Coded] 				 	!= 	TF.[FEI GL Coded]
				OR FW.ExtractDate 						!= 	Cast(TF.[ExtractDate] AS Date)
				OR FW.InvoiceDate 						!= 	TF.[InvoiceDate]
				OR FW.[Carrier Payment Approved Date] 	!= 	TF.[Carrier Payment Approved Date]
				OR FW.[Carrier Payment Corrected Date] 	!= 	TF.[Carrier Payment Corrected Date]
				OR FW.[Load ID] 						!= 	LTrim(RTrim(Replace(TF.[Load ID],'(T)','')))
				OR FW.[Shipment ID] 					!= 	LTrim(RTrim(Replace(TF.[Shipment ID],'(T)','')))
				OR FW.Mode 								!= 	TF.[Mode]
-------------------------------------------Audit table insertion for update details-----------------------------------------------------------------------------------------				
			SET @Tgt_Updcnt = ROWCOUNT_BIG();
			SELECT @Src_RwCnt = COUNT(*) FROM Ferguson_vwFreightAudit_tmp TF WHERE     
												  (
													CAST(TF.[Carrier Payment Approved Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
													OR
													CAST(TF.[Carrier Payment Corrected Date] as date)  BETWEEN Convert(Varchar, DateAdd(dd, -(DatePart(dw, getdate())+7 - 1), getdate()) ,101) and Convert(varchar, DateAdd(dd, (7 - DatePart(dw, getdate())), getdate()), 101)
												  )
			and (Case when TF.[TotalAmount] = 0 and TF.[Carrier]='RLCA' and Left(TF.[Pro#],1) = 'D' then 'Y' else 'N' end ) = 'N'
			and (Case when TF.[TotalAmount] = 0 and TF.[Mode] = 'Truckload' then 'Y' else 'N' end ) = 'N';
			SET @Src_DelCnt = NULL;
			SET @Tgt_Inscnt = NULL;
			SET @Tgt_Delcnt = NULL;

			INSERT INTO dbo.ODS_Audit(DataBaseName,SchemaName,TableName,Src_RwCnt,Src_DelCnt,Tgt_Inscnt,Tgt_Delcnt,Tgt_Updcnt,CreatedDate,UpdatedDate)
			SELECT 'ODS_Mode','dbo','Fact_Ferguson_BR_Weekly',@Src_RwCnt,@Src_DelCnt,@Tgt_Inscnt,@Tgt_Delcnt,@Tgt_Updcnt,GETDATE(),NULL;
			
--------------------------------------Control table update with current date in Fact_Ferguson_BR_Weekly table---------------------------------------------------------			
		Update dbo.ODS_Control
		SET Status = 'Success', CreatedDate = Convert(Date,Getdate(),101),UpdatedDate = Convert(Date,Getdate(),101)
		Where TableName = 'Fact_Ferguson_BR_Weekly';
------------------------------------------------------------------------------------------------------------------------------------------------------------
		END TRY
---------------------------------------ERROR Table Insert -----------------------------------------------------------------------------------------------		
		BEGIN CATCH
				
				INSERT INTO dbo.ODS_Error(DataBaseName,SchemaName,TableName,ErrorID,ErrorDesc,ErrorProc,ErrorLine,ErrorDate)
				SELECT   'ODS_Mode'
						,'dbo'
						,'Fact_Ferguson_BR_Weekly'
						,Error_Number()
						,Error_Message()
						,Error_Procedure() 
						,Error_Line()
						,Getdate()
				
		END CATCH		
END
GO

IF EXISTS (Select 1 from INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_NAME = 'SP_Ferguson_BR_Automation') 
BEGIN
 Print 'Ferguson BR Automation - Procedure executed Successfully'
END
ELSE
BEGIN
Print 'Abort - Procedure Error'
END
GO

Use ODS_Mode

DECLARE @JobName Varchar(Max) = 'Ferguson_BR_Automation'
DECLARE @Step_ID int = 2
DECLARE @Cmd Varchar(Max) = 
'
----------------------------------------------SEND EMAIL ALERT Incase Any Failure ------------------------------------------------------------------------
----------Created BY   : Premkumar S
----------Created DATE : 01-11-2019
BEGIN
DECLARE @RWCNT INT = 0;
----------------------change the profile available in production --------------------------------------------------------
DECLARE @PROFILE VARCHAR(MAX) = (Select top 1 Name from msdb..sysmail_profile order by 1 desc);
-------------------------email recipients --------------------------------------------------------------------------------
DECLARE @RECP VARCHAR(MAX) =  ''Juliet.Tuapen@modetransportation.com;Maya.Petkova@modetransportation.com'';

IF @RWCNT < (SELECT Count(1) AS cNT
FROM ODS_Mode.dbo.ODS_Error
Where Format(ErrorDate,''MM-dd-yyyy HH'') = Format(Getdate(),''MM-dd-yyyy HH'')
And TableName IN (''Fact_Ferguson_BR_ref_upd'',''Fact_Ferguson_BR_Weekly'')
)
BEGIN
DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)

SET @xml = CAST(( SELECT ISNULL([DataBaseName],''NA'') AS ''td'','''',ISNULL([SchemaName],''NA'') AS ''td'','''', ISNULL([TableName],''NA'') AS ''td'','''',
ISNULL([ErrorID],-1) AS ''td'','''',ISNULL([ErrorDesc],''NA'') AS ''td'','''', ISNULL([ErrorProc],''NA'') AS ''td'','''',ISNULL([ErrorLine],-1) AS ''td'','''',ISNULL([ErrorDate],''1900-01-01'') AS ''td''
FROM ODS_Mode.dbo.ODS_Error
Where Format(ErrorDate,''MM-dd-yyyy HH'') = Format(Getdate(),''MM-dd-yyyy HH'')
And TableName IN (''Fact_Ferguson_BR_ref_upd'',''Fact_Ferguson_BR_Weekly'')
ORDER BY TableName
FOR XML PATH(''tr''), ELEMENTS ) AS NVARCHAR(MAX))


SET @body =''<html><body><H3>Ferguson BR Automation Load - Failed</H3>
<table border = 1> 
<tr>
<th> DataBaseName </th> <th> SchemaName </th> <th> TableName </th><th> ErrorID </th>
<th> ErrorDesc </th><th> ErrorProc </th><th> ErrorLine </th><th> ErrorDate </th></tr>''    
 
SET @body = @body + @xml +''</table></body></html>''

EXEC msdb.dbo.sp_send_dbmail
@profile_name = @PROFILE, 
@body = @body,
@body_format =''HTML'',
@recipients = @RECP,
@subject = ''Ferguson BR Automation Load - Failure Email Alert'' ;
END
ELSE 
BEGIN
	SET @body = ''Ferguson BR Automation Load -  Completed Successfully''
	EXEC msdb.dbo.sp_send_dbmail
	@profile_name = @PROFILE, 
	@body = @body,
	@body_format =''HTML'',
	@recipients = @RECP,
	@subject = ''Ferguson BR Automation Load - Success Email Alert'' ;
END
END
'
EXEC MSDB.DBO.SP_UPDATE_JOBSTEP @JOB_NAME = @JobName
              ,@STEP_ID = @Step_ID
              ,@COMMAND = @Cmd
			  
PRINT 'Ferguson_BR_Automation - Job step updated Successfully'
			  
Use ODS_Mode

DECLARE @JobName_1 Varchar(Max) = 'Ferguson_BR_Automation_Weeklyload'
DECLARE @Step_ID_1 int = 5
DECLARE @Cmd_1 Varchar(Max) = 
'
----------------------------------------------SEND EMAIL ALERT Incase Any Failure ------------------------------------------------------------------------
----------Created BY   : Premkumar S
----------Created DATE : 01-11-2019
BEGIN
DECLARE @RWCNT INT = 0;
----------------------EMail Profile --------------------------------------------------------
DECLARE @PROFILE VARCHAR(MAX) = (Select top 1 Name from msdb..sysmail_profile Order by 1 desc); -- Change appropriate Profile name to send email
-------------------------email recipients --------------------------------------------------------------------------------
DECLARE @RECP VARCHAR(MAX) =  ''Juliet.Tuapen@modetransportation.com;Maya.Petkova@modetransportation.com''; -- Add Email Recipients 

IF @RWCNT < (SELECT Count(1) AS CNT
FROM ODS_Mode.dbo.ODS_Error
Where Format(ErrorDate,''MM-dd-yyyy HH'') = Format(Getdate(),''MM-dd-yyyy HH'')
And TableName IN (''Fact_Ferguson_BR_ref_upd'',''Fact_Ferguson_BR_Weekly'')
)
BEGIN
DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)

SET @xml = CAST(( SELECT ISNULL([DataBaseName],''NA'') AS ''td'','''',ISNULL([SchemaName],''NA'') AS ''td'','''', ISNULL([TableName],''NA'') AS ''td'','''',
ISNULL([ErrorID],-1) AS ''td'','''',ISNULL([ErrorDesc],''NA'') AS ''td'','''', ISNULL([ErrorProc],''NA'') AS ''td'','''',ISNULL([ErrorLine],-1) AS ''td'','''',ISNULL([ErrorDate],''1900-01-01'') AS ''td''
FROM ODS_Mode.dbo.ODS_Error
Where Format(ErrorDate,''MM-dd-yyyy HH'') = Format(Getdate(),''MM-dd-yyyy HH'')
And TableName IN (''Fact_Ferguson_BR_ref_upd'',''Fact_Ferguson_BR_Weekly'')
ORDER BY TableName
FOR XML PATH(''tr''), ELEMENTS ) AS NVARCHAR(MAX))


SET @body =''<html><body><H3>Ferguson BR Automation Load - Failed</H3>
<table border = 1> 
<tr>
<th> DataBaseName </th> <th> SchemaName </th> <th> TableName </th><th> ErrorID </th>
<th> ErrorDesc </th><th> ErrorProc </th><th> ErrorLine </th><th> ErrorDate </th></tr>''    
 
SET @body = @body + @xml +''</table></body></html>''

EXEC msdb.dbo.sp_send_dbmail
@profile_name = @PROFILE, 
@body = @body,
@body_format =''HTML'',
@recipients = @RECP,
@subject = ''Ferguson BR Automation Load - Failure Email Alert'' ;
END
ELSE 
BEGIN
	SET @body = ''Ferguson BR Automation Load -  Completed Successfully''
	EXEC msdb.dbo.sp_send_dbmail
	@profile_name = @PROFILE, 
	@body = @body,
	@body_format =''HTML'',
	@recipients = @RECP,
	@subject = ''Ferguson BR Automation Load - Success Email Alert'' ;
END
END
'

EXEC MSDB.DBO.SP_UPDATE_JOBSTEP @JOB_NAME = @JobName_1
              ,@STEP_ID = @Step_ID_1
              ,@COMMAND = @Cmd_1


PRINT 'Ferguson_BR_Automation_Weekly - Job step updated Successfully'