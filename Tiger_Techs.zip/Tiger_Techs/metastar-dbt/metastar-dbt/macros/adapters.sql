{% macro create_procedure(relation, sql) -%}
  {%- set raw_persist_docs = config.get('persist_docs', {}) -%}

  create or replace procedure {{ relation }}({{config.get('parameters')}})
    BEGIN
--   {{ bigquery_table_options(persist_docs=raw_persist_docs, temporary=false) }}
    {{ sql }};
    END;
{% endmacro %}