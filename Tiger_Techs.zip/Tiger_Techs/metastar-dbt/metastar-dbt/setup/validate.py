from google.cloud import bigquery

client = bigquery.Client()
job_config = bigquery.QueryJobConfig(dry_run=True, use_query_cache=False)

# Start the query, passing in the extra configuration.
query_job = client.query(
    (
        '''select * from `mint-bi-reporting`.revenue_repor.spr_advertiser'''
    ),
    job_config=job_config,
)  # Make an API request.
print("This query is valid and will process {} bytes.".format(query_job.total_bytes_processed))

