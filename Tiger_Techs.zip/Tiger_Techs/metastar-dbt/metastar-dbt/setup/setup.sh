#!/usr/bin/env bash

DirPath="$(dirname "$(dirname $vv)")"

cp validate.py $DirPath/dbt/task/validate.py
cp main.py $DirPath/dbt/main.py

#pip install -r requirements.txt