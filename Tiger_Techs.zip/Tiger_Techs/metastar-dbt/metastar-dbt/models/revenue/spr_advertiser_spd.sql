{{ config(schema='test_reports') }}
select
spr_advertiser.spr_channel_name,
spr_advertiser.channel_name,
spr_advertiser.source_name,
spr_advertiser.genre,
spr_advertiser.sub_genre,
spr_advertiser.type_of_beam,
spr_advertiser.subscription,
spr_advertiser.network,
spr_advertiser.channel_primary_tg,
spr_advertiser.channel_genre_tg,
spr_advertiser.genre_tg,
spr_advertiser.date,
spr_advertiser.month,
spr_advertiser.year,
spr_advertiser.advertiser_name,
spr_advertiser.advertiser_id_master,
case when star_internal_buys.advertiser_group_name is NULL then spr_advertiser.advertiser_group
else star_internal_buys.advertiser_group_name end as advertiser_group,
case when star_internal_buys.advertiser_group_name is NULL then spr_advertiser.region
else 'WEST' end as region,
spr_advertiser.advertiser_category,
spr_advertiser.on_air_sales_unit,
spr_advertiser.impact_regular,
spr_advertiser.spot_status,
spr_advertiser.time_band,
spr_advertiser.event_status,
spr_advertiser.revenue_classification,
spr_advertiser.part_of_day,
spr_advertiser.revenue,
spr_advertiser.fct,
spr_advertiser.agency,
spr_advertiser.sub_agency,
spr_advertiser.disney_week,
spr_advertiser.disney_month,
spr_advertiser.disney_f_year,
spr_advertiser.disney_quarter
from 
(
select spr_advertiser.*,disney_week,disney_month,disney_f_year, disney_quarter
from
(
(
select spr_advertiser.*, monthly_agency.agency,monthly_agency.sub_agency
from
(
    (
SELECT
  spr_channel_name,
  ch_master.channel_group_name as channel_name,
  ch_master.source_name as source_name,
  ch_master.genre as genre,
  ch_master.sub_genre as sub_genre,
  ch_master.type_of_beam as type_of_beam,
  ch_master.subscription as subscription,
  ch_master.network as network,
  ch_master.channel_primary_tg as channel_primary_tg,
  ch_master.channel_secondary_tg as channel_genre_tg,
  ch_master.genre_tg  as genre_tg,
  spr.telecast_date as date,
  spr.month as month,
  spr.year as year,
  spr.advertiser_name_master as advertiser_name,
  spr.advertiser_id_master  as advertiser_id_master ,
  advt_master.advertiser_group_name as advertiser_group,
  advt_master.region as region,
  advt_master.advertiser_category as advertiser_category,
  spr.sales_unit_pool_name  AS on_air_sales_unit,
  case when sales_unit.tag is NULL then 'regular'
  else sales_unit.tag  end AS impact_regular,
  spr.spot_status as spot_status,
  spr.time_band AS time_band,
  spr.event_status as event_status,
  spr.revenue_classification as revenue_classification,
  spr.part_of_day ,
  spr.revenue as revenue,
  spr.fct as fct
FROM
  (
select onair_spr.spr_channel_name,network,telecast_date,day,month,year,advertiser_name_master,advertiser_id_master,spot_status,sales_unit_pool_name,time_band,event_status,revenue_classification,hour_type,part_of_day,revenue,fct
from
(SELECT channel_name as spr_channel_name, telecast_date, EXTRACT(Month FROM telecast_date) AS month,EXTRACT(YEAR FROM telecast_date) AS year,
lower(FORMAT_DATE('%a', telecast_date)) as day,
(CASE WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'mon' THEN 1
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'tue' THEN 2
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'wed' THEN 3
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'thu' THEN 4
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'fri' THEN 5
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'sat' THEN 6
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'sun' THEN 7
      else 0 end) as day_num,
advertiser_name_master,advertiser_id_master ,spot_status, sales_unit_pool_name, time_band, event_status,revenue_classification,cast(split(time_band,'-')[OFFSET(0)] as int64)  as ST_hr,cast(split(time_band,'-')[OFFSET(1)] as int64) as ET_hr ,
sum(pitched_price/conversion_rate) AS revenue, sum(duration)/1000 AS fct
    FROM {{source('revenue','spr')}}
--     where lower(channel_name) in ('star plus')
-- and telecast_date = '2020-01-14'
GROUP BY channel_name, telecast_date, month,year,advertiser_name_master, advertiser_id_master,spot_status, sales_unit_pool_name, time_band,event_status,revenue_classification) as onair_spr
left join
(SELECT *,
(CASE WHEN from_day = 'mon' THEN 1
      WHEN from_day = 'tue' THEN 2
      WHEN from_day = 'wed' THEN 3
      WHEN from_day = 'thu' THEN 4
      WHEN from_day = 'fri' THEN 5
      WHEN from_day = 'sat' THEN 6
      WHEN from_day = 'sun' THEN 7
      else 0 end) as from_day_num,
(CASE WHEN to_day = 'mon' THEN 1
      WHEN to_day = 'tue' THEN 2
      WHEN to_day = 'wed' THEN 3
      WHEN to_day = 'thu' THEN 4
      WHEN to_day = 'fri' THEN 5
      WHEN to_day = 'sat' THEN 6
      WHEN to_day = 'sun' THEN 7
      else 0 end) as to_day_num
FROM {{source('master','ent_channel_master')}}
where --lower(channel_name) in ('star plus')and
source_name in ('ONAIR','ONAIR_ADSHARP') and hour_type in ('daypart')) as ch_master
on onair_spr.spr_channel_name = ch_master.channel_name
and onair_spr.day_num >= ch_master.from_day_num
and onair_spr.day_num <= ch_master.to_day_num
and onair_spr.ST_hr >= ch_master.start_time
and onair_spr.ST_hr < ch_master.end_time
  ) AS spr
left join
(SELECT distinct channel_name ,source_name ,channel_group_name ,genre ,sub_genre ,type_of_beam ,subscription ,network,channel_primary_tg ,channel_secondary_tg ,genre_tg   FROM {{source('master','ent_channel_master')}}
where source_name in ('ONAIR','ONAIR_ADSHARP')) as ch_master
on spr.spr_channel_name=ch_master.channel_name
  left JOIN
  (
    SELECT DISTINCT region, advertiser_group_name, advertiser_name,onair_id, advertiser_category
    FROM {{source('master','ent_advertiser_master')}}
      ) AS advt_master
  ON spr.advertiser_id_master = advt_master.onair_id
  left JOIN
  (
SELECT distinct sales_unit  as on_air_sales_unit,tag  FROM {{source('master','onair_sales_unit_taggings')}}) AS sales_unit
  ON sales_unit.on_air_sales_unit = spr.sales_unit_pool_name
GROUP BY spr_channel_name,channel_name, date, month,year, advertiser_group, region,advertiser_category,
spot_status, on_air_sales_unit, impact_regular,
time_band, revenue, fct,spr.part_of_day,ch_master.genre ,ch_master.sub_genre,ch_master.type_of_beam,ch_master.subscription,ch_master.network,ch_master.channel_primary_tg ,ch_master.channel_secondary_tg,ch_master.genre_tg,spr.advertiser_name_master,spr.advertiser_id_master,ch_master.source_name,spr.event_status,spr.revenue_classification 
  )
  )as spr_advertiser
LEFT JOIN
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM  {{source('master','month_wise_agency_mappings')}}) as monthly_agency
on lower(spr_advertiser.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and spr_advertiser.month = monthly_agency.month
-- and spr_advertiser.year = monthly_agency.year
  )
  ) as spr_advertiser
inner Join
(SELECT year as disney_yar,month as disney_month, week as disney_week,start_date,end_date, fin_year as disney_f_year,quarter as disney_quarter FROM {{source('master','disney_fy_cal')}}) as disney_calendar
on spr_advertiser.date >= disney_calendar.start_date
and spr_advertiser.date <= disney_calendar.end_date
  )  as spr_advertiser
left JOIN
(SELECT distinct advertiser_name,onair_id ,advertiser_group_name  FROM {{source('master','star_internal_buys')}}
where lower(source) in ('onair')) as star_internal_buys
on spr_advertiser.advertiser_id_master =   star_internal_buys.onair_id