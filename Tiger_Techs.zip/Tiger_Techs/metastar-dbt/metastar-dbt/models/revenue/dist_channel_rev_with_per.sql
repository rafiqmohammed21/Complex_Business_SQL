{{ config(schema='revenue_reports') }}

SELECT month,year,year_month,customer_nbr,channel_name,'Billed Revenue' as revenue_category,
  sum(amount) AS revenue,
  rank()over(partition by customer_nbr,snap_shot_date order by cast (concat(cast (year as string),lpad (cast (month as string) ,2,"0")) as int64)  DESC)rnk,
  sum(sum(amount)) over (partition by customer_nbr,year,month,snap_shot_date) total_rev,
  case when
  sum(sum(amount)) over (partition by customer_nbr,year,month,snap_shot_date) = 0.0 then NULL
  else
  sum(amount) / sum(sum(amount))over(partition by customer_nbr,year,month,snap_shot_date) end as channel_percnetage
  ,snap_shot_date
FROM {{ref('dist_channel_revenue')}}
WHERE month in (SELECT DISTINCT(st_month) FROM {{ref('dist_channel_revenue')}})
group by month,year,year_month,customer_nbr,channel_name,snap_shot_date
order by customer_nbr,rnk