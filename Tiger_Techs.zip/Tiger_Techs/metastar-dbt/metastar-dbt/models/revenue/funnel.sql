  {{ config(schema='revenue_reports') }}
  SELECT funnel.*,monthly_agency.agency ,monthly_agency.sub_agency  from
  (SELECT funnel_id, channel_name, month as date, created_at, year_month, updated_at, advertiser_group, missed_client, campaign_budget, share_in_campaign, creator_name, region, impact_regular, projection_inr,EXTRACT(Month FROM month) AS month,EXTRACT(YEAR FROM month) AS year
   FROM {{source('revenue','ent_funnel')}} ) as funnel
  left join
  (SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}} ) as monthly_agency
  on lower(funnel.advertiser_group) = lower(monthly_agency.advertiser_group) 
--   and funnel.month = monthly_agency.month
--   and funnel.year = monthly_agency.year
