{{ config(schema='revenue_reports') }}
(


with cte_calendar as (
SELECT year, month, week, date, fin_year, quarter from {{source('master','disney_fy_cal')}} a
join ( select date
FROM UNNEST(
    GENERATE_DATE_ARRAY((select min(start_date) from {{source('master','disney_fy_cal')}}), (select max(end_date) from {{source('master','disney_fy_cal')}}), INTERVAL 1 DAY)
) AS date) as cte_day
on cte_day.date >= a.start_date and cte_day.date <= a.end_date
order by year, month, week, date )
,
number_of_days_per_month_cte as (
  SELECT
    year, month, (DATE_DIFF(max(end_date), min(start_Date), day)) + 1  as number_of_days
  from
    {{source('master','disney_fy_cal')}}
  GROUP BY year, month
)
,
cte_spr as ( SELECT channel_name, date,
  region, impact_regular, advertiser_group, agency, sub_agency, sum(revenue) as revenue, part_of_day as pt_npt
  FROM {{ref('reg_spr_advertiser')}}
  WHERE
      lower(spot_status) in ('aired', 'placed')
    AND
      date < CURRENT_DATE()
  GROUP BY
    channel_name,date, region, advertiser_group, agency, sub_agency, impact_regular , pt_npt
)
,
cte_spr_booked as ( SELECT channel_name, date,
  region, impact_regular, advertiser_group, agency, sub_agency, sum(revenue) as booked_revenue, part_of_day as pt_npt
  FROM {{ref('reg_spr_advertiser')}}
  WHERE
      date >= CURRENT_DATE()
  GROUP BY
    channel_name,date, region, advertiser_group, agency, sub_agency, impact_regular , pt_npt
)
,
cte_funnel as (
 SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency, sum(projection_inr)/ (2*max(number_of_days_per_month_cte.number_of_days)) as revenue, "pt" as pt_npt
  FROM {{ref('reg_funnel')}} a
  JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY advertiser_group,channel_name, date, agency, sub_agency, region, impact_regular, pt_npt
  UNION ALL
  SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency, sum(projection_inr)/ (2*max(number_of_days_per_month_cte.number_of_days)) as revenue, "npt" as pt_npt
  FROM {{ref('reg_funnel')}} a
  JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY advertiser_group,channel_name, date, agency, sub_agency, region, impact_regular, pt_npt
)
,
final_cte as (
  SELECT coalesce( cte_spr.advertiser_group, cte_spr_booked.advertiser_group, cte_funnel.advertiser_group) as advertiser_group,
      coalesce( cte_spr.date, cte_spr_booked.date, cte_funnel.date) as date,
      coalesce( cte_spr.channel_name, cte_spr_booked.channel_name, cte_funnel.channel_name) as channel_name,
      coalesce( cte_spr.region, cte_spr_booked.region, cte_funnel.region ) as region,
      coalesce( cte_spr.impact_regular,cte_spr_booked.impact_regular,  cte_funnel.impact_regular  ) as impact_regular,
      coalesce( cte_spr.pt_npt,cte_spr_booked.pt_npt,  cte_funnel.pt_npt ) as pt_npt,
      coalesce( cte_spr.agency , cte_spr_booked.agency, cte_funnel.agency) as agency ,
      coalesce( cte_spr.sub_agency, cte_spr_booked.sub_agency,  cte_funnel.sub_agency ) as sub_agency,
  null as ro_revenue,
  cte_spr.revenue as actual_revenue,
  cte_spr_booked.booked_revenue as booked_revenue,
  null as deals_revenue,
  cte_funnel.revenue as projection_revenue,
  FROM
  cte_spr
  FULL JOIN
  cte_spr_booked
  using(channel_name,date, region, advertiser_group, agency, sub_agency, impact_regular, pt_npt)
  FULL JOIN
  cte_funnel
  using(channel_name, date, region, advertiser_group, agency, sub_agency, impact_regular, pt_npt)
)
select advertiser_group, channel_name, date, agency,sub_agency, region, impact_regular, pt_npt, sum(ro_revenue) as ro_revenue, sum(actual_revenue) as actual_revenue,sum(booked_revenue) as booked_revenue,(ifnull(sum(actual_revenue),0)+ifnull(sum(booked_revenue),0)) as total_revenue, sum(deals_revenue) as deals_revenue, sum(projection_revenue) as projection_revenue from final_cte
group by advertiser_group,channel_name, date,agency,sub_agency, region, impact_regular, pt_npt
  )