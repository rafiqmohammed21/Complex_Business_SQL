{{ config(schema='revenue_reports') }}
select spr.*,ent_adv_master.advertiser_group_name from

(select spr.*, disney_fy_cal.year as disney_year, disney_fy_cal.week as disney_week, disney_fy_cal.month as disney_month, disney_fy_cal.fin_year as disney_fin_year, disney_fy_cal.quarter as disney_quarter
from 
( select spr.*, On_Air_Channel_ID, SOURCE , Channel_Group_name , Business_Unit , Type_Of_Beam , 
    main_channel_tag , Business_Unit_Genre , STAR_Genre, Start_Day, end_day, Live_hrs_ET, Live_hrs_ST , 
    PT_Start_Time , PT_End_Time , TG_Market_1 , TG_Market_2 , TG_Market_3, (case  when Live_hrs_ST is null and Live_hrs_ET is null
    then null
        when (ST_hr >= cast(Live_hrs_ST as int64) ) and (ET_hr <= cast(Live_hrs_ET as int64))
        then (CASE when (ST_hr >= cast(PT_Start_Time as int64)) and (ET_hr <= cast(PT_End_Time as int64))
                   then 'PT' else 'NPT' end)
        else 'DH' end) as day_part from
( (select *, cast(split(time_band,'-')[OFFSET(0)] as int64)  as ST_hr,
    cast(split(time_band,'-')[OFFSET(1)] as int64) as ET_hr
    from {{source('revenue','spr')}} ) as spr
left join 
(SELECT * ,

    (CASE WHEN Start_Day = 'Mon' THEN 1
      WHEN Start_Day = 'Tue' THEN 2
      WHEN Start_Day = 'Wed' THEN 3
      WHEN Start_Day = 'Thu' THEN 4
      WHEN Start_Day = 'Fri' THEN 5
      WHEN Start_Day = 'Sat' THEN 6
      WHEN Start_Day = 'Sun' THEN 7
      else 0 end) as start_day_num, 
      (CASE WHEN End_Day = 'Mon' THEN 1
      WHEN End_Day = 'Tue' THEN 2
      WHEN End_Day = 'Wed' THEN 3
      WHEN End_Day = 'Thu' THEN 4
      WHEN End_Day = 'Fri' THEN 5
      WHEN End_Day = 'Sat' THEN 6
      WHEN End_Day = 'Sun' THEN 7
      else 0 end) as end_day_num

     FROM {{source('master','spr_channel_master')}}
     where LOWER(source) = 'on-air' ) as channel_master
on lower(spr.channel_name) = lower(channel_master.channel_name) )
WHERE ( CAST(FORMAT_DATE('%u', spr.telecast_date) as int64) between channel_master.start_day_num and channel_master.end_day_num
           OR channel_master.Channel_Group_Name is null
           OR channel_master.start_day_num = 0) ) as spr
inner join 
(select * from {{source('master','disney_fy_cal')}} )as disney_fy_cal
on spr.telecast_date BETWEEN disney_fy_cal.start_date and disney_fy_cal.end_date) as spr
left join 
(select distinct advertiser_name, onair_id, source, advertiser_group_name 
from {{source('master','ent_advertiser_master')}}  where lower(source) in ('onair') ) as ent_adv_master
on spr.advertiser_id_master = ent_adv_master.onair_id