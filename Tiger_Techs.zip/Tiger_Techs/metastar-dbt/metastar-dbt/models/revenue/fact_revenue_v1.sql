{{ config(schema='revenue_reports') }}
(
select * from {{ref('reg_fact_revenue_v1')}}
union all
select * from {{ref('ent_fact_revenue_v1')}}
)