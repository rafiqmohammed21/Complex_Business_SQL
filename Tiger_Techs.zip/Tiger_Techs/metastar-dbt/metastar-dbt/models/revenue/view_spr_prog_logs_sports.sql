{{ config(schema='revenue_reports') }}
(select * except(rank) from
(
select spr.*, pp.description, pp.start_time, pp.week_date, row_number() over (partition by spot_id order by  CAST( CAST( REPLACE (pp.start_time , ":", "") as FLOAT64) as INT64)  ) as rank
from {{source('revenue','prog_logs_sports')}} pp right join {{source('revenue','spr')}} spr on  pp.week_date = spr.telecast_date
and lower(pp.channel)= lower(spr.channel_name)
and CAST( CAST( REPLACE (pp.start_time, ":", "") as FLOAT64) as INT64) > CAST(CAST(spr.aired_time as FLOAT64 ) as INT64)
where lower(spr.channel_name) like "%star sport%"
)
where rank=1)