{{ config(schema='revenue_reports') }}

WITH channel_rev_boq AS (
  SELECT CASE WHEN lower(dr.bouquet_alacarte) = 'bouquet' THEN lower(cbm.channel_name)
  WHEN lower(dr.bouquet_alacarte) = 'alacarte' THEN lower(dr.bouquet_alacarte_name) END AS channel_name,
  case when cbm.bouquet_name is NULL then 'alacarte' else 'bouquet' end as type,
  SUM(dr.charge_amount) as charge_amount
         ,dr.customer_nbr,dr.month,dr.year
         ,cbm.bouquet_name
         ,cast(concat(cast (dr.year as string), cast(dr.month as string)) as INT64) AS year_month
         ,dr.snap_shot_date


  FROM {{source('test','dist_revenue_snap')}} dr
  LEFT JOIN {{source('revenue','dist_channel_bouquet_mapping')}} cbm on lower(dr.bouquet_alacarte_name) = lower(cbm.bouquet_name)
  GROUP BY customer_nbr, month, year, channel_name, bouquet_name,snap_shot_date
 )

 ,mng_alloc AS(
  SELECT ma.year
         ,ma.month
         ,ma.management_allocation
         ,ma.management_allocation_total
         ,ma.management_allocation_wt
         ,ma.bouquet_name
         ,lower(ma.channel_name) as channel_name
  FROM {{source('revenue','dist_management_allocation')}} ma
  )
SELECT *
from
(SELECT channel_rev_boq.customer_nbr,channel_rev_boq.month,channel_rev_boq.year,channel_rev_boq.year_month,channel_rev_boq.channel_name,channel_rev_boq.type,management_allocation_wt,st.month as st_month,st.year as st_year,
  CASE WHEN channel_rev_boq.type = 'alacarte' THEN  (1*channel_rev_boq.charge_amount)
    ELSE (management_allocation_wt*channel_rev_boq.charge_amount) end AS amount,
    channel_rev_boq.snap_shot_date

FROM channel_rev_boq
LEFT JOIN mng_alloc st on channel_rev_boq.bouquet_name = st.bouquet_name
                    AND channel_rev_boq.channel_name = st.channel_name
                    AND channel_rev_boq.year = st.year
                    AND channel_rev_boq.month = st.month
GROUP BY channel_name,customer_nbr,month,year,year_month,type,st.management_allocation_wt,charge_amount,st_month,st_year,snap_shot_date)
-- WHERE month=st_month AND year = st_year


