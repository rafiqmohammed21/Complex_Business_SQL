{{ config(schema='revenue_reports') }}

(select coalesce(dci.customer_nbr,dbu.customer_nbr) as customer_nbr,
coalesce(dci.par_month,dbu.month) as month,
coalesce(dci.par_year,dbu.year) as year,
coalesce(dci.channel_name,dbu.channel_name) as channel_name,
coalesce(dbu.snap_shot_date,dci.snap_shot_date) as snap_shot_date,
coalesce(dbu.revenue_category,dci.revenue_category) as revenue_category,
coalesce(dbu.revenue,dci.incentive) as revenue
From
(select coalesce(billed_unbilled.customer_nbr,customer_nbr) as customer_nbr,
coalesce(billed_unbilled.month,month) as month,
coalesce(billed_unbilled.year,year) as year,
coalesce(billed_unbilled.channel_name,channel_name) as channel_name,
coalesce(snap_shot_date,billed_unbilled.snap_shot_date) as snap_shot_date,
coalesce(revenue_category,billed_unbilled.revenue_category) as revenue_category,
coalesce(revenue,billed_unbilled.revenue) as revenue
from
(select coalesce(billed_rev.customer_nbr,dud.customer_nbr) as customer_nbr,
coalesce(billed_rev.month,dud.month) as month,
coalesce(billed_rev.year,dud.year) as year,
coalesce(billed_rev.channel_name,dud.channel_name) as channel_name,
coalesce(dud.snap_shot_date,billed_rev.snap_shot_date) as snap_shot_date,
CASE WHEN
          dud.customer_nbr is null THEN 'Billed Revenue'
     -- WHEN
       --   dud.revenue_category = 'Deferred Revenue' THEN 'Deferred Revenue'
      WHEN
         dud.customer_nbr = billed_rev.customer_nbr  THEN 'Billed Revenue'
      WHEN
        billed_rev.customer_nbr is null AND sum (dud.revenue) >=0 THEN 'Unbilled Revenue'
        END AS revenue_category,
     CASE WHEN billed_rev.customer_nbr is null then sum(dud.revenue)
    --  WHEN dud.revenue_category = 'Deferred Revenue' THEN sum(dud.revenue)
     ELSE sum (billed_rev.revenue) END AS revenue from
(SELECT * FROM {{ref('dist_unbilled_deferred_channel_rev_stat')}} where lower(revenue_category) in ('unbilled revenue')) AS dud
FULL OUTER JOIN
(SELECT *  FROM {{ref('dist_channel_rev_with_per_stat')}}) AS billed_rev
ON dud.customer_nbr = billed_rev.customer_nbr
    AND dud.channel_name = billed_rev.channel_name
    AND dud.month = billed_rev.month
    AND dud.year = billed_rev.year
    AND dud.snap_shot_date = billed_rev.snap_shot_date
 group by billed_rev.customer_nbr ,billed_rev.month ,billed_rev.year ,billed_rev.channel_name ,billed_rev.snap_shot_date,
 dud.customer_nbr ,dud.month ,dud.year ,dud.channel_name ,dud.snap_shot_date,dud.revenue_category) as billed_unbilled
 UNION ALL
(SELECT customer_nbr,month,year,channel_name,snap_shot_date,revenue_category,revenue, FROM {{ref('dist_unbilled_deferred_channel_rev_stat')}} WHERE revenue_category = 'Deferred Revenue'
GROUP BY customer_nbr,month,year,channel_name,revenue,revenue_category,snap_shot_date)) as dbu
FULL OUTER JOIN
(SELECT * from {{ref('dist_channel_incentive_stat')}}) dci
ON dbu.customer_nbr = dci.customer_nbr
    AND dbu.channel_name = dci.channel_name
    AND dbu.month = dci.par_month
    AND dbu.year = dci.par_year
    AND dbu.revenue_category = dci.revenue_category)
