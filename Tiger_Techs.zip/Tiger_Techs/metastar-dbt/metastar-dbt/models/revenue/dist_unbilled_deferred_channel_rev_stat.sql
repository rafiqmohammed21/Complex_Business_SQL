{{ config(schema='revenue_reports') }}

SELECT CASE WHEN channel_percentage.customer_nbr is null then dud.customer_nbr
       ELSE channel_percentage.customer_nbr END AS customer_nbr,
       dud.month, dud.year, dud.revenue_category,channel_percentage.channel_name,
       CASE WHEN channel_percentage.customer_nbr is null then sum(dud.revenue)
       ELSE SUM(dud.revenue * channel_percentage.channel_percnetage) END AS revenue,
       channel_percentage.snap_shot_date
FROM
(SELECT * FROM {{source('revenue','dist_stat_unbilled_differed')}}) AS dud

LEFT JOIN

(SELECT customer_nbr,rnk,channel_name ,channel_percnetage,snap_shot_date  FROM {{ref('dist_channel_rev_with_per_stat')}}
where rnk = 1
group by customer_nbr,rnk,channel_name ,channel_percnetage,snap_shot_date) AS channel_percentage

ON dud.customer_nbr = channel_percentage.customer_nbr
-- AND dud.snap_shot_date = channel_percentage.snap_shot_date

GROUP BY channel_percentage.customer_nbr,dud.customer_nbr,dud.month, dud.year, dud.revenue_category,channel_name,snap_shot_date
