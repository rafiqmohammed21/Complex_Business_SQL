{{ config(schema='revenue_reports') }}

(SELECT  coalesce(channel_percentage.customer_nbr,dmi.customer_nbr) as customer_nbr
       ,dmi.par_month, dmi.par_year, dmi.revenue_category,channel_percentage.channel_name,
       CASE WHEN channel_percentage.customer_nbr is null then sum(dmi.total_incentive)
       ELSE SUM(dmi.total_incentive * channel_percentage.channel_percnetage) END AS incentive,
       coalesce(channel_percentage.snap_shot_date,dmi.snap_shot_date) as snap_shot_date
FROM
(SELECT * FROM {{ref('dist_monthly_incentive')}}) AS dmi
LEFT JOIN
-- (SELECT customer_nbr,rnk,channel_name,month,year ,channel_percnetage,snap_shot_date  FROM `mint-bi-reporting`.`revenue_reports`.`dist_channel_rev_with_per`
-- --where rnk = 1
-- group by customer_nbr,rnk,channel_name ,channel_percnetage,snap_shot_date,month,year) AS channel_percentage
(select customer_nbr,channel_name ,year ,month ,revenue_category,snap_shot_date ,sum (revenue) as revenue,
sum(sum(revenue)) over (partition by customer_nbr,year,month,snap_shot_date) total_rev,
  case when
  sum(sum(revenue)) over (partition by customer_nbr,year,month,snap_shot_date) = 0.0 then NULL
  else
  sum(revenue) / sum(sum(revenue))over(partition by customer_nbr,year,month,snap_shot_date) end as channel_percnetage
from
(select coalesce(billed_rev.customer_nbr,dud.customer_nbr) as customer_nbr,
coalesce(billed_rev.month,dud.month) as month,
coalesce(billed_rev.year,dud.year) as year,
coalesce(billed_rev.channel_name,dud.channel_name) as channel_name,
coalesce(dud.snap_shot_date,billed_rev.snap_shot_date) as snap_shot_date,
CASE WHEN
          dud.customer_nbr is null THEN 'Billed Revenue'
     -- WHEN
       --   dud.revenue_category = 'Deferred Revenue' THEN 'Deferred Revenue'
      WHEN
         dud.customer_nbr = billed_rev.customer_nbr  THEN 'Billed Revenue'
      WHEN
        billed_rev.customer_nbr is null AND sum (dud.revenue) >=0 THEN 'Unbilled Revenue'
        END AS revenue_category,
     CASE WHEN billed_rev.customer_nbr is null then sum(dud.revenue)
    --  WHEN dud.revenue_category = 'Deferred Revenue' THEN sum(dud.revenue)
     ELSE sum (billed_rev.revenue) END AS revenue from
(SELECT * FROM {{ref('dist_unbilled_deferred_channel_rev')}} where lower(revenue_category) in ('unbilled revenue')) AS dud
FULL OUTER JOIN
(SELECT *  FROM {{ref('dist_channel_rev_with_per')}}) AS billed_rev
ON dud.customer_nbr = billed_rev.customer_nbr
    AND dud.channel_name = billed_rev.channel_name
    AND dud.month = billed_rev.month
    AND dud.year = billed_rev.year
    AND dud.snap_shot_date = billed_rev.snap_shot_date
 group by billed_rev.customer_nbr ,billed_rev.month ,billed_rev.year ,billed_rev.channel_name ,billed_rev.snap_shot_date,
 dud.customer_nbr ,dud.month ,dud.year ,dud.channel_name ,dud.snap_shot_date,dud.revenue_category)
 group by year,month,revenue_category,channel_name,customer_nbr ,snap_shot_date ) AS channel_percentage
ON dmi.customer_nbr = channel_percentage.customer_nbr
AND dmi.snap_shot_date = channel_percentage.snap_shot_date
and dmi.par_month = channel_percentage.month
and dmi.par_year = channel_percentage.year
GROUP BY channel_percentage.customer_nbr,dmi.customer_nbr,dmi.par_month, dmi.par_year, dmi.revenue_category,channel_name,channel_percentage.snap_shot_date,dmi.snap_shot_date
  )