{{
    config
    (
        schema='revenue_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_channel STRING, var_region ARRAY<STRING>, var_impact_regular ARRAY<STRING>, all_region_selected BOOL'
    )

}}

SELECT
round(ifnull(SUM(value),0),2) as target
FROM {{ref('ent_ad_revenue_target')}}
WHERE
    lower(channel_name) = lower(var_channel)
         and concat(cast(year as string),"_",cast(month as string)) in  
                     ( select distinct concat(year,'_',month) from {{source('master','disney_fy_cal')}}
                       where start_date = var_start_date)
    and 
    CASE WHEN all_region_selected = true
                       THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
                       ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
    and
    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end