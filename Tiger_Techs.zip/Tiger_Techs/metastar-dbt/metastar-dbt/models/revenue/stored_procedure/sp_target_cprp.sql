{{
    config
    (
        schema='revenue_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_channel STRING, var_pt_npt ARRAY<STRING>'
    )

}}

SELECT
ifnull(value,0) as target_cprp
FROM {{ref('ent_ad_revenue_target_cprp')}}
WHERE
     lower(channel_name) = lower(var_channel)
     and(
         CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                     THEN lower(pt_npt) = 'overall'
                     ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     )
     and concat(cast(year as string),"_",cast(month as string)) in  
                     ( select distinct concat(year,'_',month) from {{source('master','disney_fy_cal')}}
                       where start_date = var_start_date)