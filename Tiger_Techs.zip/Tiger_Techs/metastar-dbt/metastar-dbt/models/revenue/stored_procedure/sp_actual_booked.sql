{{
    config
    (
        schema='revenue_reports',
        materialized='stored_procedure',
        parameters='var_actual_start_date DATE, var_actual_end_date DATE, dev_period ARRAY<DATE>, var_booked_start_date DATE, var_booked_end_date DATE, var_channel STRING, var_region ARRAY<STRING>, var_pt_npt ARRAY<STRING>, var_impact_regular ARRAY<STRING>, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL'
    )

}}
select
    round(actual_revenue/10000000,2) as actual_revenue,
    round(actual_deviation/10000000,2) as actual_deviation,
    round((safe_divide(((safe_divide(ifnull(actual_revenue,0),(DATE_DIFF(var_actual_end_date, var_actual_start_date, day)+1))) - (ifnull(actual_deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))),(ifnull(actual_deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))))*100,2) as actual_percentage_deviation,
    round(total_revenue/10000000,2) as total_revenue,
    round(actual_deviation/10000000,2) as total_deviation,
    round((safe_divide(((ifnull(total_revenue_normalized,0)/1) - (ifnull(actual_deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))),(ifnull(actual_deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))))*100,2) as total_percentage_deviation,
    DATE_DIFF(var_actual_end_date,var_actual_start_date,day) + 1 as number_of_days_actualised,
    CASE WHEN var_booked_end_date < var_actual_start_date then
        DATE_DIFF(var_actual_end_date,var_actual_start_date,day) + 1 else
        DATE_DIFF(var_booked_end_date, var_actual_start_date,day) + 1 end as number_of_days_month,
    round(actual_revenue_internal/10000000,2) as actual_revenue_internal,
    round(booked_revenue_internal/10000000,2) as booked_revenue_internal,
    round(total_revenue_internal/10000000,2) as total_revenue_internal
FROM
(
   select
     sum(actual_revenue) as actual_revenue,
     sum(actual_deviation) as actual_deviation,
     sum(booked_revenue)  as booked_revenue,
     sum(actual_revenue_internal ) as actual_revenue_internal,
     sum(booked_revenue_internal ) as booked_revenue_internal,
     ifnull(sum(actual_revenue),0)+ifnull(sum(booked_revenue),0) as total_revenue,
     ifnull(sum(actual_revenue_internal),0)+ifnull(sum(booked_revenue_internal),0) as total_revenue_internal,
     (ifnull(safe_divide(sum(actual_revenue),(DATE_DIFF(var_actual_end_date, var_actual_start_date, day)+1)),0) + ifnull((safe_divide(sum(booked_revenue),(DATE_DIFF(var_booked_end_date, var_booked_start_date, day)+1))),0)) as total_revenue_normalized
   from
    (
        SELECT advertiser_group ,sum (revenue /agency_count) as actual_revenue, 
        sum(revenue_internal/agency_count) as actual_revenue_internal
        from
        (
                SELECT advertiser_group ,sum (revenue) as revenue, 
                case when lower(advertiser_group) in ('star tv network') then sum(revenue) else null end as revenue_internal,
                case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
                FROM {{ref('spr_advertiser')}}
                WHERE
                    lower(channel_name)= lower(var_channel)
                    and  (date between var_actual_start_date and var_actual_end_date)
                    and
                    CASE WHEN all_region_selected=true
                         THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                         ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                       THEN (lower(part_of_day) in (  "pt"   ,"npt"  ) OR part_of_day IS NULL)
                       ELSE lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a  ) end
					and
                    CASE WHEN var_actual_start_date < "2019-10-27"
                      THEN lower(advertiser_group) not in ('star tv network') else 1=1 end
					and 
					  CASE WHEN all_advertiser_selected = true
					  then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
					  else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
					and 
					  CASE WHEN all_agency_selected = true
					 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
					 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
					and 
					  CASE WHEN all_sub_agency_selected = true
					  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
					  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
                    and lower(spot_status) in ('aired', 'placed')
                 GROUP BY advertiser_group
         )
         GROUP BY advertiser_group
        ) as curr_actual

        FULL JOIN

        (
           SELECT advertiser_group , ifnull(sum (revenue /agency_count),0) as actual_deviation,
           from
           (
               SELECT advertiser_group ,sum (revenue) as revenue, 
               case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
               FROM {{ref('spr_advertiser')}}
               WHERE
                    lower(channel_name)= lower(var_channel)
                    and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                    and
                    CASE WHEN all_region_selected = true
                         THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                         ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                       THEN (lower(part_of_day) in (  "pt"   ,"npt"  ) OR part_of_day IS NULL)
                       ELSE lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a  ) end
					 and
                    CASE WHEN dev_period[OFFSET(0)] < "2019-10-27"
                      THEN lower(advertiser_group) not in ('star tv network') else 1=1 end
                    and 
					   CASE WHEN all_advertiser_selected = true
					   then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
					   else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
					 and 
					   CASE WHEN all_agency_selected = true
					  then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
					  else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
					 and 
					   CASE WHEN all_sub_agency_selected = true
					   then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
   else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
                   and lower(spot_status) in ('aired', 'placed')
               GROUP BY advertiser_group
           )
           GROUP BY advertiser_group
        ) as dev_actual
    using(advertiser_group)

    FULL JOIN

    (
          SELECT advertiser_group ,
          sum (revenue /agency_count) as booked_revenue,
          sum(revenue_internal/agency_count) as booked_revenue_internal
          from
          (
             SELECT advertiser_group ,sum (revenue) as revenue,
             case when lower(advertiser_group) in ('star tv network') then sum(revenue) else null end as revenue_internal,
             case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
              FROM {{ref('spr_advertiser')}}
              WHERE
                  lower(channel_name)= lower(var_channel)
                    and  (date between var_booked_start_date and var_booked_end_date)
                    and
                    CASE WHEN all_region_selected = true
                         THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                         ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                       THEN (lower(part_of_day) in (  "pt"   ,"npt"  ) OR part_of_day IS NULL)
                       ELSE lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a  ) end
					and
                    CASE WHEN var_booked_start_date < "2019-10-27"
                      THEN lower(advertiser_group) not in ('star tv network') else 1=1 end
                    and 
					  CASE WHEN all_advertiser_selected = true
					  then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
					  else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
					and 
					  CASE WHEN all_agency_selected = true
					 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
					 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
					and 
					  CASE WHEN all_sub_agency_selected = true
					  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
					  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
              GROUP BY advertiser_group
          )
          GROUP BY advertiser_group
    ) as curr_booked
    using(advertiser_group)
)