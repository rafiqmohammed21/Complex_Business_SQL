{{
    config
    (
        schema='revenue_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_end_date DATE, dev_period ARRAY<DATE>, var_channel STRING, var_region ARRAY<STRING>, var_pt_npt STRING, var_impact_regular ARRAY<STRING>, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, overall BOOL, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL'
    )

}}

select 
case when overall then advertiser_group else "CONST" end as advertiser_group,
round(sum(revenue)/10000000,2) as revenue,
round(sum(deviation)/10000000,2) deviation,
case when overall then sum(percentage_deviation) else round((safe_divide(((ifnull(sum(revenue),0)/(date_diff(var_end_date,var_start_date,day)+1)) - (ifnull(sum(deviation),0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))),
                           (ifnull(sum(deviation),0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))))*100,2) end as percentage_deviation
 from                           
(select coalesce(curr_data.advertiser_group, dev_data.advertiser_group) as advertiser_group, revenue, deviation,
        round((safe_divide(((safe_divide(ifnull(revenue,0),(date_diff(var_end_date,var_start_date,day)+1))) - (ifnull(deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))),(ifnull(deviation,0)/(CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1) + (date_diff(dev_period[OFFSET(3)],dev_period[OFFSET(2)],day)+1) + (date_diff(dev_period[OFFSET(5)],dev_period[OFFSET(4)],day)+1)
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN (date_diff(dev_period[OFFSET(1)],dev_period[OFFSET(0)],day)+1)
                           ELSE 1 end))))*100,2) as percentage_deviation 
         from
            (
                SELECT advertiser_group ,sum (revenue /agency_count) as revenue
                from(
                SELECT advertiser_group , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
                    CASE WHEN lower(var_pt_npt) = "npt"
                       THEN sum(channel_npt_revenue)
                       WHEN lower(var_pt_npt) = "pt"
                       THEN sum(channel_pt_revenue)
                       ELSE sum(revenue) END AS revenue,
                FROM {{ref('ro')}}
                WHERE
                    lower(channel_name) = lower(var_channel)
                    and (airing_date between var_start_date and var_end_date)
                    and
                    CASE WHEN var_start_date < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                    and 
					  CASE WHEN all_advertiser_selected = true
					  then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
					  else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
					and 
					  CASE WHEN all_agency_selected = true
					 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
					 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
					and 
					  CASE WHEN all_sub_agency_selected = true
					  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
					  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end       
                    and
                    CASE WHEN all_region_selected = true
                         THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                         ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
                 GROUP BY advertiser_group
               )
               GROUP BY advertiser_group
      ) as curr_data
      
      FULL JOIN
      
      (
        SELECT advertiser_group ,sum (revenue /agency_count) as deviation
        from(
            SELECT advertiser_group ,case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
                CASE WHEN lower(var_pt_npt) = "npt"
                       THEN sum(channel_npt_revenue)
                       WHEN lower(var_pt_npt) = "pt"
                       THEN sum(channel_pt_revenue)
                       ELSE sum(revenue) END AS revenue,
            FROM {{ref('ro')}}
            WHERE
                lower(channel_name) = lower(var_channel)
                and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN airing_date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or airing_date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or airing_date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN airing_date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE airing_date between '1891-01-01' and '1891-01-07' end                   
                    and 
                    CASE WHEN dev_period[OFFSET(0)] < "2019-10-27" THEN
                        lower(advertiser_group) not in ('star tv network') else 1=1 end
                    and 
					   CASE WHEN all_advertiser_selected = true
					   then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
					   else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
					 and 
					   CASE WHEN all_agency_selected = true
					  then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
					  else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
					 and 
					   CASE WHEN all_sub_agency_selected = true
					   then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
					   else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
                    and
                    CASE WHEN all_region_selected = true
                         THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                         ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                    and
                    CASE WHEN ARRAY_LENGTH(var_impact_regular) = 2
                         THEN (lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) OR impact_regular IS NULL)
                         ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
            GROUP BY advertiser_group
           )
           GROUP BY advertiser_group
      ) as dev_data
      on curr_data.advertiser_group = dev_data.advertiser_group       
)
group by advertiser_group