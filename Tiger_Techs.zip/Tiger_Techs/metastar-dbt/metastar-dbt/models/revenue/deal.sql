{{ config(schema='revenue_reports') }}
(
select deal.*,monthly_agency.agency ,monthly_agency.sub_agency  from
(SELECT * FROM {{source('revenue','deal')}}) as deal
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}}) as monthly_agency
on lower(deal.advertiser_group) = lower(monthly_agency.advertiser_group) 
-- and deal.month = monthly_agency.month
-- and deal.year = monthly_agency.year
  )