{{
    config(
        schema='master',
        materialized='table'
    )
}}

SELECT
  *
FROM
  `mint-bi-reporting.master.reg_channel_master`FOR SYSTEM_TIME AS OF
TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 5 DAY)