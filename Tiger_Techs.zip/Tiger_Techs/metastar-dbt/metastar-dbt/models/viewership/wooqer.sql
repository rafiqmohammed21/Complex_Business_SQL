 {{ config(schema='viewership_reports') }}

 SELECT wooqer.*,monthly_agency.agency ,monthly_agency.sub_agency  from
  (SELECT *,EXTRACT(Month FROM date) AS month,EXTRACT(YEAR FROM date) AS year FROM {{source('viewership','wooqer')}}) as wooqer
  left join
  (SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}} ) as monthly_agency
on lower(wooqer.advertiser_group) = lower(monthly_agency.advertiser_group) 
-- and wooqer.month = monthly_agency.month
-- and wooqer.year = monthly_agency.year

