{{ config(schema='viewership_reports') }}
SELECT date FROM {{source('viewership','ent_spot_ratings_channel_tg')}}