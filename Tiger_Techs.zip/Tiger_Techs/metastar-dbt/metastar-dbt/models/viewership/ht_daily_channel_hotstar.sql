{{ config(schema='viewership_reports') }}


with cm as (select cm.Channel_Name, cm.Channel_Group_name, cm.Business_Unit, cm.Business_Unit_Genre, cm.STAR_Genre
from {{source('master', 'spr_channel_master')}} cm
where lower(SOURCE) ="hotstar"
group by 1,2,3,4,5)
SELECT ht.channel_name,
ht.daily_video_views as daily_video_viewer,
ht.daily_watch_time as watch_time,
ht.date,
cm.Channel_Group_name, cm.Business_Unit, cm.Business_Unit_Genre, cm.STAR_Genre, 'universe' as target, 'india' as regions
FROM {{source('viewership', 'ht_ent_daily_channel_performance')}} ht
LEFT JOIN cm
ON lower(ht.channel_name) = lower(cm.Channel_Name)