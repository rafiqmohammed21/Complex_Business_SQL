{{ config(schema='viewership_reports') }}
WITH qty_hd_al AS (
  SELECT quantity
        ,date
        ,ROW_NUMBER() OVER (PARTITION BY customer_nbr, state ORDER BY quantity DESC) max_qty_cust_state
  FROM {{source('viewership','dist_data')}}
  WHERE star='Star' and disney_Star='Star' and alacarte_bouquet= 'ALACARTE' and sd_hd='HD'
)
,active_universe AS (
  SELECT date ,SUM(active_universe) as universe
  FROM {{source('viewership','dist_active_universe')}}
  GROUP BY date
)
,qty_basic AS (

  SELECT date
  ,"Bouquet" as pack
  ,SUM(CASE WHEN star='Star' and disney_star='Star' and alacarte_bouquet='BOUQUET' and vp in ('Premium','Value') THEN quantity ELSE NULL END) as quantity
  FROM {{source('viewership','dist_data')}}
  GROUP BY date
  UNION ALL

  SELECT date
    ,"Premium" as pack
    ,SUM(CASE WHEN star='Star' and disney_Star='Star' and alacarte_bouquet= 'BOUQUET' and vp in ('Premium', 'English Lite') THEN quantity ELSE NULL END) as quantity
  FROM {{source('viewership','dist_data')}}
  GROUP BY date
  UNION ALL

  SELECT bq.date,"HD" as pack,bq.quantity + al.quantity
  FROM
  (
    SELECT date,SUM(CASE WHEN star='Star' and disney_Star='Star' and alacarte_bouquet= 'BOUQUET' and sd_hd='HD' and vp in ('Premium', 'Value') THEN quantity ELSE NULL END) as quantity
    FROM {{source('viewership','dist_data')}}
    GROUP BY date
  ) bq JOIN
  (
    SELECT date,SUM(CASE WHEN max_qty_cust_state = 1 THEN quantity ELSE NULL END) as quantity
    FROM qty_hd_al
    GROUP BY date
  ) al on bq.date = al.date
  UNION ALL

  SELECT date,"Kids" as pack
    ,SUM(CASE WHEN disney_Star='Disney' and alacarte_bouquet = 'BOUQUET' and service_name not in ('Hindi Entertainment Bouquet','HD Bouquet')THEN quantity ELSE NULL END)
    +SUM(CASE WHEN disney_Star='Disney' and alacarte_bouquet = 'ALACARTE' and service_name not in ('UTV Movies','UTV Action','UTV HD','Bindass @ Rs 0.1','Disney International HD','Bindass @ Rs 1')THEN quantity ELSE NULL END)
    as quantity
  FROM {{source('viewership','dist_data')}}
  GROUP BY date

)
SELECT qty_basic.date,qty_basic.pack,qty_basic.quantity*100 as quantity,active_universe.universe
FROM qty_basic
INNER JOIN active_universe on qty_basic.date = active_universe.date