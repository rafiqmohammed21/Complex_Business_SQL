{{ config(schema='viewership_reports') }}
with barc as (
  select *
    from {{source('viewership','reg_spot_ratings')}}
)

SELECT barc.*, CHANNEL_ID, CHANNEL_GROUP_NAME, GENRE_NAME, SUB_GENRE_NAME, NETWORK_NAME, IS_ACTIVE, SUBSCRIPTION, SHORT_NAME, IS_SOUTH_CHANNEL, LANGUAGE, TYPE_OF_BEAM, advertiser_group_name as Advertiser_Common_name, Agency_name, Advertiser_Category, Tamil_Region, Telugu_Region, Malayalam_Region, Kannada_Region, Marathi_Region, Bengali_Region FROM
 barc
left join
(select * from {{source('master','reg_channel_master')}} where source = 'BARC') as c
    on barc.channel = c.CHANNEL_NAME
left join
    {{source('master','reg_advertiser_master')}} as a
    on barc.advertiser = a.Advertiser_name