{{ config(schema='viewership_reports') }}


with cm as (select cm.Channel_Name, cm.Channel_Group_name, cm.Business_Unit, cm.Business_Unit_Genre
from {{source('master', 'spr_channel_master')}} cm
where lower(SOURCE) ="hotstar"
group by 1,2,3,4)
SELECT ht.channel_name,
weekly_video_views as unique_users,
weekly_watch_time aswatch_time,
week_starting_on,
year,
week,
cm.Channel_Group_name,cm.Business_Unit, cm.Business_Unit_Genre, 'universe' as target, 'india' as regions
FROM {{source('viewership', 'ht_ent_weekly_channel_performance')}} ht
LEFT JOIN cm
ON lower(ht.channel_name) = lower(cm.Channel_Name)