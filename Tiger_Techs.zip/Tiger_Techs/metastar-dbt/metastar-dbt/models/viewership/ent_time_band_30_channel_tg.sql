
{{
    config(
        schema='viewership',
        materialized='table',
        partition_by='date',
        partitions=dbt.partition_range(var('dates', default=yesterday())),
        verbose=True
    )
}}

WITH chnl_pri_tg AS (
  SELECT ecj.channel,ecj.genre,ecj.sub_genre,tgl.channel_primary_tg
  FROM
  (
   SELECT DISTINCT esr.channel, ecm.genre, ecm.sub_genre
   FROM (SELECT channel FROM {{source('viewership','ent_time_band_30')}} WHERE date = '{{((var('dates', default=yesterday()))|string)[0:4]+'-'+((var('dates', default=yesterday()))|string)[4:6]+'-'+((var('dates', default=yesterday()))|string)[6:8]}}') AS esr
   INNER JOIN (SELECT DISTINCT channel_name,genre,sub_genre FROM {{source('master','ent_channel_master')}}) ecm ON esr.channel = ecm.channel_name
  ) as ecj

  INNER JOIN

  (
   SELECT DISTINCT genre, sub_genre, channel_primary_tg
   FROM {{source('master','ent_channel_master')}}
   WHERE network in ('Star Network') and genre_tg is not null
  ) tgl

  ON ecj.genre = tgl.genre AND ecj.sub_genre = tgl.sub_genre
 )
SELECT sr.*
FROM {{source('viewership','ent_time_band_30')}} sr
INNER JOIN chnl_pri_tg ON sr.channel = chnl_pri_tg.channel AND lower(CONCAT(sr.target,' ', sr.region)) = lower(chnl_pri_tg.channel_primary_tg)
WHERE date = '{{((var('dates', default=yesterday()))|string)[0:4]+'-'+((var('dates', default=yesterday()))|string)[4:6]+'-'+((var('dates', default=yesterday()))|string)[6:8]}}'