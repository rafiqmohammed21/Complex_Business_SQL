{{ config(schema='viewership_reports') }}
SELECT (case when channel_group_name is null then concat(channel,'*') else channel_group_name end) as channel_name
      ,(case when advertiser_common_name is null then concat( advertiser,'*') else advertiser_common_name end) as advertiser_name
      ,target
      ,region
      ,level
      ,brand
      ,genre_name
      ,sub_genre_name
      ,network_name
      ,is_active
      ,subscription
      ,short_name
      ,is_south_channel
      ,language
      ,type_of_beam
      ,agency_name, advertiser_category
      ,tamil_region, telugu_region, malayalam_region, kannada_region, marathi_region, bengali_region
      ,(ratings * duration / 10) as grp
      ,date
      ,duration
FROM {{source('viewership','reg_spot_ratings')}} sr
LEFT JOIN (select * from {{source('master','reg_channel_master')}} where lower(source) = 'barc') as c on sr.channel = c.channel_name
LEFT JOIN {{source('master','reg_advertiser_master')}} as a on sr.advertiser = a.advertiser_name
