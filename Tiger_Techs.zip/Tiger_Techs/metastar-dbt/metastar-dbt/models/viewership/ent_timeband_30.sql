{{ config(schema='viewership_reports') }}
select * from
(SELECT region ,target, channel as BARC_channel_name,date,week ,year,time_band,start_time as timeband_start_time,end_time as timeband_end_time,concat(target," ",region) as tg_market,
 cast(SUBSTR(CAST(REGEXP_REPLACE(start_time, ':', '') as string),1,4) as INT64) as BARC_start_time,
       cast(SUBSTR(CAST(REGEXP_REPLACE(end_time, ':', '') as string),1,4) as INT64) as BARC_end_time, 'BARC' as BARC_source_name,ratings ,impressions ,target_audience,
lower(FORMAT_DATE('%a', date)) as day,
(CASE WHEN lower(FORMAT_DATE('%a', date)) = 'mon' THEN 1
WHEN lower(FORMAT_DATE('%a', date)) = 'tue' THEN 2
WHEN lower(FORMAT_DATE('%a', date)) = 'wed' THEN 3
WHEN lower(FORMAT_DATE('%a', date)) = 'thu' THEN 4
WHEN lower(FORMAT_DATE('%a', date)) = 'fri' THEN 5
WHEN lower(FORMAT_DATE('%a', date)) = 'sat' THEN 6
WHEN lower(FORMAT_DATE('%a', date)) = 'sun' THEN 7
else 0 end) as day_num
FROM  {{source('viewership','ent_time_band_30_channel_tg')}}) as timeband_30
left join
(select distinct source_name,channel_name as ch_name,channel_group_name as channel_name,genre ,sub_genre ,type_of_beam ,subscription ,network  from {{source('master','ent_channel_master')}} where source_name in ('BARC')) as ch_master
on timeband_30.BARC_channel_name  = ch_master.ch_name