{{ config(schema='viewership_reports') }}

SELECT
    CAST(mtWPC.peak_concurrency AS FLOAT64)/1000000 as peak_concurrency_in_millions,
    dHTMP.edition_number as edition_number,
    dHTMP.match_no as match,
    htMTVV.match_id as match_no,
    htMTVV.date as date,
    htMTVV.tournament_name as event,
    htMTVV.season_name as edition,
    dHTMP.team1 as team1,
    dHTMP.team2 as team2,
    CAST(htMTVV.daily_watch_time AS FLOAT64) as wc_dwt_in_minutes,
    htMTVV.daily_video_viewers as wc_dvv,
    'universe' as target,
    'india' as regions,
    EXTRACT(YEAR from htMTVV.date) as f_year
FROM  {{source('viewership', 'ht_spt_matchwise_video_viewers')}} htMTVV
JOIN {{source('master', 'ht_master_mapping')}} dHTMP ON
    dHTMP.date = htMTVV.date AND
    dHTMP.match_number = htMTVV.match_id AND
    dHTMP.event = htMTVV.tournament_name AND
    dHTMP.edition = htMTVV.season_name AND
    dHTMP.edition_number = htMTVV.season_id AND
    dHTMP.F_year = EXTRACT(YEAR FROM htMTVV.date)
JOIN {{source('viewership', 'ht_spt_match_wise_peak_concurrency')}} mtWPC ON
    -- htMTVV.Tournament_id = CAST(mtWPC.tournament_id AS INT64) AND
    htMTVV.tournament_name = mtWPC.tournament_name AND
    htMTVV.season_id = CAST(mtWPC.season_id AS INT64) AND
    htMTVV.season_name = mtWPC.season_name AND
    htMTVV.game_name = mtWPC.game_name AND
    htMTVV.match_id = CAST(mtWPC.match_id AS INT64) AND
    htMTVV.match_name = mtWPC.match_name AND
    htMTVV.date = CAST(mtWPC.date AS DATE)