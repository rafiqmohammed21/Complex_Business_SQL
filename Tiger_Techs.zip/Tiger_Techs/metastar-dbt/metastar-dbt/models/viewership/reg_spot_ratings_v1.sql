{{ config(schema='viewership_reports') }}

select
reg_spot_rating.row_num,
reg_spot_rating.target,
reg_spot_rating.BARC_region,
reg_spot_rating.sector,
reg_spot_rating.category,
reg_spot_rating.brand,
reg_spot_rating.advertiser_name,
reg_spot_rating.BARC_advertiser_group,
reg_spot_rating.master_programme,
reg_spot_rating.position,
reg_spot_rating.level,
reg_spot_rating.event_type,
reg_spot_rating.promo_type,
reg_spot_rating.promo_category,
reg_spot_rating.promo_sponsor_name,
reg_spot_rating.promo_programme_name,
reg_spot_rating.pib,
reg_spot_rating.tib,
reg_spot_rating.pp_start_time,
reg_spot_rating.cp_start_time,
reg_spot_rating.channel,
reg_spot_rating.start_time_av_tm,
reg_spot_rating.end_time_av_tm,
reg_spot_rating.break_code,
reg_spot_rating.date,
reg_spot_rating.week,
reg_spot_rating.programme_genre,
reg_spot_rating.programme_theme,
reg_spot_rating.duration,
reg_spot_rating.ratings,
reg_spot_rating.impressions,
reg_spot_rating.target_av,
reg_spot_rating.year,
reg_spot_rating.timeband_start_time,
reg_spot_rating.timeband_end_time,
reg_spot_rating.barc_year,
reg_spot_rating.tg_market,
reg_spot_rating.BARC_channel_name,
reg_spot_rating.BARC_start_time,
reg_spot_rating.BARC_end_time,
reg_spot_rating.BARC_source_name,
reg_spot_rating.month,
reg_spot_rating.day,
reg_spot_rating.day_num,
reg_spot_rating.channel_name,
reg_spot_rating.genre,
reg_spot_rating.sub_genre,
reg_spot_rating.type_of_beam,
reg_spot_rating.subscription,
reg_spot_rating.network,
reg_spot_rating.channel_primary_tg,
reg_spot_rating.channel_secondary_tg,
reg_spot_rating.genre_tg,
reg_spot_rating.advertiser,
case when star_internal_buys.advertiser_group_name is NULL then reg_spot_rating.region
else 'WEST' end as region,
case when star_internal_buys.advertiser_group_name is NULL then reg_spot_rating.advertiser_group
else star_internal_buys.advertiser_group_name end as advertiser_group,
reg_spot_rating.agency,
reg_spot_rating.sub_agency,
reg_spot_rating.impact_regular,
reg_spot_rating.pt_npt,
reg_spot_rating.channel_def_name
from
(
select reg_spot_rating.*,ch_master.part_of_day as pt_npt,ch_master.channel_group_name as channel_def_name   from
(select reg_spot_rating.*,
CASE WHEN barc_impact.tag is NULL then 'regular'
else barc_impact.tag  end AS impact_regular from
(
      select reg_spot_rating.*,monthly_agency.agency ,monthly_agency.sub_agency
      from
(
      (
            select spot_rating.*,ch_master.channel_group_name as channel_name,ch_master.genre,ch_master.sub_genre ,ch_master.type_of_beam ,ch_master.subscription,ch_master.network ,ch_master.channel_primary_tg ,ch_master.channel_secondary_tg ,ch_master.genre_tg ,advt_master.*
            from
             (SELECT row_num ,target ,region as BARC_region,sector ,category ,brand,advertiser as advertiser_name,advertiser_group as BARC_advertiser_group,master_programme ,position ,level ,event_type ,promo_type ,promo_category ,promo_sponsor_name ,promo_programme_name ,pib,tib,pp_start_time ,cp_start_time,channel  ,start_time_av_tm ,end_time_av_tm ,break_code ,date,week ,time_band programme_genre ,programme_theme ,duration,ratings ,impressions ,target_av ,year,timeband_start_time ,timeband_end_time ,barc_year  , concat(target," ",region) as tg_market, channel as BARC_channel_name
, cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_start_time, ':', '') as string),1,4) as INT64) as BARC_start_time,
cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_end_time, ':', '') as string),1,5) as INT64) as BARC_end_time,
'BARC' as BARC_source_name,EXTRACT(Month FROM date) AS month,
lower(FORMAT_DATE('%a', date)) as day,
       (CASE WHEN lower(FORMAT_DATE('%a', date)) = 'mon' THEN 1
      WHEN lower(FORMAT_DATE('%a', date)) = 'tue' THEN 2
      WHEN lower(FORMAT_DATE('%a', date)) = 'wed' THEN 3
      WHEN lower(FORMAT_DATE('%a', date)) = 'thu' THEN 4
      WHEN lower(FORMAT_DATE('%a', date)) = 'fri' THEN 5
      WHEN lower(FORMAT_DATE('%a', date)) = 'sat' THEN 6
      WHEN lower(FORMAT_DATE('%a', date)) = 'sun' THEN 7
      else 0 end) as day_num
FROM {{source('viewership','reg_spot_ratings_channel_tg')}}
WHERE level in ('Level 4')) as spot_rating
left join
(SELECT distinct channel_name ,source_name ,channel_group_name ,genre ,sub_genre ,type_of_beam ,subscription ,network,channel_primary_tg ,channel_secondary_tg ,genre_tg   FROM `mint-bi-reporting`.`master`.`reg_channel`
where source_name in ('BARC')) as ch_master
      on spot_rating.BARC_channel_name=ch_master.channel_name
left JOIN
(
      SELECT distinct advertiser_name as advertiser,region, advertiser_group_name as advertiser_group
      FROM {{source('master','reg_advertiser')}}
where lower(source) in ('barc') and region is NOT NULL) AS advt_master
      ON spot_rating.advertiser_name = advt_master.advertiser
)
)as reg_spot_rating
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM  `mint-bi-reporting`.`master`.`reg_month_wise_agency_mappings`) as monthly_agency
      on lower(reg_spot_rating.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and reg_spot_rating.month = monthly_agency.month
-- and reg_spot_rating.year = monthly_agency.year
) as reg_spot_rating
Left join
(SELECT * FROM {{source('master','barc_impact_taggings')}})  as barc_impact
on reg_spot_rating.BARC_channel_name = barc_impact.channel
and reg_spot_rating.date = barc_impact.date
and reg_spot_rating.master_programme = barc_impact.description
and reg_spot_rating.cp_start_time = barc_impact.start_time) as reg_spot_rating
left join
(SELECT *,
(CASE WHEN from_day = 'mon' THEN 1
      WHEN from_day = 'tue' THEN 2
      WHEN from_day = 'wed' THEN 3
      WHEN from_day = 'thu' THEN 4
      WHEN from_day = 'fri' THEN 5
      WHEN from_day = 'sat' THEN 6
      WHEN from_day = 'sun' THEN 7
      else 0 end) as from_day_num,
(CASE WHEN to_day = 'mon' THEN 1
      WHEN to_day = 'tue' THEN 2
      WHEN to_day = 'wed' THEN 3
      WHEN to_day = 'thu' THEN 4
      WHEN to_day = 'fri' THEN 5
      WHEN to_day = 'sat' THEN 6
      WHEN to_day = 'sun' THEN 7
      else 0 end) as to_day_num
FROM {{source('master','reg_channel')}}
where
source_name in ('BARC') and hour_type in ('daypart')) as ch_master
on reg_spot_rating.genre = ch_master.genre
and reg_spot_rating.sub_genre = ch_master.sub_genre
and reg_spot_rating.day_num >= ch_master.from_day_num
and reg_spot_rating.day_num <= ch_master.to_day_num
and reg_spot_rating.BARC_start_time >= ch_master.start_time
and reg_spot_rating.BARC_start_time < ch_master.end_time
  ) as reg_spot_rating
left join
(SELECT distinct   advertiser_name ,advertiser_group_name  FROM  {{source('master','star_internal_buys')}}
where lower(source) in ('barc') ) as star_internal_buys
on reg_spot_rating.advertiser_name = star_internal_buys.advertiser_name