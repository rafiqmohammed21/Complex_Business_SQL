{{ config(schema='viewership_reports') }}
WITH dist_v AS (
    SELECT d.star,d.disney_Star,d.alacarte_bouquet,d.service_name,d.vp,d.sd_hd,d.state,d.date
      ,d.display_state, d.display_group_state
      ,csm.relevant_state
      ,csm.display_channel_name as display_channel_master
      ,SUM(au.active_universe) as universe
      ,SUM(d.quantity) as quantity

    FROM {{source('viewership','dist_data')}} d
    INNER JOIN {{source('viewership','dist_channel_state_master')}} csm on csm.display_channel_name in UNNEST(d.display_channel_name)
    INNER JOIN {{source('viewership','dist_active_universe')}} au on au.states = d.state
    GROUP BY star,disney_Star,alacarte_bouquet,service_name,vp,sd_hd,state,date,display_state,display_group_state,display_channel_master,relevant_state

  )

SELECT dist_v.*
FROM dist_v