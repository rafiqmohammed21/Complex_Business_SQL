
{{ config(schema='viewership_reports') }}
with timeband as (
select  *
 from `mint-bi-reporting`.`viewership`.`reg_time_band_30`
)

SELECT timeband.*,  CHANNEL_ID, CHANNEL_GROUP_NAME, GENRE_NAME, SUB_GENRE_NAME, NETWORK_NAME, IS_ACTIVE, SUBSCRIPTION,              SHORT_NAME, IS_SOUTH_CHANNEL, LANGUAGE, TYPE_OF_BEAM from
    timeband
    left join
    (select * from `mint-bi-reporting`.`master`.`reg_channel_master` where source = 'BARC') as c
    on timeband.channel = c.CHANNEL_NAME
