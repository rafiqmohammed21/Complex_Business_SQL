{{ config(schema='viewership_reports') }}
(

SELECT * FROM {{ref('ent_fact_spot_ratings_v1')}}
UNION ALL
SELECT * FROM {{ref('reg_fact_spot_ratings_v1')}}
)