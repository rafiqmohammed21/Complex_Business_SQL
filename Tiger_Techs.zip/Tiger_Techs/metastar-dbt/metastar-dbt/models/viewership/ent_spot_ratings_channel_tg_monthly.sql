{{
    config(
        schema='viewership',
        materialized='table',
        partition_by='month_start_date',
        partitions=dbt.partition_range(var('dates', default=yesterday())),
        verbose=True
    )
}}
WITH esrmv AS
(
SELECT sr.*, cast (concat(cast (EXTRACT(year from date ) as string),"-",cast (EXTRACT(month from date ) as string) ,"-01") as date) as month_start_date
FROM {{source('viewership','ent_spot_ratings_channel_tg')}} sr
)
SELECT *
FROM esrmv
WHERE month_start_date = '{{((var('dates', default=yesterday()))|string)[0:4]+'-'+((var('dates', default=yesterday()))|string)[4:6]+'-'+((var('dates', default=yesterday()))|string)[6:8]}}'
