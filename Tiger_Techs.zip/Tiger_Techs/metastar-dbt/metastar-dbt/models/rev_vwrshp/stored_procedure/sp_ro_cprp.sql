{{
    config
    (
        schema='rev_vwrshp_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_end_date DATE, dev_period ARRAY<DATE>, lag_start_date DATE, lag_end_date DATE, dev_lag ARRAY<DATE>, var_channel STRING, var_region ARRAY<STRING>, var_pt_npt STRING, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, var_advertiser_category ARRAY<STRING>, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL, all_advertiser_category_selected BOOL'
    )

}}

Select advertiser_group,
SUM(current_revenue)/10000000 as revenue,
SUM(current_ad_grp) as ad_grp,
SUM(deviation_revenue)/10000000 as deviation_revenue,
SUM(deviation_ad_grp) as deviation_ad_grp,
safe_divide( SUM(current_revenue),SUM(current_ad_grp) ) as cprp,
safe_divide( SUM(deviation_revenue),SUM(deviation_ad_grp) ) as deviation_cprp,
((safe_divide(((ifnull(  safe_divide( SUM(current_revenue),SUM(current_ad_grp) )  ,0)/1) - (ifnull( safe_divide( SUM(deviation_revenue),SUM(deviation_ad_grp) ) ,0)/1)),
(ifnull(  safe_divide( SUM(deviation_revenue),SUM(deviation_ad_grp) )  ,0)/1)))*100) as percentage_deviation
             from
                (Select
                coalesce(curr_data.advertiser_group, dev_data.advertiser_group) as advertiser_group,
                current_revenue, current_ad_grp,
                safe_divide(current_revenue,current_ad_grp) as current_ro_cprp,
                deviation_revenue, deviation_ad_grp,
                safe_divide(deviation_revenue,deviation_ad_grp) as deviation_ro_cprp
                from
                (
            SELECT advertiser_group ,sum (revenue) as current_revenue ,sum(fct * rating / 10 ) as current_ad_grp
            from
            (
                SELECT advertiser_group ,onair.start_time,onair.end_time,revenue, fct, avg(rating) as rating , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
                from
                    (
        select channel_name,advertiser_group,channel_primary_tgmarket,agency,sub_agency ,
            product_start_time AS start_time,
            product_end_time AS end_time,
            CASE WHEN var_pt_npt = "npt"
                 THEN sum(channel_npt_revenue)
                 WHEN var_pt_npt = "pt"
                 THEN sum(channel_pt_revenue)
                 ELSE sum(revenue) END AS revenue,

            CASE WHEN var_pt_npt = "npt"
                 THEN sum(channel_npt_fct)
                 WHEN var_pt_npt = "pt"
                 THEN sum(channel_pt_fct)
                 ELSE sum(fct) END AS fct

            FROM {{ref('ro_spd')}}


            WHERE
                lower(channel_name) = lower(var_channel)
                and  ( airing_date between var_start_date and var_end_date )
                and (
                CASE WHEN all_region_selected = true
                     THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                     ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                )
                and (lower(impact_regular) in  ('regular') )
                and
				  CASE WHEN all_advertiser_selected = true
				  then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
				  else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
				and
				  CASE WHEN all_agency_selected = true
				 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
				 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
				and
				  CASE WHEN all_sub_agency_selected = true
				  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
				  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
    and
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end

        GROUP BY channel_name,advertiser_group,channel_primary_tgmarket,agency,sub_agency,start_time,end_time

        ) as onair
                    LEFT JOIN
                    (
                SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time,
                ROUND(   safe_divide( sum(ratings * duration),sum (duration) )  ,6) AS rating

            FROM  {{source(env_var('DBT_TARGET'),'spot_ratings_common')}}

                WHERE
                    lower(channel_name) = lower(var_channel)
                    and lower(pt_npt) in ('pt', 'npt')
                    and lower(channel_def_name) = lower(var_channel)
                    and lower(tg_market) in (
                            Select distinct lower(target_region)

            FROM `mint-bi-reporting`.`master`.`ent_reporting_tg_market`
         where
                            lower(channel_group_name) = lower(var_channel)
                            and reporting_tg = true
                        )
                    and  ( (date between lag_start_date and lag_end_date) )
                GROUP BY channel_name ,start_time,end_time


                    ) as spot_rating
                    ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
                    and onair.start_time <= spot_rating.start_time
                    and onair.end_time >= spot_rating.end_time
                GROUP BY advertiser_group,revenue ,fct,onair.start_time,onair.end_time

            )
            GROUP BY advertiser_group ,agency_count

            ) as curr_data
                FULL JOIN
                (
            SELECT advertiser_group ,sum (revenue ) as deviation_revenue ,sum(fct * rating / 10 ) as deviation_ad_grp
            from
            (
                SELECT advertiser_group ,onair.start_time,onair.end_time,revenue, fct, avg(rating) as rating , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
                from
                    (
        select channel_name,advertiser_group,channel_primary_tgmarket,agency,sub_agency ,
            product_start_time AS start_time,
            product_end_time AS end_time,
            CASE WHEN lower(var_pt_npt) = "npt"
                 THEN sum(channel_npt_revenue)
                 WHEN lower(var_pt_npt) = "pt"
                 THEN sum(channel_pt_revenue)
                 ELSE sum(revenue) END AS revenue,

            CASE WHEN lower(var_pt_npt) = "npt"
                 THEN sum(channel_npt_fct)
                 WHEN lower(var_pt_npt) = "pt"
                 THEN sum(channel_pt_fct)
                 ELSE sum(fct) END AS fct

            FROM {{ref('ro_spd')}}


            WHERE
                lower(channel_name) = lower(var_channel)
                and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN airing_date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or airing_date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or airing_date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN airing_date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE airing_date between '1891-01-01' and '1891-01-07' end
                and (
                CASE WHEN all_region_selected = true
                     THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                     ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                )
                and (lower(impact_regular) in  ( 'regular' ) )
                and
                    CASE WHEN dev_period[OFFSET(0)] < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                and
				   CASE WHEN all_advertiser_selected = true
				   then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
				   else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
				 and
				   CASE WHEN all_agency_selected = true
				  then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
				  else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
				 and
				   CASE WHEN all_sub_agency_selected = true
				   then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
   else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
         and
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end
GROUP BY channel_name,advertiser_group,channel_primary_tgmarket,agency,sub_agency,start_time,end_time

        ) as onair
                    LEFT JOIN
                    (
                SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time,
                ROUND(  safe_divide( sum (ratings * duration),sum (duration) ) ,6) AS rating

            FROM  {{source(env_var('DBT_TARGET'),'spot_ratings_common')}}

                WHERE
                    lower(channel_name) = lower(var_channel)
                    and lower(pt_npt) in ('pt', 'npt')
                    and lower(channel_def_name) = lower(var_channel)
                    and lower(tg_market) in (
                            Select distinct lower(target_region)

            FROM `mint-bi-reporting`.`master`.`ent_reporting_tg_market`
         where
                            lower(channel_group_name) = lower(var_channel)
                            and reporting_tg = true
                        )
                    and CASE WHEN ARRAY_LENGTH(dev_lag)=6
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)] or date between dev_lag[OFFSET(2)] and dev_lag[OFFSET(3)] or date between dev_lag[OFFSET(4)] and dev_lag[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_lag) = 2
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                GROUP BY channel_name ,start_time,end_time


                    ) as spot_rating
                    ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
                    and onair.start_time <= spot_rating.start_time
                    and onair.end_time >= spot_rating.end_time
                GROUP BY advertiser_group,revenue ,fct,onair.start_time,onair.end_time

            )
            GROUP BY advertiser_group ,agency_count

            ) as dev_data
                on curr_data.advertiser_group=dev_data.advertiser_group
    )
group by advertiser_group