{{
    config
    (
        schema='rev_vwrshp_reports',
        materialized='stored_procedure',
        parameters='channel STRING, periods ARRAY<STRUCT<start_date DATE, end_date DATE>>, var_region ARRAY<STRING>, var_pt_npt ARRAY<STRING>, var_impact_regular ARRAY<STRING>, var_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL'
    )

}}
DECLARE var_dt DATE DEFAULT '2020-01-01';
SET var_dt =(SELECT max(date) from {{ref('barc_dates')}} WHERE date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date);
select coalesce(revenue.advertiser_group, vwrshp.advertiser_group) as advertiser_group,
ro, actual_revenue , booked_revenue , revenue.revenue , deals , projection ,
channel_grp_ad  as grp, genre_grp , market_share ,
safe_divide(revenue_exit_cprp,channel_grp_ad) as exit_cprp
from
(
(
    select advertiser_group,
    sum(ro_revenue/agency_count)/10000000 as ro, 
    sum(actual_revenue/agency_count)/10000000 as actual_revenue,
    sum(booked_revenue/agency_count)/10000000 as booked_revenue,
    sum(total_revenue/agency_count)/10000000 as revenue,
    sum(deals_revenue/agency_count)/10000000 as deals, 
    sum(projection_revenue/agency_count)/10000000 as projection,
    sum(actual_revenue_exit_cprp /agency_count_exit_cprp) as revenue_exit_cprp,
    from
    ((select advertiser_group,
    sum(ro_revenue) ro_revenue, 
    sum(actual_revenue) as actual_revenue,
    sum(booked_revenue) as booked_revenue,
    sum(total_revenue) as total_revenue,
    sum(deals_revenue) as deals_revenue, 
    sum(projection_revenue) as projection_revenue,
    case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
    from 
      {{source('revenue','ent_fact_revenue')}}
    where
      lower(channel_name) = lower(channel)
      and CASE 
             WHEN ARRAY_LENGTH(periods)=3
              THEN 
                date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date 
                or date between periods[OFFSET(1)].start_date and periods[OFFSET(1)].end_date
                or date between periods[OFFSET(2)].start_date and periods[OFFSET(2)].end_date
             WHEN ARRAY_LENGTH(periods) = 1
              THEN date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date
             ELSE date between '1891-01-01' and '1891-01-07' end
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN (lower(pt_npt) in ("pt", "npt", "dead_hours") OR pt_npt IS NULL)
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and CASE 
            WHEN ARRAY_LENGTH(var_impact_regular) = 2
              THEN (lower(impact_regular) in ("impact", "regular") OR impact_regular IS NULL)
            ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
      and
         CASE WHEN periods[OFFSET(0)].start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
     and 
      CASE WHEN all_advertiser_selected = true
      then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
      else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
    and 
      CASE WHEN all_agency_selected = true
     then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
     else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
    and 
      CASE WHEN all_sub_agency_selected = true
      then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
      else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
    GROUP BY advertiser_group) as rev
    
    FULL JOIN
    
    (select advertiser_group,
    sum(actual_revenue) as actual_revenue_exit_cprp,
    case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count_exit_cprp
    from 
      {{source('revenue','ent_fact_revenue')}}
    where
      lower(channel_name) = lower(channel)
      and CASE 
             WHEN ARRAY_LENGTH(periods)=3
              THEN 
                date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date 
                or date between periods[OFFSET(1)].start_date and periods[OFFSET(1)].end_date
                or date between periods[OFFSET(2)].start_date and periods[OFFSET(2)].end_date
             WHEN ARRAY_LENGTH(periods) = 1
              THEN date between periods[OFFSET(0)].start_date and var_dt
             ELSE date between '1891-01-01' and '1891-01-07' end
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN (lower(pt_npt) in ("pt", "npt", "dead_hours") OR pt_npt IS NULL)
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and (lower(impact_regular) in ("regular"))
      and
         CASE WHEN periods[OFFSET(0)].start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
      and 
      CASE WHEN all_advertiser_selected = true
      then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
      else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
    and 
      CASE WHEN all_agency_selected = true
     then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
     else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
    and 
      CASE WHEN all_sub_agency_selected = true
      then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
      else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
    GROUP BY advertiser_group) as exit_cprp
    using(advertiser_group)
    )
    group by advertiser_group
   ) as revenue

FULL JOIN

(
    select coalesce(ch_grp.advertiser_group,gen_grp.advertiser_group) as advertiser_group,channel_grp as channel_grp_ad,genre_grp as genre_grp, safe_divide(channel_grp,genre_grp)*100 as market_share
from
(select advertiser_group, ((ch_grp/agency_count)/region_count) as channel_grp from
(select advertiser_group, sum (ch_grp) as ch_grp,
case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
case when count(distinct region )!=0 then count(distinct region ) else 1 end as region_count
from
(SELECT channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, sum (ad_grp) as ch_grp FROM {{source('viewership','ent_fact_viewership')}}
where
 lower(channel_name) = lower(channel)
      and lower(channel_def_name) = lower(channel)
      and CASE 
             WHEN ARRAY_LENGTH(periods)=3
              THEN 
                date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date 
                or date between periods[OFFSET(1)].start_date and periods[OFFSET(1)].end_date
                or date between periods[OFFSET(2)].start_date and periods[OFFSET(2)].end_date
             WHEN ARRAY_LENGTH(periods) = 1
              THEN date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date
             ELSE date between '1891-01-01' and '1891-01-07' end
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN lower(pt_npt) in ("pt", "npt")
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and CASE 
            WHEN ARRAY_LENGTH(var_impact_regular) = 2
              THEN (lower(impact_regular) in ("impact", "regular") OR impact_regular IS NULL)
            ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
      and
         CASE WHEN periods[OFFSET(0)].start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
      and 
      CASE WHEN all_advertiser_selected = true
      then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
      else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
    and 
      CASE WHEN all_agency_selected = true
     then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
     else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
    and 
      CASE WHEN all_sub_agency_selected = true
      then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
      else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
group by channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency)
group by advertiser_group
)) as ch_grp
FULL JOIN
(select advertiser_group, ((genre_grp/agency_count)/region_count) as genre_grp from
(select advertiser_group, sum (genre_grp) as genre_grp,
case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
case when count(distinct region )!=0 then count(distinct region ) else 1 end as region_count
from
(SELECT channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, sum (ad_grp) as genre_grp FROM {{source('viewership','ent_fact_viewership')}}
where
      lower(channel_def_name) = lower(channel)
      and CASE 
             WHEN ARRAY_LENGTH(periods)=3
              THEN 
                date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date 
                or date between periods[OFFSET(1)].start_date and periods[OFFSET(1)].end_date
                or date between periods[OFFSET(2)].start_date and periods[OFFSET(2)].end_date
             WHEN ARRAY_LENGTH(periods) = 1
              THEN date between periods[OFFSET(0)].start_date and periods[OFFSET(0)].end_date
             ELSE date between '1891-01-01' and '1891-01-07' end
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN lower(pt_npt) in ("pt", "npt")
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and CASE 
            WHEN ARRAY_LENGTH(var_impact_regular) = 2
              THEN (lower(impact_regular) in ("impact", "regular") OR impact_regular IS NULL)
            ELSE lower(impact_regular) in (SELECT lower(a) FROM UNNEST(var_impact_regular) a) end
      and
         CASE WHEN periods[OFFSET(0)].start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
      and 
      CASE WHEN all_advertiser_selected = true
      then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
      else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
    and 
      CASE WHEN all_agency_selected = true
     then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
     else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
    and 
      CASE WHEN all_sub_agency_selected = true
      then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
      else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
group by  channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency)
group by advertiser_group
)) as gen_grp
using(advertiser_group)
) as vwrshp
on lower(revenue.advertiser_group) = lower(vwrshp.advertiser_group) 
)