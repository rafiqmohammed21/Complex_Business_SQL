{{
    config
    (
        schema='rev_vwrshp_reports',
        materialized='stored_procedure',
        parameters='par_channel_name STRING'
    )

}}

WITH

spr_cte AS(SELECT max(telecast_date) as updated_date FROM `mint-bi-reporting.revenue.spr`
WHERE telecast_date between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

,reporting_tg_market_cte as (SELECT target_region   FROM (select channel_group_name, target_region,reporting_tg from `mint-bi-reporting.master.ent_reporting_tg_market`
union all select channel_group_name, target_region,reporting_tg from `mint-bi-reporting.master.reg_reporting_tg_market`) WHERE lower(channel_group_name) = lower(par_channel_name) and reporting_tg = true)

,funnel_cte AS (SELECT EXTRACT(date from max(updated_at)) as updated_date FROM ( select * from `mint-bi-reporting.revenue.ent_funnel` union all
select * from `mint-bi-reporting.revenue.reg_funnel` )
WHERE EXTRACT(date from updated_at) between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

,ro_cte as (SELECT EXTRACT(date from max(release_order_updated_at)) as updated_date FROM `mint-bi-reporting.revenue.ro`
WHERE EXTRACT(date from release_order_updated_at) between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

, deal_cte as (SELECT EXTRACT(date from max(spr_airing_start_date)) as updated_date FROM `mint-bi-reporting.revenue.deal`
WHERE EXTRACT(date from spr_airing_start_date) between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

,wooqer_cte as (SELECT EXTRACT(date from max(updated_at)) as updated_date FROM `mint-bi-reporting.viewership.wooqer`
WHERE EXTRACT(date from updated_at) between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

,ad_revenue_target_cte as (SELECT EXTRACT(date from max(updated_at)) as updated_date FROM (select * from `mint-bi-reporting.revenue.ent_ad_revenue_target` union all
select * from `mint-bi-reporting.revenue.reg_ad_revenue_target`)
WHERE EXTRACT(date from updated_at) between date_sub(current_date, interval 3 month) and date_add(current_date, interval 2 month))

,barc_year_cte as (select * from (SELECT distinct week, barc_year as year from viewership.ent_spot_ratings_channel_tg
                            WHERE date between date_sub(current_date, interval 120 day) and current_date
union all SELECT distinct week, barc_year as year from viewership.reg_spot_ratings_channel_tg
                            WHERE date between date_sub(current_date, interval 120 day) and current_date )
                            order by year desc , week desc limit 1 )


select STRUCT( barc_year_cte.week as week, barc_year_cte.year as year) as barc_year_week
, date_sub(current_date, interval 1 day)  as spr_to_date
, reporting_tg_market_cte.target_region as channel_primary_tg
,funnel_cte.updated_date as projection
,ro_cte.updated_date as ro
,deal_cte.updated_date as deals
,spr_cte.updated_date as actual_booked
,ad_revenue_target_cte.updated_date as target
,wooqer_cte.updated_date as productivity
,'Star Data Lake' as data_source
from barc_year_cte, reporting_tg_market_cte, funnel_cte, ro_cte, deal_cte,spr_cte, ad_revenue_target_cte, wooqer_cte