{{
    config
    (
        schema='test_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_end_date DATE, dev_period ARRAY<DATE>, var_channel STRING, var_region ARRAY<STRING>, var_pt_npt ARRAY<STRING>, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>,all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL'
    )

}}
DECLARE var_dt DATE DEFAULT '2020-01-01';
SET var_dt =(SELECT max(date) from {{ref('barc_dates')}} WHERE date between var_start_date and var_end_date);

Select advertiser_group,ROUND(SUM(current_revenue)/10000000,2) as total_revenue, ROUND(SUM(current_ad_grp),2) as total_ad_grp, ROUND(SUM(deviation_revenue)/10000000,2) as total_deviation_revenue, ROUND(SUM(deviation_ad_grp),2) as total_deviation_ad_grp, ROUND(SUM(current_revenue)/SUM(current_ad_grp),2) as exit_cprp, ROUND(SUM(deviation_revenue)/SUM(deviation_ad_grp),2) as deviation_exit_cprp, round((safe_divide(((ifnull(SUM(current_revenue)/SUM(current_ad_grp),0)/1) - (ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)),(ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)))*100,2) as percentage_deviation
from(
Select coalesce(curr_data.advertiser_group,dev_data.advertiser_group, curr_ch_grp.advertiser_group, dev_ch_grp.advertiser_group) as advertiser_group,
sum(curr_revenue/curr_data.agency_count) as current_revenue ,
sum(dev_revenue/dev_data.agency_count) as deviation_revenue, sum((curr_channel_grp /curr_ch_grp.agency_count)/curr_ch_grp.region_count) as current_ad_grp , sum((dev_channel_grp/dev_ch_grp.agency_count)/dev_ch_grp.region_count) as deviation_ad_grp
from
(
(select advertiser_group, sum(actual_revenue) as curr_revenue,
    case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
    from {{source('revenue','ent_fact_revenue')}}
    where
      lower(channel_name) = lower(var_channel)
                  and  date between var_start_date and var_dt
                  and (
                  CASE WHEN all_region_selected = true
                       THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
                       ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
                  )
                  and(
                  CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                       THEN (lower(pt_npt) in (  "pt" ,"npt", "dead_hours"  ) OR pt_npt IS NULL)
                       ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a  ) end
                  )
                  and (lower(impact_regular) in  ( 'regular' ) )
                  and
                    CASE WHEN var_start_date < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                  and 
                    CASE WHEN all_advertiser_selected = true
                    then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
                    else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
                  and 
                    CASE WHEN all_agency_selected = true
                   then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
                   else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
                  and 
                    CASE WHEN all_sub_agency_selected = true
                    then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
                    else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
    GROUP BY advertiser_group) as curr_data

FULL JOIN

(select advertiser_group, sum(actual_revenue) as dev_revenue,
    case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
    from {{source('revenue','ent_fact_revenue')}}
    where
      lower(channel_name) = lower(var_channel)
                  and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                  and (
                  CASE WHEN all_region_selected= true
                       THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
                       ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
                  )
                  and(
                  CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                       THEN (lower(pt_npt) in (  "pt"   ,"npt", "dead_hours"  ) OR pt_npt IS NULL)
                       ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a  ) end
                  
                  )
                  and (lower(impact_regular) in  ( 'regular' ) )
                  and
                    CASE WHEN dev_period[OFFSET(0)] < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                   and 
                     CASE WHEN all_advertiser_selected = true
                     then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
                     else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
                   and 
                     CASE WHEN all_agency_selected = true
                    then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
                    else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
                   and 
                     CASE WHEN all_sub_agency_selected = true
                     then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
                     else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
    GROUP BY advertiser_group) as dev_data
    USING(advertiser_group)
    
  FULL JOIN

(select advertiser_group, round(sum (ch_grp),2) as curr_channel_grp,
case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
case when count(distinct region )!=0 then count(distinct region ) else 1 end as region_count
from
(SELECT channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, sum (ad_grp) as ch_grp FROM {{source('viewership','ent_fact_viewership')}}
where
 lower(channel_name) = lower(var_channel)
      and lower(channel_def_name) = lower(var_channel)
      and  date between var_start_date and var_dt
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN lower(pt_npt) in ("pt", "npt")
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and  (lower(impact_regular) in ("regular") OR impact_regular IS NULL)
      and
         CASE WHEN var_start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
     and 
        CASE WHEN all_advertiser_selected = true
        then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
        else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
      and 
        CASE WHEN all_agency_selected = true
       then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
       else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
      and 
        CASE WHEN all_sub_agency_selected = true
        then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
        else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
group by channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency)
group by advertiser_group
) as curr_ch_grp
using(advertiser_group)

FULL JOIN
(select advertiser_group, round(sum (ch_grp),2) as dev_channel_grp,
case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count,
case when count(distinct region )!=0 then count(distinct region ) else 1 end as region_count
from
(SELECT channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, sum (ad_grp) as ch_grp FROM {{source('viewership','ent_fact_viewership')}}
where
 lower(channel_name) = lower(var_channel)
      and lower(channel_def_name) = lower(var_channel)
      and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
      and CASE 
            WHEN all_region_selected = true
              THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) OR region IS NULL)
            ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a  ) end
      and CASE 
            WHEN ARRAY_LENGTH(var_pt_npt) = 2
              THEN lower(pt_npt) in ("pt", "npt")
            ELSE lower(pt_npt) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
     and  (lower(impact_regular) in ("regular") OR impact_regular IS NULL)
      and
         CASE WHEN var_start_date < "2019-10-27" THEN
           lower(advertiser_group) not in ('star tv network') else 1=1 end
       and 
         CASE WHEN all_advertiser_selected = true
         then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
         else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
       and 
         CASE WHEN all_agency_selected = true
        then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
        else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
       and 
         CASE WHEN all_sub_agency_selected = true
         then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
         else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
group by channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency)
group by advertiser_group
) as dev_ch_grp
using(advertiser_group)
 )
 group by advertiser_group
 )
group by advertiser_group