{{
    config
    (
        schema='rev_vwrshp_reports',
        materialized='stored_procedure',
        parameters='var_start_date DATE, var_end_date DATE, var_channel STRING, var_pt_npt ARRAY<STRING>, var_impact_regular ARRAY<STRING>'
    )

}}



with reporting_tg_market_cte as (
      Select distinct lower(target_region) FROM (select channel_group_name, target_region,reporting_tg from `mint-bi-reporting`.`master`.`ent_reporting_tg_market` union all select channel_group_name, target_region,reporting_tg from `mint-bi-reporting`.`master`.`reg_reporting_tg_market`)
      where lower(channel_group_name) = lower(var_channel) and reporting_tg = true )
,

channel_master_cte as (SELECT source_name,channel_name as mint_channel_name,channel_group_name as channel_name,genre as ch_genre,sub_genre as ch_sub_genre,type_of_beam ,subscription ,network ,hour_type ,part_of_day ,from_day ,to_day ,start_time ,end_time,channel_primary_tg ,channel_secondary_tg ,genre_tg,
                            (CASE WHEN from_day = 'mon' THEN 1
                                  WHEN from_day = 'tue' THEN 2
                                  WHEN from_day = 'wed' THEN 3
                                  WHEN from_day = 'thu' THEN 4
                                  WHEN from_day = 'fri' THEN 5
                                  WHEN from_day = 'sat' THEN 6
                                  WHEN from_day = 'sun' THEN 7
                                  else 0 end) as from_day_num,
                            (CASE WHEN to_day = 'mon' THEN 1
                                  WHEN to_day = 'tue' THEN 2
                                  WHEN to_day = 'wed' THEN 3
                                  WHEN to_day = 'thu' THEN 4
                                  WHEN to_day = 'fri' THEN 5
                                  WHEN to_day = 'sat' THEN 6
                                  WHEN to_day = 'sun' THEN 7
                                  else 0 end) as to_day_num

            FROM (select * from `mint-bi-reporting`.`master`.`ent_channel_master` union all select * from `mint-bi-reporting`.`master`.`reg_channel`)
         where lower(source_name) in ('barc') and hour_type in ('daypart') and lower(channel_group_name) = lower(var_channel))
,

genre_sub_genre_cte as (
      Select distinct lower(genre) as genre, lower(sub_genre) as sub_genre FROM `mint-bi-reporting`.`viewership_reports`.`ent_timeband_30`
        where lower(channel_name) = lower(var_channel)
union all
Select distinct lower(genre) as genre, lower(sub_genre) as sub_genre FROM `mint-bi-reporting`.`viewership_reports`.`reg_timeband_30_spd`
        where lower( channel_name ) = lower(var_channel)

)


select round(channel_grp,2) as channel_grp, round(genre_grp,2) as genre_grp, round(safe_divide(channel_grp,genre_grp)*100,2) as fair_share
from
(
  SELECT 1 as const, ifnull(sum(ratings),0) as channel_grp
  from
  (
    select ent_spot_rating.*,ch_mst.part_of_day
    from
    (
        (Select ratings,genre,sub_genre,day_num,BARC_start_time,BARC_end_time FROM `mint-bi-reporting`.`viewership_reports`.`ent_timeband_30`
          WHERE
              lower(channel_name) = lower(var_channel)
              AND ( (date BETWEEN var_start_date AND var_end_date) )
              and (lower(tg_market) in ( select * from reporting_tg_market_cte))

union all Select ratings, genre, sub_genre,day_num,BARC_start_time,BARC_end_time FROM `mint-bi-reporting`.`viewership_reports`.`reg_timeband_30_spd`
          WHERE
              lower(channel_name) = lower(var_channel)
              AND ( (date BETWEEN var_start_date AND var_end_date) )
              and (lower(tg_market) in ( select * from reporting_tg_market_cte))
        ) as ent_spot_rating

        LEFT JOIN

        (select * from channel_master_cte) as ch_mst
        on ent_spot_rating.genre = ch_mst.ch_genre
        and ent_spot_rating.sub_genre =ch_mst.ch_sub_genre
        and ent_spot_rating.day_num >= ch_mst.from_day_num
        and ent_spot_rating.day_num <= ch_mst.to_day_num
        and  ent_spot_rating.BARC_start_time >= ch_mst.start_time
        and  ent_spot_rating.BARC_end_time <= ch_mst.end_time
    )
    where (lower(part_of_day) in  ( select lower(a) from UNNEST(var_pt_npt) a ) )
  )
)

INNER JOIN

(
  SELECT 1 as const, ifnull(sum(ratings),0) as genre_grp
  from
  (
    select ent_spot_rating.*,ch_mst.part_of_day
    from

    (Select * FROM `mint-bi-reporting`.`viewership_reports`.`ent_timeband_30`
          WHERE
              ( (date BETWEEN var_start_date AND var_end_date) )
              and lower(genre) in (Select genre from genre_sub_genre_cte )
              and lower(sub_genre) in (select sub_genre from genre_sub_genre_cte )
              and lower(tg_market) in (select * from reporting_tg_market_cte )
      union all
Select * FROM `mint-bi-reporting`.`viewership_reports`.`reg_timeband_30_spd`
          WHERE
              ( (date BETWEEN var_start_date AND var_end_date) )
              and lower(genre) in (Select genre from genre_sub_genre_cte )
              and lower(sub_genre) in (select sub_genre from genre_sub_genre_cte )
              and lower(tg_market) in (select * from reporting_tg_market_cte )
     ) as ent_spot_rating

      left JOIN

      (select * from channel_master_cte) as ch_mst
       on ent_spot_rating.genre = ch_mst.ch_genre
       and ent_spot_rating.sub_genre =ch_mst.ch_sub_genre
        and ent_spot_rating.day_num >= ch_mst.from_day_num
        and ent_spot_rating.day_num <= ch_mst.to_day_num
        and  ent_spot_rating.BARC_start_time >= ch_mst.start_time
        and  ent_spot_rating.BARC_end_time <= ch_mst.end_time
     )
     where (lower(part_of_day) in  (select lower(a) from UNNEST(var_pt_npt) a) )
)
using(const)