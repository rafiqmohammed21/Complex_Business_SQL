{{
    config
    (
        schema='rev_vwrshp_reports',
        materialized='stored_procedure',
        parameters='var_channel STRING, var_start_date DATE, var_end_date DATE'
    )

}}


WITH with_hul_cte as (select round(avg_fct/timeband,2) as with_hul
from
(
  select 1 as const, avg(fct_corrected) as avg_fct
  from
  (
      select date,sum(fct/agency_count ) as fct_corrected
      from
      (
            SELECT date,advertiser_group , sum (fct/60) as fct,case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
            FROM
			(select advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name from {{ref('ent_spr_advertiser_common')}}
            union all
            select  advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name from {{ref('reg_spr_advertiser_common')}})

            WHERE
                lower(channel_name) = lower(var_channel)
                and  (date BETWEEN var_start_date AND var_end_date)
                and lower(part_of_day) in ('pt','npt', 'all daypart')
                and lower(event_status) in ('primary')
                and lower(revenue_classification) in ('commercial')
                and lower(source_name) in ('onair')
                and
                CASE WHEN var_start_date < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
            GROUP BY date, advertiser_group
            )  GROUP BY date
    )
)

inner join

(SELECT 1 as const, (count(distinct time_band)/2) as timeband
  FROM (select advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name,time_band from {{ref('ent_spr_advertiser_common')}}
            union all
            select  advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name,time_band from {{ref('reg_spr_advertiser_common')}})
  WHERE
      lower(channel_name) = lower(var_channel)
      and  ( (date BETWEEN var_start_date AND var_end_date) )
      and lower(part_of_day) in ('pt','npt', 'all daypart')
      and lower(event_status) in ('primary')
      and lower(revenue_classification) in ('commercial')
      and lower(source_name) in ('onair')
      and
         CASE WHEN var_start_date < "2019-10-27" THEN
             lower(advertiser_group) not in ('star tv network') else 1=1 end
) using(const)),

without_hul_cte as
(select round(avg_fct/timeband,2) as without_hul
from
(
  select 1 as const, avg(fct_corrected) as avg_fct
  from
  (
      select date,sum(fct/agency_count ) as fct_corrected
      from
      (
          SELECT date,advertiser_group , sum (fct/60) as fct,case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
          FROM (select advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name from {{ref('ent_spr_advertiser_common')}}
            union all
            select  advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name from {{ref('reg_spr_advertiser_common')}})
          WHERE
              lower(channel_name) = lower(var_channel)
              and  ( (date BETWEEN var_start_date AND var_end_date) )
              and lower(part_of_day) in ('pt','npt', 'all daypart')
              and lower(event_status) in ('primary')
              and lower(revenue_classification) in ('commercial')
              and lower(source_name) in ('onair')
              and
                CASE WHEN var_start_date < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
              and lower(advertiser_group) NOT IN ('hul' )
           GROUP BY date, advertiser_group
        ) GROUP BY date
    )
)

inner join

(SELECT 1 as const, (count(distinct time_band)/2) as timeband
   FROM (select advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name,time_band from {{ref('ent_spr_advertiser_common')}}
            union all
            select  advertiser_group,fct,agency,channel_name,date,part_of_day,event_status,revenue_classification,source_name,time_band from {{ref('reg_spr_advertiser_common')}})
   WHERE
       lower(channel_name) = lower(var_channel)
        and  ( (date BETWEEN var_start_date AND var_end_date) )
       and lower(part_of_day) in ('pt','npt', 'all daypart')
        and lower(event_status) in ('primary')
      and lower(revenue_classification) in ('commercial')
      and lower(source_name) in ('onair')
       and
          CASE WHEN var_start_date < "2019-10-27" THEN
              lower(advertiser_group) not in ('star tv network') else 1=1 end
       and lower(advertiser_group) NOT IN ( 'hul' )
       ) using(const))

select with_hul,without_hul from with_hul_cte,without_hul_cte