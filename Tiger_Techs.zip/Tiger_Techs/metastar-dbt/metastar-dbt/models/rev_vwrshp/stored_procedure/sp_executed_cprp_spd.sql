{{
    config
    (
        schema='test_reports',
        materialized='stored_procedure',
        parameters='var_selection STRING, var_start_date DATE, var_end_date DATE, dev_period ARRAY<DATE>, lag_start_date DATE, lag_end_date DATE, dev_lag ARRAY<DATE>, var_channel ARRAY<STRING>, var_region ARRAY<STRING>, var_pt_npt ARRAY<STRING>, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, var_advertiser_category ARRAY<STRING>, var_brands ARRAY<STRING>, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL, all_advertiser_category_selected BOOL, all_brands_selected BOOL'
    )

}}

Select selection_group,ROUND(SUM(current_revenue)/10000000,2) as total_revenue, ROUND(SUM(current_ad_grp),2) as total_ad_grp, ROUND(SUM(deviation_revenue)/10000000,2) as total_deviation_revenue, ROUND(SUM(deviation_ad_grp),2) as total_deviation_ad_grp, ROUND(SUM(current_revenue)/SUM(current_ad_grp),2) as executed_cprp, ROUND(SUM(deviation_revenue)/SUM(deviation_ad_grp),2) as deviation_executed_cprp, round((safe_divide(((ifnull(SUM(current_revenue)/SUM(current_ad_grp),0)/1) - (ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)),(ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)))*100,2) as percentage_deviation

             from
                (Select
                coalesce(curr_data.selection_group, dev_data.selection_group) as selection_group,
                current_revenue, current_ad_grp,
                round(safe_divide(current_revenue,current_ad_grp),2) as current_executed_cprp,
                deviation_revenue, deviation_ad_grp,
                round(safe_divide(deviation_revenue,deviation_ad_grp),2) as deviation_executed_cprp
                from
                (
      select selection_group, sum(current_revenue) as current_revenue,sum(current_ad_grp) as current_ad_grp
      from(
        SELECT selection_group ,sum (revenue ) as current_revenue ,round(sum(fct * rating / 10 ),2) as current_ad_grp
        from
        (
            SELECT 
            case when var_selection = 'channel_name' then lower(onair.channel_name )
              when var_selection = 'region' then lower(region)
              when var_selection = 'agency' then lower(agency)
              when var_selection = 'advertiser_group' then lower(advertiser_group)
              when var_selection = 'advertiser_category' then lower(advertiser_category)
              when var_selection = 'overall' then 'CONST'
              else lower(advertiser_group)  end as selection_group,
            advertiser_group ,onair.start_time,onair.end_time, revenue, fct, rating , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
            from
                (
        select channel_name,advertiser_group,region,agency,sub_agency ,advertiser_category,
            CAST(SUBSTR(time_band,1,4) AS INT64) AS start_time,
            CAST(SUBSTR(time_band,6,4) AS INT64) AS end_time,
            sum(revenue) as revenue, sum(fct) as fct

            FROM {{ref('spr_advertiser_spd')}}
            WHERE
                lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                and  ( date between var_start_date and var_end_date)
                and (
                CASE WHEN all_region_selected = true
                     THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                     ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                )
                and(
                CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                     THEN (lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) OR part_of_day IS NULL)
                     ELSE lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
                )
                and (lower(impact_regular) in  ( 'regular' ) )
                and
                CASE WHEN var_start_date < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                and 
 CASE WHEN all_advertiser_selected = true
 then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
 else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
and 
  CASE WHEN all_agency_selected = true
 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
and 
  CASE WHEN all_sub_agency_selected = true
  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
and 
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end
                AND lower(spot_status) in ('aired', 'placed')
        GROUP BY channel_name,advertiser_group,region,agency,sub_agency,advertiser_category,start_time,end_time

        ) as onair
                LEFT JOIN
                (
                    select onair_tagging.channel_name ,vwrship.start_time, vwrship.end_time, rating
                    from
                        (
              SELECT channel_name,
                CAST(SUBSTR(time_band,1,4) AS INT64) AS start_time,
                CAST(SUBSTR(time_band,6,4) AS INT64) AS end_time,

            FROM {{ref('spr_advertiser_spd')}}

                 WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and  (( date between var_start_date and var_end_date) )
                    and (lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) )
        ) as onair_tagging
                        LEFT JOIN
                        (
                SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time,
                ROUND(sum (ratings * duration)/sum (duration),6) AS rating

            FROM {{ref('ent_spot_ratings_spd')}}

                WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and lower(tg_market) in (
                            Select distinct lower(target_region)

            FROM {{source('master','ent_reporting_tg_market')}}
         where
                            lower(channel_group_name) in (select lower(a) from UNNEST(var_channel) a)
                            and reporting_tg = true
                        )
                    and  ( ( date between lag_start_date and lag_end_date)  )
                GROUP BY channel_name ,start_time,end_time

            ) as vwrship
                    ON lower(onair_tagging.channel_name)  = lower(vwrship.channel_name)
                    and onair_tagging.start_time <= vwrship.start_time
                    and onair_tagging.end_time >= vwrship.end_time
                ) as spot_rating
                ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
                and onair.start_time <= spot_rating.start_time
                and onair.end_time >= spot_rating.end_time
            GROUP BY selection_group,advertiser_group,region,onair.start_time,onair.end_time,revenue ,fct,rating

        )
        GROUP BY 1 ,agency_count
      )
      group by 1
        ) as curr_data
                FULL JOIN
                (
                 select selection_group, sum(deviation_revenue) as deviation_revenue,sum(deviation_ad_grp) as deviation_ad_grp
      from(
        SELECT selection_group ,sum (revenue ) as deviation_revenue ,round(sum(fct * rating / 10 ),2) as deviation_ad_grp
        from
        (
            SELECT 
            case when var_selection = 'channel_name' then lower(onair.channel_name )
              when var_selection = 'region' then lower(region)
              when var_selection = 'agency' then lower(agency)
              when var_selection = 'advertiser_group' then lower(advertiser_group)
              when var_selection = 'advertiser_category' then lower(advertiser_category)
              when var_selection = 'overall' then 'CONST'
              else lower(advertiser_group)  end as selection_group,
            advertiser_group ,onair.start_time,onair.end_time,revenue, fct, rating , 
            case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
            from
                (
        select channel_name,advertiser_group,region,agency,sub_agency ,advertiser_category,
            CAST(SUBSTR(time_band,1,4) AS INT64) AS start_time,
            CAST(SUBSTR(time_band,6,4) AS INT64) AS end_time,
            sum(revenue) as revenue, sum(fct) as fct

            FROM {{ref('spr_advertiser_spd')}}


            WHERE
                lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                and (
                CASE WHEN all_region_selected = true
                     THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                     ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                )
                and(
                CASE WHEN ARRAY_LENGTH(var_pt_npt) = 2
                     THEN (lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) OR part_of_day IS NULL)
                     ELSE lower(part_of_day) in (SELECT lower(a) FROM UNNEST(var_pt_npt) a) end
                )
                and (lower(impact_regular) in  ( 'regular' ) )
                and
                CASE WHEN dev_period[OFFSET(0)] < "2019-10-27" THEN
                      lower(advertiser_group) not in ('star tv network') else 1=1 end
                and 
   CASE WHEN all_advertiser_selected = true
   then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
   else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
 and 
   CASE WHEN all_agency_selected = true
   then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
   else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
 and 
   CASE wHEN all_sub_agency_selected = true
   then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
   else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
 and 
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end
                AND lower(spot_status) in ('aired', 'placed')
        GROUP BY channel_name,advertiser_group,region,agency,sub_agency,advertiser_category,start_time,end_time

        ) as onair
                LEFT JOIN
                (
                    select onair_tagging.channel_name ,vwrship.start_time, vwrship.end_time, rating
                    from
                        (
              SELECT channel_name,
                CAST(SUBSTR(time_band,1,4) AS INT64) AS start_time,
                CAST(SUBSTR(time_band,6,4) AS INT64) AS end_time,

            FROM {{ref('spr_advertiser_spd')}}

                 WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)] or date between dev_period[OFFSET(2)] and dev_period[OFFSET(3)] or date between dev_period[OFFSET(4)] and dev_period[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_period[OFFSET(0)] and dev_period[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                    and (lower(part_of_day) in  (SELECT lower(a) FROM UNNEST(var_pt_npt) a) )
        ) as onair_tagging
                        LEFT JOIN
                        (
                SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time,
                ROUND(sum (ratings * duration)/sum (duration),6) AS rating

            FROM {{ref('ent_spot_ratings_spd')}}

                WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and lower(tg_market) in (
                            Select distinct lower(target_region)

            FROM {{source('master','ent_reporting_tg_market')}}
         where
                            lower(channel_group_name) in (select lower(a) from UNNEST(var_channel) a)
                            and reporting_tg = true
                        )
                    and CASE WHEN ARRAY_LENGTH(dev_period)=6
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)] or date between dev_lag[OFFSET(2)] and dev_lag[OFFSET(3)] or date between dev_lag[OFFSET(4)] and dev_lag[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_PERIOD) = 2
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                GROUP BY channel_name ,start_time,end_time

            ) as vwrship
                    ON lower(onair_tagging.channel_name)  = lower(vwrship.channel_name)
                    and onair_tagging.start_time <= vwrship.start_time
                    and onair_tagging.end_time >= vwrship.end_time
                ) as spot_rating
                ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
                and onair.start_time <= spot_rating.start_time
                and onair.end_time >= spot_rating.end_time
            GROUP BY selection_group,advertiser_group,region,onair.start_time,onair.end_time,revenue ,fct,rating

        )
        GROUP BY 1 ,agency_count
      )
      group by 1
        ) as dev_data
                on curr_data.selection_group=dev_data.selection_group
                )
                group by 1