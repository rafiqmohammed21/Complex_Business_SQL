{{
    config
    (
        schema='test_reports',
        materialized='stored_procedure',
        parameters='var_selection STRING, var_start_date DATE, var_end_date DATE, dev_start_date DATE, dev_end_date DATE, lag_start_date DATE, lag_end_date DATE, dev_lag ARRAY<DATE>, var_channel ARRAY<STRING>, var_region ARRAY<STRING>, var_pt_npt STRING, var_advertiser_group ARRAY<STRING>, var_dev_advertiser_group ARRAY<STRING>, var_agency ARRAY<STRING>, var_sub_agency ARRAY<STRING>, var_advertiser_category ARRAY<STRING>, var_brands ARRAY<STRING>, all_region_selected BOOL, all_advertiser_selected BOOL, all_agency_selected BOOL, all_sub_agency_selected BOOL, all_advertiser_category_selected BOOL, all_brands_selected BOOL'
    )

}}

Select selection_group,ROUND(SUM(current_revenue)/10000000,2) as total_revenue, ROUND(SUM(current_ad_grp),2) as total_ad_grp, ROUND(SUM(deviation_revenue)/10000000,2) as total_deviation_revenue, ROUND(SUM(deviation_ad_grp),2) as total_deviation_ad_grp, ROUND(SUM(current_revenue)/SUM(current_ad_grp),2) as deals_cprp, ROUND(SUM(deviation_revenue)/SUM(deviation_ad_grp),2) as deviation_deals_cprp, round((safe_divide(((ifnull(SUM(current_revenue)/SUM(current_ad_grp),0)/1) - (ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)),(ifnull(SUM(deviation_revenue)/SUM(deviation_ad_grp),0)/1)))*100,2) as percentage_deviation
from
(
    Select
      coalesce(curr_data.selection_group, dev_data.selection_group) as selection_group,
      current_revenue, current_ad_grp,
      round(safe_divide(current_revenue,current_ad_grp),2) as current_deals_cprp,
      deviation_revenue, deviation_ad_grp,
      round(safe_divide(deviation_revenue,deviation_ad_grp),2) as deviation_deals_cprp
    from
    (
    select selection_group, sum(current_revenue) as current_revenue,sum(current_ad_grp) as current_ad_grp
      from(
        SELECT selection_group , sum (revenue ) as current_revenue , 
        round(sum((fct * rating / 10)),2) as current_ad_grp
        from
        (
           SELECT 
           case when var_selection = 'channel_name' then lower(onair.channel_name )
            when var_selection = 'region' then lower(region)
            when var_selection = 'agency' then lower(agency)
            when var_selection = 'advertiser_group' then lower(advertiser_group)
            when var_selection = 'advertiser_category' then lower(advertiser_category)
            when var_selection = 'overall' then 'CONST'
            else lower(advertiser_group)  end as selection_group,
           advertiser_group ,onair.start_time,onair.end_time,revenue, fct, avg(rating) as rating , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
            from
            (select channel_name,advertiser_group,channel_primary,region,agency,sub_agency,advertiser_category,start_time, end_time,
              CASE WHEN lower(var_pt_npt) = "npt"
                   THEN sum(channel_npt_revenue)
                   WHEN lower(var_pt_npt) = "pt"
                   THEN sum(channel_pt_revenue)
                   ELSE sum(monthly_outlay) END AS revenue,

              CASE WHEN lower(var_pt_npt) = "npt"
                   THEN sum(channel_npt_fct)
                   WHEN lower(var_pt_npt) = "pt"
                   THEN sum(channel_pt_fct)
                   ELSE sum(monthly_fct) END AS fct
              FROM {{ref('deal_spd')}}
              WHERE
                  lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                  and concat(cast(year as string),"_",cast(month as string)) in
                     ( select distinct concat(year,'_',month) from {{source('master','disney_fy_cal')}}
                       where start_date >= var_start_date and var_end_date >= start_date )
                  and (
                  CASE WHEN all_region_selected = true
                       THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                       ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                  )
                  and (lower(impact_regular) in  ( 'regular' ) )
                  and
                    CASE WHEN var_start_date < "2019-10-27"
                      THEN lower(advertiser_group) not in ('star tv network') else 1=1 end
                  and 
 CASE WHEN all_advertiser_selected = true
 then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a) or var_advertiser_group is null)
 else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_advertiser_group) a)) end
and 
  CASE WHEN all_agency_selected = true
 then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
 else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
and 
  CASE WHEN all_sub_agency_selected = true
  then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
  else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
and 
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end
            GROUP BY channel_name,advertiser_group,channel_primary,region,agency,sub_agency,advertiser_category,start_time,end_time

          ) as onair

          LEFT JOIN

          (
                SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time, ROUND(sum (ratings * duration)/sum (duration),6) AS rating
                FROM {{ref('ent_spot_ratings_spd')}}
                WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and lower(tg_market) in (Select distinct lower(target_region)
                                            FROM {{source('master','ent_reporting_tg_market')}}
                                            where lower(channel_group_name) in (select lower(a) from UNNEST(var_channel) a) and reporting_tg = true
                                            )
                    and (date between lag_start_date and lag_end_date)
                GROUP BY channel_name ,start_time,end_time
          ) as spot_rating
          ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
          and onair.start_time <= spot_rating.start_time
          and onair.end_time >= spot_rating.end_time
     GROUP BY selection_group,advertiser_group,region,revenue ,fct,onair.start_time,onair.end_time
    )
    GROUP BY 1,agency_count
    )
    group by 1
   ) as curr_data

   FULL JOIN

   (
   select selection_group, sum(deviation_revenue) as deviation_revenue,sum(deviation_ad_grp) as deviation_ad_grp
      from(
      SELECT selection_group ,sum (revenue ) as deviation_revenue ,round(sum((fct * rating / 10)),2) as deviation_ad_grp
      from
      (
        SELECT 
        case when var_selection = 'channel_name' then lower(onair.channel_name )
            when var_selection = 'region' then lower(region)
            when var_selection = 'agency' then lower(agency)
            when var_selection = 'advertiser_group' then lower(advertiser_group)
            when var_selection = 'advertiser_category' then lower(advertiser_category)
            when var_selection = 'overall' then 'CONST'
            else lower(advertiser_group)  end as selection_group,
        advertiser_group ,onair.start_time,onair.end_time,revenue, fct, avg(rating) as rating , case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count
         from
            ( select channel_name,advertiser_group,channel_primary,region,agency,sub_agency ,advertiser_category, start_time, end_time,
            CASE WHEN lower(var_pt_npt) = "npt"
                   THEN sum(channel_npt_revenue)
                   WHEN lower(var_pt_npt) = "pt"
                   THEN sum(channel_pt_revenue)
                   ELSE sum(monthly_outlay) END AS revenue,

              CASE WHEN lower(var_pt_npt) = "npt"
                   THEN sum(channel_npt_fct)
                   WHEN lower(var_pt_npt) = "pt"
                   THEN sum(channel_pt_fct)
                   ELSE sum(monthly_fct) END AS fct

            FROM {{ref('deal_spd')}}

            WHERE
                lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                and concat(cast(year as string),"_",cast(month as string)) in
                     ( select distinct concat(year,'_',month) from {{source('master','disney_fy_cal')}}
                       where start_date >= dev_start_date and dev_end_date >= start_date )
                and (
                  CASE WHEN all_region_selected = true
                       THEN (lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) OR region IS NULL)
                       ELSE lower(region) in (SELECT lower(a) FROM UNNEST(var_region) a) end
                  )
                and (lower(impact_regular) in  ( 'regular' ) )
                and
                    CASE WHEN dev_start_date < "2019-10-27"
                      THEN lower(advertiser_group) not in ('star tv network') else 1=1 end
               and 
   CASE WHEN all_advertiser_selected = true
   then (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a) or var_dev_advertiser_group is null)
   else (lower(advertiser_group) in (SELECT lower(a) FROM UNNEST(var_dev_advertiser_group) a)) end
 and 
   CASE WHEN all_agency_selected = true
   then (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or lower(agency) is null or var_agency is null )
   else (lower(agency) in (SELECT lower(a) FROM UNNEST(var_agency) a)  or var_agency is null ) end
 and 
   CASE wHEN all_sub_agency_selected = true
   then (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or lower(sub_agency) is null or var_sub_agency is null)
   else (lower(sub_agency) in (SELECT lower(a) FROM UNNEST(var_sub_agency) a)  or var_sub_agency is null ) end
 and 
  CASE WHEN all_advertiser_category_selected = true
  then (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or lower(advertiser_category) is null or var_advertiser_category is null)
  else (lower(advertiser_category) in (SELECT lower(a) FROM UNNEST(var_advertiser_category) a)  or var_advertiser_category is null ) end
            GROUP BY channel_name,advertiser_group,channel_primary,region,agency,sub_agency,advertiser_category,start_time,end_time

        ) as onair

        LEFT JOIN

        (
              SELECT channel_name , BARC_start_time AS start_time, BARC_end_time AS end_time,
                ROUND(sum (ratings * duration)/sum (duration),6) AS rating
              FROM {{ref('ent_spot_ratings_spd')}}
              WHERE
                    lower(channel_name) in (select lower(a) from UNNEST(var_channel) a)
                    and lower(tg_market) in ( Select distinct lower(target_region)
                                            FROM {{source('master','ent_reporting_tg_market')}} e
                                            where lower(channel_group_name) in (select lower(a) from UNNEST(var_channel) a) and reporting_tg = true
                                            )
                    and CASE WHEN ARRAY_LENGTH(dev_lag)=6
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)] or date between dev_lag[OFFSET(2)] and dev_lag[OFFSET(3)] or date between dev_lag[OFFSET(4)] and dev_lag[OFFSET(5)]
                           WHEN ARRAY_LENGTH(dev_lag) = 2
                           THEN date between dev_lag[OFFSET(0)] and dev_lag[OFFSET(1)]
                           ELSE date between '1891-01-01' and '1891-01-07' end
                GROUP BY channel_name ,start_time,end_time
          ) as spot_rating
          ON lower(onair.channel_name)  = lower(spot_rating.channel_name)
          and onair.start_time <= spot_rating.start_time
          and onair.end_time >= spot_rating.end_time
        GROUP BY selection_group,advertiser_group,region,revenue ,fct,onair.start_time,onair.end_time
     )
     GROUP BY 1,agency_count
     )
     group by 1
   ) as dev_data
   on curr_data.selection_group=dev_data.selection_group
)
group by 1