{{ config(schema='rev_vwrshp_reports') }}


select ent_spot_rating.* , tg_market.reporting_tg
from

(select
ent_spot_rating.row_num,
ent_spot_rating.target,
ent_spot_rating.BARC_region,
ent_spot_rating.sector,
ent_spot_rating.category,
ent_spot_rating.brand,
ent_spot_rating.advertiser_name,
ent_spot_rating.BARC_advertiser_group,
ent_spot_rating.master_programme,
ent_spot_rating.position,
ent_spot_rating.level,
ent_spot_rating.event_type,
ent_spot_rating.promo_type,
ent_spot_rating.promo_category,
ent_spot_rating.promo_sponsor_name,
ent_spot_rating.promo_programme_name,
ent_spot_rating.pib,
ent_spot_rating.tib,
ent_spot_rating.pp_start_time,
ent_spot_rating.cp_start_time,
ent_spot_rating.channel,
ent_spot_rating.start_time_av_tm,
ent_spot_rating.end_time_av_tm,
ent_spot_rating.break_code,
ent_spot_rating.date,
ent_spot_rating.week,
ent_spot_rating.programme_genre,
ent_spot_rating.programme_theme,
ent_spot_rating.duration,
ent_spot_rating.ratings,
ent_spot_rating.impressions,
ent_spot_rating.target_av,
ent_spot_rating.year,
ent_spot_rating.timeband_start_time,
ent_spot_rating.timeband_end_time,
ent_spot_rating.barc_year,
ent_spot_rating.tg_market,
ent_spot_rating.BARC_channel_name,
ent_spot_rating.BARC_start_time,
ent_spot_rating.BARC_end_time,
ent_spot_rating.BARC_source_name,
ent_spot_rating.month,
ent_spot_rating.day,
ent_spot_rating.day_num,
ent_spot_rating.channel_name,
ent_spot_rating.genre,
ent_spot_rating.sub_genre,
ent_spot_rating.type_of_beam,
ent_spot_rating.subscription,
ent_spot_rating.network,
ent_spot_rating.channel_primary_tg,
ent_spot_rating.channel_secondary_tg,
ent_spot_rating.genre_tg,
ent_spot_rating.advertiser,
case when star_internal_buys.advertiser_group_name is NULL then ent_spot_rating.region
else 'WEST' end as region,
case when star_internal_buys.advertiser_group_name is NULL then ent_spot_rating.advertiser_group
else star_internal_buys.advertiser_group_name end as advertiser_group,
ent_spot_rating.advertiser_category,
ent_spot_rating.agency,
ent_spot_rating.sub_agency,
ent_spot_rating.impact_regular,
ent_spot_rating.pt_npt,
ent_spot_rating.channel_def_name
from
(
select ent_spot_rating.*,ch_master.part_of_day as pt_npt,ch_master.channel_group_name as channel_def_name   from
(select ent_spot_rating.*,
CASE WHEN barc_impact.tag is NULL then 'regular'
else barc_impact.tag  end AS impact_regular from
(
      select ent_spot_rating.*,monthly_agency.agency ,monthly_agency.sub_agency
      from
(
      (
            select spot_rating.*,ch_master.channel_group_name as channel_name,ch_master.genre,ch_master.sub_genre ,ch_master.type_of_beam ,ch_master.subscription,ch_master.network ,ch_master.channel_primary_tg ,ch_master.channel_secondary_tg ,ch_master.genre_tg ,advt_master.*
            from
             (SELECT row_num ,target ,region as BARC_region,sector ,category ,brand,advertiser as advertiser_name,advertiser_group as BARC_advertiser_group,master_programme ,position ,level ,event_type ,promo_type ,promo_category ,promo_sponsor_name ,promo_programme_name ,pib,tib,pp_start_time ,cp_start_time,channel  ,start_time_av_tm ,end_time_av_tm ,break_code ,date,week ,time_band programme_genre ,programme_theme ,duration,ratings ,impressions ,target_av ,year,timeband_start_time ,timeband_end_time ,barc_year  , concat(target," ",region) as tg_market, channel as BARC_channel_name
, cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_start_time, ':', '') as string),1,4) as INT64) as BARC_start_time,
cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_end_time, ':', '') as string),1,5) as INT64) as BARC_end_time,
'BARC' as BARC_source_name,EXTRACT(Month FROM date) AS month,
lower(FORMAT_DATE('%a', date)) as day,
       (CASE WHEN lower(FORMAT_DATE('%a', date)) = 'mon' THEN 1
      WHEN lower(FORMAT_DATE('%a', date)) = 'tue' THEN 2
      WHEN lower(FORMAT_DATE('%a', date)) = 'wed' THEN 3
      WHEN lower(FORMAT_DATE('%a', date)) = 'thu' THEN 4
      WHEN lower(FORMAT_DATE('%a', date)) = 'fri' THEN 5
      WHEN lower(FORMAT_DATE('%a', date)) = 'sat' THEN 6
      WHEN lower(FORMAT_DATE('%a', date)) = 'sun' THEN 7
      else 0 end) as day_num
FROM `mint-bi-reporting`.`viewership`.`ent_spot_ratings_channel_tg`
WHERE level in ('Level 4')) as spot_rating
left join
(SELECT distinct channel_name ,source_name ,channel_group_name ,genre ,sub_genre ,type_of_beam ,subscription ,network,channel_primary_tg ,channel_secondary_tg ,genre_tg   FROM `mint-bi-reporting`.`master`.`ent_channel_master`
where source_name in ('BARC')) as ch_master
      on spot_rating.BARC_channel_name=ch_master.channel_name
left JOIN
(
      SELECT distinct advertiser_name as advertiser,region, advertiser_group_name as advertiser_group, advertiser_category
      FROM `mint-bi-reporting`.`master`.`ent_advertiser_master`
where lower(source) in ('barc') and region is NOT NULL) AS advt_master
      ON spot_rating.advertiser_name = advt_master.advertiser
)
)as ent_spot_rating
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM
{{source('master','month_wise_agency_mappings')}}) as monthly_agency
      on lower(ent_spot_rating.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and ent_spot_rating.month = monthly_agency.month
-- and ent_spot_rating.year = monthly_agency.year
) as ent_spot_rating
Left join
(SELECT * FROM `mint-bi-reporting`.`master`.`ent_barc_impact_taggings`)  as barc_impact
on ent_spot_rating.BARC_channel_name = barc_impact.channel
and ent_spot_rating.date = barc_impact.date
and ent_spot_rating.master_programme = barc_impact.description
and ent_spot_rating.cp_start_time = barc_impact.start_time) as ent_spot_rating
left join
( SELECT distinct  channel_group_name,network ,part_of_day,hour_type  ,from_day ,to_day ,start_time ,end_time , genre,sub_genre,
(CASE WHEN from_day = 'mon' THEN 1
      WHEN from_day = 'tue' THEN 2
      WHEN from_day = 'wed' THEN 3
      WHEN from_day = 'thu' THEN 4
      WHEN from_day = 'fri' THEN 5
      WHEN from_day = 'sat' THEN 6
      WHEN from_day = 'sun' THEN 7
      else 0 end) as from_day_num,
(CASE WHEN to_day = 'mon' THEN 1
      WHEN to_day = 'tue' THEN 2
      WHEN to_day = 'wed' THEN 3
      WHEN to_day = 'thu' THEN 4
      WHEN to_day = 'fri' THEN 5
      WHEN to_day = 'sat' THEN 6
      WHEN to_day = 'sun' THEN 7
      else 0 end) as to_day_num
FROM `mint-bi-reporting`.`master`.`ent_channel_master`
where
source_name in ('BARC') and hour_type in ('daypart')) as ch_master
on ent_spot_rating.genre = ch_master.genre
and ent_spot_rating.sub_genre = ch_master.sub_genre
and ent_spot_rating.day_num >= ch_master.from_day_num
and ent_spot_rating.day_num <= ch_master.to_day_num
and ent_spot_rating.BARC_start_time >= ch_master.start_time
and ent_spot_rating.BARC_start_time < ch_master.end_time
  ) as ent_spot_rating
left join
(SELECT distinct   advertiser_name ,advertiser_group_name  FROM `mint-bi-reporting`.`master`.`star_internal_buys`
where lower(source) in ('barc') ) as star_internal_buys
on ent_spot_rating.advertiser_name = star_internal_buys.advertiser_name)
   as ent_spot_rating
left join
(SELECT distinct genre ,sub_genre ,target ,region ,reporting_tg FROM `mint-bi-reporting`.`master`.`ent_reporting_tg_market`) as tg_market
on concat(ent_spot_rating.genre,ent_spot_rating.sub_genre,ent_spot_rating.target,ent_spot_rating.BARC_region) = concat(tg_market.genre,tg_market.sub_genre,tg_market.target,tg_market.region)