{{ config(schema='rev_vwrshp_reports') }}

with count_cte as (SELECT
  a.disney_calender_year as disney_calender_year,
  a.d_month as d_month,
  a.channel_group_name as channel_group_name,
  a.advertiser_group_name as advertiser_group_name,
  a.type_of as type_of,
  count( distinct coalesce(b.region, 'region')) as region_count,
  count( distinct coalesce(c.agency_group, 'agency')) as agency_count

FROM
  (select  * from `mint-bi-reporting.dev.datalake_provisions_data`
  where lower(type_of) in ('provisions','reversals')
  union all
  select * from `mint-bi-reporting.dev.datalake_provisions_data_reg`
where lower(type_of) in ('provisions','reversals')) a

LEFT JOIN
  (select distinct region,advertiser_group_name, advertiser_category from  `mint-bi-reporting.master.ent_advertiser_master` )b
ON a.advertiser_group_name=b.advertiser_group_name

LEFT JOIN  `mint-bi-reporting.master.month_wise_agency_mappings` c
ON a.advertiser_group_name =c.advertiser

GROUP BY
  a.disney_calender_year,
  a.d_month,
  a.channel_group_name,
  a.advertiser_group_name,
  a.type_of)
  ,
  revenue_cte as (SELECT
  a.disney_calender_year as disney_calender_year,
  a.d_month as d_month,
  a.channel_group_name as channel_group_name,
  a.advertiser_group_name as advertiser_group_name,
  a.type_of as type_of,
  b.region ,
  b.advertiser_category ,
  c.agency_group,
  sum (a.net_revenue) AS net_revenue
FROM
  (select  disney_calender_year,d_month,channel_group_name,advertiser_group_name,type_of,net_revenue from `mint-bi-reporting.dev.datalake_provisions_data`
  where lower(type_of) in ('provisions','reversals')
  union all
  select disney_calender_year,d_month,channel_group_name,advertiser_group_name,type_of,net_revenue from `mint-bi-reporting.dev.datalake_provisions_data_reg`
where lower(type_of) in ('provisions','reversals')) a
LEFT JOIN  (select distinct region,advertiser_group_name, advertiser_category from  `mint-bi-reporting.master.ent_advertiser_master` )b  ON a.advertiser_group_name=b.advertiser_group_name
LEFT JOIN
(select distinct advertiser, agency_group from `mint-bi-reporting.master.month_wise_agency_mappings`) c ON a.advertiser_group_name =c.advertiser
where lower(a.type_of) in ('provisions','reversals')
GROUP BY
  a.disney_calender_year,
  a.d_month,
  a.channel_group_name,
  a.advertiser_group_name,
  a.type_of,
  b.region ,
  b.advertiser_category ,
  c.agency_group

ORDER BY
  a.type_of)

  select
  count_cte.disney_calender_year as disney_calender_year,
  count_cte.d_month as d_month,
  count_cte.channel_group_name as channel_group_name,
  count_cte.advertiser_group_name as advertiser_group_name,
  count_cte.type_of as type_of,
  revenue_cte.region,
  revenue_cte.advertiser_category,
  revenue_cte.agency_group,
  revenue_cte.net_revenue/(count_cte.agency_count * count_cte.region_count) as net_revenue
  from
  revenue_cte
left join
count_cte
using (disney_calender_year,d_month,channel_group_name,advertiser_group_name,type_of)
