{{ config(schema='rev_vwrshp_reports') }}


(

select ro.*,monthly_agency.agency ,monthly_agency.sub_agency,adv_master.advertiser_category  from
(SELECT release_order_id, release_order_created_at, year_month, release_order_upDated_at, release_order_total_spots,  number, language, status, ro_Date,  start_Date, end_Date, release_order_product_id, release_order_product_total_spots,  caption_name, spot_duration,  rate_per_ten_sec, proposal_product_id,  grid_type,  brand,  sponsorship_type, element_type, plan_type,  brand_exposure, commercial_material,  spot_position,  release_Date_id,  spot_count, airing_Date,  channel_name, channel_primary_tgmarket, advertiser_name,  advertiser_group, region, impact_regular, impact_regular_client,  impact_regular_channel, channel_skew_weight,  client_skew_weight, product_name, product_start_time, product_end_time,  program,  proposal_primary_tgmkt, proposal_secondary_tgmkt, date, revenue,  fct,  channel_wd_revenue, channel_we_revenue, channel_pt_revenue, channel_npt_revenue,  client_wd_revenue,  client_we_revenue,  client_pt_revenue,  client_npt_revenue, channel_wd_fct, channel_we_fct, channel_pt_fct, channel_npt_fct,  client_wd_fct,  client_we_fct,  client_pt_fct,  client_npt_fct ,EXTRACT(Month FROM airing_date) AS month,EXTRACT(YEAR FROM airing_date) AS year FROM `mint-bi-reporting`.`revenue`.`ro`) as ro
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM `mint-bi-reporting`.`master`.`month_wise_agency_mappings` ) as monthly_agency
on lower(ro.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and ro.month = monthly_agency.month
-- and ro.year = monthly_agency.year
left join
  (Select distinct advertiser_category, advertiser_group_name as advertiser_group from `mint-bi-reporting`.`master`.`ent_advertiser_master`) as adv_master
  on lower(ro.advertiser_group) = lower(adv_master.advertiser_group)
  )