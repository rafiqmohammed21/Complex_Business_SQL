{{ config(schema='rev_vwrshp_reports') }}


select reg_spot_rating.* , tg_market.reporting_tg
from(
select reg_spot_rating.*,ch_master.part_of_day as pt_npt,ch_master.channel_group_name as channel_def_name   from
(select reg_spot_rating.*,
CASE WHEN barc_impact.tag is NULL then 'regular'
else barc_impact.tag  end AS impact_regular
from
(
      select reg_spot_rating.*,monthly_agency.agency ,monthly_agency.sub_agency
      from
(
      (
            select spot_rating.*,ch_master.channel_group_name as channel_name,ch_master.genre,ch_master.sub_genre ,ch_master.language,ch_master.type_of_beam ,ch_master.subscription,ch_master.network ,ch_master.channel_primary_tg ,ch_master.channel_secondary_tg ,ch_master.genre_tg ,advt_master.*
            from
             (SELECT row_num ,target ,region as BARC_region,sector ,category ,brand,advertiser as advertiser_name,advertiser_group as BARC_advertiser_group,master_programme ,position ,level ,event_type ,promo_type ,promo_category ,promo_sponsor_name ,promo_programme_name ,pib,tib,pp_start_time ,cp_start_time,channel  ,start_time_av_tm ,end_time_av_tm ,break_code ,date,week ,time_band programme_genre ,programme_theme ,duration,ratings ,impressions ,target_av ,year,timeband_start_time ,timeband_end_time ,barc_year  , concat(target," ",region) as tg_market, channel as BARC_channel_name
, cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_start_time, ':', '') as string),1,4) as INT64) as BARC_start_time,
cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_end_time, ':', '') as string),1,5) as INT64) as BARC_end_time,
'BARC' as BARC_source_name,EXTRACT(Month FROM date) AS month,
lower(FORMAT_DATE('%a', date)) as day,
       (CASE WHEN lower(FORMAT_DATE('%a', date)) = 'mon' THEN 1
      WHEN lower(FORMAT_DATE('%a', date)) = 'tue' THEN 2
      WHEN lower(FORMAT_DATE('%a', date)) = 'wed' THEN 3
      WHEN lower(FORMAT_DATE('%a', date)) = 'thu' THEN 4
      WHEN lower(FORMAT_DATE('%a', date)) = 'fri' THEN 5
      WHEN lower(FORMAT_DATE('%a', date)) = 'sat' THEN 6
      WHEN lower(FORMAT_DATE('%a', date)) = 'sun' THEN 7
      else 0 end) as day_num
FROM {{source('viewership','reg_spot_ratings_channel_tg')}}
WHERE level in ('Level 4')) as spot_rating
inner join
(SELECT distinct channel_name ,source_name ,channel_group_name ,genre ,sub_genre ,language, type_of_beam ,subscription ,network,channel_primary_tg ,channel_secondary_tg ,genre_tg   FROM {{source('master','reg_channel')}}
where source_name in ('BARC')) as ch_master
      on spot_rating.BARC_channel_name=ch_master.channel_name
left JOIN
(
      SELECT distinct advertiser_name as advertiser,region, advertiser_group_name as advertiser_group, advertiser_category
      FROM `mint-bi-reporting`.`master`.`reg_advertiser`
where lower(source) in ('barc') and region is NOT NULL) AS advt_master
      ON spot_rating.advertiser_name = advt_master.advertiser
)
)as reg_spot_rating
left join
(SELECT distinct null as year,null as month,advertiser as advertiser_group,agency_group  as agency ,""  as sub_agency  FROM  `mint-bi-reporting`.`master`.`reg_datalake_agency_mappings`) as monthly_agency
      on lower(reg_spot_rating.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and reg_spot_rating.month = monthly_agency.month
-- and reg_spot_rating.year = monthly_agency.year
) as reg_spot_rating
Left join
(SELECT * FROM `mint-bi-reporting`.`master`.`reg_barc_impact_taggings`)  as barc_impact
on reg_spot_rating.BARC_channel_name = barc_impact.channel
and reg_spot_rating.date = barc_impact.date
and reg_spot_rating.master_programme = barc_impact.description
and reg_spot_rating.cp_start_time = barc_impact.start_time) as reg_spot_rating
left join
(SELECT distinct  channel_group_name,network ,part_of_day,hour_type  ,from_day ,to_day ,start_time ,end_time , genre,sub_genre,language,
(CASE WHEN from_day = 'mon' THEN 1
      WHEN from_day = 'tue' THEN 2
      WHEN from_day = 'wed' THEN 3
      WHEN from_day = 'thu' THEN 4
      WHEN from_day = 'fri' THEN 5
      WHEN from_day = 'sat' THEN 6
      WHEN from_day = 'sun' THEN 7
      else 0 end) as from_day_num,
(CASE WHEN to_day = 'mon' THEN 1
      WHEN to_day = 'tue' THEN 2
      WHEN to_day = 'wed' THEN 3
      WHEN to_day = 'thu' THEN 4
      WHEN to_day = 'fri' THEN 5
      WHEN to_day = 'sat' THEN 6
      WHEN to_day = 'sun' THEN 7
      else 0 end) as to_day_num
FROM {{source('master','reg_channel')}}
where
source_name in ('BARC') and lower(network) in ('star network') and (hour_type in ('daypart') or hour_type is null ) ) as ch_master
on
reg_spot_rating.genre = ch_master.genre
and reg_spot_rating.sub_genre = ch_master.sub_genre
and reg_spot_rating.language = ch_master.language
and reg_spot_rating.day_num >= ch_master.from_day_num
and reg_spot_rating.day_num <= ch_master.to_day_num
and reg_spot_rating.BARC_start_time >= ch_master.start_time
and reg_spot_rating.BARC_start_time < ch_master.end_time
  ) as reg_spot_rating
left join
(SELECT distinct genre ,sub_genre ,language,target ,region ,reporting_tg FROM {{source('master','reg_reporting_tg_market')}}) as tg_market
on concat(reg_spot_rating.genre,reg_spot_rating.sub_genre,reg_spot_rating.language,reg_spot_rating.target,reg_spot_rating.BARC_region)
= concat(tg_market.genre,tg_market.sub_genre,tg_market.language,tg_market.target,tg_market.region)