{{ config(schema='rev_vwrshp_reports') }}


select ro_spot_rating.*,monthly_agency.agency ,monthly_agency.sub_agency 
from
(
select ro.channel_name, ro.airing_date,ro.month,ro.year,spot_rating.date as viewership_date, ro.advertiser_group, ro.region, ro.product_name, ro.product_start_time, ro.product_end_time,
ro.revenue AS revenue,
   (ro.channel_npt_revenue) AS channel_daypart_npt_revenue,
   (ro.channel_pt_revenue) AS channel_daypart_pt_revenue,
   (ro.channel_wd_revenue) AS channel_weekpart_wd_revenue,
   (ro.channel_we_revenue) AS channel_weekpart_we_revenue,
   (ro.fct) AS fct,
   (ro.channel_npt_fct) AS channel_daypart_npt_fct,
   (ro.channel_pt_fct) AS channel_daypart_pt_fct,
   (ro.channel_wd_fct) AS channel_weekpart_wd_fct,
   (ro.channel_we_fct) AS channel_weekpart_we_fct,
  avg (spot_rating.rating) AS rating
from
        (SELECT channel_name
    , Date_sub(airing_date  , Interval 2 month) as lag_date
    , airing_date, advertiser_group, region, product_name, product_start_time, product_end_time, channel_primary_tgmarket,
     sum(fct) as fct, sum(revenue) as revenue,
     sum (channel_npt_revenue) as channel_npt_revenue ,
sum (channel_pt_revenue) as channel_pt_revenue ,
sum (channel_wd_revenue) as channel_wd_revenue ,
sum (channel_we_revenue) as channel_we_revenue,
--sum (channel_cpt_revenue) as channel_cpt_revenue,
--sum (channel_afternoon_revenue) as channel_afternoon_revenue,
sum (channel_npt_fct) as channel_npt_fct ,
sum (channel_pt_fct) as channel_pt_fct ,
sum (channel_wd_fct) as channel_wd_fct ,
sum (channel_we_fct) as channel_we_fct,
--sum (channel_cpt_fct) as channel_cpt_fct,
--sum (channel_afternoon_fct) as channel_afternoon_fct
EXTRACT(Month FROM airing_date) AS month,EXTRACT(YEAR FROM airing_date) AS year
    FROM {{source('revenue','ro')}}
    where lower(impact_regular) = 'regular'
    group by channel_name, airing_date, advertiser_group, region, product_name, product_start_time, product_end_time, channel_primary_tgmarket,month,year) as ro
    left join
      (select * from
        (select channel, concat(target," ",region) as tg_market, date,
      cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_start_time, ':', '') as string),1,4) as INT64) as start_time,
      cast(SUBSTR(CAST(REGEXP_REPLACE(timeband_end_time, ':', '') as string),1,5) as INT64) as end_time,
      round(sum (ratings * duration)/sum (duration),6) as rating
      from {{source('viewership','ent_spot_ratings_channel_tg')}}
      group by channel, tg_market, date, start_time, end_time) as spot_rating
      inner join
      (SELECT distinct channel_name ,channel_group_name ,channel_primary_tg FROM {{source('master','ent_channel_master')}} where source_name in ('BARC')) as ch_master
  ON spot_rating.channel = ch_master.channel_name
      )as spot_rating
    on lower(ro.channel_name) = lower(spot_rating.channel_group_name)
    and spot_rating.date = ro.lag_date
    and ro.product_start_time <= spot_rating.start_time
    and ro.product_end_time >= spot_rating.end_time
    and lower(ro.channel_primary_tgmarket) = lower(spot_rating.tg_market)
group by  ro.channel_name, ro.airing_date,ro.month,ro.year,spot_rating.date, ro.advertiser_group, ro.region, ro.product_name, ro.product_start_time, ro.product_end_time, ro.fct, ro.revenue, ro.channel_npt_fct, ro.channel_npt_revenue, ro.channel_pt_fct, ro.channel_pt_revenue, ro.channel_wd_fct, ro.channel_wd_revenue, ro.channel_we_fct, ro.channel_we_revenue
  ) as ro_spot_rating
left join 
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}} ) as monthly_agency
on lower(ro_spot_rating.advertiser_group) = lower(monthly_agency.advertiser_group) 
-- and ro_spot_rating.month = monthly_agency.month
-- and ro_spot_rating.year = monthly_agency.year
