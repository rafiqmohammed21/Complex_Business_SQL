{{ config(schema='rev_vwrshp_reports') }}

SELECT CASE WHEN incentive_actual.customer_nbr is null then dia.customer_nbr
            ELSE incentive_actual.customer_nbr END AS customer_nbr
       ,CASE WHEN incentive_actual.par_month is null then dia.month
            ELSE incentive_actual.par_month END AS par_month
       ,CASE WHEN incentive_actual.par_year is null then dia.year
            ELSE incentive_actual.par_year END AS par_year
       ,CASE WHEN incentive_actual.revenue_category is null then 'Incentive Accrued'
            ELSE incentive_actual.revenue_category END AS revenue_category
       ,CASE WHEN incentive_actual.customer_nbr is null then dia.incentive_amount
            ELSE incentive_actual.total_incentive END AS total_incentive
       ,coalesce(dia.snap_shot_date,incentive_actual.snap_shot_date) as snap_shot_date
FROM

(SELECT  CAST(par_month AS INT64) AS par_month
        ,CAST(par_year AS INT64) AS par_year
        ,customer_nbr, 'Incentive Actualized' as revenue_category
        ,incentive_amount as total_incentive
        ,snap_shot_date
FROM {{source('test','dist_incentive_snap')}}) AS incentive_actual
--Testing dev deployment
FULL OUTER JOIN
(SELECT * FROM

(SELECT * FROM {{source('revenue','dist_incentive_accrued')}})
CROSS JOIN
(SELECT distinct(snap_shot_date) from {{source('test','dist_incentive_snap')}})) dia
ON incentive_actual.customer_nbr = dia.customer_nbr
   AND incentive_actual.par_month = dia.month
   AND incentive_actual.par_year = dia.year
   AND incentive_actual.snap_shot_date = dia.snap_shot_date

