{{ config(schema='rev_vwrshp_reports') }}


(

SELECT * FROM {{ref('ent_fact_spot_ratings_common')}}
UNION ALL
SELECT * FROM {{ref('reg_fact_spot_ratings_common')}}
)