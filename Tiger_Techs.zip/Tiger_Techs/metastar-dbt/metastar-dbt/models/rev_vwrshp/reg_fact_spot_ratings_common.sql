{{ config(schema='rev_vwrshp_reports') }}


(
SELECT channel_grp_cte.channel_name, channel_grp_cte.channel_def_name, channel_grp_cte.advertiser_group, channel_grp_cte.date, channel_grp_cte.region, channel_grp_cte.pt_npt, channel_grp_cte.impact_regular, channel_grp_cte.agency, channel_grp_cte.sub_agency, channel_grp_cte.advertiser_category ,channel_grp_cte.genre, channel_grp_cte.sub_genre
             ,ROUND(channel_grp_cte.ad_grp/agency_count.agency_count/agency_count.region_count,2) as ad_grp,
             ROUND(genre_grp_cte.ad_grp/agency_count.agency_count/agency_count.region_count,2) as genre_grp, ROUND(SAFE_DIVIDE(channel_grp_cte.ad_grp,genre_grp_cte.ad_grp),2) as market_share
FROM
    (
      SELECT channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, advertiser_category, genre, sub_genre
             ,(sum(ratings*duration))/10 as ad_grp
      FROM {{ref('reg_spot_ratings_common')}}
      WHERE reporting_tg is true
      GROUP BY channel_name, channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, advertiser_category, genre, sub_genre
    ) as channel_grp_cte
    FULL OUTER JOIN
    (
        SELECT channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency, advertiser_category, genre, sub_genre --duration,ratings
                ,sum(duration) as duration
                ,sum(ratings*duration)/(sum(duration)) as ratings
                ,(sum(ratings*duration)/(sum(duration))*sum(duration))/10 as ad_grp
        FROM {{ref('reg_spot_ratings_common')}}
        WHERE reporting_tg is true
        GROUP BY channel_def_name, advertiser_group, date, region, pt_npt, impact_regular, agency, sub_agency,advertiser_category, genre, sub_genre
    ) as genre_grp_cte
    ON channel_grp_cte.genre = genre_grp_cte.genre
    AND channel_grp_cte.sub_genre = genre_grp_cte.sub_genre
    AND channel_grp_cte.advertiser_group = genre_grp_cte.advertiser_group
    AND channel_grp_cte.region = genre_grp_cte.region
    AND channel_grp_cte.pt_npt = genre_grp_cte.pt_npt
    AND channel_grp_cte.impact_regular = genre_grp_cte.impact_regular
    AND channel_grp_cte.agency = genre_grp_cte.agency
    AND channel_grp_cte.sub_agency = genre_grp_cte.sub_agency
    AND channel_grp_cte.advertiser_category  = genre_grp_cte.advertiser_category
    AND channel_grp_cte.channel_def_name = genre_grp_cte.channel_def_name
    AND channel_grp_cte.date = genre_grp_cte.date
    LEFT JOIN
    (
        SELECT  advertiser_group, date, pt_npt, impact_regular, genre, sub_genre, case when count(distinct agency )!=0 then count(distinct agency ) else 1 end as agency_count, count(distinct (region)) as region_count
        FROM {{ref('reg_spot_ratings_common')}}
        WHERE reporting_tg is true
        GROUP BY advertiser_group, date, region, pt_npt, impact_regular,  genre, sub_genre
    ) as agency_count
    ON channel_grp_cte.genre = agency_count.genre
    AND channel_grp_cte.sub_genre = agency_count.sub_genre
    AND channel_grp_cte.advertiser_group = agency_count.advertiser_group
    AND channel_grp_cte.pt_npt = agency_count.pt_npt
    AND channel_grp_cte.impact_regular = agency_count.impact_regular
    AND channel_grp_cte.date = agency_count.date
GROUP BY channel_grp_cte.channel_name, channel_grp_cte.channel_def_name, channel_grp_cte.advertiser_group, channel_grp_cte.date, channel_grp_cte.region, channel_grp_cte.pt_npt, channel_grp_cte.impact_regular, channel_grp_cte.agency, channel_grp_cte.sub_agency, channel_grp_cte.advertiser_category ,channel_grp_cte.genre, channel_grp_cte.sub_genre, channel_grp_cte.ad_grp, agency_count.agency_count, agency_count.region_count, genre_grp_cte.ad_grp
  )