{{ config(schema='rev_vwrshp_reports') }}
(
  select spot_rating_lag.*,disney_week,disney_month,disney_f_year, disney_quarter
  from
  (
    select spot_rating_lag.*,monthly_agency.agency ,monthly_agency.sub_agency  from
(
(
(
(SELECT
spr_revenue.spr_channel_name ,
spr_revenue.channel_name,
spr_revenue.genre ,
spr_revenue.sub_genre,
spr_revenue.type_of_beam,
spr_revenue.subscription ,
spr_revenue.network ,
spr_revenue.channel_primary_tg,
 spr_revenue.date,
 spot_rating.date as viewership_date,
 spr_revenue.advertiser_name ,
 spr_revenue.advertiser_id_master,
 spr_revenue.advertiser_group,
 spr_revenue.spot_status as spot_status,
 spr_revenue.region,
  spr_revenue.product_name,
 spr_revenue.start_time,
 spr_revenue.end_time,
 spr_revenue.impact_regular,
 spr_revenue.part_of_day,
 (spr_revenue.revenue) AS revenue,
 (spr_revenue.fct) AS fct,
avg (spot_rating.rating) AS rating
FROM
(SELECT
spr.spr_channel_name as spr_channel_name,
ch_master.channel_group_name as channel_name,
ch_master.genre as genre,
ch_master.sub_genre as sub_genre,
ch_master.type_of_beam as type_of_beam,
ch_master.subscription as subscription,
ch_master.network as network,
ch_master.channel_primary_tg as channel_primary_tg,
 spr.lag_date AS lag_date,
 spr.telecast_date AS date,
 spr.time_band AS time_band,
 CAST(SUBSTR(time_band,
1,
4) AS INT64) AS start_time,
 CAST(SUBSTR(time_band,
6,
4) AS INT64) AS end_time,
 spr.advertiser_name_master AS advertiser_name,
 spr.advertiser_id_master as advertiser_id_master,
 spr.spot_status as spot_status,
 adv_master.advertiser_group_name AS advertiser_group,
 adv_master.region AS region,
 spr.sales_unit_pool_name AS product_name,
 --sales_unit.channel_daypart_npt AS channel_daypart_npt,
 --sales_unit.channel_daypart_pt AS channel_daypart_pt,
 --sales_unit.channel_weekpart_wd AS channel_weekpart_wd,
 --sales_unit.channel_weekpart_we AS channel_weekpart_we,
   case when sales_unit.tag is NULL then 'regular'
  else sales_unit.tag  end AS impact_regular,
 spr.part_of_day ,
 spr.fct AS fct,
 spr.revenue AS revenue
FROM
    (
select onair_spr.spr_channel_name,network,DATE_SUB(telecast_date,INTERVAL 2 month) AS lag_date,telecast_date,day,advertiser_name_master,advertiser_id_master,spot_status,sales_unit_pool_name,time_band,hour_type,part_of_day,revenue,fct
from
(SELECT channel_name as spr_channel_name, telecast_date,
lower(FORMAT_DATE('%a', telecast_date)) as day,
(CASE WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'mon' THEN 1
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'tue' THEN 2
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'wed' THEN 3
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'thu' THEN 4
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'fri' THEN 5
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'sat' THEN 6
      WHEN lower(FORMAT_DATE('%a', telecast_date)) = 'sun' THEN 7
      else 0 end) as day_num,
advertiser_name_master,advertiser_id_master, spot_status, sales_unit_pool_name, time_band, cast(split(time_band,'-')[OFFSET(0)] as int64)  as ST_hr,cast(split(time_band,'-')[OFFSET(1)] as int64) as ET_hr ,
sum(pitched_price/conversion_rate) AS revenue, sum(duration)/1000 AS fct
    FROM {{source('revenue','spr')}}
--     where lower(channel_name) in ('star plus')
-- and telecast_date = '2020-01-14'
GROUP BY channel_name, telecast_date, advertiser_name_master, advertiser_id_master,spot_status, sales_unit_pool_name, time_band) as onair_spr
left join
(SELECT *,
(CASE WHEN from_day = 'mon' THEN 1
      WHEN from_day = 'tue' THEN 2
      WHEN from_day = 'wed' THEN 3
      WHEN from_day = 'thu' THEN 4
      WHEN from_day = 'fri' THEN 5
      WHEN from_day = 'sat' THEN 6
      WHEN from_day = 'sun' THEN 7
      else 0 end) as from_day_num,
(CASE WHEN to_day = 'mon' THEN 1
      WHEN to_day = 'tue' THEN 2
      WHEN to_day = 'wed' THEN 3
      WHEN to_day = 'thu' THEN 4
      WHEN to_day = 'fri' THEN 5
      WHEN to_day = 'sat' THEN 6
      WHEN to_day = 'sun' THEN 7
      else 0 end) as to_day_num
FROM {{source('master','ent_channel_master')}}
where
source_name in ('ONAIR','ONAIR_ADSHARP') and hour_type in ('daypart')) as ch_master
  on onair_spr.spr_channel_name = ch_master.channel_name
and onair_spr.day_num >= ch_master.from_day_num
and onair_spr.day_num <= ch_master.to_day_num
and onair_spr.ST_hr >= ch_master.start_time
and onair_spr.ST_hr < ch_master.end_time
) AS spr
LEFT JOIN
(SELECT DISTINCT advertiser_name AS advertiser_name,
                 region,
                 advertiser_group_name,onair_id
 FROM {{source('master','ent_advertiser_master')}}
GROUP BY  1, 2, 3,4) AS adv_master
  ON spr.advertiser_id_master = adv_master.onair_id
LEFT JOIN
(SELECT distinct sales_unit  as on_air_sales_unit,tag  FROM {{source('master','onair_sales_unit_taggings')}}) AS sales_unit
  ON spr.sales_unit_pool_name = sales_unit.on_air_sales_unit
inner JOIN
(SELECT distinct channel_name ,channel_group_name ,channel_primary_tg,genre,sub_genre,type_of_beam,subscription,network FROM {{source('master','ent_channel_master')}} where source_name in ('ONAIR','ONAIR_ADSHARP')) as ch_master
  ON spr.spr_channel_name = ch_master.channel_name) AS spr_revenue
LEFT JOIN
(
  select * from
  (SELECT channel,
         CONCAT(target,
        " ",
        region) AS tg_market,
         date,
         CAST(SUBSTR(CAST(REGEXP_REPLACE(timeband_start_time,
         ':', '') AS string),1,4) AS INT64) AS start_time, CAST(SUBSTR(CAST(REGEXP_REPLACE(timeband_end_time, ':', '') AS string),1,5) AS INT64) AS end_time, ROUND(sum (ratings * duration)/sum (duration),6) AS rating
                        FROM {{source('viewership','ent_spot_ratings_channel_tg')}}
WHERE  LOWER(level) IN ('level 4')
GROUP BY  channel, tg_market, date, start_time, end_time) as ent_spot_rating
inner Join
(SELECT distinct channel_name ,channel_group_name ,channel_primary_tg FROM {{source('master','ent_channel_master')}} where source_name in ('BARC')) as ch_master
  ON ent_spot_rating.channel = ch_master.channel_name
) AS spot_rating
  ON LOWER(spr_revenue.channel_name) = LOWER(spot_rating.channel_group_name)
AND spot_rating.date = spr_revenue.lag_date
AND spr_revenue.start_time <= spot_rating.start_time
AND spr_revenue.end_time >= spot_rating.end_time --
AND lower(spr_revenue.channel_primary_tg) = lower(spot_rating.tg_market)
WHERE  lower(spr_revenue.impact_regular) = 'regular'
GROUP BY spr_revenue.channel_name,spr_revenue.channel_primary_tg ,spr_revenue.date,spot_rating.date, spr_revenue.advertiser_group, spr_revenue.region, spr_revenue.product_name, spr_revenue.start_time, spr_revenue.end_time, spr_revenue.impact_regular, spr_revenue.revenue,  spr_revenue.fct,spr_revenue.part_of_day ,spr_revenue.advertiser_name,spr_revenue.spr_channel_name,spr_revenue.genre,spr_revenue.sub_genre,spr_revenue.type_of_beam ,spr_revenue.subscription ,spr_revenue.network ,spr_revenue.advertiser_id_master ,spr_revenue.spot_status)
)
)
)as spot_rating_lag
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}} ) as monthly_agency
  on lower(spot_rating_lag.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and spot_rating_lag.month = monthly_agency.month
-- and spot_rating_lag.year = monthly_agency.year
)as spot_rating_lag
inner Join
(SELECT year as disney_yar,month as disney_month, week as disney_week,start_date,end_date, fin_year as disney_f_year,quarter as disney_quarter FROM {{source('master','disney_fy_cal')}} ) as disney_calendar
  on spot_rating_lag.date >= disney_calendar.start_date
and spot_rating_lag.date <= disney_calendar.end_date
)