{{ config(schema='rev_vwrshp_reports') }}


(
with cte_calendar as (
SELECT year, month, week, date, fin_year, quarter from {{source('master','disney_fy_cal')}} a
join ( select date
FROM UNNEST(
    GENERATE_DATE_ARRAY((select min(start_date) from {{source('master','disney_fy_cal')}}), (select max(end_date) from {{source('master','disney_fy_cal')}}), INTERVAL 1 DAY)
) AS date) as cte_day
on cte_day.date >= a.start_date and cte_day.date <= a.end_date
order by year, month, week, date )
,
number_of_days_per_month_cte as (
  SELECT
    year, month, (DATE_DIFF(max(end_date), min(start_Date), day)) + 1  as number_of_days
  from
    {{source('master','disney_fy_cal')}}
  GROUP BY year, month
)
,
cte_ro as (
  SELECT channel_name, airing_date as date,
    region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(channel_npt_revenue) as revenue, "npt" as pt_npt
  FROM {{ref('ro_spd')}}
  GROUP BY
    channel_name,date,region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular, pt_npt
  UNION ALL
  SELECT channel_name, airing_date as date,
    region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(channel_pt_revenue) as revenue, "pt" as pt_npt
  FROM {{ref('ro_spd')}}
  GROUP BY
    channel_name,date,region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular ,pt_npt
  UNION ALL
  SELECT channel_name, airing_date as date,
    region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(revenue)-ifnull(sum(channel_pt_revenue+channel_npt_revenue),0) as revenue, 'dead_hours' as pt_npt
  FROM {{ref('ro_spd')}}
  GROUP BY
    channel_name,date,region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular ,pt_npt
)
,
cte_spr as ( SELECT channel_name, date,
  region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(revenue) as revenue,sum(fct) as fct, part_of_day as pt_npt
  FROM {{ref('ent_spr_advertiser_common')}}
  WHERE
      lower(spot_status) in ('aired', 'placed')
    AND
      date <= CURRENT_DATE()
  GROUP BY
    channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular , pt_npt
)
,
cte_spr_booked as ( SELECT channel_name, date,
  region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(revenue) as booked_revenue,sum(fct) as booked_fct, part_of_day as pt_npt
  FROM {{ref('ent_spr_advertiser_common')}}
  WHERE
      date > CURRENT_DATE()
  GROUP BY
    channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular , pt_npt
)
,
cte_deals as (
  SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(channel_pt_revenue)/ max(number_of_days_per_month_cte.number_of_days) as revenue, "pt" as pt_npt
    FROM {{ref('deal_spd')}} a
    JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular , pt_npt
  UNION ALL
  SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(channel_npt_revenue)/ max(number_of_days_per_month_cte.number_of_days) as revenue, "npt" as pt_npt
    FROM {{ref('deal_spd')}} a
    JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular , pt_npt
  UNION ALL
  SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, (sum(monthly_outlay)-ifnull(sum(channel_pt_revenue+channel_npt_revenue),0))/ max(number_of_days_per_month_cte.number_of_days) as revenue, "dead_hours" as pt_npt
    FROM {{ref('deal_spd')}} a
    JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular , pt_npt
)
,
cte_funnel as (
 SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(projection_inr)/ (2*max(number_of_days_per_month_cte.number_of_days)) as revenue, "pt" as pt_npt
  FROM {{ref('funnel_spd')}} a
  JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY advertiser_group,channel_name, date, agency, sub_agency,advertiser_category, region, impact_regular, pt_npt
  UNION ALL
  SELECT channel_name, b.date as date, region, impact_regular, advertiser_group, agency, sub_agency,advertiser_category, sum(projection_inr)/ (2*max(number_of_days_per_month_cte.number_of_days)) as revenue, "npt" as pt_npt
  FROM {{ref('funnel_spd')}} a
  JOIN number_of_days_per_month_cte
    using (month, year)
    JOIN cte_calendar b
    using (month, year)
  GROUP BY advertiser_group,channel_name, date, agency, sub_agency,advertiser_category, region, impact_regular, pt_npt
)
,
final_cte as (
  SELECT coalesce(cte_ro.advertiser_group, cte_spr.advertiser_group, cte_spr_booked.advertiser_group,cte_deals.advertiser_group, cte_funnel.advertiser_group) as advertiser_group,
      coalesce(cte_ro.date , cte_spr.date, cte_spr_booked.date, cte_deals.date,cte_funnel.date) as date,
      coalesce(cte_ro.channel_name , cte_spr.channel_name, cte_spr_booked.channel_name, cte_deals.channel_name, cte_funnel.channel_name) as channel_name,
      coalesce(cte_ro.region, cte_spr.region, cte_spr_booked.region, cte_deals.region, cte_funnel.region ) as region,
      coalesce(cte_ro.impact_regular, cte_spr.impact_regular,cte_spr_booked.impact_regular, cte_deals.impact_regular, cte_funnel.impact_regular  ) as impact_regular,
      coalesce(cte_ro.pt_npt , cte_spr.pt_npt,cte_spr_booked.pt_npt, cte_deals.pt_npt, cte_funnel.pt_npt ) as pt_npt,
      coalesce(cte_ro.agency, cte_spr.agency , cte_spr_booked.agency, cte_deals.agency, cte_funnel.agency) as agency ,
      coalesce(cte_ro.sub_agency, cte_spr.sub_agency, cte_spr_booked.sub_agency, cte_deals.sub_agency, cte_funnel.sub_agency ) as sub_agency,
      coalesce(cte_ro.advertiser_category , cte_spr.advertiser_category, cte_spr_booked.advertiser_category, cte_deals.advertiser_category, cte_funnel.advertiser_category ) as advertiser_category,
  cte_ro.revenue as ro_revenue,
  cte_spr.revenue as actual_revenue,
  cte_spr.fct as actual_fct,
  cte_spr_booked.booked_revenue as booked_revenue,
  cte_spr_booked.booked_fct as booked_fct,
  cte_deals.revenue as deals_revenue,
  cte_funnel.revenue as projection_revenue,
  FROM
  cte_ro
  FULL JOIN
  cte_spr
  using(channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular, pt_npt)
  FULL JOIN
  cte_spr_booked
  using(channel_name,date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular, pt_npt)
  FULL JOIN
  cte_deals
  using(channel_name, date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular, pt_npt)
  FULL JOIN
  cte_funnel
  using(channel_name, date, region, advertiser_group, agency, sub_agency,advertiser_category, impact_regular, pt_npt)
)
select advertiser_group, channel_name, date, agency,sub_agency,advertiser_category, region, impact_regular, pt_npt, sum(ro_revenue) as ro_revenue, sum(actual_revenue) as actual_revenue, sum(actual_fct) as actual_fct, sum(booked_revenue) as booked_revenue, sum(booked_fct) as booked_fct,(ifnull(sum(actual_revenue),0)+ifnull(sum(booked_revenue),0)) as total_revenue, (ifnull(sum(actual_fct),0)+ifnull(sum(booked_fct),0)) as total_fct ,sum(deals_revenue) as deals_revenue, sum(projection_revenue) as projection_revenue from final_cte
group by advertiser_group,channel_name, date,agency,sub_agency,advertiser_category, region, impact_regular, pt_npt
  )