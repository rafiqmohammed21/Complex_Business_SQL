  {{ config(schema='rev_vwrshp_reports') }}
  SELECT funnel.*,monthly_agency.agency ,monthly_agency.sub_agency,adv_master.advertiser_category  from
  (SELECT funnel_id, channel_name, month as date, created_at, year_month, updated_at, advertiser_group, missed_client, campaign_budget, share_in_campaign, creator_name, region, impact_regular, projection_inr,EXTRACT(Month FROM month) AS month,EXTRACT(YEAR FROM month) AS year
   FROM {{source('revenue','ent_funnel')}} ) as funnel
  left join
  (SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM {{source('master','month_wise_agency_mappings')}} ) as monthly_agency
  on lower(funnel.advertiser_group) = lower(monthly_agency.advertiser_group) 
--   and funnel.month = monthly_agency.month
--   and funnel.year = monthly_agency.year
left join
  (Select distinct advertiser_category, advertiser_group_name as advertiser_group from {{source('master','ent_advertiser_master')}}) as adv_master
  on lower(funnel.advertiser_group) = lower(adv_master.advertiser_group)