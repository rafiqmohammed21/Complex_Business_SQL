{{ config(schema='rev_vwrshp_reports') }}

(


select reg_target.*,ch_master.channel_name from
(SELECT year ,month ,pt_npt ,channel_name as channel ,regular_impact ,value  FROM {{source(env_var('DBT_TARGET'),'reg_ad_revenue_target_cprp')}}  ) as reg_target
left join
(SELECT distinct channel_name as Channel ,source_name ,channel_group_name as channel_name ,genre ,sub_genre  FROM {{source('master','reg_channel')}}
where source_name in ('ONAIR')) as ch_master
on lower(reg_target.channel) = lower(ch_master.Channel)

union all


select ent_target.*,ch_master.channel_name from
(SELECT year ,month ,pt_npt ,channel_name as channel ,regular_impact ,value  FROM {{source(env_var('DBT_TARGET'),'ent_ad_revenue_target_cprp')}}) as ent_target
left join
(SELECT distinct channel_name as Channel ,source_name ,channel_group_name as channel_name ,genre ,sub_genre  FROM {{source('master','ent_channel_master')}}
where source_name in ('ONAIR')) as ch_master
on lower(ent_target.channel) = lower(ch_master.Channel)


)