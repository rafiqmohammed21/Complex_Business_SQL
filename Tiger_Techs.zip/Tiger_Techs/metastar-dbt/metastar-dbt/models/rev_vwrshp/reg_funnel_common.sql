{{ config(schema='rev_vwrshp_reports') }}


(

  SELECT funnel.*,monthly_agency.agency ,monthly_agency.sub_agency,adv_master.advertiser_category  from
  (SELECT funnel_id, channel_name, month as date, created_at, year_month, updated_at, advertiser_group, missed_client, campaign_budget, share_in_campaign, creator_name, region, impact_regular, projection_inr,EXTRACT(Month FROM month) AS month,EXTRACT(YEAR FROM month) AS year
   FROM {{source('revenue','reg_funnel')}} ) as funnel
  left join
  (SELECT distinct null as year, null as month, advertiser as advertiser_group,agency_group  as agency ,""  as sub_agency  FROM `mint-bi-reporting`.`master`.`reg_datalake_agency_mappings`) as monthly_agency
  on lower(funnel.advertiser_group) = lower(monthly_agency.advertiser_group)
left join
  (Select distinct advertiser_category, advertiser_group_name as advertiser_group from `mint-bi-reporting`.`master`.`reg_advertiser`) as adv_master
  on lower(funnel.advertiser_group) = lower(adv_master.advertiser_group)
  )