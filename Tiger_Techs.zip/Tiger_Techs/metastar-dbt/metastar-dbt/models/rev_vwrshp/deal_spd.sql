{{ config(schema='rev_vwrshp_reports') }}


(

(
select deal.*,monthly_agency.agency ,monthly_agency.sub_agency,adv_master.advertiser_category  from
(SELECT * FROM `mint-bi-reporting`.`revenue`.`deal`) as deal
left join
(SELECT distinct year,month,advertiser as advertiser_group,agency_group  as agency ,agency_subgroup  as sub_agency  FROM `mint-bi-reporting`.`master`.`month_wise_agency_mappings`) as monthly_agency
on lower(deal.advertiser_group) = lower(monthly_agency.advertiser_group)
-- and deal.month = monthly_agency.month
-- and deal.year = monthly_agency.year
left join
  (Select distinct advertiser_category, advertiser_group_name as advertiser_group from `mint-bi-reporting`.`master`.`ent_advertiser_master`) as adv_master
  on lower(deal.advertiser_group) = lower(adv_master.advertiser_group)
  )
  )