{{ config(schema='rev_vwrshp_reports') }}


select common.* ,cal.year as d_year, cal.month as d_month, cal.fin_year as d_fin_year from (
select * from {{ref('reg_fact_revenue_common')}}
union all
select * from {{ref('ent_fact_revenue_common')}}
) common
join
master.disney_fy_cal as cal
on common.date >= cal.start_date and common.date <= cal.end_date