#!/usr/bin/env bash

rm -f changes
if [[ $(git diff --name-only --cached models/) ]]
then
  IFS=$'\n'       # make newlines the only separator
  set -f          # disable globbing
  (git diff --name-only --cached models/)>>change
  for i in $(cat < "change"); do
     basename  "$i" .sql >> changes
  done

else
  touch changes
fi
rm -f change
git add changes
git commit -m "$1"