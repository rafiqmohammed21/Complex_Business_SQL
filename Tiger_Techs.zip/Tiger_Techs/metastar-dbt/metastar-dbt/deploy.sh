#!/usr/bin/env bash
pip freeze > requirements.txt
docker build -t asia.gcr.io/mint-bi-reporting/dev/dbt .
docker push asia.gcr.io/mint-bi-reporting/dev/dbt

# to use profile in any other directory
export DBT_PROFILES_DIR=~/Desktop/m-b-r/metastar-dbt

# to run locally
docker run -it -e MODE="SERVE" -p 8080:8080 asia.gcr.io/mint-bi-reporting/dev/dbt