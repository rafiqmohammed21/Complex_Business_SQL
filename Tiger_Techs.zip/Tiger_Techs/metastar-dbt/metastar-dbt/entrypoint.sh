#!/usr/bin/env bash

#sleep 50m
export DBT_PROFILES_DIR=/app/.dbt
export DBT_TARGET="$1"
echo $1
echo $0
if [[ "$MODE" == SERVE ]]
then
  echo "========Serving docs========"
  dbt docs generate
  dbt docs serve
elif [[ "$1" == INGEST ]]
then
  echo "========Running models from AIRFLOW========"
    date=$3
    nmod=${#5}
    d1=$(date  -d "$3" +%s)
    d2=$(date  -d "$4" +%s)
    days=(d2-d1)/86400
    for ((i=0;i<=days;i++));
    do
       echo "running for "+$date
       for modl in $5;
       do
           echo "Runnning model "+$modl
           dbt run --models $modl --vars 'dates: '+$date
       done
#       dbt run --models $2 --vars 'dates: '+$date
#      Below command runs on MAC
#      date=$(date -j -v +1d -f "%Y%m%d" "$date" +%Y%m%d)
       date=`date '+%C%y%m%d' -d "$date+1 days"`
    done
else
  if [[ -s changes ]]
  then
    echo "========Running models from Cloud Build========"
    dbt run -m $(<changes)
  fi
fi
