### dbt models for Metastar-DBT

---
- [What is dbt](https://dbt.readme.io/docs/overview)?
- Read the [dbt viewpoint](https://dbt.readme.io/docs/viewpoint)
- [Installation](https://dbt.readme.io/docs/installation)
- Join the [chat](http://ac-slackin.herokuapp.com/) on Slack for live questions and support.

---

###Project Setup

Run the following commands on the terminal:
1) `pip install -r requirements.txt`
2) `export DBT_PROFILES_DIR=~/path-to-project-dir/metastar-dbt`
3) `export DBT_TARGET="dev"`

Keep the m-b-r-key.json file in root of your project directory and include it in .gitignore

###Usage

DEV
- Use `dbt compile` to check SQL generated for the models, to check generated SQL for specific model
use `dbt compile -m model-name`
- To run your models and create/update views/tables use: `dbt run -m model-name`
- To generate model documentation use `dbt docs generate`
- To serve documentation on you local machine use: `dbt docs serve`

PROD

1) Add changed models to git: `git add model-name`
2) Commit the changes using `sh commit.sh "commit message"`
3) Push the changes to `git push origin master`

If a new table is created, add it to models/raw/schema.yml under respective dataset

Checking for changes:

The model documentation is available here: [DBT DOCS](https://devgcpdl.startv.com/dbt)